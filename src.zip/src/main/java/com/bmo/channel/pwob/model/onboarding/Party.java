
/**
 * 
 */
package com.bmo.channel.pwob.model.onboarding;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.bmo.channel.pwob.validation.ValidIdentity;
import com.bmo.channel.pwob.validation.party.ValidParty;
import com.bmo.channel.pwob.validation.party.ValidSpouseParty;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.sun.istack.NotNull;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author vvallia
 *
 */

@ValidParty
@ValidIdentity
@ValidSpouseParty

public class Party {
	
	@Valid
	@NotNull
	private String partyRefId;
	
	
	@ApiModelProperty(example="password", value="Password for account holder")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	//@ValidPassword
	private String password;	

	private String spousePartyRefId;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean applyInvestmentObjectivesToAccounts;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean creditBureauConsent;
	
	private List<PartyRole> roles =  new ArrayList<>();			
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean isPrimaryApplicantSpouse;	

	@Valid	
	private PersonalInformation personal = new PersonalInformation();
	
	@Valid
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private FinancialInformation financial;
	
	@Valid	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private InvestmentObjectives investmentObjectives;
	
	@Valid
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Preferences preferences;
	
	@Valid	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Taxation taxation;
	
	@Valid
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private RegulatoryDisclosures regulatoryDisclosures;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private TradingAuthority tradingAuthority;
	
	@Valid
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private BmoRelationship bmoRelationship;
		
	public Party() {
		
	}

	public String getPartyRefId() {
		return partyRefId;
	}

	public void setPartyRefId(String partyRefId) {
		this.partyRefId = partyRefId;
	}

	public String getSpousePartyRefId() {
		return spousePartyRefId;
	}

	public void setSpousePartyRefId(String spousePartyRefId) {
		this.spousePartyRefId = spousePartyRefId;
	}

	public Boolean getApplyInvestmentObjectivesToAccounts() {
		return applyInvestmentObjectivesToAccounts;
	}

	public void setApplyInvestmentObjectivesToAccounts(Boolean applyInvestmentObjectivesToAccounts) {
		this.applyInvestmentObjectivesToAccounts = applyInvestmentObjectivesToAccounts;
	}

	public Boolean getCreditBureauConsent() {
		return creditBureauConsent;
	}

	public void setCreditBureauConsent(Boolean creditBureauConsent) {
		this.creditBureauConsent = creditBureauConsent;
	}

	public List<PartyRole> getRoles() {
		return roles;
	}

	public void setRoles(List<PartyRole> roles) {
		this.roles = roles;
	}

	public PersonalInformation getPersonal() {
		return personal;
	}

	public void setPersonal(PersonalInformation personal) {
		this.personal = personal;
	}

	public FinancialInformation getFinancial() {
		return financial;
	}

	public void setFinancial(FinancialInformation financial) {
		this.financial = financial;
	}

	public InvestmentObjectives getInvestmentObjectives() {
		return investmentObjectives;
	}

	public void setInvestmentObjectives(InvestmentObjectives investmentObjectives) {
		this.investmentObjectives = investmentObjectives;
	}

	public Preferences getPreferences() {
		return preferences;
	}

	public void setPreferences(Preferences preferences) {
		this.preferences = preferences;
	}

	public Taxation getTaxation() {
		return taxation;
	}

	public void setTaxation(Taxation taxation) {
		this.taxation = taxation;
	}

	public RegulatoryDisclosures getRegulatoryDisclosures() {
		return regulatoryDisclosures;
	}

	public void setRegulatoryDisclosures(RegulatoryDisclosures regulatoryDisclosures) {
		this.regulatoryDisclosures = regulatoryDisclosures;
	}

	public TradingAuthority getTradingAuthority() {
		return tradingAuthority;
	}

	public void setTradingAuthority(TradingAuthority tradingAuthority) {
		this.tradingAuthority = tradingAuthority;
	}
	
	public Boolean getIsPrimaryApplicantSpouse() {
		return isPrimaryApplicantSpouse;
	}

	public void setIsPrimaryApplicantSpouse(Boolean isPrimaryApplicantSpouse) {
		this.isPrimaryApplicantSpouse = isPrimaryApplicantSpouse;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public BmoRelationship getBmoRelationship() {
		return bmoRelationship;
	}

	public void setBmoRelationship(BmoRelationship bmoRelationship) {
		this.bmoRelationship = bmoRelationship;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
