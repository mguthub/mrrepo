/**
 * Adds constraint validator to validation context 
 * @author akhales
 */
package com.bmo.channel.pwob.validation;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Properties;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.util.Constants;
import com.bmo.channel.pwob.util.DateUtils;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public abstract class AbstractBaseValidator {
	private static Logger logger = LoggerFactory.getLogger(AbstractBaseValidator.class);
	public static final String MARITAL_STATUS_NODE = "maritalStatus";
	public static final String SPOUSE_NODE = "spouse";
	public static final String PERSONAL_NODE = "personal";
	public static final String IDENTITY_NODE = "identity";
	public static final String EMPLOYMENT_NODE = "employment";
	public static final String EMPLOYMENT_PATH = "employment";
	public static final String EMPLOYMENT_ADDRESS_NODE = "employment.employmentAddress";
	public static final String EMP_ADDRESS_NODE = "employmentAddress";
	public static final String INVESTMENT_OBJECTIVES_NODE = "investmentObjectives";
	public static final String ACCOUNTS_NODE = "accounts";
	public static final String ACCOUNTS_PATH = "accounts[]";
	public static final String EMPLOYMENT_ADDRESS_PATH = "employment.employmentAddress";
	public static final String BUSINESS_NAME_FIELD_NAME = "employerBusinessName";
	public static final String TARGET_ALLOCATION_TOTAL_FIELD_NAME = "targetAllocation.total";
	public static final String TARGET_ALLOCATION_CASH_FIELD_NAME = "targetAllocation.cash";
	public static final String TARGET_ALLOCATION_FIXED_INCOME_FIELD_NAME = "targetAllocation.fixedIncome";
	public static final String TARGET_ALLOCATION_EQUITIES_FIELD_NAME = "targetAllocation.equities";
	public static final String OBJECTIVE_FIELD_NAME = "objective";
	public static final String RISK_TOLERANCE_FIELD_NAME = "riskTolerance";
	public static final String TARGET_ALLOCATION_FIELD_NAME = "targetAllocation";
	public static final String RISK_TOLERANCE_TOTAL_FIELD_NAME = "riskTolerance.total";
	public static final String RISK_TOLERANCE_LOW_FIELD_NAME = "riskTolerance.low";
	public static final String RISK_TOLERANCE_MEDIUM_FIELD_NAME = "riskTolerance.medium";
	public static final String RISK_TOLERANCE_HIGH_FIELD_NAME = "riskTolerance.high";
	public static final String PRIMARY_BUSINESS_PHONE_NODE = "primaryBusinessPhone";
	public static final String PRIMARY_BUSINESS_PHONE_PATH = "primaryBusinessPhone";
	public static final String PRIMARY_PHONE_NODE = "primaryPhone";
	public static final String PRIMARY_PHONE_PATH = "primaryPhone";
	public static final String SECONDARY_PHONE_NODE = "secondaryPhone";
	public static final String SECONDARY_PHONE_PATH = "secondaryPhone";
	public static final String PERSONAL_EMPLOYMENT_NODE = "personal.employment";
	public static final String PERSONAL_EMPLOYMENT_PATH = "personal.employment";
	public static final String PERSONAL_IDENTITY_NODE = "personal.identity";
	public static final String PERSONAL_IDENTITY_PATH = "personal.identity";
	public static final String PERSONAL_RESIDENCE = "personal.residence";
	public static final String PERSONAL_RESIDENCE_FOR_TAX_NODE = "residencyForTax";
	public static final String PERSONAL_RESIDENCE_FOR_TAX_PATH = "residencyForTax";
	public static final String PHONE_NUMBER_FIELD_NAME = "phoneNumber";
	public static final String COUNTRY_CODE_FIELD_NAME = "countryCode";
	public static final String NATURE_OF_BUSINESS_FIELD_NAME = "natureOfBusiness";		
	public static final String EMPLOYMENT_STATUS_FIELD_NAME = "employmentStatus";		
	public static final String OCCUPATION_FIELD_NAME = "occupation";
	public static final String BMO_GROUP_FIELD_NAME = "bmoGroup";
	public static final String TAXATION_NODE = "taxation";
	public static final String TAXATION_PATH = "taxation";
	public static final String BMO_RELATIONSHIP_NODE = "bmoRelationship";
	public static final String BMO_RELATIONSHIP_PATH = "bmoRelationship";
	
	protected static final List<String> bmoSubsidiaries = Arrays.asList("bmo", "bank of montreal", "nesbitt burns");

	public static final String APPLICANTS_NODE = "applicants";
	public static final String TRADINGAUTHORITIES_NODE = "tradingAuthorities";
	public static final String IS_TRADING_AGENT_SPOUSE_FIELD_NAME = "isTradingAgentSpouse";
	public static final String IS_SPOUSE_LIVE_IN_SAME_ADDRESS_FIELD_NAME = "isSpouseLiveInSameAddress";
	public static final String CLIENT_ID_CAPTURE_TIME_FIELD_NAME = "clientIdCaptureTime";
	public static final String TRADING_AUTH_PARTY_REF_ID_FIELD_NAME = "tradingAuthorityPartyRefIds";
	public static final String SPOUSE_PARTY_REF_ID_FIELD_NAME = "spousePartyRefId";
	public static final String PARTY_REF_ID_FIELD_NAME = "partyRefId";
	public static final String APPLICATION_LOB_FIELD_NAME = "applicationLob";
	public static final String LOCALE_FIELD_NAME = "locale";
	public static final String CLIENT_METADATA_FIELD_NAME = "clientMetadata";
	public static final String PARTIES_NODE = "parties";

	public static final String WORKFLOW_NODE = "workflow";
	
	public static final String REGULATORY_DISCLOURE_NODE="regulatoryDisclosures";
	
	public static final String VERIFICATION_NODE="verification";
	
	/** Verification Field names **/
	public static final String ID_VERIFICATION_METHOD_FIELD_NAME = "idVerificationMethod";	
	public static final String DOCUMENT_TYPE_FIELD_NAME = "documentType";	
	public static final String ID_NUMBER_FIELD_NAME = "idNumber";	
	public static final String EXPIRY_DATE_FIELD_NAME = "expiryDate";	
	public static final String COUNTRY_OF_BIRTH_FIELD_NAME = "countryOfBirth";
	public static final String PROVINCE_FIELD_NAME = "province";
	public static final String IS_PLACE_OF_BIRTH_US = "isPlaceOfBirthUS";
	public static final String EMP_FIRST_NAME_FIELD_NAME = "employeeFirstName";
	public static final String EMP_LAST_NAME_FIELD_NAME = "employeeLastName";
	public static final String ID_PROVIDED_MATCH_APPLICANT_INFO_FIELD_NAME = "idProvidedMatchApplicantInformation";
	public static final String REASON_FOR_DISCREPANCY_FIELD_NAME = "reasonForDiscrepancy";

    public static final String BENEFICIARY_NODE = "beneficiaries";
    public static final String BENEFICIARY_PATH = "beneficiaries[]";

	public static final String NAME_PATH = "name";
	public static final String FIRST_NAME_FIELD_NAME = "firstName";
	public static final String LAST_NAME_FIELD_NAME = "lastName";
	public static final String TITLE_FIELD_NAME = "title";
	public static final String LEGAL_NAME_NODE = "legalName";

	public static final String COUNTRY_FIELD_NAME = "country";
	public static final String CITIZENSHIP_FIELD_NAME = "citizenships";
	public static final String RESIDENCY_TAX_NODE = "residencyForTax";
	public static final String HAD_DEPENDENTS_FIELD_NAME = "hasDependents";
	public static final String ARE_DEPENDENTS_SAMEASSPOUSE_FIELD_NAME = "areDependentsSameAsSpouse";
	public static final String NUM_OF_DEPENDENTS_FIELD_NAME = "numOfDependents";
	public static final String PRIMARY_EMAIL_ADD_FIELD_NAME = "primaryEmailAddress";
	public static final String SIN_FIELD_NAME = "socialInsuranceNumber";
	public static final String DOB_FIELD_NAME = "dateOfBirth";
	
	public static final String GENERIC_NUMERIC_PATTERN = "\\d";	
	public static final String GENERIC_ALLOWED_CHARACTERS_PATTERN = "\\d\\p{IsLatin}\\s\\-' ";
	public static final String NAME_PATTERN = "^[\\p{IsLatin}\\s\\-' ]{2,20}$";
	public static final String CANADIAN_POSTAL_CODE_PATTERN = "^[^\\sDFIOQUWZ]{1}[\\-\\dA-Za-z\\s]{1,11}$";
	public static final String SPACE_CHECK_PATTERN =".*\\s{2,}.*";
	
	public static final String DEFAULT_DATE_PATTERN= "yyyy-MM-dd";

	@Resource(name = "validationRules")
	protected Properties validationRules;

	/**
	 * 
	 * @param context 
	 * @param errorCode 
	 * @param propertyName : name of invalid property field
	 * create new constrain validator, adds that to validation context among with the name of invalid property field
	 * @return  the passing errorcode 
	 */
	protected String createConstraintViolation(ConstraintValidatorContext context,String errorCode,String propertyName) {
		context.disableDefaultConstraintViolation();
		ConstraintViolationBuilder builder = context.buildConstraintViolationWithTemplate(errorCode);		
		builder.addPropertyNode(propertyName).addBeanNode();

		builder.addConstraintViolation();
		return errorCode;
	}

	protected boolean validateAndAddConstraintViolation(ValidationRequest validationRequest) {		
		boolean valid = StringUtils.isNotBlank(validationRequest.getFieldValue()) && validateField(validationRequest);		
		if(!valid) {
			if(Optional.ofNullable(validationRequest.getIndex()).isPresent()) {
				validationRequest.addConstraintViolation(validationRequest.getIndex());
			} else {
				validationRequest.addConstraintViolation();
			}
		}
		return valid;
	}

	protected boolean validateField(ValidationRequest validationRequest) {		
		String fullFieldPath = validationRequest.calculateFullFieldPath().replaceAll("\\d+", "");

		String regex = this.retrievePatternForFieldAndLob(validationRequest.getLob(), fullFieldPath);		
		if(StringUtils.isBlank(validationRequest.getFieldValue()) || 
				(StringUtils.isNoneBlank(regex) && !validationRequest.getFieldValue().matches(regex))) {			
			if(Optional.ofNullable(validationRequest.getIndex()).isPresent()) {
				validationRequest.addConstraintViolation(validationRequest.getIndex());
			} else {
				validationRequest.addConstraintViolation();
			}
			return false;
		}
		return true;
	}

	protected String retrievePatternForFieldAndLob(ApplicationLob lob, String fieldPath) {		
		return validationRules.getProperty(lob.name() + "/" + fieldPath);
	}

	public void setValidationRules(Properties validationRules) {
		this.validationRules = validationRules;
	}

	protected boolean isValidBMOSubsidiaries(String businessName) {		
		return StringUtils.isNoneBlank(businessName) && bmoSubsidiaries.contains(businessName.toLowerCase().trim());		
	}

	protected boolean shouldValidateEmploymentStatus(String status, ApplicationLob lob) {		
		if(StringUtils.isNotBlank(status)) {
			if(ApplicationLob.il == lob) {
				return this.isILEmploymentStatus(status);
			} else if(ApplicationLob.nb == lob) {
				return this.isNBEmploymentStatus(status);
			} else {
				return false;
			}
		} else {
			return false;
		}
	}	
	
	protected boolean isILEmploymentStatus(String status) {	
		return RefDataValues.EMPLOYMENT_STATUS_FULL_TIME.equals(status) 
				|| RefDataValues.EMPLOYMENT_STATUS_SELF_EMPLOYED.equals(status)
				|| RefDataValues.EMPLOYMENT_STATUS_PART_TIME.equals(status)
				|| RefDataValues.EMPLOYMENT_STATUS_CONTRACT.equals(status)
				|| RefDataValues.EMPLOYMENT_STATUS_SEASONAL.equals(status);
	}
	
	protected boolean isNBEmploymentStatus(String status) {		
		return RefDataValues.EMPLOYMENT_STATUS_FULL_TIME.equals(status) 
				|| RefDataValues.EMPLOYMENT_STATUS_SELF_EMPLOYED.equals(status)
				|| RefDataValues.EMPLOYMENT_STATUS_PART_TIME.equals(status)
				|| RefDataValues.EMPLOYMENT_STATUS_CONTRACT.equals(status)
				|| RefDataValues.EMPLOYMENT_STATUS_SEASONAL.equals(status);
	}

	public List<Party> getPrimaryApplicantParties(List<Party> parties) {
		return parties.stream()
					  .filter(r -> r.getRoles() != null)
					  .filter(r -> r.getRoles().contains(PartyRole.PRIMARY_APPLICANT))
					  .collect(Collectors.toList());	
	}
	
	public List<Party> getJointApplicantParties(List<Party> parties) {
		return parties.stream()
					  .filter(r -> r.getRoles() != null)
					  .filter(r -> r.getRoles().contains(PartyRole.JOINT_APPLICANT))
					  .collect(Collectors.toList());	
	}
	
	protected List<String> getPartyRefIds(List<Party> parties) {		
		if(CollectionUtils.isNotEmpty(parties)) {
			return parties.stream().map(p -> p.getPartyRefId()).collect(Collectors.toList());		
		}		
		return null;
	}

	//Assuming only one spouse
	protected Optional<Party> getSpouseParty(List<Party> parties) {
		Party primary = parties.stream().filter(r -> r.getRoles().contains(PartyRole.PRIMARY_APPLICANT)).findFirst().get();
		
		return parties.stream()
					  .filter(r -> { return r.getSpousePartyRefId() != null && r.getSpousePartyRefId().equals(primary.getPartyRefId()); }).findFirst();
	}

	protected  List<String> removeDuplicates(List<String> partyRefIds){
		if(CollectionUtils.isNotEmpty(partyRefIds)){
			return partyRefIds.stream().collect(Collectors.toSet()).stream().collect(Collectors.toList());
		}
		return partyRefIds;  
	}

	public boolean beneficiariesMustBeSpecified(String type, Party primaryApplicant) {
		if(primaryApplicant == null ||primaryApplicant.getPersonal() == null || primaryApplicant.getPersonal().getResidence() == null || 
				primaryApplicant.getPersonal().getResidence().getPrimaryAddress() == null ) {
			return false;
		}
		if(RefDataValues.PROVINCE_QBC.equals(primaryApplicant.getPersonal().getResidence().getPrimaryAddress().getProvince()) ||
				Account.INDIVIDUAL_TYPE.equalsIgnoreCase(type) || Account.JOINT_TYPE.equalsIgnoreCase(type)){
			return false;
		} else {
			if(Account.TFSA_TYPE.equalsIgnoreCase(type) ||					
					Account.RSP_TYPE.equalsIgnoreCase(type) || Account.RIF_TYPE.equals(type) || Account.LIRA_TYPE.equals(type)){
				return true;
			}
		}
		return true;
	}
	
	protected boolean isMarginSubTypeSelected(Account account) {
		return CollectionUtils.isNotEmpty(account.getSubTypes()) && account.getSubTypes().contains(RefDataValues.ACCOUNT_SUBTYPE_MARGIN);
	}
	
	protected boolean isValidSpouse(String maritalStatus) {
		return RefDataValues.MARITAL_STATUS_MARRIED.equals(maritalStatus) || RefDataValues.MARITAL_STATUS_COMMON_LAW.equals(maritalStatus);
	}	
	
	protected boolean isTaxResidencyRequired(ApplicationLob lob) {			
		return ApplicationLob.nb == lob;				
	}	
	
	protected boolean isPrimaryApplicantRole(List<PartyRole> roles) {
		return CollectionUtils.isNotEmpty(roles) && roles.contains(PartyRole.PRIMARY_APPLICANT);
	}
	
	protected boolean isJointApplicantRole(List<PartyRole> roles) {
		return CollectionUtils.isNotEmpty(roles) && roles.contains(PartyRole.JOINT_APPLICANT);
	}
	
	protected boolean isTradingAuthRole(List<PartyRole> roles) {
		return CollectionUtils.isNotEmpty(roles) && roles.contains(PartyRole.TRADING_AUTHORITY);
	}
	
	protected boolean isSpouseOfPrimaryApplicant(List<PartyRole> roles) {
		return CollectionUtils.isEmpty(roles);
	}
	
	protected boolean checkNull(ValidationRequest request, Boolean flag){
		boolean valid = true;
		if(!Optional.ofNullable(flag).isPresent()) {
			request.addConstraintViolation();
			valid = false;
		}
		return valid;
	}
	
	/**
	 * @param char sequence of length nine, each which is a digit
	 * @return true if value 
	 */
	protected boolean isValidSin(CharSequence value) {
		int sum = 0;
		for(int index = 0; index < 8; index++) {
			int digit = Character.digit(value.charAt(index), 10);
			// only multiply first, third, fifth and seventh digits
			if(index == 1 || index == 3 || index == 5 || index == 7) {
				// same as * 2
				digit *= 2;
				if(digit > 9) {
					digit -= 9;
				}
			}
			sum += digit;
		}

		if(sum % 10 == 0) {
			return true;
		} else {
			return doesRrEqualCheckDigit(sum, Character.digit(value.charAt(8), 10));
		}
	}

	protected boolean doesRrEqualCheckDigit(int sum, int checkDigit) {
		int matchingDigit = 10 - (sum % 10);
		return checkDigit == matchingDigit;
	}
	
	protected boolean verifySinPattern(String sin){
		if(!sin.matches("^\\d{9}$")) {
			return false;
		}
		return isValidSin(sin);
	}
	
	protected boolean isMaritalStatusNotSpecified(Identity identity) {
		return identity == null ||  identity.getMaritalStatus() == null;
	}
	
	protected boolean doesPatternMatch(String value, String pattern) {
		return StringUtils.isNoneBlank(value) && value.matches(pattern);
	}
	
	public boolean isDatePatternValid(String value, String pattern) {
		SimpleDateFormat df = new SimpleDateFormat(pattern);
		df.setLenient(false);
		try {
			if (df.parse(value) != null)
				return true;
		} catch (Exception ex) {
			logger.warn("Failed to validate date pattern : ", pattern, ex);
			return false;
		}
		return false;
	}

	protected boolean validatePartnerDOB(Party party, Party primaryParty) throws DateTimeParseException,ParseException {

		return (party.getPersonal().getIdentity() == null
				|| StringUtils.isBlank(party.getPersonal().getIdentity().getDateOfBirth())
				|| validateSpouseDOBYounger(primaryParty, party.getPersonal().getIdentity().getDateOfBirth()));
	}

	protected boolean validateSpouseDOBYounger(Party primaryApplicantParty, String spouseDOB) throws DateTimeParseException,ParseException {
		return (isDobExist(primaryApplicantParty)
				&& DateUtils.isBefore(primaryApplicantParty.getPersonal().getIdentity().getDateOfBirth(), spouseDOB, DEFAULT_DATE_PATTERN));
	}

	protected boolean isDobExist(Party party){
		return Optional.ofNullable(party.getPersonal().getIdentity()).isPresent() && 
				StringUtils.isNoneBlank(party.getPersonal().getIdentity().getDateOfBirth());
	}
	
	protected boolean isValidDOB(String dateOfBirth){
		XMLGregorianCalendar applicantDOB =DateUtils.getDateTimestamp(dateOfBirth);
		XMLGregorianCalendar minDOB=DateUtils.getDateTimestamp(Constants.MIN_DOB);
	    XMLGregorianCalendar currentDate = DateUtils.getTimestamp();
	    return DateUtils.isBetween(applicantDOB, minDOB, currentDate);
	}
	
	protected boolean isValidCanadianPostalCode(String postalCode) {
		if(Optional.ofNullable(postalCode).isPresent() && postalCode.matches(CANADIAN_POSTAL_CODE_PATTERN)
				&& !postalCode.matches(SPACE_CHECK_PATTERN)){
			return true;
		}else{
	     return false;
		}
	}
		
	public static <T extends Comparable<T>> boolean isBetween(T value, T start, T end) {
	    return value.compareTo(start) >= 0 && value.compareTo(end) <= 0;
	}
}
