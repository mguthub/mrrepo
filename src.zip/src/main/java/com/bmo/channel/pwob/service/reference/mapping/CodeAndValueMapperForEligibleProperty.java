package com.bmo.channel.pwob.service.reference.mapping;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.model.DataAndMapping;
import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.ValueType;

public class CodeAndValueMapperForEligibleProperty extends AbstractBaseReferenceMapper {

	public final String ELIGIBLE = "YES";
	
	@Override
	public List<Reference> mapToReferenceListEN(DataAndMapping dataAndMapping) {
		List<Reference> collect = dataAndMapping.getReferenceData().stream().map(v -> {
			return mapToReferenceEN(v);
		}).collect(Collectors.toList());
		return new DuplicatesFilter().filterOutDuplicates(collect);
	}

	@Override
	public List<Reference> mapToReferenceListFR(DataAndMapping dataAndMapping) {
		List<Reference> collect = dataAndMapping.getReferenceData().stream().map(v -> {			
			return mapToReferenceFR(v);
		}).collect(Collectors.toList());
		return new DuplicatesFilter().filterOutDuplicates(collect);
	}

	public Reference mapToReferenceEN(ValueType v) {
		if(ELIGIBLE.equalsIgnoreCase(getEligibleProperty(v))) {
			Reference reference = new Reference(v.getCode().getValue(), v.getName().getValue());
			if(isExpiredData(v)) {
				reference.setExpired(Boolean.TRUE);
			}
			return reference;
		}
		return null;
	}
	
	public Reference mapToReferenceFR(ValueType v) {		
		if(ELIGIBLE.equalsIgnoreCase(getEligibleProperty(v))) {
			return getTranslationForFR(v);
		}
		return null;
	}
	
	private  Reference getTranslationForFR(ValueType v) {
		Reference ref;
		
		String name = getFrenchName(v);
		if (!StringUtils.isBlank(name)){
			ref = new Reference(v.getCode().getValue(), name);
			
		} else {	//if French translation is not present, set English name
			ref = new Reference(v.getCode().getValue(), v.getName().getValue());
		}
		
		if (isExpiredData(v)) {
			ref.setExpired(Boolean.TRUE);
		}
		return ref;
	}
	
	private String getEligibleProperty(ValueType v){
		if (Optional.ofNullable(v.getProperties()).isPresent()
				&& CollectionUtils.isNotEmpty(v.getProperties().getProperty())
				&& CollectionUtils.isNotEmpty(v.getProperties().getProperty().get(1).getContent())) {
			return v.getProperties().getProperty().get(1).getContent().get(0).toString();
		}
		return null;
	}
	
}
