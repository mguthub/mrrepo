/**
 * @author snagamo
 */
package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class InterestedPartyPersonalInfo {

	@Valid
	private InterestedPartyIdentity identity = new InterestedPartyIdentity();

	@Valid
	private InterestedPartyResidence residence = new InterestedPartyResidence();
	

	public InterestedPartyIdentity getIdentity() {
		return identity;
	}

	public void setIdentity(InterestedPartyIdentity identity) {
		this.identity = identity;
	}


	public InterestedPartyResidence getResidence() {
		return residence;
	}

	public void setResidence(InterestedPartyResidence residence) {
		this.residence = residence;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
