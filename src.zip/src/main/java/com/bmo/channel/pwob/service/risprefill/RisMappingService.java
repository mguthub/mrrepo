package com.bmo.channel.pwob.service.risprefill;

import java.util.List;

import com.bmo.accounts.AccountDetailsResponse;
import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.onboarding.IndividualParty;

public interface RisMappingService {
	List<Party> mapRisPayload(AccountDetailsResponse accountDetailsResponse);
	void fetchPayloadName(NewWorkflowRequest request, AccountDetailsResponse accountDetailsResponse);
	IndividualParty fetchRisPrimaryParty(AccountDetailsResponse accountDetails);
}
