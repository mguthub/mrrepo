package com.bmo.channel.pwob.validation.financialstatus;

import com.bmo.channel.pwob.model.onboarding.Income;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface IncomeValidator {
	public boolean isValid(Income value, ValidationRequest validationRequest);
}
