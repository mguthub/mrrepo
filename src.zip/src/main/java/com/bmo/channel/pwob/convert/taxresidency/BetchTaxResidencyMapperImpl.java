package com.bmo.channel.pwob.convert.taxresidency;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.TaxResidency;
import com.bmo.channel.pwob.validation.RefDataValues;

@Component
public class BetchTaxResidencyMapperImpl implements BetchTaxResidencyMapper {

	@Override
	public void updateApplication(Application application) {
		//tax residency mapping										
		// if no tax residency or null 
		application.getParties().stream().forEach(p -> mapPersonalInfo(p.getPersonal()));
		application.getParties().stream().forEach(p -> {
			if (p.getPersonal().getHasTaxResidency() && p.getPersonal().getResidencyForTax().stream().map(TaxResidency::getCountry).anyMatch(RefDataValues.USA_COUNTRY_CODE::equals)) {
				removeW9IfNecessary(p);
			}
		});
	}

	private void mapPersonalInfo(PersonalInformation personalInformation) {
		
		if(!Optional.ofNullable(personalInformation.getResidencyForTax()).isPresent()) {
			List<TaxResidency> taxRes = new ArrayList<>();
			taxRes.add(new TaxResidency(RefDataValues.CANADA_COUNTRY_CODE));
			personalInformation.setResidencyForTax(taxRes);
			personalInformation.setHasTaxResidency(false);
		}// if only Canada is present : change flag to false
		else if (Optional.ofNullable(personalInformation.getResidencyForTax()).isPresent() && personalInformation.getResidencyForTax().get(0).getCountry().equals(RefDataValues.CANADA_COUNTRY_CODE)){
			personalInformation.setHasTaxResidency(false);
			personalInformation.getResidencyForTax().get(0).setProvince(null);
		}
		//If country not selected, add Canada and set flag to false
		else if (Optional.ofNullable(personalInformation.getResidencyForTax()).isPresent() && personalInformation.getResidencyForTax().get(0).getCountry().isEmpty()){
			personalInformation.getResidencyForTax().get(0).setCountry(RefDataValues.CANADA_COUNTRY_CODE);
			personalInformation.setHasTaxResidency(false);
			personalInformation.getResidencyForTax().get(0).setProvince(null);
		} //If non canada country, add canada at index 0 and other country at index 1
		else if (Optional.ofNullable(personalInformation.getResidencyForTax()).isPresent() && !personalInformation.getResidencyForTax().get(0).getCountry().equals(RefDataValues.CANADA_COUNTRY_CODE)){
			personalInformation.getResidencyForTax().add(0, (new TaxResidency(RefDataValues.CANADA_COUNTRY_CODE)));
			personalInformation.setHasTaxResidency(true);
			personalInformation.getResidencyForTax().get(1).setProvince(null);

		}
	}
	
	private void removeW9IfNecessary(Party party) {
		if (party.getTaxation() != null && party.getTaxation().getIsIrsW9FormProvided() != null) {
			if (!isUSCitizen(party) && !isPlaceOfBirthUS(party)) {
				party.getTaxation().setIsIrsW9FormProvided(null);
				party.getTaxation().setTaxIdentificationNumber(null);
			}
		}
	}
	
	private boolean isUSCitizen(Party party) {
		return party.getPersonal() != null && party.getPersonal().getIdentity() != null && party.getPersonal().getIdentity().getCitizenships() != null && 
				party.getPersonal().getIdentity().getCitizenships().contains(RefDataValues.USA_COUNTRY_CODE);
	}
	
	private boolean isPlaceOfBirthUS(Party party) {
		return party.getRegulatoryDisclosures() != null && party.getRegulatoryDisclosures().getVerification() != null &&
				party.getRegulatoryDisclosures().getVerification().getIsPlaceOfBirthUS() != null && 
				party.getRegulatoryDisclosures().getVerification().getIsPlaceOfBirthUS();
	}
}
