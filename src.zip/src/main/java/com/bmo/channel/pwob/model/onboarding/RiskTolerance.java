package com.bmo.channel.pwob.model.onboarding;

import java.math.BigInteger;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class RiskTolerance {
	private BigInteger low;
	private BigInteger medium;
	private BigInteger high;

	public BigInteger getLow() {
		return low;
	}

	public void setLow(BigInteger low) {
		this.low = low;
	}

	public BigInteger getMedium() {
		return medium;
	}

	public void setMedium(BigInteger medium) {
		this.medium = medium;
	}

	public BigInteger getHigh() {
		return high;
	}

	public void setHigh(BigInteger high) {
		this.high = high;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
