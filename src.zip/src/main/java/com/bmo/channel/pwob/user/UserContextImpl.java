package com.bmo.channel.pwob.user;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.exception.UnauthorizedSecurityException;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.user.IvUserParser.ParseResult;

/**
 * Determine user context based on request headers injected by ISAM gateway.
 * @author rcham02
 */
@Component
public class UserContextImpl implements UserContext {
	
	private static Logger logger = LoggerFactory.getLogger(UserContextImpl.class);
	
	@Autowired
	private HttpServletRequest request;

	@Override
	public AuthenticatedUser getAuthenticatedUser() {

		if (StringUtils.isNotBlank(request.getHeader(IV_GROUPS_HEADER))) {
			String ivUser = getIvUserHeader();
			ParseResult parseResult = new IvUserParser(ivUser).parse();
			return new AuthenticatedUser(parseResult.getNetworkId(), parseResult.getDomain(), getLob(getIvGroupHeader()));
		} else if (StringUtils.isNotBlank(request.getHeader(X_BMO_BUSINESS_CATEGORY))) {
			return new AuthenticatedUser("", "", getLob(getXBmoBusinessCategory()));
		} else {
			throw new UnauthorizedSecurityException("Missing header");
		}

	}

	private ApplicationLob getLob(String ivGroup) {
		if(ivGroup.toUpperCase().contains(GROUP_NAME_NB)) {
			return ApplicationLob.nb;
		} else if(ivGroup.toUpperCase().contains(GROUP_NAME_IL)) {
			return ApplicationLob.il;
		} else {
			throw new UnauthorizedSecurityException("Cannot determine LOB from iv-group " + ivGroup);
		}
	}

	String getIvUserHeader() {
		String header = request.getHeader(IV_USER_HEADER);		
		logger.info(String.format("User Id is: %s", header));	
		return header;
	}

	String getIvGroupHeader() {		
		
		String header = request.getHeader(IV_GROUPS_HEADER);		
		logger.info(String.format("User Groups are: %s", header));		
		return header;
	}

	private String getXBmoBusinessCategory(){
		String header = request.getHeader(X_BMO_BUSINESS_CATEGORY);		
		logger.info(String.format("BMO business catergory is: %s ", header));	
		if(StringUtils.isBlank(header)){
			throw new UnauthorizedSecurityException("x_bmo_business_category " + header);
		}
		
		return header;
	}
	/*private boolean isValidIvUser(String ivUser) {
		return ivUser != null && StringUtils.trimToEmpty(ivUser).matches("^[a-zA-Z0-9]+@[.a-zA-Z0-9_]+$");
	}*/

	boolean isValidIvGroup(String ivGroup) {
		return ivGroup != null && StringUtils.trimToEmpty(ivGroup).matches("^[a-zA-Z\\s\\_'\"-]+$");
	}
	
	
	
}
