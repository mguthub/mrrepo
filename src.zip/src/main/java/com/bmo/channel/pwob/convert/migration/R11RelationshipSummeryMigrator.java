package com.bmo.channel.pwob.convert.migration;

import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.RifPaymentDetails;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.account.RifAccountValidator;

@Component
@Order(value=1)
public class R11RelationshipSummeryMigrator implements RelationshipSummaryMigrator {
	
	public static final String TRANSIT_NUM_PATTERN = "^[\\d]{4}$";
	
	@Autowired
	private EventManager eventManager;
	

	@Override
	public void migrateRelationshipSummary(RelationshipSummary relationshipSummary, FeatureFlags systemFeatureFlags, Application application) {
		application.setRelease(Application.RELEASE_VERSION_11);	
		migrateRelationshipSummaryTransitNumber(relationshipSummary); 
		}

	@Override
	public boolean isMigrationRequired(RelationshipSummary relationshipSummary, FeatureFlags systemFeatureFlags, Application application) {
		String release = application.getRelease();
		if(isReleaseDifferent(release)) {
			eventManager.publishWarn(String.format("Migrating application %s because release version is %s", application.getApplicationId(), release));
			return true;
		} else {
			return false;
		}
	}

	private boolean isReleaseDifferent(String release) {
		try {
			Integer iRel = Integer.valueOf(release);
			return iRel <= Integer.parseInt(Application.RELEASE_VERSION_10);  
		} catch(NumberFormatException ex) {
			return true;
		}
	}

	
	private void migrateRelationshipSummaryTransitNumber(RelationshipSummary relationshipSummary) {
		if (Optional.ofNullable(relationshipSummary).isPresent()
				&& Optional.ofNullable(relationshipSummary.getClient()).isPresent()
				&& Optional.ofNullable(relationshipSummary.getClient().getTransitNumber()).isPresent()
				&& relationshipSummary.getClient().getReferralSource().equals(RefDataValues.REFERRAL_SOURCE_BMO_REFERRER)
				&& !relationshipSummary.getClient().getTransitNumber().matches(TRANSIT_NUM_PATTERN)){
				relationshipSummary.getClient().setTransitNumber(null);
			}
	}

		
}
	


