package com.bmo.channel.workflows.parties.proxy.v2;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.bmo.channel.common.domain.party.Person;
import com.bmo.channel.pwob.util.Constants;

@Produces(MediaType.APPLICATION_JSON)
public interface PartiesV2 {
    @POST
    public Person createParty(Person party, @HeaderParam(Constants.REQUEST_ID) String requestId);
    
    @GET
    @Path("/{ecifId}")
    public Person getParty(@PathParam("ecifId") String ecifId, @HeaderParam(Constants.REQUEST_ID) String requestId);
}
