package com.bmo.channel.pwob.service.applications;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.pwob.model.onboarding.AppStatus;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.SavedApplicationsFilter;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.SavedApplicationsResponse;
import com.bmo.channel.pwob.service.user.UsersService;

@Service
public class FilteringSavedApplicationsServiceImpl implements FilteringSavedApplicationsService {

	@Autowired
	private SavedApplicationsService savedApplicationsService;

	@Autowired
	private UsersService usersService;

	@Override
	public SavedApplicationsResponse retrieveSavedApplications(SavedApplicationsFilter filter) {
		SavedApplicationsResponse savedApplications;
		if(StringUtils.isNoneBlank(filter.getAppStatus())) {
			if(isPaginationSpecified(filter.getPageNum(), filter.getNumPerPage())) {
				savedApplications = savedApplicationsService.retrieveSavedApplicationsByAppStatusWithPagination(filter.getAppStatus(), filter.getPageNum(), filter.getNumPerPage());			
			}
			else if (CollectionUtils.isNotEmpty(filter.getIaCodes())) {
				savedApplications = savedApplicationsService.retrieveSavedApplicationsByIaCode(filter.getAppStatus(), filter.getIaCodes());
			}
			else {
				savedApplications = savedApplicationsService.retrieveSavedApplicationsByAppStatusFirstNameLastName(filter.getAppStatus(), filter.getFirstName(), filter.getLastName());								
			}
			
		} else {
			if (CollectionUtils.isNotEmpty(filter.getCustomerIds())) {
				savedApplications = savedApplicationsService.retrieveSavedApplicationsByCustomerId(filter.getCustomerIds());
			}
			else if (CollectionUtils.isNotEmpty(filter.getIaCodes())) {
				savedApplications = savedApplicationsService.retrieveSavedApplicationsByIaCode(filter.getIaCodes());
			}
			else {
				savedApplications = savedApplicationsService.retrieveSavedApplicationsByFirstNameLastName(filter.getFirstName(), filter.getLastName());
			}
		}
		return savedApplications;
	}

	boolean isPaginationSpecified(Integer pageNum, Integer numPerPage) {
		return pageNum != null && numPerPage != null;
	}

	@Override
	public SavedApplicationsResponse retrieveSavedApplicationsWaitingForBMApproval(SavedApplicationsFilter filter) {
		SavedApplicationsResponse savedApplications = null;
		// TODO RC restore security check once UI can implement their changes
		User currentUser = usersService.currentUser();
		if(!currentUser.getIsBranchManager()) {
			return new SavedApplicationsResponse(new ArrayList<>());
		}
		if(StringUtils.isNotBlank(filter.getFirstName()) || StringUtils.isNotBlank(filter.getLastName())) {
			List<String> iaCodes;

			if (CollectionUtils.isNotEmpty(filter.getIaCodes())) {
				iaCodes = filter.getIaCodes(); 
			} else {
				 iaCodes = usersService.currentUser().getBmApproverFor();
			}

			savedApplications = 
				savedApplicationsService.retrieveSavedApplicationsByAppStatusIaCodesFirstNameLastName(AppStatus.BM_APPROVAL.toString(), 
					iaCodes, 
					filter.getFirstName(), 
					filter.getLastName());
		} else {
			List<String> iaCodes;

			if (CollectionUtils.isNotEmpty(filter.getIaCodes())) {
				iaCodes = filter.getIaCodes(); 
			} else {
				 iaCodes = usersService.currentUser().getBmApproverFor();
			}

			savedApplications = 
				savedApplicationsService.retrieveSavedApplicationsByIaCode(AppStatus.BM_APPROVAL.toString(), iaCodes); 
		}
		return savedApplications;
	}
}
