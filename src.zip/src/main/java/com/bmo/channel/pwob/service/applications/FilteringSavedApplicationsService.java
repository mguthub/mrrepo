package com.bmo.channel.pwob.service.applications;

import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.SavedApplicationsFilter;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.SavedApplicationsResponse;

/**
 * Delegates retrieving saved applications based on request filter.
 * @author Ryan Chambers (rcham02)
 */
public interface FilteringSavedApplicationsService {

	SavedApplicationsResponse retrieveSavedApplications(SavedApplicationsFilter filter);

	SavedApplicationsResponse retrieveSavedApplicationsWaitingForBMApproval(SavedApplicationsFilter filter);

}
