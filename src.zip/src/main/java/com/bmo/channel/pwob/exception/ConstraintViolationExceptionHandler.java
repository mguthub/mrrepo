package com.bmo.channel.pwob.exception;

import java.util.HashMap;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.core.event.MessageEvent;
import com.bmo.channel.core.exception.ExceptionUtil;
import com.bmo.channel.core.mapping.DataMapper;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Beneficiary;
import com.bmo.channel.pwob.model.onboarding.Guarantee;
import com.bmo.channel.pwob.model.onboarding.Guarantor;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;

@Component
public class ConstraintViolationExceptionHandler implements ExceptionMapper<ConstraintViolationException> {
	
	@Autowired
	private EventManager eventManager;
	private DataMapper dataMapper;
	
	static Logger logger = LoggerFactory.getLogger(ConstraintViolationExceptionHandler.class);

    @Override
    public Response toResponse(ConstraintViolationException exception) {
           ValidationErrorResponse errorResponse = createValidationErrorResponse(exception);
           Status status = ExceptionUtil.getExceptionInfo(exception).getHttpStatusCode();
           try{
	           List<String> errorFieldNameList=null;
	           String fieldNames="";
	           if (Optional.ofNullable(errorResponse).isPresent() && Optional.ofNullable(errorResponse.getValidationErrors()).isPresent()) {
	                  errorFieldNameList=errorResponse.getValidationErrors().stream().map(ValidationError::getField).collect(Collectors.toList());
	                  if (CollectionUtils.isNotEmpty(errorFieldNameList)) {
	                        fieldNames=String.join(",",errorFieldNameList);
	                  }                    
	           }
	           logger.error("Error for the input field(s) : " + fieldNames,"Response error code : " +status.getStatusCode(), exception);
           }catch (Exception e) {
        	   logger.error("Error for the input field(s) : " + e.getMessage());
			}
           return buildResponse(errorResponse, status);
    }

	public Response buildResponse(ValidationErrorResponse errorResponse, Status status) {
		return Response.status(status).entity(errorResponse).build();
	}

	public ValidationErrorResponse createValidationErrorResponse(ConstraintViolationException exception) {
		Set<ConstraintViolation<?>> constraintViolations = exception.getConstraintViolations();

		List<ValidationError> errorList = createErrorList(constraintViolations);
		StringBuilder sb = new StringBuilder();
		for(ValidationError error: errorList){
			sb.append(error.getCode());
			sb.append(" : ");
			sb.append(error.getField());
			sb.append(", ");
		}
		
		MessageEvent messageEvent = getEventManager().publishInfo(sb.toString());

		ValidationErrorResponse errorResponse = getDataMapper().map(messageEvent, ValidationErrorResponse.class);
		errorResponse.setMessage("Request Validation exception");
		errorResponse.setValidationErrors(errorList);
		return errorResponse;
	}

	List<ValidationError> createErrorList(Set<ConstraintViolation<?>> constraintViolations) {
		List<ValidationError> errorList = constraintViolations.
				stream().
				map(new ConstraintViolationConverter()).
				collect(Collectors.toList());
		return errorList;
	}

	static class ConstraintViolationConverter implements Function<ConstraintViolation<?>, ValidationError> {
		static Pattern accountsPattern = Pattern.compile("accounts\\[(\\d{1,4})\\].*");
		static Pattern partiesPattern = Pattern.compile("parties\\[(\\d{1,4})\\].*");
		static Pattern guarantorPattern = Pattern.compile("guarantors\\[(\\d{1,4})\\].*");
		static Pattern guaranteePattern = Pattern.compile("guarantees\\[(\\d{1,4})\\].*");
		static Pattern beneficiaryPattern = Pattern.compile("beneficiaries\\[(\\d{1,4})\\].*");

		@Override
		public ValidationError apply(ConstraintViolation<?> constraintViolation) {
			if(constraintViolation.getRootBeanClass().isAssignableFrom(Application.class)) {
				String path = constraintViolation.getPropertyPath().toString();
				ValidationError validationError = new ValidationError(constraintViolation.getMessage(), path);

				Matcher accountsMatcher = accountsPattern.matcher(path);
				if(accountsMatcher.matches()) {
					int index = Integer.parseInt(accountsMatcher.group(1), 10);
					Account account = ((Application)constraintViolation.getRootBean()).getAccounts().get(index);

					Map<String, Object> meta = new HashMap<>();
					meta.put("accountName", account.getName());
					meta.put("accountClientRefId", account.getRefId());
					meta.put("accountType", account.getType());
					validationError.setMeta(meta);
				}

				Matcher partiesMatcher = partiesPattern.matcher(path);
				if(partiesMatcher.matches()) {
					int index = Integer.parseInt(partiesMatcher.group(1), 10);
					List<Party> parties = ((Application)constraintViolation.getRootBean()).getParties();
					Party party = parties.get(index);

					Map<String, Object> meta = new HashMap<>();
					meta.put("roles", party.getRoles());
					meta.put("isPrimaryApplicantSpouse", isPrimaryApplicantSpouse(parties, index));
					meta.put("spousePartyRefId", party.getSpousePartyRefId());
					meta.put("partyRefId", party.getPartyRefId());
					validationError.setMeta(meta);
				}
				
				Matcher guarantorMatcher = guarantorPattern.matcher(path);
				if(guarantorMatcher.matches()) {
					int index = Integer.parseInt(guarantorMatcher.group(1), 10);
					List<Guarantor> guarantors = ((Application)constraintViolation.getRootBean()).getGuarantors();
					Guarantor guarantor = guarantors.get(index);

					Map<String, Object> meta = new HashMap<>();
					meta.put("guarantorRefId", guarantor.getGuarantorRefId());
					validationError.setMeta(meta);
				}
				
				Matcher guaranteeMatcher = guaranteePattern.matcher(path);
				if(guaranteeMatcher.matches()) {
					int index = Integer.parseInt(guaranteeMatcher.group(1), 10);
					List<Guarantee> guarantees = ((Application)constraintViolation.getRootBean()).getGuarantees();
					Guarantee guarantee = guarantees.get(index);

					Map<String, Object> meta = new HashMap<>();
					meta.put("guaranteeRefId", guarantee.getGuaranteeRefId());
					validationError.setMeta(meta);
				}
				
				Matcher beneficiaryMatcher = beneficiaryPattern.matcher(path);
				if(beneficiaryMatcher.matches()) {
					int index = Integer.parseInt(beneficiaryMatcher.group(1), 10);
					List<Beneficiary> beneficiaries = ((Application)constraintViolation.getRootBean()).getBeneficiaries();
					Beneficiary beneficiary = beneficiaries.get(index);

					Map<String, Object> meta = new HashMap<>();
					meta.put("beneficiaryRefId", beneficiary.getBeneficiaryRefId());
					
					validationError.setMeta(meta);
				}

				return validationError;
			} else {
				return new ValidationError(constraintViolation.getMessage(), constraintViolation.getPropertyPath().toString());
			}
		}

		private Boolean isPrimaryApplicantSpouse(List<Party> parties, int index) {
			Party party = parties.get(index);
			if(party.getSpousePartyRefId() != null) {
				Optional<Party> spouse = parties.stream().filter(p -> p.getPartyRefId().equals(party.getSpousePartyRefId())).findFirst();
				if(spouse.isPresent() && CollectionUtils.isNotEmpty(spouse.get().getRoles())) {
					return spouse.get().getRoles().contains(PartyRole.PRIMARY_APPLICANT);
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
	}

	public EventManager getEventManager() {
		return eventManager;
	}
	public void setEventManager(EventManager eventManager) {
		this.eventManager = eventManager;
	}
	public DataMapper getDataMapper() {
		return dataMapper;
	}
	public void setDataMapper(DataMapper dataMapper) {
		this.dataMapper = dataMapper;
	}
}