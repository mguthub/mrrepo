package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.model.reference.ReferencesResponse;
import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.service.reference.ReferencesService;
import com.bmo.channel.pwob.validation.ValidReferenceType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(ReferencesEndpoint.PATH)
@Path(ReferencesEndpoint.PATH)
@Validated
/**
 * REST Controller for returning reference data.
 * @author Ryan Chambers rcham02
 */
public class ReferencesEndpoint {
	public static final String PATH = "v1/references";
	public static final String TYPE_QUERY_PARAMETER_NAME = "type";

	@Autowired
	private ReferencesService referencesService;

	@GET
	@ApiOperation(value="Retrieve reference map of data codes and their labels", 
			notes="lang param determines french or english labels",
			response=Reference.class,
			responseContainer = "map")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request")})
	public Response references(
			@Valid @ValidReferenceType
			@ApiParam(value = "Label type for fetching a specific group of labels (see results of normal call to see what types are avaiable)", required=false) 
			@QueryParam(TYPE_QUERY_PARAMETER_NAME) List<String> types, 
			@ApiParam(value = "Which language the returned labels will be in (en-ca or fr-ca only)", required=true) @QueryParam("lang") String lang) {

		UILocale locale = UILocale.parse(lang);
		Map<ReferenceType, List<Reference>> references = retrieveReferences(types, locale);
		return Response.ok(new ReferencesResponse(references)).build();
	}

	Map<ReferenceType, List<Reference>> retrieveReferences(List<String> types, UILocale locale) {
		Map<ReferenceType, List<Reference>> references;
		if(CollectionUtils.isEmpty(types)) {
			 references = referencesService.all(locale);
		} else {
			Set<ReferenceType> referenceTypes = types.stream().
				map(this::parseReferenceType).
				collect(Collectors.toSet());
			references = referencesService.ofTypes(referenceTypes,locale);
		}
		return references;
	}

	ReferenceType parseReferenceType(String type) {
		return Arrays.asList(ReferenceType.values()).stream().filter(refType -> refType.toString().equals(type)).findFirst().get();
	}
}
