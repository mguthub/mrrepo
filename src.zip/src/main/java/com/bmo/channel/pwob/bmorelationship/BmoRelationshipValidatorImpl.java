package com.bmo.channel.pwob.bmorelationship;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.BmoRelationship;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class BmoRelationshipValidatorImpl extends AbstractBaseValidator implements BmoRelationshipValidator {
	
	public static final String CARD_NUMBER_PATTERN = "^[" + GENERIC_NUMERIC_PATTERN + "]{16}$";
	public static final String ACCOUNT_NUMBER_PATTERN = "^[" + GENERIC_NUMERIC_PATTERN + "]{8}$";
	public static final String BANK_CARD_PRODUCT = "1";

	@Override
	public Boolean validateBmoRelationship(BmoRelationship bmoRealtionship, ValidationRequest request) {
		
		boolean valid = true;
		
		request.setFieldName("isApplicantExistingClient");
		request.setErrorCode(ErrorCodes.INVALID_IS_APPLICANT_EXISTING_CLIENT);
		valid = validateBmoProduct(request, bmoRealtionship.getIsApplicantExistingClient(), bmoRealtionship.getBmoProduct()) && valid;		
		valid = validateAccountNumber(request, bmoRealtionship.getIsApplicantExistingClient(), bmoRealtionship) && valid; 
		
		return valid;
	}
	
	private boolean validateAccountNumber(ValidationRequest request, Boolean isApplicantExistingClient, BmoRelationship bmoRealtionship) {
		
		boolean valid = true;
		
		if (Optional.ofNullable(bmoRealtionship.getBmoProduct()).isPresent()) {

			// if BMO credit card
			if (StringUtils.isBlank(bmoRealtionship.getBmoAccountNumber())
					|| invalidCardNumber(bmoRealtionship)
					|| invalidAccountNumber(bmoRealtionship)) {
				request.addConstraintViolation("bmoAccountNumber", ErrorCodes.INVALID_BMO_ACCOUNT_NUMBER);
				valid = false;
			}
		}

		return valid;
	}

	private boolean invalidAccountNumber(BmoRelationship bmoRealtionship) {
		return !BANK_CARD_PRODUCT.equals(bmoRealtionship.getBmoProduct())
				&& !doesPatternMatch(bmoRealtionship.getBmoAccountNumber(), ACCOUNT_NUMBER_PATTERN);
	}

	private boolean invalidCardNumber(BmoRelationship bmoRealtionship) {
		return BANK_CARD_PRODUCT.equals(bmoRealtionship.getBmoProduct())
				&& !doesPatternMatch(bmoRealtionship.getBmoAccountNumber(), CARD_NUMBER_PATTERN);
	}

	private boolean validateBmoProduct(ValidationRequest request, Boolean flag, String bmoProduct){
		boolean valid = true;
		valid = this.checkNull(request, flag) && valid;
		
		if(Optional.ofNullable(flag).isPresent() && flag && StringUtils.isBlank(bmoProduct)) {
			request.setFieldName("bmoProduct");
			request.setErrorCode(ErrorCodes.INVALID_BMO_PRODUCT);		
			request.addConstraintViolation();
			valid = false;
	
		}
		return valid;
	}

}
