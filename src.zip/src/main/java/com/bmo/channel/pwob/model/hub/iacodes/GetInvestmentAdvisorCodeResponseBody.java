package com.bmo.channel.pwob.model.hub.iacodes;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class GetInvestmentAdvisorCodeResponseBody {

	private InvestmentAdvisorCodes investmentAdvisorCodes;

	@JsonProperty("ns3:investmentAdvisorCodes")
	public InvestmentAdvisorCodes getInvestmentAdvisorCodes() {
		return investmentAdvisorCodes;
	}

	public void setInvestmentAdvisorCodes(
			InvestmentAdvisorCodes investmentAdvisorCodes) {
		this.investmentAdvisorCodes = investmentAdvisorCodes;
	}
	
}
