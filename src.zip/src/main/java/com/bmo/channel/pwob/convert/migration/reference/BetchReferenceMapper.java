package com.bmo.channel.pwob.convert.migration.reference;

import com.bmo.channel.pwob.model.onboarding.Application;

/**
 * Reference data migration
 *
 */
@FunctionalInterface
public interface BetchReferenceMapper {
	void updateApplication(Application application);	
}
