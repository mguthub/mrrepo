package com.bmo.channel.pwob.model.onboarding;

public class ClientAccessIdRequest {
	
	private Credential credential;

	public Credential getCredential() {
		return credential;
	}

	public void setCredential(Credential credential) {
		this.credential = credential;
	}
	
	                                                     

}
