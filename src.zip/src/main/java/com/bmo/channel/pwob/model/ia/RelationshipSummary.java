package com.bmo.channel.pwob.model.ia;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.validation.ErrorCodes;

public class RelationshipSummary {
	
	@Valid
	private Client client;
	
	@Valid
	private List<Party> parties = new ArrayList<>();
	
	@Valid
	private List<IaAccount> accounts = new ArrayList<IaAccount>();

	@Pattern(regexp="^[\\p{IsLatin}\\s-'0-9_ ~`+@!#$%*()=,<.>?;:{}|&^\\[\\]/  ]{0,4000}$", message=ErrorCodes.INVALID_RELATIONSHIP_DOCEDITCOMMENT)
	private String documentEdits;

	@Pattern(regexp="^[\\p{IsLatin}\\s-'0-9_ ~`+@!#$%*()=,<.>?;:{}|&^\\[\\]/  ]{0,4000}$", message=ErrorCodes.INVALID_RELATIONSHIP_COMMENT)
	private String comments;
	
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Client getClient() {
		return client;
	}

	public void setClient(Client client) {
		this.client = client;
	}

	public List<Party> getParties() {
		return parties;
	}

	public void setParties(List<Party> parties) {
		this.parties = parties;
	}

	public List<IaAccount> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<IaAccount> accounts) {
		this.accounts = accounts;
	}

	/**
	 * @return the documentEdits
	 */
	public String getDocumentEdits() {
		return documentEdits;
	}

	/**
	 * @param documentEdits the documentEdits to set
	 */
	public void setDocumentEdits(String documentEdits) {
		this.documentEdits = documentEdits;
	}
	
}
