package com.bmo.channel.pwob.service.documentpackages.dto;

public enum PackageStatus {
	OUTSTANDING("Outstanding"), COMPLETED("Completed"), ERROR("Error"), ESIGN_PENDING("ESignPending");
	
	private String description;
	
	PackageStatus (final String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return this.description;
	}
}
