package com.bmo.channel.pwob.model.ia;

import java.util.List;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ia.ValidIaAccount;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

@ValidIaAccount
public class IaAccount {
	@ApiModelProperty(example="11211220")
	private String accountNumber;
	
	private Integer estimatedSize;
	
	private Integer initialDeposit;
	
	@ApiModelProperty(example="X", value="Valid values can be found in the reference service")
	@ReferenceData(code=ErrorCodes.INVALID_PAYMENT_TYPE, type=ReferenceType.PAYMENT_TYPES)
	private String paymentType;
	
	private List<String> commissionFeeCodes;
	
	private List<String> feeBasedCodes;
	
	@ApiModelProperty(value="This is the account data of the application for reference, and does not need to be filled out")
	private Account ref;
	
	@ApiModelProperty(example="D", value="Valid values can be found in the reference service")
	@ReferenceData(code=ErrorCodes.INVALID_FEE_TYPE, type=ReferenceType.FEE_TYPES)
	private String feeType;
	
	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Integer getEstimatedSize() {
		return estimatedSize;
	}

	public void setEstimatedSize(Integer estimatedSize) {
		this.estimatedSize = estimatedSize;
	}

	public Integer getInitialDeposit() {
		return initialDeposit;
	}

	public void setInitialDeposit(Integer initialDeposit) {
		this.initialDeposit = initialDeposit;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public Account getRef() {
		return ref;
	}

	public void setRef(Account ref) {
		this.ref = ref;
	}

	public String getFeeType() {
		return feeType;
	}

	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}

	public List<String> getCommissionFeeCodes() {
		return commissionFeeCodes;
	}

	public void setCommissionFeeCodes(List<String> commissionFeeCodes) {
		this.commissionFeeCodes = commissionFeeCodes;
	}

	public List<String> getFeeBasedCodes() {
		return feeBasedCodes;
	}

	public void setFeeBasedCodes(List<String> feeBasedCodes) {
		this.feeBasedCodes = feeBasedCodes;
	}
	
}
