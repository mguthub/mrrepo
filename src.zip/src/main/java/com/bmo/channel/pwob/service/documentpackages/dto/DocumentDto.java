package com.bmo.channel.pwob.service.documentpackages.dto;

import java.util.ArrayList;
import java.util.List;

public class DocumentDto {
	private String id;
	private String referenceId;
	private String type;
	private String documentStatus;
	private String signatureStatus;
	private String documentVersion;

	public String getDocumentVersion() {
		return documentVersion;
	}

	public void setDocumentVersion(String documentVersion) {
		this.documentVersion = documentVersion;
	}

	/** Several pages can be uploaded as separated documents. */
	private List<String> content;

	private List<LabelDto> labels = new ArrayList<>();
	private int numberOfPages;
	private List<String> errors;
	private List<String> signers;

	public DocumentDto() {
	}

	public DocumentDto(final List<LabelDto> labels) {
		this.labels = labels;
	}

	public String getId() {
		return id;
	}

	public void setId(final String id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	public String getDocumentStatus() {
		return documentStatus;
	}

	public void setDocumentStatus(final String documentStatus) {
		this.documentStatus = documentStatus;
	}

	public String getSignatureStatus() {
		return signatureStatus;
	}

	public void setSignatureStatus(final String signatureStatus) {
		this.signatureStatus = signatureStatus;
	}

	public List<String> getContent() {
		return content;
	}

	public void setContent(final List<String> content) {
		this.content = content;
	}

	public List<LabelDto> getLabels() {
		return labels;
	}

	public void setLabels(final List<LabelDto> labels) {
		this.labels = labels;
	}

	public int getNumberOfPages() {
		return numberOfPages;
	}

	public void setNumberOfPages(final int numberOfPages) {
		this.numberOfPages = numberOfPages;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(final String referenceId) {
		this.referenceId = referenceId;
	}

	public List<String> getErrors() {
		return errors;
	}

	public void setErrors(final List<String> errors) {
		this.errors = errors;
	}

	public List<String> getSigners() {
		return signers;
	}

	public void setSigners(final List<String> signers) {
		this.signers = signers;
	}

}
