/**
 * @author akhales
 */
package com.bmo.channel.pwob.validation.account;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.AccountBeneficiary;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Beneficiary;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

public class AccountBeneficiaryValidator extends AbstractBaseValidator implements ConstraintValidator<ValidAccountBeneficiary, Account> {
	
	public static final String BENEFICIARIES_FIELD_NAME = "beneficiaries";
	public static final String HAS_BENEFICIARIES_FIELD_NAME = "hasBeneficiaries";
	public static final String ENTITLEMENT_PERCENT_FIELD_NAME = "entitlementPercentage";	

	@Autowired
	ValidationRequestFactory validationRequestFactory;

	@Autowired
	private UsersService userService;		

	@Override
	public void initialize(ValidAccountBeneficiary constraintAnnotation) {	}

	@Override
	public boolean isValid(Account account, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();		

		ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).build();

		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		boolean valid = true;

		Application app = validationContext.getApplication();
		
		Party primaryAppParty = app.getPrimaryApplicant();											
		
		

		if(this.beneficiariesMustBeSpecified(account.getType(), app.getPrimaryApplicant())){			
			if(account.getHasBeneficiaries()!= null && account.getHasBeneficiaries()){
				valid = this.validateAccountBeneficiaries(account, request) && valid;
				valid = this.validateBeneficiaryEntitlementAllocationTotal(account, request) && valid;				
			}
		}
		else{
			valid = this.validateNoBeneficiaries(account, request) && valid;
		}
		
		if(Account.LIRA_TYPE.equals(account.getType()) && account.getHasBeneficiaries()!= null && account.getHasBeneficiaries()){
			
			if(Optional.ofNullable(primaryAppParty).isPresent() && StringUtils.isNotBlank(primaryAppParty.getSpousePartyRefId())
					&& (primaryAppParty.getPersonal().getIdentity().getMaritalStatus()!= null &&
					(primaryAppParty.getPersonal().getIdentity().getMaritalStatus().equalsIgnoreCase(RefDataValues.MARITAL_STATUS_MARRIED) ||
							primaryAppParty.getPersonal().getIdentity().getMaritalStatus().equalsIgnoreCase(RefDataValues.MARITAL_STATUS_COMMON_LAW)))) {					
				
				if(CollectionUtils.isNotEmpty(account.getBeneficiaries()) && account.getBeneficiaries().size() > 1){
					request.addConstraintViolation(BENEFICIARIES_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_BENEFICIARIES);	
					valid = false;
					return valid;
				}else{
					boolean isSpouseBenificiary = app.getBeneficiaries().stream()
						.filter(a -> a.getBeneficiaryRefId().equals(account.getBeneficiaries().get(0).getBeneficiaryRefId()))
						.anyMatch(b -> Optional.ofNullable(b.getHasPrimaryApplicantSpouse()).isPresent() && b.getHasPrimaryApplicantSpouse());
					
					if(!isSpouseBenificiary){
						request.addConstraintViolation(BENEFICIARIES_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_BENEFICIARIES);	
						valid = false;
						return valid;
					}
				}					
			}
		}

		if(CollectionUtils.isNotEmpty(account.getBeneficiaries())) {
			List<Beneficiary> beneficiaries = app.getBeneficiaries();
			List<String> beneficiariesRefIds = beneficiaries.stream().map(t -> t.getBeneficiaryRefId()).collect(Collectors.toList());			

			int count = 0;
			for(AccountBeneficiary accBeneficiary : account.getBeneficiaries()) {				
				List<AccountBeneficiary> accBeneficiryRefIds = account.getBeneficiaries().stream()
						.filter(t -> t.getBeneficiaryRefId() != null)
						.filter(t -> t.getBeneficiaryRefId().equals(accBeneficiary.getBeneficiaryRefId()))
						.collect(Collectors.toList());

				if(CollectionUtils.isNotEmpty(accBeneficiryRefIds) && accBeneficiryRefIds.size() > 1) {
					ValidationRequest beneValReq = request.createChildValidationRequest(BENEFICIARIES_FIELD_NAME, null);
					beneValReq.addConstraintViolation(StringUtils.EMPTY, ErrorCodes.INVALID_ACC_BENEFICIARY_ID);
					valid = false;
				}

				ValidationRequest beneValReq = request.createChildValidationRequest(BENEFICIARY_NODE + "[" + count + "]", null);

				if(!beneficiariesRefIds.contains(accBeneficiary.getBeneficiaryRefId())){					
					beneValReq.addConstraintViolation("beneficiaryRefId", ErrorCodes.NO_MAPPING_BENEFICIARY_ACC_BENEFICIARY);
					valid = false;
				}

				if(StringUtils.isBlank(accBeneficiary.getEntitlementPercentage())) {				
					beneValReq.addConstraintViolation("entitlementPercentage", ErrorCodes.INVALID_ENTITLEMENT);
					valid = false;
				}

				if(CollectionUtils.isNotEmpty(accBeneficiary.getContingentBeneficiaryRefIds())) {
					if (accBeneficiary.getContingentBeneficiaryRefIds().size() > 9) {
						beneValReq.addConstraintViolation("contingentBeneficiaryRefIds", ErrorCodes.INVALID_CONTINGENT_BENEFICIARY_NUMBER);
						valid = false;
					}

					int index = 0;
					for(String refId : accBeneficiary.getContingentBeneficiaryRefIds()) {										
						if(!beneficiariesRefIds.contains(refId)){							
							beneValReq.addConstraintViolation("contingentBeneficiaryRefIds[" + index + "]", ErrorCodes.NO_MAPPING_CONTINGENT_BENEFICIARY);
							valid = false;
						}
						if(accBeneficiary.getBeneficiaryRefId().equalsIgnoreCase(refId)) {							
							beneValReq.addConstraintViolation("contingentBeneficiaryRefIds[" + index + "]", ErrorCodes.INVALID_MAPPING_CONTINGENT_BENEFICIARY_ACC_BENEFICIARY);
							valid = false;
						}
						if(accBeneficiary.getContingentBeneficiaryRefIds().stream()
								.filter(t -> t != null)
								.filter(t -> t.equals(refId))
								.collect(Collectors.toList()).size() > 1){							
							beneValReq.addConstraintViolation("contingentBeneficiaryRefIds", ErrorCodes.INVALID_CONTINGENT_BENEFICIARY_ID);
							valid = false;
						}
						index++;
					}
				}
				count++;
			}												
		}
		return valid;
	}

	private Beneficiary getBeneficiary(List<Beneficiary> beneficiaries, String beneficiaryRefId) {
		if(CollectionUtils.isNotEmpty(beneficiaries) && StringUtils.isNotBlank(beneficiaryRefId)) {
			Optional<Beneficiary> beneficiary = beneficiaries.stream().filter(b -> beneficiaryRefId.equalsIgnoreCase(b.getBeneficiaryRefId())).findFirst();
			return beneficiary.orElse(null);
		}
		return null;
	}

	private boolean validateBeneficiaryEntitlementAllocationTotal(Account account, ValidationRequest request) {
		if(Optional.ofNullable(account.getHasBeneficiaries()).isPresent() &&
					account.getHasBeneficiaries() &&  CollectionUtils.isNotEmpty(account.getBeneficiaries()) && 
					!isEntitlementAllocationTotalValid(account.getBeneficiaries()))  {
			ValidationRequest beneValReq = request.createChildValidationRequest(BENEFICIARIES_FIELD_NAME, null);
			beneValReq.addConstraintViolation(ENTITLEMENT_PERCENT_FIELD_NAME, ErrorCodes.INVALID_ENTITLEMENT_ALLOCATION);
			return false;
		}
		return true;
	}

	private boolean validateAccountBeneficiaries(Account account, ValidationRequest request) {
		if(Optional.ofNullable(account.getHasBeneficiaries()).isPresent() && 
				(account.getBeneficiaries() == null || CollectionUtils.isEmpty(account.getBeneficiaries()))) {							
			request.addConstraintViolation(BENEFICIARIES_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_BENEFICIARIES);
			return false;		
		}
		return true;
	}
	
	private boolean validateNoBeneficiaries(Account account, ValidationRequest request) {
		boolean valid = true;
		
		if(account.getHasBeneficiaries() != null && account.getHasBeneficiaries()){
			request.addConstraintViolation(HAS_BENEFICIARIES_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_TYPE_FOR_BENEFICIARIES);
			valid = false;
		}
		if(CollectionUtils.isNotEmpty(account.getBeneficiaries())){
			request.addConstraintViolation(BENEFICIARIES_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_TYPE_FOR_BENEFICIARIES);
			valid = false;
		}
		return valid;
	}

	private boolean isEntitlementAllocationTotalValid(List<AccountBeneficiary> beneficiaries) {		
		BigDecimal sum = BigDecimal.ZERO;
		for (AccountBeneficiary beneficiary : beneficiaries) {				
			if(StringUtils.isNoneBlank(beneficiary.getEntitlementPercentage())) {
				sum = sum.add(new BigDecimal(beneficiary.getEntitlementPercentage()));
			} 
			else {
				//only validate sum if all entitlement's specified
				return true; 
			}
		}				
		return (sum.compareTo(BigDecimal.valueOf(100.0)) == 0);
	}			
}
