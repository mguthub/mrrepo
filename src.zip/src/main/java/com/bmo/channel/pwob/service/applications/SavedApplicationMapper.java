package com.bmo.channel.pwob.service.applications;

import java.math.BigDecimal;
import java.util.List;
import java.util.function.Function;

import org.apache.commons.collections.CollectionUtils;

import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.applications.SavedApplicationsAccount;
import com.bmo.channel.pwob.model.onboarding.Account;

import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Metadata;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Metadata.KeyValuePair;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Workflow;

class SavedApplicationMapper implements Function<Workflow, SavedApplication> {
	static final String IA_CODE = "iaCode";
	static final String UPDATE_TIMESTAMP = "lastUpdatedByTimestamp";
	static final String UPDATE_BY = "lastUpdatedBy";
	static final String ACCOUNT_TYPE= "accountType";

	@Override
	public SavedApplication apply(Workflow workflow) {
		SavedApplication savedApplication = new SavedApplication();
		savedApplication.setCustomerId(workflow.getCustomerId());
		savedApplication.setWorkflowId(workflow.getWorkflowId());
		savedApplication.setClientFirstName(workflow.getFirstName());
		savedApplication.setClientLastName(workflow.getLastName());
		savedApplication.setAppStatus(workflow.getWorkflowStatus());
		savedApplication.setLastUpdated(workflow.getLastUpdatedByDate());
		savedApplication.setApplicationNumber(workflow.getAttribute2());
		if(workflow.getLastUpdatedBy() != null){
			savedApplication.setLastUpdatedBy(extractNetworkId(workflow.getLastUpdatedBy()));
		}
		Metadata metadata = workflow.getMetadata();
		if(metadata != null) {
			List<KeyValuePair> keyValuePair = metadata.getKeyValuePair();
			if(CollectionUtils.isNotEmpty(keyValuePair)) {
				for (KeyValuePair kv : keyValuePair) {
					String key = kv.getKey();
					String value = kv.getValue().get(0);

					if(key.startsWith(ACCOUNT_TYPE)) {
						// the format for returning the number and count is:
						// key				value
						// accountType.A			2
						// accountType.B			1.0
						// accountType.B.spousal	1.0
						String split[] = key.split("\\.");
						if(split.length == 2) {
							savedApplication.addSavedApplicationAccount(new SavedApplicationsAccount(split[1], new BigDecimal(value).intValue()));
						}
						else if(split.length >= 3){
							savedApplication.addSavedApplicationAccount(new SavedApplicationsAccount(Account.SPOUSAL_RSP_TYPE, new BigDecimal(value).intValue()));
						}
					} else {
						 switch(key) {
							case IA_CODE:
								savedApplication.setIaCode(value);
								break;
							//case UPDATE_TIMESTAMP:
								//savedApplication.setLastUpdated(value);
								//break;
							//case UPDATE_BY:
								//savedApplication.setLastUpdatedBy(extractNetworkId(value));
								//break;
						}
					}
				}
			}
		}
		return savedApplication;
	}

	/**
	 * Only return network id, if domain also provided
	 * @param value  domain\network_id
	 * @return network_id
	 */
	private String extractNetworkId(String value) {
		String[] split = value.split("\\\\");
		if(split.length > 1) {
			return split[1];
		} else {
			return value;
		}
	}
}