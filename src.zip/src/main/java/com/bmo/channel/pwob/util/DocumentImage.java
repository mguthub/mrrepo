package com.bmo.channel.pwob.util;

import java.util.List;

/**
 * Provides the utilities to process image (jpeg/tiff/png) and pdf files.
 *
 */
public interface DocumentImage {
	public byte[] merge(final List<StringBuilder> contents);
}
