package com.bmo.channel.pwob.model.reference;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.service.reference.ReferenceType;

public class ReferencesResponse {

	private Map<ReferenceType, List<Reference>> references;

	public ReferencesResponse(Map<ReferenceType, List<Reference>> references) {
		this.references = references;
	}

	public Map<ReferenceType, List<Reference>> getReferences() {
		return references;
	}
	public void setReferences(Map<ReferenceType, List<Reference>> references) {
		this.references = references;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
