package com.bmo.channel.pwob.service.workflowstatus;


import com.bmo.channel.pwob.util.GetCountRequestWrapper;
import com.bmo.channel.pwob.util.GetCountResponseRootWrapper;
import com.bmo.channel.pwob.util.GetStatusResponseRootWrapper;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.*;
import org.springframework.web.bind.annotation.RequestBody;
import com.bmo.channel.pwob.util.GetStatusRequestWrapper;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
public interface WorkflowStatusEndpointInterface {

    @POST
    @Path("/setMetadata")
    SetMetadaResponse setMetadata(@RequestBody SetMetadataRequest requestWrapper,
                                  @HeaderParam("APIHeader") String requestHeader);

    @POST
    @Path("/setStatus")

    SetStatusResponse setStatus(@RequestBody SetStatusRequest requestWrapper,
                                @HeaderParam("APIHeader") String requestHeader);

    @POST
    @Path("/getStatus")
    GetStatusResponseRootWrapper getStatus(@RequestBody GetStatusRequestWrapper requestWrapper,
                                           @HeaderParam("APIHeader") String requestHeader);

    @POST
    @Path("/getCount")
    GetCountResponseRootWrapper getCount(@RequestBody GetCountRequestWrapper requestWrapper,
                                         @HeaderParam("APIHeader") String requestHeader);
}

