package com.bmo.channel.pwob.util;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.config.EnvironmentConfig;
import com.bmo.channel.pwob.model.onboarding.AlternateAddress;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.Phone;
import com.bmo.channel.pwob.model.onboarding.Residence;
import com.bmo.channel.pwob.validation.RefDataValues;

@Component
public class W8FormHelper {
	
	@Autowired
	private EnvironmentConfig environmentConfig;
	protected static final String [] USA_PHONE_COUNTRY_CODE= {"001","1"};

	private boolean checkUSAlternateAddress(final Residence residence) {
	 	return residence!=null && residence.getAlternateAddress() != null && this.isUSACountry(residence.getAlternateAddress().getCountry());
	}


	/**
	 * Check the phone area code in US area codes.
	 */
	private boolean checkUSPhone(final Residence residence, final Employment employmentInformation) {
		boolean checkTaxDetails = false;
		
		if(residence != null && employmentInformation!=null){
			
			String resPrimPhoneNUmber =	Optional.ofNullable(residence.getPrimaryPhone()).isPresent()? residence.getPrimaryPhone().getPhoneNumber() : null;
			String resSecPhoneNUmber =	Optional.ofNullable(residence.getSecondaryPhone()).isPresent()? residence.getSecondaryPhone().getPhoneNumber() : null;
			String empPhoneNUmber =	Optional.ofNullable(employmentInformation.getPrimaryBusinessPhone()).isPresent()? employmentInformation.getPrimaryBusinessPhone().getPhoneNumber() : null;
			
			if(!this.areAllPhoneNumbersEmpty(resPrimPhoneNUmber,resSecPhoneNUmber, empPhoneNUmber)) {
				if(this.isUSAPhoneNumber(residence.getPrimaryPhone())&& 
					this.isUSAPhoneNumber(residence.getSecondaryPhone()) && 
					this.isUSAPhoneNumber(employmentInformation.getPrimaryBusinessPhone())) {

					checkTaxDetails = true;
				}
			}
        }
		
		return checkTaxDetails;
	}
	

	private boolean areAllPhoneNumbersEmpty(String primaryPhone, String secondaryphone, String employmentPhone) {
		return StringUtils.isEmpty(primaryPhone) && StringUtils.isEmpty(secondaryphone) && StringUtils.isEmpty(employmentPhone);
	}

	private boolean isUSAPhoneNumber(Phone phone) {
			
		return  Objects.isNull(phone)||StringUtils.isBlank(phone.getPhoneNumber()) || phone.getPhoneNumber().length() < 4 ||
				(verifyCountryCode(phone) && environmentConfig.getUsaPhoneAreaCodes().contains(phone.getPhoneNumber().subSequence(Constants.ZERO, Constants.THREE)));
	}
	

	
	private boolean verifyCountryCode(Phone phone){
		if(Optional.ofNullable(phone.getIsInternationalNumber()).isPresent() && phone.getIsInternationalNumber())
			return StringUtils.isBlank(phone.getCountryCode()) ||
					Arrays.asList(USA_PHONE_COUNTRY_CODE).contains(phone.getCountryCode());
		else
			return true;
	}
	

	private boolean checkUSADuplicateMailingAddress(final List<AlternateAddress> duplicateAddress) {
		if(CollectionUtils.isNotEmpty(duplicateAddress)) {
			for (AlternateAddress address : duplicateAddress) {
				if (this.isUSACountry(address.getCountry())) {
					return true;
				}			
			}
		}			
		return false;
	}
	
	private boolean checkIDVerificationMethodIsBMOAffiliate(final List<PartyRole> roles, final String idVerificationMethod) {
		if (StringUtils.isNoneBlank(idVerificationMethod)
				&& RefDataValues.ID_VERIFICATION_METHOD_AFFILIATE.equals(idVerificationMethod)
				&& CollectionUtils.isNotEmpty(roles)
				&& (roles.contains(PartyRole.PRIMARY_APPLICANT) || roles.contains(PartyRole.JOINT_APPLICANT))) {
			return true;
		}
		return false;
	}
	
	private boolean isUSACountry(String country) {
		return RefDataValues.USA_COUNTRY_CODE.equalsIgnoreCase(country);
	}


	public boolean isW8FormApplicable(final Residence residence, final Employment employmentInformation, List<AlternateAddress> duplicateAddresses, List<PartyRole> roles, String idVerificationMethod) {
		return checkUSAlternateAddress(residence) || checkUSPhone(residence, employmentInformation) || checkUSADuplicateMailingAddress(duplicateAddresses) || checkIDVerificationMethodIsBMOAffiliate(roles, idVerificationMethod);
	}
	
}
