/**
 * 
 */
package com.bmo.channel.pwob.validation.residence;

import java.util.regex.Pattern;

import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.validation.request.ValidationRequest;


public interface PrimaryAddressValidator {
	
	static final String STREET_ADDRESS_FIELD_NAME = "streetAddress";
	static final String PRIMARY_RESIDENTIAL_ADDRESS_FIELD_NAME = "primaryAddress";

	static final Pattern PO_BOX_REGEX = Pattern.compile("^\\s*((P(OST )?.?\\s*(O(FF(ICE)?)?)?.?\\s+(B(IN|OX))?)|B(IN|OX)|(CP))", Pattern.CASE_INSENSITIVE);


	boolean validatePrimaryAddress(Address value, ValidationRequest request);	
}
