package com.bmo.channel.pwob.service.user;

public class UserIdInfo {

	private String jobFunction;
	private String firstName;
	private String lastName;

	public UserIdInfo(String firstName, String lastName, String jobFunction) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.jobFunction = jobFunction;
	}

	public String getJobFunction() {
		return jobFunction;
	}
	public void setJobFunction(String jobFunction) {
		this.jobFunction = jobFunction;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
}
