package com.bmo.channel.pwob.service.credential;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.convert.ConvertorService;
import com.bmo.channel.pwob.exception.ExceptionUtils;
import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.ClientAccessIdResponse;
import com.bmo.channel.pwob.model.onboarding.Credential;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.SuggestedUserIds;
import com.bmo.channel.pwob.service.applications.SavedApplicationsService;
import com.bmo.channel.pwob.service.authorization.PwobAction;
import com.bmo.channel.pwob.service.authorization.SecurityService;
import com.bmo.channel.pwob.service.workflow.WorkflowService;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.channel.pwob.util.PwobHeaderInfo;

import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationResponse;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.ApplicationData;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.ClientAccessId;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.AddAccessIdRequestBodyType;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.AddAccessIdRequestPayLoad;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.AddAccessIdResponsePayLoad;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.CheckAccessIdRequestBodyType;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.CheckAccessIdRequestPayload;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.CheckAccessIdResponsePayload;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.ValidateExistingAccessIdRequestBodyType;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.ValidateExistingAccessIdRequestPayload;
import net.bmogc.xmlns.hub.cg.pwob.wealthcredential.intf.types.v1_0.ValidateExistingAccessIdResponsePayload;
import net.bmogc.xmlns.hub.cg.wealthmanagement.wealthcredential.intf.v1_0.HUBError;
import net.bmogc.xmlns.hub.cg.wealthmanagement.wealthcredential.intf.v1_0.WealthCredential;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderResponse;
import net.bmogc.xmlns.huberror._1_0.ServiceResponseMessageType;

/** 
 * For user credential related functionalities.
 *
 */
@Service
public class CredentialServiceImpl implements CredentialService {
	
	private static Logger logger = LoggerFactory.getLogger(CredentialServiceImpl.class);
	
	private static final String PRODUCT_FSB = "FSB";
	private static final String CHANNEL_WEB = "WEB";
	private static final List<String> UserIdNotFound = Arrays.asList(new String[]{
			"VALIDATE.EXISTING.CLIENT.USER.ID.INVALID",
			"VALIDATE.EXISTING.CLIENT.USER.ID.INVALID.NO.ASSOCIATE.ACCOUNT",
			"VALIDATE.EXISTING.CLIENT.USER.ID.BRANCH.INVALID"
	});
	private static final String INVALID_DATA_ERROR_MSG = "Invalid.Missing.Data";

	@Autowired
	private SecurityService securityService;

	@Autowired 
	private SavedApplicationsService savedApplicationsService;

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private ConvertorService convertorService;

	@Autowired
	private WealthCredential wealthCredential;

	@Autowired
	private HubRequestComponent hubRequestComponent;

	@Autowired
	private PwobHeaderInfo headerInfo;

	@Override
	public ClientAccessIdResponse reserveUserCredential(final String applicationId, final Credential credential) {
		final SavedApplication savedApp = savedApplicationsService.retrieveSavedApplication(applicationId);
		
		if (!Optional.ofNullable(savedApp).isPresent()){
			logger.error("Saved application response is null for reserveUserCredential with application id: "+applicationId);
			throw new WebServiceException("Saved Application response is null");
		}
		
		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.UPDATE_APPLICATION);
		
		final RetrieveApplicationResponse retrieveAppResponse = workflowService.retrieveApplicationResponse(savedApp.getWorkflowId(), savedApp.getCustomerId());
		
		if (!Optional.ofNullable(retrieveAppResponse).isPresent()){
			logger.error("Retrieve application response is null for reserveUserCredential with application id: "+applicationId);
			throw new WebServiceException("Retrieve application response is null");
		}
		
		//final XMLGregorianCalendar lastUpdatedDateTime = retrieveAppResponse.getBody().getLastUpdatedDateTime();
		final ApplicationData originalAppData = retrieveAppResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData();
		
		if(originalAppData.getClientAccessId() != null && StringUtils.isNotBlank(originalAppData.getClientAccessId().getUserId())) {
			logger.error("Action 'Update_application' is not allowed with app status: "+savedApp.getAppStatus()+" for user: "+credential.getUserId());
			throw ExceptionUtils.buildStatusExceptionForActionNotAllowedContext(PwobAction.UPDATE_APPLICATION.toString(), savedApp.getAppStatus());
		}
		
		Credential respCredential = new Credential();
		ClientAccessIdResponse accessIdResponse = new ClientAccessIdResponse();
		
		//Do not call add access id if it is an existing gateway id and link to account		
		if(StringUtils.isBlank(credential.getPrimaryAccountNumber())) {
			AddAccessIdResponsePayLoad  response = this.addAccessId(applicationId, credential, savedApp.getCustomerId());			
			accessIdResponse.setTemporaryPassword(response.getAddAccessIdResponseBody().getTempPassword());						
			respCredential.setUserId(response.getAddAccessIdResponseBody().getUserId());
		} else {
			respCredential.setUserId(credential.getUserId());
			respCredential.setPrimaryAccountNumber(credential.getPrimaryAccountNumber());
		}

		accessIdResponse.setCredential(respCredential);
		this.populateCredential2AppData(respCredential, originalAppData);
		final Application application = convertorService.getOnboardApplicationData(applicationId, originalAppData, savedApp.getAppStatus());
		application.setStatus(savedApp.getAppStatus());
		this.workflowService.storeUpdatedApplication(application, originalAppData, applicationId, retrieveAppResponse.getBody());

		if(accessIdResponse.getTemporaryPassword() != null) {
			application.getClientMetadata().put("isGatewayExisting", "false");
		}
		else {
			application.getClientMetadata().put("isGatewayExisting", "true");
		}
		
		List<Party> parties = application.getParties();
		for(Party party : parties){
			if(party.getPersonal() != null && party.getPersonal().getIdentity() != null){
				if(party.getPersonal().getIdentity().getCitizenships() == null){
					party.getPersonal().getIdentity().setCitizenships(new ArrayList<String>());
				}
			}
		}
		
		accessIdResponse.setApplication(application);
		
		return accessIdResponse;
	}
	
	@Override
	public ClientAccessIdResponse retrieveApplicationUserId(final String applicationId) {
		
		final SavedApplication savedApp = savedApplicationsService.retrieveSavedApplication(applicationId);
		
		if (!Optional.ofNullable(savedApp).isPresent()){
			logger.error("Saved application response is null for retrieveApplicationUserId with application id: "+applicationId);
			throw new WebServiceException("Saved Application response is null");
		}
		
		final RetrieveApplicationResponse retrieveAppResponse = workflowService.retrieveApplicationResponse(savedApp.getWorkflowId(), savedApp.getCustomerId());
		
		if (!Optional.ofNullable(retrieveAppResponse).isPresent()){
			logger.error("Retrieve application response is null for retrieveApplicationUserId with application id: "+applicationId);
			throw new WebServiceException("Retrieve application response is null");
		}
		
		final ApplicationData originalAppData  = retrieveAppResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData();
		Credential credential = null;
		
		if(Optional.ofNullable(originalAppData.getClientAccessId()).isPresent()) {
			credential = new Credential();
			credential.setUserId(originalAppData.getClientAccessId().getUserId());
			credential.setPrimaryAccountNumber(originalAppData.getClientAccessId().getPrimaryAccountNumber());
		} else {		
			logger.error("Failed to get application credential for application id: "+applicationId);
			throw new NotFoundException("WealthCredential - Application credential does not exist");
		}				
		ClientAccessIdResponse accessIdResponse = new ClientAccessIdResponse();
		accessIdResponse.setCredential(credential);
    	return accessIdResponse;
	}
	
	@Override
	public SuggestedUserIds retrieveSuggestedUserIds(final String applicationId, final String userIds) {
		
		final SavedApplication savedApp = savedApplicationsService.retrieveSavedApplication(applicationId);
		
		if (!Optional.ofNullable(savedApp).isPresent()){
			logger.error("Saved Application response is null in retrieveSuggestedUserIds for application id: "+applicationId);
			throw new WebServiceException("Saved Application response is null");
		}
		
		CheckAccessIdResponsePayload response = null;
		SuggestedUserIds suggestedUserIds = new SuggestedUserIds();
		suggestedUserIds.setAvailableUserIds(Collections.emptyList());
		CheckAccessIdRequestPayload request = new CheckAccessIdRequestPayload();
		
		CheckAccessIdRequestBodyType requestBody = new CheckAccessIdRequestBodyType();
		requestBody.setChannel(CHANNEL_WEB);		
		requestBody.setProduct(PRODUCT_FSB);
		requestBody.setApplicationId(applicationId);
		requestBody.setUserId(userIds);		
		
		request.setCheckAccessIdRequestBody(requestBody);
		
		final HUBHeaderRequest hubHeaderRequest = buildHUBHeaderRequest("CheckAccessId", applicationId, savedApp.getCustomerId());
		Holder<HUBHeaderResponse> hubHeaderResponse = null;		
		
		try {
			response = wealthCredential.checkAccessId(request, hubHeaderRequest, hubHeaderResponse);
		} catch (HUBError err) {	
			logger.error("Failed to retrieve suggested user ids with applicationId: "+applicationId,
					" and  userId: "+userIds,err);
			if (INVALID_DATA_ERROR_MSG.equalsIgnoreCase(err.getFaultInfo().getErrorCode())) { 
			logger.error("The applicationId: "+applicationId+" or  userId: "+userIds+" is invalid",err);
					throw new NotFoundException("The application id or user id is invalid");
			}
			
			throw new WebServiceException(err);
		}    		
		
		if(!Optional.ofNullable(response).isPresent()) {
			logger.error("WealthCredential - Check Access Id response is null for application id: "+applicationId);
			throw new WebServiceException("WealthCredential - Check Access Id response is null.");
		}
		if(StringUtils.isNoneBlank(response.getCheckAccessIdResponseBody().getUserId())) {
			suggestedUserIds.setAvailableUserIds(Arrays.asList(response.getCheckAccessIdResponseBody().getUserId()));
			return suggestedUserIds;
		} else if(Optional.ofNullable(response.getCheckAccessIdResponseBody().getAvailableUserIdList()).isPresent() &&
				CollectionUtils.isNotEmpty(response.getCheckAccessIdResponseBody().getAvailableUserIdList().getUserId())) {
			suggestedUserIds.setAvailableUserIds(response.getCheckAccessIdResponseBody().getAvailableUserIdList().getUserId());
			return suggestedUserIds;
		}
	
    	return suggestedUserIds;
	}
	
	@Override
	public Credential validateExistingAccessId(final String applicationId, final String userId) {
		
		final SavedApplication savedApp = savedApplicationsService.retrieveSavedApplication(applicationId);
		
		if (!Optional.ofNullable(savedApp).isPresent()){
			logger.error("Saved Application response is null in validateExistingAccessId for application id: "+applicationId);
			throw new WebServiceException("Saved Application response is null");
		}
		
		ValidateExistingAccessIdResponsePayload response = null;
		
		ValidateExistingAccessIdRequestPayload request = new ValidateExistingAccessIdRequestPayload();
		
		ValidateExistingAccessIdRequestBodyType requestBody = new ValidateExistingAccessIdRequestBodyType();
		requestBody.setChannel(CHANNEL_WEB);
		requestBody.setExistingUserId(userId);
		requestBody.setIACode(savedApp.getIaCode());
		requestBody.setProduct(PRODUCT_FSB);
		
		request.setValidateExistingAccessIdRequestBody(requestBody);
		
		final HUBHeaderRequest hubHeaderRequest = buildHUBHeaderRequest("ValidateExistingAccessId", applicationId, savedApp.getCustomerId());
		Holder<HUBHeaderResponse> hubHeaderResponse = null;
		Credential credential = null; 
		
		try {
			response = wealthCredential.validateExistingAccessId(request, hubHeaderRequest, hubHeaderResponse);
		} catch (HUBError e) {
			logger.warn("Failed to validate existing access id for userID: "+userId,e);
			List<ServiceResponseMessageType> serviceResponseMessageList = e.getFaultInfo().getMessageList().getServiceResponseMessage();

			if (serviceResponseMessageList.stream().anyMatch(message -> UserIdNotFound.contains(message.getMessageCode()))) { 
				logger.error("User id not found, userId: "+userId,e);	
				throw new NotFoundException("User Id not found");
			}
			
			throw new WebServiceException(e);
		}    		
		
		if(!Optional.ofNullable(response).isPresent()) {
			logger.error("Validate Existing Access Id response is null with userId: "+userId);
			throw new WebServiceException("WealthCredential - Validate Existing Access Id response is null.");
		}
		if(!Optional.ofNullable(response.getValidateExistingAccessIdResponseBody().getUserIdORaliasId()).isPresent() && 
				!Optional.ofNullable(response.getValidateExistingAccessIdResponseBody().getExistingPrimaryAccountNumber()).isPresent()) {
			logger.error("Access Id is not a valid user Id with userId: "+userId);
			throw new NotFoundException("WealthCredential - Access Id is not a valid user Id");
		}
		if(Optional.ofNullable(response.getValidateExistingAccessIdResponseBody()).isPresent()) {
			credential = new Credential();
			credential.setPrimaryAccountNumber(response.getValidateExistingAccessIdResponseBody().getExistingPrimaryAccountNumber());
			credential.setUserId(response.getValidateExistingAccessIdResponseBody().getUserIdORaliasId());
			if(!Optional.ofNullable(response.getValidateExistingAccessIdResponseBody().getUserIdORaliasId()).isPresent()) {
				credential.setUserId(response.getValidateExistingAccessIdResponseBody().getExistingPrimaryAccountNumber());
			}
			credential.setFirstName(response.getValidateExistingAccessIdResponseBody().getFirstName());
			credential.setLastName(response.getValidateExistingAccessIdResponseBody().getLastName());
		}	
    		
    	return credential;
	}
	
	public AddAccessIdResponsePayLoad addAccessId(final String applicationId, final Credential credential, final String ecifId) {
		final AddAccessIdRequestPayLoad payloadRequest = new AddAccessIdRequestPayLoad();
		final AddAccessIdRequestBodyType addAccessIdRequestBodyType = new AddAccessIdRequestBodyType();
		
		addAccessIdRequestBodyType.setApplicationId(applicationId);
		addAccessIdRequestBodyType.setSelectedUserId(credential.getUserId());
		addAccessIdRequestBodyType.setChannel(CHANNEL_WEB);
		addAccessIdRequestBodyType.setProduct(PRODUCT_FSB);
		
		payloadRequest.setAddAccessIdRequestBody(addAccessIdRequestBodyType);
		
		final HUBHeaderRequest requestHeader = buildHUBHeaderRequest("AddAccessId", applicationId, ecifId);
		Holder<HUBHeaderResponse> hubHeaderResponse = null;
		AddAccessIdResponsePayLoad response =  null;
    	try {
    		response = wealthCredential.addAccessId(payloadRequest, requestHeader, hubHeaderResponse);
    	
    		if(!Optional.ofNullable(response).isPresent()) {
    			logger.error("WealthCredential Add Access Id response is null for applicationId: "+applicationId);
				throw new WebServiceException("WealthCredential Add Access Id response is null.");
			}
    		if(!Optional.ofNullable(response.getAddAccessIdResponseBody().getUserId()).isPresent()) {
    			logger.error("WealthCredential Add Access Id response is empty for applicationId: "+applicationId);
				throw new NotFoundException("WealthCredential Add Access Id response empty.");
			}
		} catch (NotFoundException ex){ 
			logger.error("error generated when adding the access id for application id: ",applicationId, ex);
			throw new NotFoundException(ex.getMessage());
		} catch (Exception ex) {
			logger.error("error generated when adding the access id for application id: ",applicationId, ex);
    		throw new WebServiceException(ex);
    	}
    	return response;
	}
	
	private HUBHeaderRequest buildHUBHeaderRequest(final String functionName, final String workflowId, final String ecifId) {
		return hubRequestComponent
				.getHubBuilder()
				.originatorResource("OnboardApplication")
				.originatorResourceFunction(functionName)
				.originatorLocationId(headerInfo.getRemoteAddress())
				.partyId(ecifId)
				.packageId(null)
				.documentId(null)
				.workflowId(workflowId)
				.build();
	}
	
	protected void populateCredential2AppData(final Credential credential, final ApplicationData applicationData) {
		
		final ClientAccessId clientAccessId = new ClientAccessId();
		clientAccessId.setHasDeclinedOnlineAccess(Boolean.FALSE);
		clientAccessId.setPrimaryAccountNumber(credential.getPrimaryAccountNumber());
		clientAccessId.setUserId(credential.getUserId());
		applicationData.setClientAccessId(clientAccessId);
	}
}
