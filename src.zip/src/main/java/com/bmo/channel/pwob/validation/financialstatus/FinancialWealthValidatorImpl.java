package com.bmo.channel.pwob.validation.financialstatus;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.FinancialWealth;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.Patterns;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class FinancialWealthValidatorImpl extends AbstractBaseValidator implements FinancialWealthValidator{
	
	@Autowired 	UsersService userService;	
	
	public boolean isValid(FinancialWealth value, ValidationRequest validationRequest) {
		final ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}
		
		boolean valid = true;

		if(ApplicationLob.nb == this.userService.currentUser().getLob()) {
				
			if(!Optional.ofNullable(value.getIsBorrowingToInvest()).isPresent()) {				
				validationRequest.addConstraintViolation("isBorrowingToInvest",ErrorCodes.INVALID_IS_BORROWING_TO_INVEST);
				valid = false;
			}
			
			if(value.getHasOtherInvestmentAccounts() == null) {
				validationRequest.addConstraintViolation("hasOtherInvestmentAccounts",ErrorCodes.INVALID_HAS_OTHER_INVESTMENT_ACCT);
				valid = false;
			}

		}
		
		 if(value.getHasOtherInvestmentAccounts()!=null && 
				 value.getHasOtherInvestmentAccounts() && StringUtils.isBlank(value.getOtherInvestmentInstitution())){
			 validationRequest.addConstraintViolation("otherInvestmentInstitution",ErrorCodes.INVALID_OTHER_INVESTMENT_INSTITUTION);
				valid = false;
		}
		
		if(value.getSourcesOfWealth() == null || value.getSourcesOfWealth().isEmpty()) {			
			validationRequest.addConstraintViolation("sourcesOfWealth",ErrorCodes.INVALID_SRC_WEALTH);
			valid = false;
		} else {
			if(value.getSourcesOfWealth().contains(RefDataValues.WEALTH_SOURCE_OTHER) && isInvalidOtherSourceOfWealth(value.getOtherSourceOfWealth())) {
				validationRequest.addConstraintViolation("otherSourceOfWealth",ErrorCodes.INVALID_OTHER_SOURCE_WEALTH);
				valid = false;
			}
		}				
		return valid;
	}

	boolean isInvalidOtherSourceOfWealth(String otherSourceOfWealth) {
		return StringUtils.isBlank(otherSourceOfWealth) || ! otherSourceOfWealth.matches("^[" + Patterns.FRALPHANUMERIC + "]{1,30}$");
	}


}
