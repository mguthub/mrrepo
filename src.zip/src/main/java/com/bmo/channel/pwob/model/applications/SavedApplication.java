package com.bmo.channel.pwob.model.applications;

import java.util.ArrayList;
import java.util.List;

public class SavedApplication {
	private String workflowId;	 
	private String customerId;
	private String lastUpdated;
	private String lastUpdatedBy;
	private String appStatus;
	private String clientFirstName;
	private String clientLastName;
	private String applicationNumber;
	
	public static final String IA_CODE = "iaCode";
	public static final String UPDATE_TIMESTAMP = "lastUpdatedByTimestamp";
	public static final String UPDATE_BY = "lastUpdatedBy";
	public static final String ACCOUNT_TYPE= "accountType";
	
	private List<SavedApplicationsAccount> accounts = new ArrayList<SavedApplicationsAccount>();
	private String iaCode;
	
	public String getWorkflowId() {
		return workflowId;
	}
	public void setWorkflowId(String workflowId) {
		this.workflowId = workflowId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}
	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}
	public String getAppStatus() {
		return appStatus;
	}
	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}
	public String getClientFirstName() {
		return clientFirstName;
	}
	public void setClientFirstName(String clientFirstName) {
		this.clientFirstName = clientFirstName;
	}
	public String getClientLastName() {
		return clientLastName;
	}
	public void setClientLastName(String clientLastName) {
		this.clientLastName = clientLastName;
	}
	public String getIaCode() {
		return iaCode;
	}
	public void setIaCode(String iaCode) {
		this.iaCode = iaCode;
	}
	
	public List<SavedApplicationsAccount> getAccounts() {
		return accounts;
	}
	 void setAccounts(List<SavedApplicationsAccount> accounts) {
		this.accounts = accounts;
	}

	public void addSavedApplicationAccount(SavedApplicationsAccount account) {
		accounts.add(account);
	}
	
	public String getApplicationNumber() {
		return applicationNumber;
	}
	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}
}
