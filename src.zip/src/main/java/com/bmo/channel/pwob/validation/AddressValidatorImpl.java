package com.bmo.channel.pwob.validation;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class AddressValidatorImpl extends AbstractBaseValidator implements AddressValidator {

	@Override
	public boolean validatePostalCode(ValidationRequest validationRequest) {
		validationRequest.setFieldName(POSTAL_CODE_FIELD_NAME);
		validationRequest.setErrorCode(ErrorCodes.INVALID_POSTAL_CODE);
		return validateAndAddConstraintViolation(validationRequest);
	}

	@Override
	public boolean validateStreetAddress(ValidationRequest validationRequest) {
		validationRequest.setFieldName(STREET_ADDRESS_FIELD_NAME);
		validationRequest.setErrorCode(ErrorCodes.INVALID_STREET_ADDR);
		return validateAndAddConstraintViolation(validationRequest);
	}

	@Override
	public boolean validateUnitNumber(ValidationRequest validationRequest) {
		validationRequest.setFieldName(UNIT_NUMBER_FIELD_NAME);
		validationRequest.setErrorCode(ErrorCodes.INVALID_UNIT_NUMBER);
		if(StringUtils.isNoneBlank(validationRequest.getFieldValue())) {
			return validateAndAddConstraintViolation(validationRequest);
		}
		return true;		
	}

	@Override
	public boolean validateCity(ValidationRequest validationRequest) {
		validationRequest.setFieldName(CITY_FIELD_NAME);
		validationRequest.setErrorCode(ErrorCodes.INVALID_CITY);				
		return validateAndAddConstraintViolation(validationRequest);
	}

	@Override
	public boolean validateCountry(ValidationRequest validationRequest) {
		validationRequest.setFieldName(COUNTRY_FIELD_NAME);
		validationRequest.setErrorCode(ErrorCodes.INVALID_COUNTRY);
		return validateAndAddConstraintViolation(validationRequest);
	}

	@Override
	public boolean validateRecipient(ValidationRequest request) {
		request.setFieldName(RECIPIENT_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_RECIPIENT);
		return this.validateField(request);
	}

	@Override
	protected boolean validateAndAddConstraintViolation(ValidationRequest request) {
		boolean valid = StringUtils.isNotBlank(request.getFieldValue()) && isValidField(request);				
		if(!valid) {
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}
		}
		return valid;
	}

	private boolean isValidField(ValidationRequest validationRequest) {				
		String fullFieldPath = validationRequest.calculateFullFieldPath().replaceAll("\\d+", "");
		String regex = this.retrievePatternForFieldAndLob(validationRequest.getLob(), fullFieldPath);
		return (StringUtils.isNoneBlank(regex) && validationRequest.getFieldValue().matches(regex));
	}

	@Override
	public boolean validateUnitStreetCityPostalCountry(ValidationRequest request, Address address) {
		boolean valid = true;
		
		request.setFieldValue(address.getUnitNumber());
		valid = validateUnitNumber(request) && valid;
		
		request.setFieldValue(address.getStreetAddress());
		valid = validateStreetAddress(request) && valid;
		
		request.setFieldValue(address.getCity());
		valid = validateCity(request) && valid;
		
		String country = address.getCountry();
		request.setFieldValue(country);
		valid = validateCountry(request) && valid;
		
		if(RefDataValues.USA_COUNTRY_CODE.equals(country)) {
			request.setFieldValue(address.getPostalCode());
			valid = validatePostalCode(request) && valid;
		}else if(RefDataValues.CANADA_COUNTRY_CODE.equals(country)){  
			request.setFieldValue(address.getPostalCode());
			valid = validateCanadianPostalCode(request) && valid; 
		}
		return valid;
	}
	
	private boolean validateCanadianPostalCode(ValidationRequest request) {		
		request.setFieldName(POSTAL_CODE_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_POSTAL_CODE);
		boolean valid = isValidCanadianPostalCode(request.getFieldValue());
		if(!valid) {
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}
		}
		return valid;
	}

}
