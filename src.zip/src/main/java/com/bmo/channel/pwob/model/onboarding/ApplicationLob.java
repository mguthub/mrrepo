package com.bmo.channel.pwob.model.onboarding;

/**
 * Line of business.
 */
public enum ApplicationLob {
	il, nb
}