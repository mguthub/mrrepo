package com.bmo.channel.pwob.service.risprefill;

import java.io.IOException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.accounts.AccountDetailsRequest;
import com.bmo.accounts.AccountDetailsResponse;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.service.contractv6.ContractService;
import com.bmo.channel.pwob.service.digitaltoken.DigitalTokenService;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.channel.pwob.validation.risprefill.RisPrefillValidator;
import com.bmo.onboarding.IndividualParty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import net.bmogc.xmlns.hub.cg.wealthmanagement.risaccountreporting.intf.types.v1.GetAccountDetailsRequestType;
import net.bmogc.xmlns.hub.cg.wealthmanagement.risaccountreporting.intf.types.v1.GetAccountDetailsResponseType;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

@Service
public class RisPrefillServiceImpl implements RisPrefillService {

	private static Logger logger = LoggerFactory.getLogger(RisPrefillServiceImpl.class);
	
	@Autowired
	DigitalTokenService digitalTokenService;
	
	@Autowired
	RisMappingService risMappingService;
	

	@Autowired
	ContractService contractService;
	
	@Autowired
	RisPrefillValidator risPrefillValidator;
	
	@Autowired
	RisAccountSearchEndpointInterface risAccountSearchEndpointInterface;
	
	@Autowired
	private HubRequestComponent hubRequestComponent;
	
	@Autowired
	private UserContext userContext;
	
	@Override
	public List<Party> getParties(String token, NewWorkflowRequest request) {
		String payload = digitalTokenService.validateToken(token);
		AccountDetailsResponse risModel = deserialize(payload);
		request.setEcifId(contractService.retrieveEcifId(risModel));		
		return risMappingService.mapRisPayload(risModel);
	}

	@Override
	public NewWorkflowRequest searchForParty(String accountNumber) {

		//run search with account Number
		AccountDetailsResponse accountDetails = getRisResponse(accountNumber).getGetAccountDetailsResponseBody();

		IndividualParty risPrimary = risMappingService.fetchRisPrimaryParty(accountDetails);
		if(risPrimary != null){
			risPrefillValidator.primaryApplicantNamesValidator(risPrimary);
			risPrefillValidator.primaryApplicantPrimaryAddressValidator(risPrimary,accountNumber);
			
		}
		
		NewWorkflowRequest response = new NewWorkflowRequest();
		risMappingService.fetchPayloadName(response, accountDetails);

		String serialized = serialize(accountDetails);
		response.setRisToken(digitalTokenService.generateToken(serialized));
		return response;
	}
	

	private String serialize(AccountDetailsResponse model) {

		String serialized = null;
		
		try {
			ObjectMapper mapper = new ObjectMapper();
			serialized = mapper.writeValueAsString(model);
		} catch (IOException ex) {
			logger.error("Failed to serialize account details response :", ex);
			throw new WebServiceException(ex);
		}
		
		return serialized;
	}
	
	private AccountDetailsResponse deserialize(String payload) {
		AccountDetailsResponse response = null;
		
		try {
			ObjectMapper mapper = new ObjectMapper();
			response = mapper.readValue(payload, AccountDetailsResponse.class);
		} catch (IOException ex) {
			logger.error("Failed to deSerialize account details response :", ex);
			throw new WebServiceException(ex);
		}
		
		return response;
	}

	private HUBHeaderRequest createHeader() {
		return hubRequestComponent
				.getHubBuilder()
				.originatorResource("RISAccountReporting")
				.originatorResourceFunction("getAccountDetails")
				.build();
	}
	
	String generateHeaderString(final HUBHeaderRequest requestHeader) throws JsonProcessingException {
		return ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
	}
	
	private GetAccountDetailsResponseType getRisResponse(String accountNumber) {
		
		/*Currently myWealth only supports nestbitts Burns accounts (channel= WEB.ASSIT and Product = FSB)
		 * In future it will support Invester line accounts also (Channel= WEB.SS and Product = SD)
		 * 
		 */
		GetAccountDetailsRequestType requestWrapper = new GetAccountDetailsRequestType();
		AccountDetailsRequest accountDetailsRequest = new AccountDetailsRequest();
		accountDetailsRequest.setAccountId(accountNumber);
		accountDetailsRequest.setApplicationId("AccountDetails");
		accountDetailsRequest.setChannel("WEB.ASSIST");
		accountDetailsRequest.setProduct("FSB");
		accountDetailsRequest.setIncludeAll(true);
		accountDetailsRequest.setIncludeCreditEventData(true);
		accountDetailsRequest.setIncludeEmploymentInfo(true);
		accountDetailsRequest.setIncludeContactInfo(true);
		accountDetailsRequest.setIncludePersonalInfo(true);
		accountDetailsRequest.setIncludeBeneficiaryInfo(true);
		accountDetailsRequest.setDateTimeOffset(-1);
		accountDetailsRequest.setNetworkId(userContext.getAuthenticatedUser().getNetworkId());
		
		GetAccountDetailsRequestType.KeyPairs kp = new GetAccountDetailsRequestType.KeyPairs();
		kp.getKeyPair();		
		requestWrapper.setKeyPairs(kp);
		
		requestWrapper.setGetAccountDetailsRequestBody(accountDetailsRequest);
					
		try {
		return risAccountSearchEndpointInterface.getAccountDetails(requestWrapper, generateHeaderString(createHeader()));
		} catch (JsonProcessingException ex) {
			logger.error("Failed to get account details for RIS response: ", accountNumber, ex);
			throw new WebServiceException(ex);
		}		
	}	
}
