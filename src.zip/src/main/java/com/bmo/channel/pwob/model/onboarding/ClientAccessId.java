package com.bmo.channel.pwob.model.onboarding;

import com.bmo.channel.pwob.validation.credentials.ValidCredentials;

import io.swagger.annotations.ApiModelProperty;

@ValidCredentials
public class ClientAccessId {
	@ApiModelProperty(example = "True", value = "Flag it to True when the user declined for online access")
	private Boolean hasDeclinedOnlineAccess;
		
	public Boolean getHasDeclinedOnlineAccess() {
		return hasDeclinedOnlineAccess;
	}

	public void setHasDeclinedOnlineAccess(Boolean hasDeclinedOnlineAccess) {
		this.hasDeclinedOnlineAccess = hasDeclinedOnlineAccess;
	}
	
	
}
