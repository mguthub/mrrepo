package com.bmo.channel.pwob.service.documentpackages.dto;

import java.util.List;

public class DocumentPackageDto {
	private String id;	 
	private String packageCreateDate;	 
	private String documentReceivedDate;	
	private String status;	
	private String type;
	private List<DocumentDto> documents;	 
	private List<SignerDto> signers;
	private List<LabelDto> labels;
	private String locale;
	private List<String> errors;
	private String signatureType;
	
	public String getDocumentReceivedDate() {
		return documentReceivedDate;
	}
	public void setDocumentReceivedDate(String documentReceivedDate) {
		this.documentReceivedDate = documentReceivedDate;
	}
	
	public String getId() {
		return id;
	}
	public void setId(final String packageId) {
		this.id = packageId;
	}
	public String getPackageCreateDate() {
		return packageCreateDate;
	}
	public void setPackageCreateDate(final String packageCreateDate) {
		this.packageCreateDate = packageCreateDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(final String status) {
		this.status = status;
	}
	public String getType() {
		return type;
	}
	public void setType(final String type) {
		this.type = type;
	}
	public List<DocumentDto> getDocuments() {
		return documents;
	}
	public void setDocuments(final List<DocumentDto> documents) {
		this.documents = documents;
	}
	public List<SignerDto> getSigners() {
		return signers;
	}
	public void setSigners(final List<SignerDto> signers) {
		this.signers = signers;
	}
	public void setLabels(final List<LabelDto> labels) {
		this.labels = labels;
	}
	public List<LabelDto> getLabels() {
		return labels;
	}
	public void setLocale(final String locale) {
		this.locale = locale;
	}
	public String getLocale() {
		return locale;
	}
	public List<String> getErrors() {
		return errors;
	}
	public void setErrors(final List<String> errors) {
		this.errors = errors;
	}
	public String getSignatureType() {
		return signatureType;
	}
	public void setSignatureType(final String signatureType) {
		this.signatureType = signatureType;
	}
}
