package com.bmo.channel.pwob.validation.financialstatus;

import com.bmo.channel.pwob.model.onboarding.NetWorth;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface NetWorthValidator {
	public boolean isValid(NetWorth value, ValidationRequest validationRequest);
}
