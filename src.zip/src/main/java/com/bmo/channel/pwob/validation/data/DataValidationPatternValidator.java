package com.bmo.channel.pwob.validation.data;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.field.FieldPathExtractor;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;

public class DataValidationPatternValidator extends AbstractBaseValidator implements ConstraintValidator<DataValidationPattern, String> {

	private String code;

	@Autowired
	private FieldPathExtractor fieldPathExtractor;

	@Autowired 	
	private UsersService userService;

	@Override
	public void initialize(DataValidationPattern constraint) {
		code = constraint.code();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		ValidationContextHolder validationContextHolder = ValidationManager.validationContext.get();
		if(validationContextHolder.getAction() == Action.SAVE) {
			// null / empty allowed
			if(StringUtils.isBlank(value)) {
				return true;
			}
		}

		String fieldPath = fieldPathExtractor.determineFieldPath(context);
		String regex = this.retrievePatternForFieldAndLob(this.userService.currentUser().getLob(), fieldPath);

		if (regex != null && !matchesPattern(value, regex)) {
			this.createConstraintViolation(context, code, null);
			return false;
		}

   		return true;
	}

	boolean matchesPattern(String value, String regex) {
		if(value == null) {
			// will get NPE if applying regular expression to null, so use empty string instead
			return "".matches(regex);
		} else {
			boolean matches = value.matches(regex);
			return matches;
		}
	}

}
