package com.bmo.channel.workflows.parties.service;

import java.util.ArrayList;
import java.util.ListIterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.common.domain.party.Person;
import com.bmo.channel.core.mapping.DataMapper;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.Residence;

@Component
public class PartyMapperImpl implements PartyMapper {
	public static final String RESIDENTIAL_PRIMARY_PHONE_CODE = "100000";
	public static final String RESIDENTIAL_SECONDARY_PHONE_CODE = "100002";
	public static final String PERMANENT_RESIDENTIAL_LEGAL_ADDRESS_CODE = "100010";
	public static final String PREVIOUS_RESIDENTIAL_ADDRESS_CODE = "100047";
	public static final String RESIDENTIAL_PRIMARY_EMAIL_CODE = "100008";
	public static final String LEGAL_NAME_CODE = "1";
	public static final String PREFERRED_NAME_CODE = "100002";

	@Autowired
	private DataMapper mapper;

	@Override
	public Person mapPartyCreate(String firstName, String lastName) {
		Person person = new Person();
		person.setNames(new ArrayList<com.bmo.channel.common.domain.party.Name>());
		com.bmo.channel.common.domain.party.Name personName = new com.bmo.channel.common.domain.party.Name();
		personName.setFirstName(firstName);
		personName.setLastName(lastName);
		personName.setNameUsageType(LEGAL_NAME_CODE);
		person.getNames().add(personName);
		person.setLangType("888888");
		return person;
	}

	@Override
	public Party mapPerson(Person person) {
		Party party = mapper.map(person, Party.class);
		
		populatePartyNames(person, party.getPersonal().getIdentity());
		populatePartyAddresses(person, party.getPersonal().getResidence());
		populatePartyPhones(person, party.getPersonal().getResidence());
		populateDependentsFlag(person, party.getPersonal().getIdentity());
		populateEmail(person,party.getPersonal().getIdentity());
		
		return party;
	}

	private void populateEmail(Person person, Identity identity) {
		ListIterator<com.bmo.channel.common.domain.party.Email> personEmailIt = person.getEmails().listIterator();
		while(personEmailIt.hasNext()){
			com.bmo.channel.common.domain.party.Email personEmail = personEmailIt.next();
			if(personEmail.getType().equals(RESIDENTIAL_PRIMARY_EMAIL_CODE)){
				identity.setPrimaryEmailAddress(personEmail.getAddress());
				break;
			}
		}
	}

	private void populateDependentsFlag(Person person, Identity identity) {
		if(identity.getNumOfDependents()!=null && identity.getNumOfDependents()>0){
			identity.setHasDependents(true);
		}
		else{
			identity.setHasDependents(false);
		}	
	}

	private void populatePartyPhones(Person person, Residence residence) {
		ListIterator<com.bmo.channel.common.domain.party.Phone> personPhoneIt = person.getPhones().listIterator();
		while(personPhoneIt.hasNext()){
			com.bmo.channel.common.domain.party.Phone personPhone = personPhoneIt.next();
			
			if(personPhone.getType().equals(RESIDENTIAL_PRIMARY_PHONE_CODE)){
				com.bmo.channel.pwob.model.onboarding.Phone partyPhone = mapper.map(personPhone, com.bmo.channel.pwob.model.onboarding.Phone.class);
				residence.setPrimaryPhone(partyPhone);
				continue;
			}
			else if(personPhone.getType().equals(RESIDENTIAL_SECONDARY_PHONE_CODE)){
				com.bmo.channel.pwob.model.onboarding.Phone partyPhone = mapper.map(personPhone, com.bmo.channel.pwob.model.onboarding.Phone.class);
				residence.setSecondaryPhone(partyPhone);
			}
		}
	}

	private void populatePartyAddresses(Person person, Residence residence) {
		ListIterator<com.bmo.channel.common.domain.party.Address> personAddressesIt = person.getAddresses().listIterator();
		while(personAddressesIt.hasNext()){
			com.bmo.channel.common.domain.party.Address personAddress = personAddressesIt.next();
			
			if(personAddress.getAddressType().equals(PERMANENT_RESIDENTIAL_LEGAL_ADDRESS_CODE)){
				com.bmo.channel.pwob.model.onboarding.Address partyAddress = mapper.map(personAddress, com.bmo.channel.pwob.model.onboarding.Address.class);
				partyAddress.setStreetAddress(personAddress.getStreetNumber() + " " + personAddress.getStreetName());
				residence.setPrimaryAddress(partyAddress);
				continue;
			}
			else if(personAddress.getAddressType().equals(PREVIOUS_RESIDENTIAL_ADDRESS_CODE)){
				com.bmo.channel.pwob.model.onboarding.Address partyAddress = mapper.map(personAddress, com.bmo.channel.pwob.model.onboarding.Address.class);
				partyAddress.setStreetAddress(personAddress.getStreetNumber() + " " + personAddress.getStreetName());
				residence.setPreviousAddress(partyAddress);
			}
		}
	}

	private void populatePartyNames(Person person, Identity identity) {
		ListIterator<com.bmo.channel.common.domain.party.Name> personNamesIt = person.getNames().listIterator();
		while(personNamesIt.hasNext()){
			com.bmo.channel.common.domain.party.Name personName = personNamesIt.next();
			
			if(personName.getNameUsageType().equals(LEGAL_NAME_CODE)){
				com.bmo.channel.pwob.model.onboarding.Name partyName = mapper.map(personName, com.bmo.channel.pwob.model.onboarding.Name.class);
				identity.setLegalName(partyName);
				continue;
			}
			else if(personName.getNameUsageType().equals(PREFERRED_NAME_CODE)){
				com.bmo.channel.pwob.model.onboarding.Name partyName = mapper.map(personName, com.bmo.channel.pwob.model.onboarding.Name.class);
				identity.setPreferredName(partyName);
				identity.setHasPreferredName(true);
			}
		}
		if(identity.getHasPreferredName()==null){
			identity.setHasPreferredName(false);
		}
	}
}
