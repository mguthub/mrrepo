package com.bmo.channel.pwob.service.party;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;

import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.model.onboarding.FinancialInformation;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.InvestmentObjectives;
import com.bmo.channel.pwob.model.onboarding.Name;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.Phone;
import com.bmo.channel.pwob.model.onboarding.Preferences;
import com.bmo.channel.pwob.model.onboarding.RegulatoryDisclosures;
import com.bmo.channel.pwob.model.onboarding.Residence;
import com.bmo.channel.pwob.model.onboarding.Taxation;

@Component
public class PartyFactoryImpl implements PartyFactory {

	@Override
	public Party createPrimaryApplicantParty(Party party) {
		
		party.setRoles(Arrays.asList(PartyRole.PRIMARY_APPLICANT));
		party.setPartyRefId(UUID.randomUUID().toString());
		
		this.createIdentityObject(party);		
		this.createResidenceObject(party);
		this.createEmploymentObject(party);
		this.createTaxResidency(party);
		this.createPartyLevelObject(party);	
	
		return party;
	}
	
	@Override
	public Party createJointApplicantParty(Party party) {
		
		party.setRoles(Arrays.asList(PartyRole.JOINT_APPLICANT));
		party.setPartyRefId(UUID.randomUUID().toString());
		
		this.createIdentityObject(party);		
		this.createResidenceObject(party);
		this.createEmploymentObject(party);
		this.createTaxResidency(party);
		this.createPartyLevelObject(party);	
	
		return party;
	}
	
	@Override
	public Party createSpouseParty(Party spouse, Party party) {
		party.setPartyRefId(UUID.randomUUID().toString());
		party.setSpousePartyRefId(spouse.getPartyRefId());
		this.createIdentityObject(party);
		this.createEmploymentObject(party);		
		
		return party;
	}

	
	private void createIdentityObject(Party party) {
		PersonalInformation personal = party.getPersonal();
		personal.setIdentity(new Identity());
		personal.getIdentity().setPreferredName(new Name());				
		personal.getIdentity().setCitizenships(new ArrayList<>());
		
		party.setPersonal(personal);			
	}	
	
	private void createResidenceObject(Party party) {
		Residence residence = party.getPersonal().getResidence();
		
		residence.setPrimaryAddress(new Address());
		residence.setPreviousAddress(new Address());
		residence.setPrimaryPhone(new Phone());
		residence.setSecondaryPhone(new Phone());
		
		party.getPersonal().setResidence(residence);
	}
	
	private void createEmploymentObject(Party party) {
		PersonalInformation personal = party.getPersonal();
		
		personal.setEmployment(new Employment());
		
		personal.getEmployment().setPrimaryBusinessPhone(new Phone());
		personal.getEmployment().setEmploymentAddress(new Address());
		
		party.setPersonal(personal);
	}
	
	private void createTaxResidency(Party party) {
		PersonalInformation personal = party.getPersonal();				
		personal.setResidencyForTax(new ArrayList<>());
		party.setPersonal(personal);
	}
	
	private void createPartyLevelObject(Party party) {
		party.setFinancial(new FinancialInformation());
		party.setInvestmentObjectives(new InvestmentObjectives());
		party.setPreferences(new Preferences());
		party.setTaxation(new Taxation());
		party.setRegulatoryDisclosures(new RegulatoryDisclosures());
	}
}
