package com.bmo.channel.pwob.service.reference;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.bmo.channel.pwob.service.reference.model.GetDataListForParameterRequest;
import com.bmo.channel.pwob.service.reference.model.GetDataListForParameterResponse;

@Produces(MediaType.APPLICATION_JSON)
public interface ReferenceDataServiceEndpointInterface {

	@POST
	public GetDataListForParameterResponse getDataListForParameter(@RequestBody GetDataListForParameterRequest requestWrapper, 
			@HeaderParam("hubHeader") String requestHeader);
}
