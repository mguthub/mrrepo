package com.bmo.channel.pwob.validation.ia;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.bmo.channel.pwob.model.ia.IaAccount;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;

public class IaAccountValidator extends AbstractBaseValidator implements ConstraintValidator<ValidIaAccount, IaAccount> {
	
	private static final String FEE_BASED_PAYMENT_TYPE = "1";
	private static final String COMMISSION_PAYMENT_TYPE = "2";
	
	@Override
	public void initialize(ValidIaAccount constraintAnnotation) {
	}

	@Override
	public boolean isValid(IaAccount account, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		
		boolean valid = true;
		valid = validateFeeType(account, context, validationContext.getApplication()) && valid;
		
		return valid;
	}

	private boolean validateFeeType(IaAccount account, ConstraintValidatorContext context, Application applicationContext) {
		Optional<Account> ref = applicationContext.getAccounts().stream().filter(c-> c.getAccountNumber().equals(account.getAccountNumber())).findFirst();
		if (ref.isPresent() && !ref.get().isIndividual() && !ref.get().isJoint()) {
			
			if (account.getPaymentType().equals(FEE_BASED_PAYMENT_TYPE) && account.getFeeType() != null) {
				this.createConstraintViolation(context, ErrorCodes.INVALID_FEE_TYPE_FOR_PAYMENT_TYPE, "feeType");
				return false;
			}
			else if (account.getPaymentType().equals(COMMISSION_PAYMENT_TYPE) && account.getFeeType() == null) {
				this.createConstraintViolation(context, ErrorCodes.INVALID_FEE_TYPE_FOR_PAYMENT_TYPE, "feeType");
				return false;
			}
		} else if (ref.isPresent()) { //individual accounts don't have fee codes
			if (account.getFeeType() != null) {
				this.createConstraintViolation(context, ErrorCodes.INVALID_FEE_TYPE, "feeType");
				return false;
			}
		}
		
		return true;
	}

}
