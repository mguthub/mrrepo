/**
 * @author akhales
 */
package com.bmo.channel.pwob.model;

public enum UILocale {
	EN_CA("en-ca"),
	FR_CA("fr-ca");

	private String  lang;

	private UILocale(String language) {
		this.lang = language;
	}

	public String getLang() {
		return this.lang;
	}

	public static UILocale parse(String language) {
		for (UILocale item:UILocale.values()) {
			if (item.getLang().equalsIgnoreCase(language)) {
				return item;
			}
		}
		// default value
		return UILocale.EN_CA;
	}
}
