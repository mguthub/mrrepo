package com.bmo.channel.pwob.service.authorization;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

import com.bmo.channel.pwob.model.onboarding.AppStatus;

public class StatusMap {
	public final static String ANY_APP_STATUS = "*";

	private static Map<PwobAction, StatusChangeRequirement> statuses;

	public static StatusChangeRequirement getRequirements(PwobAction function){
		return statuses.get(function);
	}

	static {
		statuses = new EnumMap<>(PwobAction.class);

		populateAcceptableStatuses(PwobAction.CREATE_APPLICATION, Arrays.asList(ANY_APP_STATUS));

		populateAcceptableStatuses(PwobAction.UPDATE_APPLICATION, Arrays.asList(AppStatus.DATA_COLLECTION.toString()));

		populateAcceptableStatuses(PwobAction.UPDATE_RELATIONSHIP_SUMMARY, Arrays.asList(AppStatus.ACCOUNT_SETUP.toString()));
		
		populateAcceptableStatuses(PwobAction.RETRIEVE_RELATIONSHIP_SUMMARY, Arrays.asList(AppStatus.ACCOUNT_SETUP.toString()));

		populateAcceptableStatuses(PwobAction.IA_APPROVAL, Arrays.asList(AppStatus.IA_APPROVAL.toString(), AppStatus.IA_REMEDIATION.toString(), AppStatus.CONDITIONALLY_APPROVED.toString()));

		populateAcceptableStatuses(PwobAction.BM_APPROVAL, Arrays.asList(AppStatus.BM_APPROVAL.toString()));

		populateAcceptableStatuses(PwobAction.DELETE_WORKFLOW, Arrays.asList(AppStatus.IA_APPROVAL.toString(),
															AppStatus.IA_REMEDIATION.toString(),
															AppStatus.DOCUMENT_COLLECTION.toString(),
															AppStatus.ACCOUNT_SETUP.toString(),
															AppStatus.BM_APPROVAL.toString(),
															AppStatus.DATA_COLLECTION.toString()));

		populateAcceptableStatuses(PwobAction.UNLOCK_DATA, Arrays.asList(AppStatus.DOCUMENT_COLLECTION.toString(),
															AppStatus.ACCOUNT_SETUP.toString(),
															AppStatus.IA_APPROVAL.toString(),
															AppStatus.IA_REMEDIATION.toString()));

        populateAcceptableStatuses(PwobAction.GENERATE_DOCUMENTS, Arrays.asList(AppStatus.DATA_COLLECTION.toString()));        

        populateAcceptableStatuses(PwobAction.UPLOAD_DOCUMENT, Arrays.asList(AppStatus.DOCUMENT_COLLECTION.toString(),
        													AppStatus.ACCOUNT_SETUP.toString(),
													        AppStatus.IA_APPROVAL.toString(),
															AppStatus.IA_REMEDIATION.toString()));        	

        populateAcceptableStatuses(PwobAction.DOCUMENT_ACTION, Arrays.asList(AppStatus.DOCUMENT_COLLECTION.toString(),
															AppStatus.ACCOUNT_SETUP.toString(),
													        AppStatus.IA_APPROVAL.toString(),
													        AppStatus.BM_APPROVAL.toString(),
															AppStatus.IA_REMEDIATION.toString()));		
	}

	private static void populateAcceptableStatuses(PwobAction action, List<String> statusList) {
		StatusChangeRequirement requirements = new StatusChangeRequirement();
		requirements.setAcceptableAppStatuses(statusList);		
		statuses.put(action, requirements);
	}
}
