package com.bmo.channel.pwob.service.reference.model;

import java.util.List;
import java.util.Map;

import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.ValueType;

public class DataAndMapping {
	private List<ValueType> referenceData;
	private Map<String,String> mappingData;
	public List<ValueType> getReferenceData() {
		return referenceData;
	}
	public void setReferenceData(List<ValueType> referenceData) {
		this.referenceData = referenceData;
	}
	public Map<String, String> getMappingData() {
		return mappingData;
	}
	public void setMappingData(Map<String, String> mappingData) {
		this.mappingData = mappingData;
	}
}
