package com.bmo.channel.pwob.validation.employment;

import java.util.Properties;


import java.util.Optional;


import javax.annotation.Resource;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.model.onboarding.Phone;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.AddressValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class EmploymentValidatorImpl extends AbstractBaseValidator implements EmploymentValidator {
	
	public static final String RETIRED_BMO_GROUP_FIELD_NAME = "retiredBmoGroup";
	
	public static final String COUNTRY_CODE_PATTERN =  "^\\d\\d?\\d?$";

	@Autowired private AddressValidator addressValidator;

	@Resource(name = "validationRules")
	private Properties validationRules;

	@Override
	public boolean validateEmployment(Employment employment,Phone primaryPhone, boolean isPrimaryApplicantSpouse, ValidationRequest request) {
		if(employment == null) {
			// TODO is there a better way to handle this?
			employment = new Employment();
		}

		boolean valid;

		//validate employment status
		request.setFieldValue(employment.getEmploymentStatus());
		valid = this.validateEmploymentStatus(request);

		if(isValidBMOSubsidiaries(employment.getEmployerBusinessName())) {
			request.setFieldValue(employment.getBmoGroup());
			valid = this.validateLineOfBusiness(request) && valid;
		}

		//validate for BMO group value if the the flag is true
		request.setFieldValue(employment.getBmoGroup());		
		request.setBooleanFieldValue(employment.getIsBmoEmployee());		
		valid = this.validateBMOGroup(request) && valid;

		//validate for Retired BMO group value if the the retired BMO flag is true;
		request.setFieldValue(employment.getRetiredBmoGroup());		
		request.setBooleanFieldValue(employment.getRetiredBmoEmployee());		
		valid = this.validateRetiredBMOGroup(request) && valid;

		if(this.shouldValidateEmploymentStatus(employment.getEmploymentStatus(), request.getLob())) {			
			valid = validateEmploymentFields(request, employment) && valid;
		}
		
		else if (StringUtils.isNotBlank(employment.getEmploymentStatus()) && employment.getEmploymentStatus().equals(RefDataValues.EMPLOYMENT_STATUS_RETIRED)) {
			if(!isPrimaryApplicantSpouse){
			   valid = this.validateRetiredFields(request, employment) && valid; 
			}
		}
		
		if (primaryPhone != null && employment.getPrimaryBusinessPhone() != null) {
			valid = this.validateBusinessPhone(request, primaryPhone,employment.getPrimaryBusinessPhone()) && valid;
		}

		return valid;
	}

	
	private boolean validateBusinessPhone(ValidationRequest request,Phone primaryPhone, Phone businessPhone) {
		boolean valid = true;		
		if (StringUtils.isNotBlank(businessPhone.getPhoneExtension()) && StringUtils.isBlank(businessPhone.getPhoneNumber())
				&& primaryPhone.getIsInternationalNumber() == null){
			
			request.setFieldName(PRIMARY_BUSINESS_PHONE_PATH.concat(".").concat(PHONE_NUMBER_FIELD_NAME));
			request.setErrorCode(ErrorCodes.INVALID_BUSINESS_PHONE);
			request.setChildFieldPath(PRIMARY_BUSINESS_PHONE_PATH);
			request.addConstraintViolation();
			valid=false;
		}		
		
		if (primaryPhone.getIsInternationalNumber() != null && primaryPhone.getIsInternationalNumber() && StringUtils.isBlank(businessPhone.getPhoneNumber())
				&& StringUtils.isNotBlank(businessPhone.getCountryCode())) {
			
			request.setFieldName(PRIMARY_BUSINESS_PHONE_PATH.concat(".").concat(PHONE_NUMBER_FIELD_NAME));
			request.setErrorCode(ErrorCodes.INVALID_BUSINESS_PHONE);
			request.setChildFieldPath(PRIMARY_BUSINESS_PHONE_PATH);
			request.addConstraintViolation();
			valid=false;
			
		}
		
		if (primaryPhone.getIsInternationalNumber() != null && primaryPhone.getIsInternationalNumber() && StringUtils.isNotBlank(businessPhone.getPhoneNumber())
				&& (StringUtils.isBlank(businessPhone.getCountryCode()) || !this.doesPatternMatch(businessPhone.getCountryCode(), COUNTRY_CODE_PATTERN))) {
			
			request.setFieldName(PRIMARY_BUSINESS_PHONE_PATH.concat(".").concat(COUNTRY_CODE_FIELD_NAME));
			request.setErrorCode(ErrorCodes.INVALID_PHONE_COUNTRY_CODE);
			request.setChildFieldPath(PRIMARY_BUSINESS_PHONE_PATH);
			request.addConstraintViolation();
			valid=false;
			
		}
		
		return valid;
	}
	
	

	
	
	
	private boolean validateEmploymentFields(ValidationRequest request, Employment employment) {
		boolean valid;

		//business name validation			
		valid = this.validateEmployerBusinessName(request, employment.getEmployerBusinessName());

		//nature of business validation
		if (this.shouldValidateNatureOfBusiness(employment)) {
			request.setFieldValue(employment.getNatureOfBusiness());
			valid = this.validateNatureOfBusiness(request) && valid;
		}

		//occupation validation
		request.setFieldValue(employment.getOccupation());
		valid = this.validateOccupation(request) && valid;

		//validate business primary phone number	
		
		//valid = this.validatePrimaryBusinessPhone(request, employment.getPrimaryBusinessPhone()) && valid;
		
		//address validation for personal employment
		request.setIndex(null);
		valid = this.validateAddress(request, employment.getEmploymentAddress()) && valid;	

		return valid;
	}
	
	private boolean validateRetiredFields(ValidationRequest request, Employment employment) {
		boolean valid = true;
		request.setFieldValue(employment.getOccupation());
		valid = validateOccupation(request) && valid;
		
		if (this.shouldValidateNatureOfBusiness(employment)) {
			request.setFieldValue(employment.getNatureOfBusiness());
			valid = validateNatureOfBusiness(request) && valid;
		}
		return valid;
	}

	@Override
	public boolean validateEmploymentStatus(ValidationRequest request) {			
		if(StringUtils.isBlank(request.getFieldValue()))  {
			request.addConstraintViolation(EMPLOYMENT_STATUS_FIELD_NAME, ErrorCodes.INVALID_EMPLOYMENT_STATUS);
			return false;
		}
		return true;
	}
	
	@Override
	public boolean validateBMOGroup(ValidationRequest request) {		
		if(request.getBooleanFieldValue() != null && request.getBooleanFieldValue() &&
				StringUtils.isBlank(request.getFieldValue())) {
			request.addConstraintViolation(BMO_GROUP_FIELD_NAME, ErrorCodes.INVALID_BMO_GROUP);			
			return false; 
		} else return true;
	}

	private boolean validateRetiredBMOGroup(ValidationRequest request) {
		request.setFieldName(RETIRED_BMO_GROUP_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_RETIRED_BMO_GROUP);					
		if(request.getBooleanFieldValue() != null && request.getBooleanFieldValue() &&
				StringUtils.isBlank(request.getFieldValue())) {
			request.addConstraintViolation();			
			return false; 
		} else return true;
	}	
	
	private boolean validatePrimaryBusinessPhone(ValidationRequest request, Phone primaryBusinessPhone) {
		boolean valid = true;
		if (Optional.ofNullable(primaryBusinessPhone).isPresent()) {
			if (!isValidCountryCode(primaryBusinessPhone)) {
				request.setFieldName(PRIMARY_BUSINESS_PHONE_PATH.concat(".").concat(COUNTRY_CODE_FIELD_NAME));
				request.setErrorCode(ErrorCodes.INVALID_PHONE_COUNTRY_CODE);
				request.setChildFieldPath(PRIMARY_BUSINESS_PHONE_PATH);
				request.addConstraintViolation();
				valid=false;
			}
			if (!isValidPhoneNumber(primaryBusinessPhone)) {
				request.setFieldName(PRIMARY_BUSINESS_PHONE_PATH.concat(".").concat(PHONE_NUMBER_FIELD_NAME));
				request.setErrorCode(ErrorCodes.INVALID_PHONE);
				request.setChildFieldPath(PRIMARY_BUSINESS_PHONE_PATH);
				request.addConstraintViolation();
				valid=false;
			}
		}
		return valid;
	}

	public boolean isValidCountryCode(Phone phoneNumber) {
		if (Optional.ofNullable(phoneNumber.getIsInternationalNumber()).isPresent() && phoneNumber.getIsInternationalNumber()
				&& (StringUtils.isBlank(phoneNumber.getCountryCode())
						|| !this.doesPatternMatch(phoneNumber.getCountryCode(), COUNTRY_CODE_PATTERN))){
			return false;
		}	
		return true;
	}
	
	public boolean isValidPhoneNumber(Phone phoneNumber) {		
		if (Optional.ofNullable(phoneNumber.getIsInternationalNumber()).isPresent() && phoneNumber.getIsInternationalNumber()
				&& StringUtils.isBlank(phoneNumber.getPhoneNumber())) {
			return false;
		}	
		return true;
	}	
	
	@Override
	public boolean validateEmployerBusinessName(ValidationRequest request, String businessName) {
		if(StringUtils.isBlank(businessName) || !this.doesPatternMatch(businessName, EMPLOYER_BUSINESS_NAME_PATTERN)) {
			request.addConstraintViolation(BUSINESS_NAME_FIELD_NAME, ErrorCodes.INVALID_BUSINESS_NAME);
			return false;
		}
		return true;		
	}

	@Override
	public boolean validateLineOfBusiness(ValidationRequest request) {		
		if(StringUtils.isBlank(request.getFieldValue())){
			request.addConstraintViolation(BMO_GROUP_FIELD_NAME, ErrorCodes.INVALID_BMO_GROUP);
			return false;
		}
		return true;		
	}

	@Override
	public boolean validateNatureOfBusiness(ValidationRequest request) {		
		if(StringUtils.isBlank(request.getFieldValue())){
			request.addConstraintViolation(NATURE_OF_BUSINESS_FIELD_NAME, ErrorCodes.INVALID_BUSINESS_NATURES);
			return false;
		}
		return true; 
	}

	@Override
	public boolean validateOccupation(ValidationRequest request) {		
		if(StringUtils.isBlank(request.getFieldValue())){
			request.addConstraintViolation(OCCUPATION_FIELD_NAME, ErrorCodes.INVALID_OCCUPATION_TYPES);
			return false;
		}
		return true; 
	}

	private boolean validateAddress(ValidationRequest request, Address address) {								
		ValidationRequest addressValidationRequest = 
				request.createChildValidationRequest(PERSONAL_NODE.concat(".").concat(EMPLOYMENT_NODE).concat(".").concat(EMP_ADDRESS_NODE), 
						PERSONAL_NODE.concat(".").concat(EMPLOYMENT_NODE).concat(".").concat(EMP_ADDRESS_NODE));
		boolean valid = true;
		
		if(address == null) {
			address = new Address();
		}
		valid = addressValidator.validateUnitStreetCityPostalCountry(addressValidationRequest, address);
		
		return valid;
	}

	@Override
	protected boolean validateAndAddConstraintViolation(ValidationRequest request) {		
		boolean valid = StringUtils.isNotBlank(request.getFieldValue()) && validateField(request);				
		if(!valid) {
			request.addConstraintViolation();
		}
		return valid;
	}

	@Override
	protected boolean validateField(ValidationRequest request) {		
		String fullFieldPath =request.calculateFullFieldPath().replaceAll("\\d+", "");
		String regex = this.retrievePatternForFieldAndLob(request.getLob(), fullFieldPath);
		if(StringUtils.isBlank(request.getFieldValue()) || 
				(StringUtils.isNoneBlank(regex) && !request.getFieldValue().matches(regex))) {
			request.addConstraintViolation();
			return false;
		}
		return true;
	}

	@Override
	public boolean shouldValidateNatureOfBusiness(Employment employment) {
		if(employment.getOccupation() == null){
			return true;
		}
		return !(employment.getOccupation().equals(RefDataValues.OCCUPATION_HOMEMAKER) ||
				employment.getOccupation().equals(RefDataValues.OCCUPATION_STUDENT) ||
				employment.getOccupation().equals(RefDataValues.OCCUPATION_UNEMPLOYED));
	}

	protected void addConstraintViolation(ValidationRequest request) {
		request.getContext().disableDefaultConstraintViolation();
		ConstraintViolationBuilder builder = request.getContext()
				.buildConstraintViolationWithTemplate(request.getErrorCode());	

		builder.addPropertyNode(request.getFieldName())
			   .addBeanNode()
			   .addConstraintViolation();		
	}
}
