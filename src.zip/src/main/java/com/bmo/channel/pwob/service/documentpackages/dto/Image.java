package com.bmo.channel.pwob.service.documentpackages.dto;

public class Image {
	private String ext;
	private String value;

	public String getExt() {
		return ext;
	}
	public void setExt(String ext) {
		this.ext = ext;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
}
