package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;

import io.swagger.annotations.ApiModelProperty;

public class AccountBeneficiary {
	@ApiModelProperty(value="Reference to an element in application beneficiary list")
	private String beneficiaryRefId;

	@ApiModelProperty(value="References to elements in application beneficiaries list")
	private List<String> contingentBeneficiaryRefIds;

	@ApiModelProperty(value="Percentage entitlement for this beneficiary", example="25.00")
	private String entitlementPercentage;

	public String getBeneficiaryRefId() {
		return beneficiaryRefId;
	}
	public void setBeneficiaryRefId(String beneficiaryRefId) {
		this.beneficiaryRefId = beneficiaryRefId;
	}

	public List<String> getContingentBeneficiaryRefIds() {
		return contingentBeneficiaryRefIds;
	}
	public void setContingentBeneficiaryRefIds(List<String> contingentBeneficiaryRefIds) {
		this.contingentBeneficiaryRefIds = contingentBeneficiaryRefIds;
	}
	public String getEntitlementPercentage() {
		return entitlementPercentage;
	}
	public void setEntitlementPercentage(String entitlementPercentage) {
		this.entitlementPercentage = entitlementPercentage;
	}

	public Boolean getHasContingentBeneficiaries() {
		return CollectionUtils.isNotEmpty(contingentBeneficiaryRefIds);
	}
	public void setHasContingentBeneficiaries(Boolean b) {
		// used for deserialization and dozer auto-mapping only
	}
}
