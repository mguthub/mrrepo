package com.bmo.channel.pwob.validation.risprefill;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.TreeMap;
import java.util.regex.Pattern;

import javax.ws.rs.BadRequestException;
import javax.ws.rs.NotAcceptableException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.Phone;
import com.bmo.channel.pwob.model.onboarding.TaxResidency;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.service.reference.ReferencesService;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.util.Constants;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.onboarding.IndividualParty;

@Service
public class RisPrefillValidatorImpl extends AbstractBaseValidator implements RisPrefillValidator {
	
	private static Logger logger = LoggerFactory.getLogger(RisPrefillValidatorImpl.class);
	
	private static final Pattern p = Pattern.compile("[^a-zA-ZÀ-Ÿà-ÿ\\s\\-'’ ]", Pattern.CASE_INSENSITIVE);
	public static final String CANADA_COUNTRY = "Canada";
	
	private static final String LEGAL_FIRST_NAME_FIELD_PATH 				="parties[].personal.identity.legalName.firstName";
	private static final String LEGAL_LAST_NAME_FIELD_PATH 					="parties[].personal.identity.legalName.lastName";
	private static final String LEGAL_MIDDLE_NAME_FIELD_PATH 				="parties[].personal.identity.legalName.middleName";
	
	private static final String PREFERRED_FIRST_NAME_FIELD_PATH 			="parties[].personal.identity.preferredName.firstName";
	private static final String PREFERRED_LAST_NAME_FIELD_PATH 				="parties[].personal.identity.preferredName.lastName";
	private static final String PREFERRED_MIDDLE_NAME_FIELD_PATH 			="parties[].personal.identity.preferredName.middleName";
	
	private static final String ADDRESS_UNIT_NUMBER_FIELD_PATH 				="parties[].personal.residence.primaryAddress.unitNumber";
	private static final String ADDRESS_STREET_ADDRESS_FIELD_PATH 			="parties[].personal.residence.primaryAddress.streetAddress";
	private static final String ADDRESS_POSTAL_CODE_FIELD_PATH 				="parties[].personal.residence.primaryAddress.postalCode";
	private static final String ADDRESS_COUNTRY_FIELD_PATH 					="parties[].personal.residence.primaryAddress.country";
	private static final String ADDRESS_CITY_FIELD_PATH 					="parties[].personal.residence.primaryAddress.city";	
	
	private static final String PRIMARY_PHONE_PHONE_NUMBER_FIELD_PATH 		="parties[].personal.residence.primaryPhone.phoneNumber";
	private static final String PRIMARY_PHONE_PHONE_EXTENSION_FIELD_PATH 	="parties[].personal.residence.primaryPhone.phoneExtension";
	private static final String PRIMARY_PHONE_COUNTRY_CODE_FIELD_PATH 		="parties[].personal.residence.primaryPhone.countryCode";
	
	private static final String SECONDERY_PHONE_PHONE_NUMBER_FIELD_PATH 	="parties[].personal.residence.secondaryPhone.phoneNumber";
	private static final String SECONDERY_PHONE_PHONE_EXTENSION_FIELD_PATH 	="parties[].personal.residence.secondaryPhone.phoneExtension";
	private static final String SECONDERY_PHONE_COUNTRY_CODE_FIELD_PATH 	="parties[].personal.residence.secondaryPhone.countryCode";
	
	private static final String BUSINESS_PHONE_PHONE_NUMBER_FIELD_PATH 		="parties[].personal.employment.primaryBusinessPhone.phoneNumber";
	private static final String BUSINESS_PHONE_PHONE_EXTENSION_FIELD_PATH 	="parties[].personal.employment.primaryBusinessPhone.phoneExtension";
	private static final String BUSINESS_PHONE_COUNTRY_CODE_FIELD_PATH 		="parties[].personal.employment.primaryBusinessPhone.countryCode";
	
	private static final String EMPLOYER_BUSINESS_NAME_FIELD_PATH			="parties[].personal.employment.employerBusinessName";
	private static final String EMPLOYER_JOB_TITLE_FIELD_PATH				="parties[].personal.employment.jobTitle";
	
	private static final String EMPLOYER_ADDRESS_UNIT_NUMBER_FIELD_PATH 	="parties[].personal.employment.employmentAddress.unitNumber";
	private static final String EMPLOYER_ADDRESS_STREET_ADDRESS_FIELD_PATH 	="parties[].personal.employment.employmentAddress.streetAddress";
	private static final String EMPLOYER_ADDRESS_POSTAL_CODE_FIELD_PATH 	="parties[].personal.employment.employmentAddress.postalCode";
	private static final String EMPLOYER_ADDRESS_COUNTRY_FIELD_PATH 		="parties[].personal.employment.employmentAddress.country";
	private static final String EMPLOYER_ADDRESS_CITY_FIELD_PATH 			="parties[].personal.employment.employmentAddress.city";
	
	public static final String COUNTRY_CODE_PATTERN =  "^\\d\\d?\\d?$";
	
	@Autowired 	
	private UsersService userService;

	@Autowired
	private ReferencesService referencesService;

	@Override
	public void titleValidator(Party party) {

		// retrieve list of valid titles and validate

		List<Reference> references;
		references = referencesService.ofType(ReferenceType.TITLES, UILocale.EN_CA);
		if (Optional.ofNullable(party.getPersonal().getIdentity().getLegalName().getTitle()).isPresent()) {
			String title = party.getPersonal().getIdentity().getLegalName().getTitle();
			
			Optional<String> ecifId = references.stream().map(Reference::getCode).filter(Objects::nonNull).filter(code ->code.contains(title)).findFirst();
			
			if(ecifId.isPresent() && !ecifId.get().isEmpty()){
				party.getPersonal().getIdentity().getLegalName().setTitle(ecifId.get());
			}else{
				party.getPersonal().getIdentity().getLegalName().setTitle(null);
			}
		}
	}	

	@Override
	public void primaryApplicantNamesValidator(IndividualParty party){
		boolean valid = this.validateLegalAndPreferredNames(party);				
		if(!valid){
				throw new BadRequestException();
		}
	}
	
	@Override
	public void primaryApplicantPrimaryAddressValidator(IndividualParty party,String accountNumber){
		com.bmo.onboarding.Address primaryAddress = party.getContactInformation().getPrimaryAddress();
		if ( Optional.ofNullable(primaryAddress).map(com.bmo.onboarding.Address::getCountry).isPresent() && !CANADA_COUNTRY.equalsIgnoreCase(primaryAddress.getCountry()) ) {
			logger.error("Country of primary address is other than Canada for account number "+accountNumber);
			throw new NotAcceptableException();
		}
	}
	
	@Override
	public void spouseNameValidator(Party party){		
		if(!StringUtils.isEmpty(party.getPersonal().getIdentity().getLegalName().getFirstName())){
			if(!validate(party.getPersonal().getIdentity().getLegalName().getFirstName(), LEGAL_FIRST_NAME_FIELD_PATH) || checkForSpecialCharacters(party.getPersonal().getIdentity().getLegalName().getFirstName())){
				party.getPersonal().getIdentity().getLegalName().setFirstName(null);
			}
		}		
		if(!StringUtils.isEmpty(party.getPersonal().getIdentity().getLegalName().getLastName())){
			if(!validate(party.getPersonal().getIdentity().getLegalName().getLastName(), LEGAL_LAST_NAME_FIELD_PATH) || checkForSpecialCharacters(party.getPersonal().getIdentity().getLegalName().getLastName())){
				party.getPersonal().getIdentity().getLegalName().setLastName(null);
			}
		}		
		if(!StringUtils.isEmpty(party.getPersonal().getIdentity().getLegalName().getMiddleName())){
			if(!validate(party.getPersonal().getIdentity().getLegalName().getMiddleName(), LEGAL_MIDDLE_NAME_FIELD_PATH) || checkForSpecialCharacters(party.getPersonal().getIdentity().getLegalName().getMiddleName())){
				party.getPersonal().getIdentity().getLegalName().setMiddleName(null);
			}
		}
	}
	
	boolean validateLegalAndPreferredNames(IndividualParty party){
		
		if(!validate(party.getPersonalInformation().getFirstName(), LEGAL_FIRST_NAME_FIELD_PATH) || checkForSpecialCharacters(party.getPersonalInformation().getFirstName())){
			return false;		
		}
		if(!validate(party.getPersonalInformation().getLastName(), LEGAL_LAST_NAME_FIELD_PATH)|| checkForSpecialCharacters(party.getPersonalInformation().getLastName())){
			return false;		
		}
		if(!StringUtils.isEmpty(party.getPersonalInformation().getMiddleName())){
			if(!validate(party.getPersonalInformation().getMiddleName(), LEGAL_MIDDLE_NAME_FIELD_PATH) || checkForSpecialCharacters(party.getPersonalInformation().getMiddleName())){
				return false;		
			}
		}		

		if(!StringUtils.isEmpty(party.getPersonalInformation().getPreferredFirstName())){
			if(!validate(party.getPersonalInformation().getPreferredFirstName(), PREFERRED_FIRST_NAME_FIELD_PATH) || checkForSpecialCharacters(party.getPersonalInformation().getPreferredFirstName())){
				return false;
			}
		}		
		if(!StringUtils.isEmpty(party.getPersonalInformation().getPreferredLastName())){
			if(!validate(party.getPersonalInformation().getPreferredLastName(), PREFERRED_LAST_NAME_FIELD_PATH) || checkForSpecialCharacters(party.getPersonalInformation().getPreferredLastName())){
				return false;
			}
		}
		
		if(!StringUtils.isEmpty(party.getPersonalInformation().getPreferredMiddleName())){
			if(!validate(party.getPersonalInformation().getPreferredMiddleName(), PREFERRED_MIDDLE_NAME_FIELD_PATH) || checkForSpecialCharacters(party.getPersonalInformation().getPreferredMiddleName())){
				return false;
			}
		}
			
		return true;
	}
	
	
	@Override
	public void primaryApplicantAddressValidator(Party party){		
		Address primaryAddress = party.getPersonal().getResidence().getPrimaryAddress();
		if(validateAddressFields(primaryAddress.getStreetAddress(),ADDRESS_STREET_ADDRESS_FIELD_PATH) &&
				validateAddressFields(primaryAddress.getCity(),ADDRESS_CITY_FIELD_PATH) &&
				validateAddressFields(primaryAddress.getCountry(),ADDRESS_COUNTRY_FIELD_PATH)){	
			
			if((RefDataValues.USA_COUNTRY_CODE.equals(primaryAddress.getCountry()) && !validateAddressFields(primaryAddress.getPostalCode(),ADDRESS_POSTAL_CODE_FIELD_PATH))
					|| (RefDataValues.CANADA_COUNTRY_CODE.equals(primaryAddress.getCountry()) && !isValidCanadianPostalCode(primaryAddress.getPostalCode()))){
				party.getPersonal().getResidence().setPrimaryAddress(new Address());
			}
			
			if(StringUtils.isNoneBlank(primaryAddress.getUnitNumber())) {
				if(!validateAddressFields(primaryAddress.getUnitNumber(),ADDRESS_UNIT_NUMBER_FIELD_PATH)){
					party.getPersonal().getResidence().setPrimaryAddress(new Address());
				}
			}			
		}else{
			party.getPersonal().getResidence().setPrimaryAddress(new Address());
		}
	}
	
	@Override
	public void primaryApplicantPhoneValidator(Party party){		
		Phone primaryPhone = party.getPersonal().getResidence().getPrimaryPhone();		
		if(primaryPhone != null){
			if(primaryPhone.getCountryCode() != null && !validate(primaryPhone.getCountryCode(),PRIMARY_PHONE_COUNTRY_CODE_FIELD_PATH)){
				primaryPhone.setCountryCode(null);
			}else if(primaryPhone.getCountryCode() != null){
				primaryPhone.setIsInternationalNumber(true);
			}
			if(primaryPhone.getPhoneNumber() != null && !validate(primaryPhone.getPhoneNumber(),PRIMARY_PHONE_PHONE_NUMBER_FIELD_PATH)){
				primaryPhone.setPhoneNumber(null);
			}
			if(primaryPhone.getPhoneExtension() != null && !validate(primaryPhone.getPhoneExtension(),PRIMARY_PHONE_PHONE_EXTENSION_FIELD_PATH)){
				primaryPhone.setPhoneExtension(null);
			}
		}
		
		this.validateSecondaryPhone(primaryPhone, party.getPersonal().getResidence().getSecondaryPhone());
		
		if(Optional.ofNullable(party.getPersonal()).map(PersonalInformation::getEmployment).map(Employment::getPrimaryBusinessPhone).isPresent()){
			this.validateBusinessPhone(party.getPersonal().getEmployment().getPrimaryBusinessPhone());
		}
	
	}	
	
	@Override
	public void taxResidencyValidator(Party party){	
		
		List<Reference> references;		
		references = referencesService.ofType(ReferenceType.COUNTRIES, UILocale.EN_CA);		
		
		List<TaxResidency> invalidTaxRecidencies = new ArrayList<TaxResidency>();
		
		if(party.getPersonal().getResidencyForTax() != null){
			for(TaxResidency taxResidency: party.getPersonal().getResidencyForTax()){
				
				Optional<String> countryCode = references.stream().map(Reference::getCode).filter(code ->code.contains(taxResidency.getCountry())).findFirst();
				if(countryCode.isPresent() && !countryCode.get().isEmpty()){
					if(!RefDataValues.CANADA_COUNTRY_CODE.equals(taxResidency.getCountry())){
						party.getPersonal().setHasTaxResidency(true);
					}else{
						taxResidency.setTaxIdentificationNumber(null);
					}
					if(StringUtils.isNotBlank(taxResidency.getTaxIdentificationNumberMissingReason())){
						taxResidency.setHaveNoTaxIdentificationNumber(true);
					}
				}else{
					invalidTaxRecidencies.add(taxResidency);
				}
			}
		}
		if(invalidTaxRecidencies.size() > 0){
			party.getPersonal().getResidencyForTax().removeAll(invalidTaxRecidencies);
		}		

		if (CollectionUtils.isNotEmpty(party.getPersonal().getResidencyForTax())) {
			party.getPersonal().setResidencyForTax(this.sortTaxResidency(party.getPersonal().getResidencyForTax(), references));
		}		

	}	
	
	
	private void validateBusinessPhone(Phone businessPhone) {	
		if(businessPhone != null){
			if(businessPhone.getCountryCode() != null && !validate(businessPhone.getCountryCode(),BUSINESS_PHONE_COUNTRY_CODE_FIELD_PATH)){
				businessPhone.setCountryCode(null);
			}else if(businessPhone.getCountryCode() != null){
				businessPhone.setIsInternationalNumber(true);
			}
			if(businessPhone.getPhoneNumber() != null && !validate(businessPhone.getPhoneNumber(),BUSINESS_PHONE_PHONE_NUMBER_FIELD_PATH)){
				businessPhone.setPhoneNumber(null);
			}
			if(businessPhone.getPhoneExtension() != null && !validate(businessPhone.getPhoneExtension(),BUSINESS_PHONE_PHONE_EXTENSION_FIELD_PATH)){
				businessPhone.setPhoneExtension(null);
			}
		}
	}
	
	private void validateSecondaryPhone(Phone primaryPhone, Phone secondaryPhone) {
		if(secondaryPhone != null){
			if(secondaryPhone.getCountryCode() != null && !validate(secondaryPhone.getCountryCode(),SECONDERY_PHONE_COUNTRY_CODE_FIELD_PATH)){
				secondaryPhone.setCountryCode(null);
			}else if(secondaryPhone.getCountryCode() != null){
				secondaryPhone.setIsInternationalNumber(true);
			}
			if(secondaryPhone.getPhoneNumber() != null && !validate(secondaryPhone.getPhoneNumber(),SECONDERY_PHONE_PHONE_NUMBER_FIELD_PATH)){
				secondaryPhone.setPhoneNumber(null);
			}
			if(secondaryPhone.getPhoneExtension() != null && !validate(secondaryPhone.getPhoneExtension(),SECONDERY_PHONE_PHONE_EXTENSION_FIELD_PATH)){
				secondaryPhone.setPhoneExtension(null);
			}
		}
		
		if(primaryPhone != null && secondaryPhone != null){
			if (StringUtils.isNotBlank(secondaryPhone.getPhoneExtension()) && StringUtils.isBlank(secondaryPhone.getPhoneNumber())
					&& primaryPhone.getIsInternationalNumber() == null){
				secondaryPhone.setPhoneExtension(null);
			}		
			if (primaryPhone.getIsInternationalNumber() != null && primaryPhone.getIsInternationalNumber() && StringUtils.isBlank(secondaryPhone.getPhoneNumber())
					&& StringUtils.isNotBlank(secondaryPhone.getCountryCode())) {
				secondaryPhone.setPhoneExtension(null);
			}
			
			if (primaryPhone.getIsInternationalNumber() != null && primaryPhone.getIsInternationalNumber() && StringUtils.isNotBlank(secondaryPhone.getPhoneNumber())
					&& (StringUtils.isBlank(secondaryPhone.getCountryCode()) || !this.doesPatternMatch(secondaryPhone.getCountryCode(), COUNTRY_CODE_PATTERN))) {
				secondaryPhone.setCountryCode(null);	
			}
		}
	
	}
	
	
	protected boolean validateAddressFields(String value,String fieldPath) {	
		String regex = this.retrievePatternForFieldAndLob(this.userService.currentUser().getLob(), fieldPath);	
		if(StringUtils.isNotBlank(value) && StringUtils.isNoneBlank(regex) && value.matches(regex)
				&& !value.matches(SPACE_CHECK_PATTERN)){
			return true;
		}
		return false;
	}
	
	boolean checkForSpecialCharacters(String name){
		return p.matcher(name).find();
	}
	
	boolean validate(String value, String fieldPath){		
		String regex = this.retrievePatternForFieldAndLob(this.userService.currentUser().getLob(), fieldPath);
		if (regex == null || !matchesPattern(value, regex)) {
					return false;
		}
		return true;
	}
	
	boolean matchesPattern(String value, String regex) {
		if(value == null) {
			// will get NPE if applying regular expression to null, so use empty string instead
			return "".matches(regex);
		} else {
			boolean matches = value.matches(regex);
			return matches;
		}
	}

	public void employmentDetailsValidator(Party party) {
		if (Optional.ofNullable(party.getPersonal().getEmployment()).isPresent()) {
			Employment employment = party.getPersonal().getEmployment();
			boolean isEmploymentStatusValid = employmentStatusValidator(employment);
			if (isEmploymentStatusValid) {
				employerNameValidator(employment);
				employerBMOGroupValidator(employment);
				occupationValidator(employment);
				employerNatureOfBusinessValidator(employment);
				jobTitleValidator(employment);
				if (!employment.getEmploymentStatus().equals(RefDataValues.EMPLOYMENT_STATUS_UNEMPLOYED)
						|| !employment.getEmploymentStatus().equals(RefDataValues.EMPLOYMENT_STATUS_RETIRED)) {
					employmentAddressValidator(employment);
				}				
			}
		}
	}
    
    private boolean employmentStatusValidator(Employment employment) {
    	boolean isEmploymentStatusValid=true;
    	if (StringUtils.isBlank(employment.getEmploymentStatus()) || !referenceDataValidator(ReferenceType.EMPLOYMENT_STATUSES, employment.getEmploymentStatus())) {    				
			employment.setEmploymentStatus(null);
			employment.setEmployerBusinessName(null);
			employment.setBmoGroup(null);
			employment.setOccupation(null);
			employment.setNatureOfBusiness(null);
			employment.setEmploymentAddress(null);
			employment.setJobTitle(null);
			isEmploymentStatusValid=false;
    	}
		return isEmploymentStatusValid;
    }    
    
	private void employerNameValidator(Employment employment) {
		// Triming to max length
		employment.setEmployerBusinessName(
				checkAndTrimFieldLength(employment.getEmployerBusinessName(), RefDataValues.EMPLOYER_NAME_MAX_LENGTH));
		if (employment.getEmploymentStatus().equals(RefDataValues.EMPLOYMENT_STATUS_UNEMPLOYED)
				|| employment.getEmploymentStatus().equals(RefDataValues.EMPLOYMENT_STATUS_RETIRED)
				|| StringUtils.isBlank(employment.getEmployerBusinessName())
				|| !validate(employment.getEmployerBusinessName(), EMPLOYER_BUSINESS_NAME_FIELD_PATH)) {
			employment.setEmployerBusinessName(null);
		}
	}
    
	private void employerBMOGroupValidator(Employment employment) {
		if ((StringUtils.isBlank(employment.getEmployerBusinessName()))
				|| (StringUtils.isNotBlank(employment.getEmployerBusinessName())
						&& !StringUtils.containsIgnoreCase(employment.getEmployerBusinessName(),
								Constants.BMO_SEARCH_STR)
						&& !StringUtils.containsIgnoreCase(employment.getEmployerBusinessName(),
								Constants.BANK_OF_MONTREAL_SEARCH_STR)
						&& !StringUtils.containsIgnoreCase(employment.getEmployerBusinessName(),
								Constants.NESBITT_BURNS_SEARCH_STR))
				|| (StringUtils.isBlank(employment.getBmoGroup())
						|| !referenceDataValidator(ReferenceType.BMO_COMPANY_CODES, employment.getBmoGroup()))) {
			employment.setBmoGroup(null);
		} else {
			employment.setIsBmoEmployee(true);
		}
	}
    
	private void occupationValidator(Employment employment) {
		if (StringUtils.isBlank(employment.getOccupation())
					|| (RefDataValues.EMPLOYMENT_STATUS_RETIRED.equalsIgnoreCase(employment.getEmploymentStatus())
							&& RefDataValues.OCCUPATION_RETIRED.equalsIgnoreCase(employment.getOccupation()))
					|| employment.getEmploymentStatus().equals(RefDataValues.EMPLOYMENT_STATUS_UNEMPLOYED)
					|| !referenceDataValidator(ReferenceType.OCCUPATIONS_TYPES, employment.getOccupation())){
				employment.setOccupation(null);
			}
		}

	private void jobTitleValidator(Employment employment) {
		if (StringUtils.isBlank(employment.getJobTitle())
				|| employment.getEmploymentStatus().equals(RefDataValues.EMPLOYMENT_STATUS_UNEMPLOYED)
				|| !validate(employment.getJobTitle(), EMPLOYER_JOB_TITLE_FIELD_PATH)) {
			employment.setJobTitle(null);
		}
	}
	
	private void employmentAddressValidator(Employment employment){		
		Address employmentAddress = employment.getEmploymentAddress();
		if(Optional.ofNullable(employmentAddress).isPresent() && validateAddressFields(employmentAddress.getStreetAddress(),EMPLOYER_ADDRESS_STREET_ADDRESS_FIELD_PATH) &&
				validateAddressFields(employmentAddress.getCity(),EMPLOYER_ADDRESS_CITY_FIELD_PATH) &&
				validateAddressFields(employmentAddress.getCountry(),EMPLOYER_ADDRESS_COUNTRY_FIELD_PATH)){
			
			if((RefDataValues.USA_COUNTRY_CODE.equals(employmentAddress.getCountry()) && !validateAddressFields(employmentAddress.getPostalCode(),EMPLOYER_ADDRESS_POSTAL_CODE_FIELD_PATH))
					|| (RefDataValues.CANADA_COUNTRY_CODE.equals(employmentAddress.getCountry()) && !isValidCanadianPostalCode(employmentAddress.getPostalCode()))){
				employment.setEmploymentAddress(new Address());
			}
			
			if(StringUtils.isNoneBlank(employmentAddress.getUnitNumber())) {
				if(!validateAddressFields(employmentAddress.getUnitNumber(),EMPLOYER_ADDRESS_UNIT_NUMBER_FIELD_PATH)){
					employment.setEmploymentAddress(new Address());
				}
			}			
		}else{
			employment.setEmploymentAddress(new Address());
		}
	}
	
	private void employerNatureOfBusinessValidator(Employment employment) {
		if (StringUtils.isBlank(employment.getNatureOfBusiness())
				|| employment.getEmploymentStatus().equals(RefDataValues.EMPLOYMENT_STATUS_UNEMPLOYED)
				|| !referenceDataValidator(ReferenceType.BUSINESS_NATURES, employment.getNatureOfBusiness())) {
			employment.setNatureOfBusiness(null);
		}
	}
	
    private boolean referenceDataValidator(ReferenceType referenceType, String refData) {
        List<Reference> references = referencesService.ofType(referenceType, UILocale.EN_CA);
        if (Optional.ofNullable(refData).isPresent() && references.stream().map(Reference::getCode).anyMatch(refData::equals)) {
               return true;
        }
        return false;
    }

    private String checkAndTrimFieldLength(String fieldName, int maxFieldLength) {
        if (StringUtils.isNotBlank(fieldName) && fieldName.length() > maxFieldLength) {
               return fieldName.substring(0, maxFieldLength);
        }
        return fieldName;        
 	}

	@Override
	public void preferredLangValidator(Party primary) {
		//if lang is not english or french (Set to null)
		if(Optional.ofNullable(primary.getPersonal()).map(PersonalInformation::getIdentity).map(Identity::getPreferredLanguage).isPresent()){
			if(!Arrays.asList(Constants.LANGUAGE_CODE_100001,Constants.LANGUAGE_CODE_100).contains(primary.getPersonal().getIdentity().getPreferredLanguage())){
				primary.getPersonal().getIdentity().setPreferredLanguage(null);
			}
		}

	}

	@Override
	public void citizenshipValidator(Party party) {
		// retrieve list of valid countries and validate

				List<Reference> references;
				references = referencesService.ofType(ReferenceType.COUNTRIES, UILocale.EN_CA);
				if (Optional.ofNullable(party.getPersonal().getIdentity().getCitizenships()).isPresent() && !party.getPersonal().getIdentity().getCitizenships().isEmpty()) {
					
					List<String> countries = new ArrayList<String>();
					party.getPersonal().getIdentity().getCitizenships().stream().forEach(citizenship -> {						
												
						Optional<String> ecifId = references.stream().map(Reference::getCode).filter(code ->code.contains(citizenship)).findFirst();
						if(ecifId.isPresent() && !ecifId.get().isEmpty()){
							countries.add(ecifId.get());
						}else{
							countries.remove(citizenship);
						}	
			 	 });	
					// Clear citizenship list and populate valid list
					party.getPersonal().getIdentity().getCitizenships().clear();
					party.getPersonal().getIdentity().getCitizenships().addAll(countries);					
			}
	}

	@Override
	public void preferredNameValidator(Party party) {
		if (Optional.ofNullable(party.getPersonal().getIdentity().getPreferredName()).isPresent()
				&& StringUtils.isNotBlank(party.getPersonal().getIdentity().getPreferredName().getFirstName())) {
			party.getPersonal().getIdentity().setHasPreferredName(true);
		}
	}

	@Override
	public void maritalStatusValidator(Party party) {
		List<Reference> references;
		references = referencesService.ofType(ReferenceType.MARITAL_STATUSES, UILocale.EN_CA);
		if (Optional.ofNullable(party.getPersonal().getIdentity().getMaritalStatus()).isPresent()) {
			String maritalStatus = party.getPersonal().getIdentity().getMaritalStatus();
			Optional<String> ecifId = references.stream().map(Reference::getCode).filter(Objects::nonNull).filter(code -> code.contains(maritalStatus)).findFirst();
			if (!ecifId.isPresent()) {
				party.getPersonal().getIdentity().setMaritalStatus(null);
			}
		}
	}


	@Override
	public void dateOfBirthValidator(Party party) {
		boolean valid = isValidDOB(party.getPersonal().getIdentity().getDateOfBirth());	
		if(!valid){
			party.getPersonal().getIdentity().setDateOfBirth(null);
		}
	}
	

	
	private List<TaxResidency> sortTaxResidency(List<TaxResidency> taxResidencyList, List<Reference> references) {
		TreeMap<String, TaxResidency> nonUSTaxResidencyMap= new TreeMap<String, TaxResidency>();
		List<TaxResidency> taxResidencyOrderedList = new ArrayList<TaxResidency>();
		for (TaxResidency taxResidency:taxResidencyList) {
			if (RefDataValues.CANADA_COUNTRY_CODE.equals(taxResidency.getCountry()) || RefDataValues.USA_COUNTRY_CODE.equals(taxResidency.getCountry())) {
				taxResidencyOrderedList.add(taxResidency);
				continue;
			}			
			Optional<Reference> reference = references.stream().filter(a ->a.getCode().contains(taxResidency.getCountry())).findFirst();
			if (reference.isPresent() && !reference.get().getLabel().isEmpty()) {
				nonUSTaxResidencyMap.put(reference.get().getLabel(), taxResidency);
			}
		}
		
		for (Map.Entry<String, TaxResidency> entry:nonUSTaxResidencyMap.entrySet()) {
			taxResidencyOrderedList.add(entry.getValue());
		}
		if (taxResidencyOrderedList.size() > 1
				&& RefDataValues.USA_COUNTRY_CODE.equals(taxResidencyOrderedList.get(0).getCountry())
				&& RefDataValues.CANADA_COUNTRY_CODE.equals(taxResidencyOrderedList.get(1).getCountry())) {			
			TaxResidency taxResidencyTemp = taxResidencyOrderedList.get(0);
			taxResidencyOrderedList.set(0, taxResidencyOrderedList.get(1));
			taxResidencyOrderedList.set(1, taxResidencyTemp);
		}
		return taxResidencyOrderedList.subList(0, Math.min(taxResidencyOrderedList.size(), Constants.MAX_TAX_RESIDENCY));		
	}

}
