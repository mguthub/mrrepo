package com.bmo.channel.pwob.model.onboarding;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

public class NextStepsData {

	@ApiModelProperty(value = "Title")
	private String title;
	
	@ApiModelProperty(value = "First name of primary applicant")
	private String firstName;

	@ApiModelProperty(value = "Last name of primary applicant")
	private String lastName;
	
	@ApiModelProperty(value = "Middle name of primary applicant")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String middleName;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String preferredLanguage;

	private String accountNumber;

	private String applicationNumber;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean isProAccount;	
	
	@ApiModelProperty(example="101", value="Valid values can be found in the reference service")
	private String province;
	
	@ApiModelProperty(example="100544", value="Valid values can be found in the reference service", allowableValues="100544,100545,100562,100391,10391-SPOUSAL")
	private String accountType;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String workflowStatus;

	private BmoRelationship bmoRelationship;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean iirocMember;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String iirocOrganization;


	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getApplicationNumber() {
		return applicationNumber;
	}

	public void setApplicationNumber(String applicationNumber) {
		this.applicationNumber = applicationNumber;
	}

	public Boolean getIsProAccount() {
		return isProAccount;
	}

	public void setIsProAccount(Boolean isProAccount) {
		this.isProAccount = isProAccount;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public BmoRelationship getBmoRelationship() {
		return bmoRelationship;
	}

	public void setBmoRelationship(BmoRelationship bmoRelationship) {
		this.bmoRelationship = bmoRelationship;
	}

	public Boolean getIirocMember() {
		return iirocMember;
	}

	public void setIirocMember(Boolean iirocMember) {
		this.iirocMember = iirocMember;
	}

	public String getIirocOrganization() {
		return iirocOrganization;
	}

	public void setIirocOrganization(String iirocOrganization) {
		this.iirocOrganization = iirocOrganization;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getPreferredLanguage() {
		return preferredLanguage;
	}

	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}

	public String getWorkflowStatus() {
		return workflowStatus;
	}

	public void setWorkflowStatus(String workflowStatus) {
		this.workflowStatus = workflowStatus;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

}
