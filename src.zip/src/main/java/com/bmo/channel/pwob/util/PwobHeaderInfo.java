package com.bmo.channel.pwob.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.apache.cxf.message.Message;
import org.apache.cxf.phase.PhaseInterceptorChain;
import org.apache.cxf.transport.http.AbstractHTTPDestination;

@Component
public class PwobHeaderInfo {
	
	 private static Pattern PRIVATE_ADDRESS_PATTERN = Pattern.compile(
		      "(^127\\.)|(^192\\.168\\.)|(^10\\.)|(^172\\.1[6-9]\\.)|(^172\\.2[0-9]\\.)|(^172\\.3[0-1]\\.)|(^::1$)|(^[fF][cCdD])",
		      Pattern.CANON_EQ);
	
	@Autowired
	private HttpServletRequest request;
		
	public String getHostName() {		
		return request.getRemoteHost();
	}
	
	public String getRemoteAddress() {							
		Message message = PhaseInterceptorChain.getCurrentMessage();
	    HttpServletRequest contxt = (HttpServletRequest)message.get(AbstractHTTPDestination.HTTP_REQUEST);
	    String ipAddress =  contxt.getRemoteAddr();

	    /*String headerClientIp = contxt.getHeader("Client-IP");
	    String headerXForwardedFor = contxt.getHeader("X-Forwarded-For");
	    if(StringUtils.isEmpty(ipAddress) && StringUtils.isNotEmpty(headerClientIp)) {
	    	ipAddress = headerClientIp;
	    } else if (StringUtils.isNotEmpty(headerXForwardedFor)) {
	    	ipAddress = headerXForwardedFor;
	    }*/
	    if(isPrivateOrLocalAddress(ipAddress)) {
	      return StringUtils.EMPTY;
	    } else {
	      return ipAddress;
	    }
	}
	
	 private boolean isPrivateOrLocalAddress(String ipAddress) {
	    Matcher regexMatcher = PRIVATE_ADDRESS_PATTERN.matcher(ipAddress);
	    return regexMatcher.matches();
	 }
	
	public String getServerName() {				
		return request.getServerName();	
	}
}
