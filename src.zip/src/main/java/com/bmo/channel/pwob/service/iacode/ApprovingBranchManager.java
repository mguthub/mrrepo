package com.bmo.channel.pwob.service.iacode;

public class ApprovingBranchManager {

	private String networkId;
	private String branchCode;

	public ApprovingBranchManager(String branchCode, String networkId) {
		this.branchCode = branchCode;
		this.networkId = networkId;
	}

	public String getNetworkId() {
		return networkId;
	}
	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}

	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
}
