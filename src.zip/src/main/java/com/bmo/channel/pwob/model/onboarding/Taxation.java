package com.bmo.channel.pwob.model.onboarding;

public class Taxation {
	private Boolean isIrsW8FormProvided;
	private String beneficialOwnerCountry;
	private String beneficialOwnerCountryReason;
	private Boolean isIrsW9FormProvided;
	private String taxIdentificationNumber;
	
	public Boolean getIsIrsW8FormProvided() {
		return isIrsW8FormProvided;
	}
	public void setIsIrsW8FormProvided(final Boolean isIrsW8FormProvided) {
		this.isIrsW8FormProvided = isIrsW8FormProvided;
	}
	public String getBeneficialOwnerCountry() {
		return beneficialOwnerCountry;
	}
	public void setBeneficialOwnerCountry(final String beneficialOwnerCountry) {
		this.beneficialOwnerCountry = beneficialOwnerCountry;
	}
	public String getBeneficialOwnerCountryReason() {
		return beneficialOwnerCountryReason;
	}
	public void setBeneficialOwnerCountryReason(String beneficialOwnerCountryReason) {
		this.beneficialOwnerCountryReason = beneficialOwnerCountryReason;
	}
	public Boolean getIsIrsW9FormProvided() {
		return isIrsW9FormProvided;
	}
	public void setIsIrsW9FormProvided(final Boolean isIrsW9FormProvided) {
		this.isIrsW9FormProvided = isIrsW9FormProvided;
	}
	public String getTaxIdentificationNumber() {
		return taxIdentificationNumber;
	}
	public void setTaxIdentificationNumber(final String taxIdentificationNumber) {
		this.taxIdentificationNumber = taxIdentificationNumber;
	}
}
