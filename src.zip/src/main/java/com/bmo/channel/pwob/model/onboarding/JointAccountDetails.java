package com.bmo.channel.pwob.model.onboarding;

import java.util.ArrayList;
import java.util.List;

public class JointAccountDetails {	
		
		
		private Boolean hasNoRightsOfSurvivorship;	
		
		private List<String> accountNameOrder = new ArrayList<String>();		
			
		private Preferences preferences;
		
		public Boolean getHasNoRightsOfSurvivorship() {
			return hasNoRightsOfSurvivorship;
		}

		public void setHasNoRightsOfSurvivorship(Boolean hasNoRightsOfSurvivorship) {
			this.hasNoRightsOfSurvivorship = hasNoRightsOfSurvivorship;
		}

		public List<String> getAccountNameOrder() {
			return accountNameOrder;
		}

		public void setAccountNameOrder(List<String> accountNameOrder) {
			this.accountNameOrder = accountNameOrder;
		}

		public Preferences getPreferences() {
			return preferences;
		}

		public void setPreferences(Preferences preferences) {
			this.preferences = preferences;
		}		
}
