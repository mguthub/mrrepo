package com.bmo.channel.pwob.config;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.cxf.endpoint.Server;
import org.apache.cxf.feature.LoggingFeature;
import org.apache.cxf.jaxrs.spring.JAXRSServerFactoryBeanDefinitionParser.SpringJAXRSServerFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bmo.channel.common.interceptor.WorkflowIdInterceptor;
import com.bmo.channel.core.exception.DefaultExceptionHandler;
import com.bmo.channel.core.exception.JsonParseExceptionHandler;
import com.bmo.channel.core.exception.WebApplicationExceptionHandler;
import com.bmo.channel.core.exception.WebServiceExceptionHandler;
import com.bmo.channel.core.jaxrs.DateParamConverterProvider;
import com.bmo.channel.pwob.exception.ConstraintViolationExceptionHandler;
import com.bmo.channel.pwob.exception.StatusExceptionHandler;
import com.bmo.channel.pwob.exception.UnrecognizedPropertyExceptionHandler;
import com.bmo.channel.pwob.exception.BackEndExceptionHandler;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.AccountNumbersEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.CredentialsEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.DigitalTokensEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.DocumentTrackerEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.FinancialInstitutionsEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.ILLaunchEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.InternalApprovalsEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.ReferencesEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.RisPrefillEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.SavedApplicationsEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.UsersEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.WorkflowAccountsEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.WorkflowPartiesEndpoint;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.WorkflowsEndpoint;
import com.fasterxml.jackson.jaxrs.json.JacksonJaxbJsonProvider;

@Configuration
public class EndpointsConfig {
  
  /******************************************************** 
  ********************  Endpoints  ************************
  *********************************************************/
  
	@Bean
	WorkflowsEndpoint workflowsEndpoint() {
		return new WorkflowsEndpoint();
	}

	@Bean
	ReferencesEndpoint referencesEndpoint() {
		return new ReferencesEndpoint();
	}

	@Bean
	DocumentTrackerEndpoint documentTrackerEndpoint() {
		return new DocumentTrackerEndpoint();
	}

	@Bean
	UsersEndpoint usersEndpoint() {
		return new UsersEndpoint();
	}

	@Bean
	InternalApprovalsEndpoint internalApprovalsEndpoint() {
		return new InternalApprovalsEndpoint();
	}

	@Bean
	SavedApplicationsEndpoint savedApplicationsEndpoint() {
		return new SavedApplicationsEndpoint();
	}
	
	@Bean
	ILLaunchEndpoint ilLaunchEndpoint() {
		return new ILLaunchEndpoint();
	}

	@Bean
	WorkflowPartiesEndpoint workflowPartiesEndpoint(){
		return new WorkflowPartiesEndpoint();
	}

	@Bean
	WorkflowAccountsEndpoint workflowAccountsEndpoint(){
		return new WorkflowAccountsEndpoint();
	}
	
	@Bean
	AccountNumbersEndpoint accountNumbersEndpoint(){
		return new AccountNumbersEndpoint();
	}

	@Bean
	FinancialInstitutionsEndpoint financialInstitutionsEndpoint() {
		return new FinancialInstitutionsEndpoint();
	}

	@Bean
	CredentialsEndpoint credentialsEndpoint() {
		return new CredentialsEndpoint();
	}

	@Bean
	DigitalTokensEndpoint digitalTokenEndpoint() {
		return new DigitalTokensEndpoint();
	}
	
	@Bean
	RisPrefillEndpoint risPrefillEndpoint() {
		return new RisPrefillEndpoint();
	}

	/******************************************************** 
	********************  Rest Server  **********************
	*********************************************************/
	
	@Bean
	public Server pwobService(	LoggingFeature loggingFeature, 	
								DefaultExceptionHandler h1, 
								WebApplicationExceptionHandler h2, 
								WebServiceExceptionHandler h3,
								ConstraintViolationExceptionHandler h4, 
								UnrecognizedPropertyExceptionHandler h5, 
								StatusExceptionHandler h6, 
								JsonParseExceptionHandler h7,
								BackEndExceptionHandler h8){
		
		SpringJAXRSServerFactoryBean factoryBean = new SpringJAXRSServerFactoryBean();
		factoryBean.setAddress("/");
		factoryBean.setExtensionMappings(configureExtensionMappings());
		factoryBean.setFeatures(Arrays.asList(loggingFeature));
		factoryBean.setInInterceptors(Arrays.asList(workflowIdInterceptor()));
		factoryBean.setProviders(Arrays.asList(serverJsonProvider(), h1,h2,h3,h4,h5,h6,h7,h8));
		
		factoryBean.setServiceBeans(Arrays.asList(
				workflowsEndpoint(),
				referencesEndpoint(),
				documentTrackerEndpoint(),
				usersEndpoint(),
				internalApprovalsEndpoint(),
				savedApplicationsEndpoint(),
				workflowAccountsEndpoint(),
				workflowPartiesEndpoint(),
				accountNumbersEndpoint(),
				credentialsEndpoint(),
				financialInstitutionsEndpoint(),
				ilLaunchEndpoint(),
				digitalTokenEndpoint(),
				risPrefillEndpoint()
		));
		return factoryBean.create();
	}
	
	@Bean
	public JacksonJaxbJsonProvider serverJsonProvider(){
		return new JacksonJaxbJsonProvider();
	}
	
	@Bean
	public DateParamConverterProvider dateProvider(){
		return new DateParamConverterProvider();
	}
	
	@Bean 
	public WorkflowIdInterceptor workflowIdInterceptor(){
		return new WorkflowIdInterceptor();
	}
	
	private Map<Object, Object> configureExtensionMappings(){
		Map<Object, Object> extensionMap = new HashMap<>();
		extensionMap.put("json", "application/json");
		return extensionMap;
	}
}
