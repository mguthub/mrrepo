package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

public class DocumentTracker {

	List<String> documentPackageIds;

	public List<String> getDocumentPackageIds() {
		return documentPackageIds;
	}

	public void setDocumentPackageIds(List<String> documentPackageIds) {
		this.documentPackageIds = documentPackageIds;
	}

	
	
}
