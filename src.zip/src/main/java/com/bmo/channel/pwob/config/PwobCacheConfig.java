package com.bmo.channel.pwob.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bmo.channel.common.ehcache.CacheService;

import net.sf.ehcache.CacheManager;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.DiskStoreConfiguration;
import net.sf.ehcache.config.PersistenceConfiguration;

/**
 * All EhCache config
 * @author Ryan Chambers rcham02
 */
@Configuration
public class PwobCacheConfig {
	@Value("${ehcache.file.name}")
	private String ehcacheFileName;

	// default to 28800 seconds (24 hours) if not specified in properties file
	@Value("${iaCodesTtlSeconds:28800}")
	private long iaCodesTtlSeconds;

	// default to 3600 seconds (1 hour) if not specified in properties file
	@Value("${refDataTtlSeconds:3600}")
	private long refDataTtlSeconds;

	// Please ensure to specify a unique name to your bean if you are using this implementation in other projects.
	// A bean name must be unique across your spring config files
	// Spring gives a default name if name is not specified.
	@Bean(name="wealthCacheService")
	public CacheService getCacheService() {
		CacheService cacheService = new CacheService(ehCacheCacheManager());
		return cacheService;
	}

	/**
	 * @return EhCacheManagerBean.
	 */
	@Bean
	public EhCacheCacheManager ehCacheCacheManager() {
		return new EhCacheCacheManager(ehCacheManager());
	}

    @Bean(destroyMethod="shutdown")
    public net.sf.ehcache.CacheManager ehCacheManager() {
        net.sf.ehcache.config.Configuration config = new net.sf.ehcache.config.Configuration();
        DiskStoreConfiguration diskStoreConfigurationParameter = new DiskStoreConfiguration();
        diskStoreConfigurationParameter.setPath("java.io.tmpdir/" + ehcacheFileName + ".cache");
		config.addDiskStore(diskStoreConfigurationParameter);
        config.addCache(createIaCodesCache());
        config.addCache(createRefDataCache());
        config.addCache(createFinancialInstitutionsCache());
        CacheManager newInstance = net.sf.ehcache.CacheManager.newInstance(config);
		return newInstance;
    }

	private CacheConfiguration createRefDataCache() {
		CacheConfiguration cacheConfiguration = new CacheConfiguration();
        cacheConfiguration.setName("refDataCache");
        cacheConfiguration.setTimeToIdleSeconds(0L);
        cacheConfiguration.setTimeToLiveSeconds(refDataTtlSeconds);
        cacheConfiguration.setMaxEntriesLocalHeap(4000L);
        cacheConfiguration.setEternal(false);
        cacheConfiguration.setMemoryStoreEvictionPolicy("LFU");
        cacheConfiguration.setTransactionalMode("off");
        PersistenceConfiguration persistence = new PersistenceConfiguration();
        persistence.setStrategy(PersistenceConfiguration.Strategy.NONE.name());
		return cacheConfiguration;
	}

	private CacheConfiguration createIaCodesCache() {
		CacheConfiguration cacheConfiguration = new CacheConfiguration();
        cacheConfiguration.setName("iaCodesCache");
        cacheConfiguration.setTimeToIdleSeconds(0L);
        cacheConfiguration.setTimeToLiveSeconds(iaCodesTtlSeconds);
        cacheConfiguration.setMaxEntriesLocalHeap(4000L);
        cacheConfiguration.setEternal(false);
        cacheConfiguration.setMemoryStoreEvictionPolicy("LFU");
        cacheConfiguration.setTransactionalMode("off");
        PersistenceConfiguration persistence = new PersistenceConfiguration();
        persistence.setStrategy(PersistenceConfiguration.Strategy.NONE.name());
		return cacheConfiguration;
	}
	
	private CacheConfiguration createFinancialInstitutionsCache() {
		CacheConfiguration cacheConfiguration = new CacheConfiguration();
        cacheConfiguration.setName("financialInstitutionsCache");
        cacheConfiguration.setTimeToIdleSeconds(0L);
        cacheConfiguration.setTimeToLiveSeconds(28800L);
        cacheConfiguration.setMaxEntriesLocalHeap(4000L);
        cacheConfiguration.setEternal(false);
        cacheConfiguration.setMemoryStoreEvictionPolicy("LFU");
        cacheConfiguration.setTransactionalMode("off");
        PersistenceConfiguration persistence = new PersistenceConfiguration();
        persistence.setStrategy(PersistenceConfiguration.Strategy.NONE.name());
		return cacheConfiguration;
	}
}
