package com.bmo.channel.pwob.util;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bmo.channel.core.exception.WebServiceException;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfReader;

/**
 * Provides the utilities to process pdf files.
 */
public class PDFUtil implements DocumentImage {
	
	private static Logger logger = LoggerFactory.getLogger(PDFUtil.class);
	/**
	 * This is to concatenate several pdf files and get a single pdf.
	 * 
	 * @param contents List of byte[] of pdf contents.
	 * @return Concatenated pdf file.
	 * @throws Exception In case of error.
	 */
	
	static 
	{ 
		PdfReader.unethicalreading = true; 
	}
	
	public  byte[] merge(final List<StringBuilder> contents) {
		final Document mergedDocument = new Document();
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		final List<PdfReader> readers = new ArrayList<>();
		PdfCopy copy = null;
		try {
			copy = new PdfCopy(mergedDocument, out);
			copy.setMergeFields();
			mergedDocument.open();
			PdfReader reader = null;
			for (StringBuilder content : contents) {
				reader = new PdfReader(Base64.decodeBase64(content.toString()));
				readers.add(reader);
				copy.addDocument(reader);
			}
		} catch (Exception ex) {
			logger.error("Failed to merge pdf files : ", ex);
			throw new WebServiceException(ex);
		} finally {
			if (mergedDocument.isOpen()) {
				mergedDocument.close();
			}
			for (PdfReader reader : readers) {
				reader.close();
			}
			IOUtils.closeQuietly(out);
			if (copy != null) {
				copy.close();
			}
		}
		return out.toByteArray();
	}

}
