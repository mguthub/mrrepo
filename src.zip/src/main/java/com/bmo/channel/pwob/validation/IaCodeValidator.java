package com.bmo.channel.pwob.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;

public class IaCodeValidator extends AbstractBaseValidator implements ConstraintValidator<ValidIaCode, String> {
	@Autowired
	UsersService userService;

	@Override
	public void initialize(ValidIaCode constraintAnnotation) {
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(ApplicationLob.il == this.userService.currentUser().getLob()) {
			return true;
		}

		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		if (StringUtils.isEmpty(value) || currentUserDoesNotHaveIaCode(value)) {
			this.createConstraintViolation(context, ErrorCodes.INVALID_IA_CODE, "");
			return false;
		}

		return true;
	}

	boolean currentUserDoesNotHaveIaCode(String iaCode) {
		return userService.currentUser().getIaCodes().stream().noneMatch(c -> c.equals(iaCode));
	}
}
