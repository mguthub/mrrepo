package com.bmo.channel.pwob.provider;

/**
 * Provides access to System property app.properties which configured in spring config bean-core
 * @author akhales
 */
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class ApplicationProperties {

	@Value("${workflow.template.id}")
	private String workflowTemplateId;
	
	@Value("${workflow.version}")
	private String workflowVersion;

	public String getWorkflowTemplateId() {
		return workflowTemplateId;
	}

	public String getWorkflowVersion() {
		return workflowVersion;
	}
	
	
}
