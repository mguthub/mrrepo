package com.bmo.channel.pwob.validation;

import com.bmo.channel.pwob.model.onboarding.Name;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface NameValidator {

	boolean validateFirstName(Name name, ValidationRequest validationRequest);

	boolean validateLastName(Name name, ValidationRequest validationRequest);

	boolean validateTitle(Name name, ValidationRequest validationRequest);

}
