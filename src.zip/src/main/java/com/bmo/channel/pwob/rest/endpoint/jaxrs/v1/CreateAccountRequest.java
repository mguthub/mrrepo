package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

public class CreateAccountRequest {
	private String type;

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
