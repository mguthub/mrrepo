/**
 * @author akhales
 */
package com.bmo.channel.pwob.validation.account;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.LiraAccountDetails;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.Preferences;
import com.bmo.channel.pwob.service.reference.ReferencesService;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.InvestmentObjectivesValidator;
import com.bmo.channel.pwob.validation.Patterns;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.preferences.PreferencesValidator;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

public class AccountValidator extends AbstractBaseValidator implements ConstraintValidator<ValidAccount, Account> {
	public static final int NUMBER_OF_ALLOWED_JOINT_APPLICANTS = 1;
	
	public static final String HUNDRED_DECIMAL = "0.0";
	public static final String HAS_BENEFICIARIES_FIELD_NAME = "hasBeneficiaries";
	public static final String BENEFICIARIES_FIELD_NAME = "beneficiaries";
	public static final String ARE_OTHER_PARTIES_SPECIFIED_FIELD_NAME = "areOtherPartiesSpecified";
	public static final String ENTITLEMENT_PERCENT_FIELD_NAME = "entitlementPercentage";
	
	public static final String SUB_TYPES_FIELD_NAME = "subTypes";
	public static final String OPTIONS_TRADING_FIELD_NAME = "optionsTrading";
	public static final String KNOWLEDGE_FIELD_NAME = "knowledge";
	public static final String OPTION_TYPE_EXPERIENCES_FIELD_NAME = "optionTypeExperiences";
	public static final String OPTION_TYPES_FIELD_NAME = "optionTypes";
	public static final String HAS_OPTIONS_TRADING_FIELD_NAME = "hasOptionsTrading";
	public static final String INTENDED_USE_FIELD_NAME = "intendedUse";
	public static final String OTHER_DESCRIPTION_FIELD_NAME = "otherDescription";
	public static final String LINK_DEBIT_FIELD_NAME = "linkDebitCard";
	public static final String DEBIT_CARD_NUMBER_FIELD_NAME = "debitCardNumber";
	public static final String IS_SPOUSAL_FIELD_NAME = "isSpousal";
	public static final String ACCOUNT_LINK_TYPE_FIELD_NAME = "accountLinkType";
	public static final String BANK_US_FUNDS_FIELD_NAME = "bankUsFunds";
	public static final String TYPE_FIELD_NAME = "type";
	public static final String ACCOUNT_NUMBER_FIELD_NAME = "accountNumber";
	public static final String INVESTMENT_TIME_HORIZON_FIELD_NAME = "investmentTimeHorizon";
	public static final String SUCCESSOR_ANNUITANT_FIELD_NAME = "hasSuccessorAnnuitant";
	public static final String PRIMARY_APPLICANT_PARTY_REF_ID_FIELD_NAME = "primaryApplicantPartyRefId";
	public static final String HAS_THIRD_PARTY_FIELD_NAME = "hasThirdPartyInterest";
	
	public static final String IS_PRIMARY_APPLICANT_SPOUSE = "isPrimaryApplicantSpouse";
	public static final String ADD_JOINT_APPLICANT_FIELD_NAME = "JointApplicant";
	public static final String JOINT_ACCOUNT_DETAILS = "jointAccountDetails";
	public static final String LIRA_ACCOUNT_DETAILS = "liraAccountDetails";
	public static final String LIF_ACCOUNT_DETAILS = "lifAccountDetails";
	public static final String JOINT_ACCOUNT_DETAILS_PREFERENCES = "jointAccountDetails.preferences";
	public static final String RIGHTS_OF_SURVIVORSHIP_FIELD_NAME = "RightsOfSurvivorship";
	public static final String JURISDICTION_TYPE_FIELD_NAME = "JurisdictionType";
	public static final String FEDERAL_PENSIONPLAN_TYPE_FIELD_NAME = "FederalPensionPlanType";
	public static final String PENSIONESSETS_ORIGINATEFROM_FIELD_NAME = "PensionAssetsOriginateFrom";
	
	public static final String PENSION_ACCUMULATES_BEFORE1993_FIELD_NAME = "PensionAccumulatedBefore1993";
	public static final String FUNDING_INSTRUCTIONS_FIELD_NAME = "FundingInstructions";
	public static final String TRANSFERRED_AMOUNT_FIELD_NAME = "TransferredAmount";
	public static final String TRANSFERRED_AMOUNT_IN_WORDS_FIELD_NAME = "TransferredAmountInWords";
	//public static final String province = "Province";
	
	public static final String LIRA_PROVINCE_FIELD_NAME = "LiraProvince";
	public static final String LIF_PROVINCE_FIELD_NAME = "LifProvince";
	public static final String TRANSFERRED_AMOUNT_MAX_VAL = "999999999.99";
	public static final String TRANSFERRED_AMOUNT_MIN_VAL = "0.01";
	public static final int TRANSFERRED_AMOUNT_DOLLARS_IN_WORDS_MAX_SIZE = 100;
	public static final int TRANSFERRED_AMOUNT_CENTS_IN_WORDS_MAX_SIZE = 20;
	public static final String PENSION_VARIED_ONBASISOF_GENDER_FIELD_NAME = "PensionVariedoOnBasisOfGender";
	public static final String ACCOUNT_NAME_ORDER_FIELD_NAME= "accountNameOrder";
	public static final String JOINT_ACCOUNT_PREFERENCES= "jointAccountPreferences";
	public static final String JOINT_APPLICANT_PARTY_REF_IDS= "jointApplicantPartyRefIds";
	
	public static final String CONTRIBUTOR_FIELD_NAME = "contributor";
	public static final String SUCCESSOR_FIELD_NAME = "successor";
	
	public static final String SOURCE_OF_ASSETS_NAME = "sourcesOfAssets";
	public static final String SPOUSE_OPTION_TYPE = "spouseOptionType";
	public static final String FEDERAL_JURISDICTION_TYPE = "1";
	public static final String PROVINCIAL_JURISDICTION_TYPE = "2";
	public static final String SPECIFY_AMT_OF_TRFR_FUNDING_INSTRUCTION = "1";
	public static final String TOTAL_REMANINING_BAL_FUNDING_INSTRUCTION = "2";

	@Autowired private ValidationRequestFactory validationRequestFactory;

	@Autowired private InvestmentObjectivesValidator investmentObjectivesValidator;
	
	@Autowired private PreferencesValidator preferencesValidator;

	@Autowired
	private UsersService userService;

	static private final Map<ApplicationLob, List<String>> ALLOWED_SUB_TYPES;
	static {
		ALLOWED_SUB_TYPES = new EnumMap<>(ApplicationLob.class);
		ALLOWED_SUB_TYPES.put(ApplicationLob.il, Arrays.asList(RefDataValues.ACCOUNT_SUBTYPE_CASH, RefDataValues.ACCOUNT_SUBTYPE_MARGIN));
		ALLOWED_SUB_TYPES.put(ApplicationLob.nb, Arrays.asList(RefDataValues.ACCOUNT_SUBTYPE_CASH, RefDataValues.ACCOUNT_SUBTYPE_MARGIN));
	}

	@Override
	public void initialize(ValidAccount constraintAnnotation) {
		// none required
	}

	@Override
	public boolean isValid(Account account, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();		

		ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).build();

		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		boolean valid = true;
		Application application = validationContext.getApplication();

		valid = this.validatePrimaryApplicantPartyRefId(account, request, application.getPrimaryApplicant()) && valid;

		if(account.isIndividual() || account.isJoint()) {
			valid = this.validateSubTypes(account, request) && valid;
		}

		//valid = this.validateOptionsTrading(account, request) && valid;

		valid = this.validateIntendedUse(account, request) && valid;
		
		valid = this.isValidLinkDebitCard(account, request) && valid;
		
		//not required
		//valid = this.isValidDebitCardNumber(account, request) && valid;

		valid = this.isValidAccountLinkType(account, request) && valid;

		valid = this.isValidBankUsFunds(account, request) && valid;

		valid = isValidAccountType(account, request) && valid;						

		valid = isValidInvestmentTimeHorizon(account, request) && valid;

		valid = validateAreOtherPartiesSpecified(account, request) && valid;

		valid = validateAccountInvestmentObjectives(application.getPrimaryApplicant(), account, request) && valid;
		
		valid = validateThirdPartyInterest(account, request) && valid;		

		Party applicant = application.getPrimaryApplicant();
		if(applicant != null) {
			if(account.isTfsa()) {
				valid = isValidSuccessorAnnuitant(account, request, applicant) && valid;
			}
			if(account.isRif()){
				valid = isValidSuccessorAnnuitant(account, request, applicant) && valid;
			}
		
			if(beneficiariesMustBeSpecified(account.getType(), applicant)){
				valid = this.validateHasBeneficiariesAnswered(account, request) && valid;
			}		
			
		}
		
		if(account.isJoint()){
			ValidationRequest jointAccountDetailsRequestContext = request.createChildValidationRequest(JOINT_ACCOUNT_DETAILS, JOINT_ACCOUNT_DETAILS);
			valid = validateJointAccountDetails(account, 
					jointAccountDetailsRequestContext, 
					application.getPrimaryApplicant(),
					application.getJointApplicants(account.getJointApplicantPartyRefIds())) && valid;
		}
		
		if(account.isLira()){
			ValidationRequest liraAccountDetailsRequestContext = request.createChildValidationRequest(LIRA_ACCOUNT_DETAILS, LIRA_ACCOUNT_DETAILS);
			valid = validateLiraAccountDetails(account, liraAccountDetailsRequestContext, application.getPrimaryApplicant()) && valid;
		}else if(account.isLif()){
			ValidationRequest lifAccountDetailsRequestContext = request.createChildValidationRequest(LIF_ACCOUNT_DETAILS, LIF_ACCOUNT_DETAILS);
			valid = validateLifAccountDetails(account, lifAccountDetailsRequestContext, application.getPrimaryApplicant()) && valid;
		}
			
		valid = validatejointApplicantPartyRefIds(account, request, application) && valid;

		valid = validateIsSpousalForRsp(account, request) && valid;
		
		valid = isValidSpousalRsp(account, request) && valid;
		
		return valid;
	}

	private boolean validateJointAccountDetails(Account account, ValidationRequest request, Party primaryApplicant, List<Party> jointApplicants) {	
		boolean valid = true;
		Preferences JointAccountPreferences =null;
		ValidationRequest preferencesRequestContext = request.createChildValidationRequest(JOINT_ACCOUNT_DETAILS_PREFERENCES, JOINT_ACCOUNT_DETAILS_PREFERENCES);
		
		if(account.getJointAccountDetails() != null){
			
			Boolean quebecFlag=checkProvinceIsQUEBEC(primaryApplicant);
			
			if(quebecFlag && !Optional.ofNullable(account.getJointAccountDetails().getHasNoRightsOfSurvivorship()).isPresent()) {
				request.addConstraintViolation(RIGHTS_OF_SURVIVORSHIP_FIELD_NAME, ErrorCodes.INVALID_RIGHTS_OF_SURVIVORSHIP);							
				valid = false;
			}
			
			List<String> partyIds = account.getJointAccountDetails().getAccountNameOrder();
			
			if(partyIds == null || partyIds.size() <2 || partyIds.contains(null) || partyIds.contains("")){
				request.addConstraintViolation(ACCOUNT_NAME_ORDER_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_NAME_ORDER);
				valid = false;
			}else{
				for(String id: partyIds){
					if(!id.equals(primaryApplicant.getPartyRefId()) &&  !validateAccountNameOrderPartyId(id,jointApplicants)){
						request.addConstraintViolation(ACCOUNT_NAME_ORDER_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_NAME_ORDER);
						valid = false;
						break;
					}
				}
			}
			
			Preferences pref = account.getJointAccountDetails().getPreferences();				
			valid = this.preferencesValidator.arePreferencesValidForJointAccount(pref, preferencesRequestContext) && valid;
			
		}else{
			request.addConstraintViolation(RIGHTS_OF_SURVIVORSHIP_FIELD_NAME, ErrorCodes.INVALID_RIGHTS_OF_SURVIVORSHIP);
			request.addConstraintViolation(ACCOUNT_NAME_ORDER_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_NAME_ORDER);
			valid = this.preferencesValidator.arePreferencesValidForJointAccount(JointAccountPreferences, preferencesRequestContext) && valid;
		}
		
		return valid;
	}
	
	
	private boolean validateLiraAccountDetails(Account account, ValidationRequest request, Party primaryApplicant) {	
		boolean valid = true;		
		
		if(account.getLiraAccountDetails() != null){
			if(Optional.ofNullable(account.getLiraAccountDetails().getJurisdictionType()).isPresent()){
				if("1".equals(account.getLiraAccountDetails().getJurisdictionType())){
					
					if(!Optional.ofNullable(account.getLiraAccountDetails().getFederalPensionPlanType()).isPresent()){
						request.addConstraintViolation(FEDERAL_PENSIONPLAN_TYPE_FIELD_NAME, ErrorCodes.INVALID_FEDERAL_PENSIONPLAN_TYPE);
						valid = false;
					}				

					if(!Optional.ofNullable(account.getLiraAccountDetails().getPensionVariedoOnBasisOfGender()).isPresent()){
						request.addConstraintViolation(PENSION_VARIED_ONBASISOF_GENDER_FIELD_NAME, ErrorCodes.INVALID_PENSION_VARIED_ONBASISOF_GENDER);
						valid = false;
					}
				
					
				}else{
					if(Optional.ofNullable(account.getLiraAccountDetails().getProvince()).isPresent()){
						if(RefDataValues.PROVINCE_MB.equals(account.getLiraAccountDetails().getProvince())){
							if(!Optional.ofNullable(account.getLiraAccountDetails().getPensionAssetsOriginateFrom()).isPresent()){
								request.addConstraintViolation(PENSIONESSETS_ORIGINATEFROM_FIELD_NAME, ErrorCodes.INVALID_PENSIONASSETS_ORIGINATE_FROM);
								valid = false;
							}
						}else if(RefDataValues.PROVINCE_NL.equals(account.getLiraAccountDetails().getProvince()) 
								|| RefDataValues.PROVINCE_NS.equals(account.getLiraAccountDetails().getProvince())
								|| RefDataValues.PROVINCE_ONT.equals(account.getLiraAccountDetails().getProvince())){
							if(!Optional.ofNullable(account.getLiraAccountDetails().getPensionVariedoOnBasisOfGender()).isPresent()){
								request.addConstraintViolation(PENSION_VARIED_ONBASISOF_GENDER_FIELD_NAME, ErrorCodes.INVALID_PENSION_VARIED_ONBASISOF_GENDER);
								valid = false;
							}
							
						}else if(RefDataValues.PROVINCE_NB.equals(account.getLiraAccountDetails().getProvince())){
							if(!Optional.ofNullable(account.getLiraAccountDetails().getPensionVariedoOnBasisOfGender()).isPresent()){
								request.addConstraintViolation(PENSION_VARIED_ONBASISOF_GENDER_FIELD_NAME, ErrorCodes.INVALID_PENSION_VARIED_ONBASISOF_GENDER);
								valid = false;
							}
							
							if(!Optional.ofNullable(account.getLiraAccountDetails().getFundingInstructions()).isPresent()){
								request.addConstraintViolation(FUNDING_INSTRUCTIONS_FIELD_NAME, ErrorCodes.INVALID_FUNDING_INSTRUCTIONS);
								valid = false;
							}else if("1".equals(account.getLiraAccountDetails().getFundingInstructions())){
								if (!Optional.ofNullable(account.getLiraAccountDetails().getTransferredAmount())
										.isPresent()
										|| !isBetween(account.getLiraAccountDetails().getTransferredAmount(),
												new BigDecimal(TRANSFERRED_AMOUNT_MIN_VAL),
												new BigDecimal(TRANSFERRED_AMOUNT_MAX_VAL))) {
									request.addConstraintViolation(TRANSFERRED_AMOUNT_FIELD_NAME,
											ErrorCodes.INVALID_TRANSFERRED_AMOUNT);
									valid = false;
								}
								if (StringUtils
										.isBlank(account.getLiraAccountDetails().getTransferredAmountDollarsInWords())
										|| StringUtils
												.isBlank(account.getLiraAccountDetails().getTransferredAmountCentsInWords())
										|| (StringUtils
												.isNotBlank(account.getLiraAccountDetails()
														.getTransferredAmountDollarsInWords())
												&& account.getLiraAccountDetails().getTransferredAmountDollarsInWords()
														.length() > TRANSFERRED_AMOUNT_DOLLARS_IN_WORDS_MAX_SIZE)
										|| (StringUtils.isNotBlank(
												account.getLiraAccountDetails().getTransferredAmountCentsInWords())
												&& account.getLiraAccountDetails().getTransferredAmountCentsInWords()
														.length() > TRANSFERRED_AMOUNT_CENTS_IN_WORDS_MAX_SIZE)) {
									request.addConstraintViolation(TRANSFERRED_AMOUNT_IN_WORDS_FIELD_NAME,
											ErrorCodes.INVALID_TRANSFERRED_AMOUNT_IN_WORDS);
									valid = false;

								}
							}														
							
						}else if(RefDataValues.PROVINCE_QBC.equals(account.getLiraAccountDetails().getProvince())){							
							if(!Optional.ofNullable(account.getLiraAccountDetails().getPensionAssetsOriginateFrom()).isPresent()){
								request.addConstraintViolation(PENSIONESSETS_ORIGINATEFROM_FIELD_NAME, ErrorCodes.INVALID_PENSIONASSETS_ORIGINATE_FROM);
								valid = false;
							}
						}else if(RefDataValues.PROVINCE_SK.equals(account.getLiraAccountDetails().getProvince())){
							if(!Optional.ofNullable(account.getLiraAccountDetails().getPensionAssetsOriginateFrom()).isPresent()){
								request.addConstraintViolation(PENSIONESSETS_ORIGINATEFROM_FIELD_NAME, ErrorCodes.INVALID_PENSIONASSETS_ORIGINATE_FROM);
								valid = false;
							}
							if(!Optional.ofNullable(account.getLiraAccountDetails().getPensionAccumulatedBefore1993()).isPresent()){
								request.addConstraintViolation(PENSION_ACCUMULATES_BEFORE1993_FIELD_NAME, ErrorCodes.INVALID_PENSIONACCUMULATED_BEFORE1993);
								valid = false;
							}
							
						}else if(RefDataValues.PROVINCE_AB.equals(account.getLiraAccountDetails().getProvince())
								|| RefDataValues.PROVINCE_BC.equals(account.getLiraAccountDetails().getProvince())){
							
						}
					}else{
						if(account.isLira()){
						request.addConstraintViolation(LIRA_PROVINCE_FIELD_NAME, ErrorCodes.INVALID_LIRA_PROVINCE);
						valid = false;
						}
					}
				}
				
			}else{
				request.addConstraintViolation(JURISDICTION_TYPE_FIELD_NAME, ErrorCodes.INVALID_JURISDICTION_TYPE);
				valid = false;
			}
			
		}else{
			request.addConstraintViolation(JURISDICTION_TYPE_FIELD_NAME, ErrorCodes.INVALID_JURISDICTION_TYPE);			
			valid = false;
		}
		
		return valid;
	}
	
	private boolean validateLifAccountDetails(Account account, ValidationRequest request, Party primaryApplicant) {
		boolean valid = true;
		if(Optional.ofNullable(account.getLiraAccountDetails()).map(LiraAccountDetails::getJurisdictionType).isPresent()){

			if (FEDERAL_JURISDICTION_TYPE.equals(account.getLiraAccountDetails().getJurisdictionType())) {

			} else if (PROVINCIAL_JURISDICTION_TYPE.equals(account.getLiraAccountDetails().getJurisdictionType())) {
				valid = validateLifProvince(account.getLiraAccountDetails().getProvince(), request) && valid;
				valid = validateLifFundingInstructions(account.getLiraAccountDetails().getFundingInstructions(),
						account.getLiraAccountDetails().getProvince(), request) && valid;
				valid = validateLifTransferredAmount(account.getLiraAccountDetails().getTransferredAmount(),
						account.getLiraAccountDetails().getProvince(),
						account.getLiraAccountDetails().getFundingInstructions(), request) && valid;
				valid = validateLifTransferredAmountDollarsAndCentsInWords(
						account.getLiraAccountDetails().getTransferredAmountDollarsInWords(),
						account.getLiraAccountDetails().getTransferredAmountCentsInWords(),
						account.getLiraAccountDetails().getProvince(),
						account.getLiraAccountDetails().getFundingInstructions(), request) && valid;
				valid = validateLifPensionAssetsOriginateFrom(
						account.getLiraAccountDetails().getPensionAssetsOriginateFrom(),
						account.getLiraAccountDetails().getProvince(), request);
				valid = validateSpouseOptionType(account.getLiraAccountDetails().getSpouseOptionType(),
						account.getLiraAccountDetails().getProvince(), primaryApplicant, request) && valid;
			}
			valid = validateSourcesOfAssets(account.getLiraAccountDetails().getSourcesOfAssets(), request) && valid;
	
		}else{
			request.addConstraintViolation(JURISDICTION_TYPE_FIELD_NAME, ErrorCodes.INVALID_JURISDICTION_TYPE);			
			valid = false;
		}
		
		return valid;
	}
	
	private boolean validatejointApplicantPartyRefIds(Account account, ValidationRequest request, Application application) {
		boolean valid = true;
		
		if (account.isJoint()) {
			if (account.getJointApplicantPartyRefIds() == null 
					|| CollectionUtils.isEmpty(account.getJointApplicantPartyRefIds()) 
					|| account.getJointApplicantPartyRefIds().size() > NUMBER_OF_ALLOWED_JOINT_APPLICANTS) {
				
				request.addConstraintViolation(JOINT_APPLICANT_PARTY_REF_IDS, ErrorCodes.INVALID_JOINT_APPLICANT_PARTY_REF_IDS);
				valid = false;
			}
			
			else { 
				for (String jointPartyRefId: account.getJointApplicantPartyRefIds()) {
					
					
					
					if (application.getPrimaryApplicant().getPartyRefId().equals(jointPartyRefId) || 
							!application.getParties().stream().anyMatch(p -> p.getPartyRefId().equals(jointPartyRefId))) {
						
						request.addConstraintViolation(JOINT_APPLICANT_PARTY_REF_IDS, ErrorCodes.INVALID_JOINT_APPLICANT_PARTY_REF_IDS);
						valid = false;
					}
				}
			}
		}
		else {
			if(account.getJointApplicantPartyRefIds() != null && CollectionUtils.isNotEmpty(account.getJointApplicantPartyRefIds())) {
				request.addConstraintViolation(JOINT_APPLICANT_PARTY_REF_IDS, ErrorCodes.INVALID_JOINT_APPLICANT_PARTY_REF_IDS);
				valid = false;
			}
		}
		return valid;
	}
	
	private boolean validateAccountNameOrderPartyId(String id,List<Party> jointApplicants) {
		for(Party party: jointApplicants){
			if(id.equals(party.getPartyRefId())){
				return true;
			}
		}
		return false;
	}
	
	private boolean validateHasBeneficiariesAnswered(Account account, ValidationRequest request) {
		if(!Optional.ofNullable(account.getHasBeneficiaries()).isPresent()) {					
			request.addConstraintViolation(HAS_BENEFICIARIES_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_HAS_BENEFICIARIES);
			return false;
		}		
		return true;
	}

	private boolean validatePrimaryApplicantPartyRefId(Account account, ValidationRequest request,Party primaryApplicant) {		
		if(StringUtils.isBlank(account.getPrimaryApplicantPartyRefId())
				|| !account.getPrimaryApplicantPartyRefId().equalsIgnoreCase(primaryApplicant.getPartyRefId()))  {
			request.addConstraintViolation(PRIMARY_APPLICANT_PARTY_REF_ID_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_PRIMARY_APPLICANT_PARTY_REF_ID);
			return false;
		}
		return true;
	}
	
	private boolean checkProvinceIsQUEBEC(Party primaryApplicant) {
		if(primaryApplicant.getPersonal().getResidence()!=null &&
				primaryApplicant.getPersonal().getResidence().getPrimaryAddress()!=null &&
				RefDataValues.PROVINCE_QBC.equals(primaryApplicant.getPersonal().getResidence().getPrimaryAddress().getProvince()))
			return true;
		else	
			return false;
	}

	private boolean isValidSuccessorAnnuitant(Account account, ValidationRequest request, Party primaryApplicant) {
		// annuitant can't be specified in QC
		boolean valid = true;
		Boolean quebecFlag=checkProvinceIsQUEBEC(primaryApplicant);
		if(quebecFlag && account.getHasSuccessorAnnuitant() != null && account.getHasSuccessorAnnuitant()) {
			addSuccessorAnnuitantConstraintViolation(request);							
			valid = false;
		} else if(!quebecFlag){
			Boolean hasSuccessorAnnuitant = account.getHasSuccessorAnnuitant();	
			Boolean isPrimaryApplicantHasSpouse = this.isValidSpouse(primaryApplicant.getPersonal().getIdentity().getMaritalStatus());
			if(isPrimaryApplicantHasSpouse && !Optional.ofNullable(hasSuccessorAnnuitant).isPresent()) {				
				addSuccessorAnnuitantConstraintViolation(request);							
				valid = false;				
			}
			else if(!isPrimaryApplicantHasSpouse && hasSuccessorAnnuitant != null && hasSuccessorAnnuitant) {
				addSuccessorAnnuitantConstraintViolation(request);							
				valid = false;
			}			
		}		
		return valid;
	}

	private boolean validateIsSpousalForRsp(Account account, ValidationRequest request) {
		if(account.isRsp() && !Optional.ofNullable(account.getIsSpousal()).isPresent()) {
			request.addConstraintViolation(IS_SPOUSAL_FIELD_NAME, ErrorCodes.INVALID_SPOUSAL_RSP);
			return false;
		}
		return true;
	} 
	
	private boolean isValidSpousalRsp(Account account, ValidationRequest request) {
		boolean valid = true;
		ValidationRequest contributorValReq = request.createChildValidationRequest(CONTRIBUTOR_FIELD_NAME, null);
		
		if(Optional.ofNullable(account.getContributor()).isPresent() 
				&& Optional.ofNullable(account.isSpousalRsp()).isPresent() && account.isSpousalRsp()) {
			
			if(Optional.ofNullable(account.getContributor().getName()).isPresent()
					&& !Optional.ofNullable(account.getContributor().getName().getFirstName()).isPresent()
					|| !this.doesPatternMatch(account.getContributor().getName().getFirstName(),NAME_PATTERN)) {				
				contributorValReq.addConstraintViolation(NAME_PATH.concat(".").concat(FIRST_NAME_FIELD_NAME), ErrorCodes.INVALID_FIRST_NAME);							
				valid = false;
			}
		    if(Optional.ofNullable(account.getContributor().getName()).isPresent() 
		    		&& !Optional.ofNullable(account.getContributor().getName().getLastName()).isPresent()
		    		|| !this.doesPatternMatch(account.getContributor().getName().getLastName(),NAME_PATTERN)) {			
		    	contributorValReq.addConstraintViolation(NAME_PATH.concat(".").concat(LAST_NAME_FIELD_NAME), ErrorCodes.INVALID_LAST_NAME);
				valid = false;
			}
			if(!Optional.ofNullable(account.getContributor().getDateOfBirth()).isPresent()) {				
				contributorValReq.addConstraintViolation(DOB_FIELD_NAME, ErrorCodes.INVALID_DATE_OF_BIRTH);
				valid = false;
			}
			if(!Optional.ofNullable(account.getContributor().getSocialInsuranceNumber()).isPresent()
					|| (Optional.ofNullable(account.getContributor().getSocialInsuranceNumber()).isPresent() 
							&& !verifySinPattern(account.getContributor().getSocialInsuranceNumber()))) {				
				contributorValReq.addConstraintViolation(SIN_FIELD_NAME, ErrorCodes.INVALID_SIN);
				valid = false;
			}
		}
		return valid;
	}
	

	private void addSuccessorAnnuitantConstraintViolation(ValidationRequest request) {		
		request.addConstraintViolation(SUCCESSOR_ANNUITANT_FIELD_NAME, ErrorCodes.INVALID_SUCCESSOR_ANNUITANT);		
	}		

	private boolean validateSubTypes(Account account, ValidationRequest request) {
		if(!areSubTypesValid(account.getSubTypes(), request.getLob()))  {			
			request.addConstraintViolation(SUB_TYPES_FIELD_NAME, ErrorCodes.INVALID_SUB_TYPE);
			return false;
		}
		return true;
	}

	private boolean validateAreOtherPartiesSpecified(Account account, ValidationRequest request) {
		boolean valid = true;
		
		if (!Optional.ofNullable(account.getAreOtherPartiesSpecified()).isPresent()) {
				request.addConstraintViolation(ARE_OTHER_PARTIES_SPECIFIED_FIELD_NAME, ErrorCodes.INVALID_OTHER_PARTIES_SPECIFIED);
				valid = false;
		}
		else if ((account.isIndividual() || account.isJoint())&& account.getAreOtherPartiesSpecified()) {
			if (CollectionUtils.isEmpty(account.getGuaranteeRefIds()) 
					&& CollectionUtils.isEmpty(account.getGuarantorRefIds()) 
					&& CollectionUtils.isEmpty(account.getTradingAuthorityPartyRefIds())) {

				request.addConstraintViolation(ARE_OTHER_PARTIES_SPECIFIED_FIELD_NAME, ErrorCodes.INVALID_OTHER_PARTIES_INFO);
				valid = false;
			}
		}
		else if(account.getAreOtherPartiesSpecified()){
			if(CollectionUtils.isEmpty(account.getTradingAuthorityPartyRefIds())){					
				request.addConstraintViolation(TRADING_AUTH_PARTY_REF_ID_FIELD_NAME, ErrorCodes.INVALID_TRADING_AUTHORITY_PARTY_REF_ID);
				valid = false;
			}
		}
		return valid;
	} 

	private boolean validateIntendedUse(Account account, ValidationRequest request) {
		if(StringUtils.isBlank(account.getIntendedUse())) {			
			request.addConstraintViolation(INTENDED_USE_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_INTENDED_USE);
			return false;
		} else {
			if(isOtherIntendedUse(account.getIntendedUse()) && isInvalidOtherDescription(account.getOtherDescription())) {				
				request.addConstraintViolation(OTHER_DESCRIPTION_FIELD_NAME, ErrorCodes.INVALID_INTENDED_USE_DESCRIPTION);
				return false;
			}
		}
		return true;
	}
	
	private boolean isValidLinkDebitCard(Account account, ValidationRequest request) {
		//IL required; for NB not required
		if ( /*(ApplicationLob.il.equals(request.getLob()) && !Optional.ofNullable(account.getLinkDebitCard()).isPresent() ) ||*/
				(ApplicationLob.nb.equals(request.getLob()) && Optional.ofNullable(account.getLinkDebitCard()).isPresent()) ) {			
			request.addConstraintViolation(LINK_DEBIT_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_LINK_DEBIT_CARD);
			return false;	
		}
		return true;
	}

	private boolean isValidDebitCardNumber(Account account, ValidationRequest request) {
		//IL only, NB its not required			
		request.setFieldValue(account.getDebitCardNumber());
		if (( ApplicationLob.il.equals(request.getLob()) &&  Optional.ofNullable(account.getLinkDebitCard()).isPresent() && account.getLinkDebitCard() 
				&& StringUtils.isEmpty(account.getDebitCardNumber()) )  
				|| (ApplicationLob.nb.equals(request.getLob()) && StringUtils.isNoneBlank(account.getDebitCardNumber()))
				) {
				request.addConstraintViolation(DEBIT_CARD_NUMBER_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_DEBIT_CARD);
				return false;
		}
		return true;
	}

	private boolean isInvalidOtherDescription(String otherDescription) {
		return StringUtils.isBlank(otherDescription) || ! otherDescription.matches("^[ \\,"+ Patterns.ALPHANUMERIC + "]{1,100}$");
	}

	private boolean isOtherIntendedUse(String intendedUse) {
		return RefDataValues.INTENDED_USE_OTHER.equalsIgnoreCase(intendedUse);
	}

	boolean areSubTypesValid(List<String> subTypes, ApplicationLob applicationLob) {
		boolean valid;
		
		if(ApplicationLob.nb == applicationLob) {
			valid = CollectionUtils.isNotEmpty(subTypes) && isAllowedSubTypes(subTypes, applicationLob);
		} else if(ApplicationLob.il == applicationLob) {
			valid = CollectionUtils.isNotEmpty(subTypes) && (subTypes.size() == 1) && isAllowedSubTypes(subTypes, applicationLob);
		} else {
			valid = false;
		}
		return valid;
	}

	private boolean isAllowedSubTypes(List<String> subTypes, ApplicationLob lob) {
		List<String> allowedList = ALLOWED_SUB_TYPES.get(lob);
		for(String subType : subTypes) {
			if(!allowedList.contains(subType.toUpperCase())) return false;
		}
		return true;
	}

	private boolean isValidAccountLinkType(Account account, ValidationRequest request) {
		//IL only, NB not required
		if ( /*( ApplicationLob.il.equals(request.getLob()) && StringUtils.isEmpty(account.getAccountLinkType())) ||*/
				(ApplicationLob.nb.equals(request.getLob()) && StringUtils.isNoneBlank(account.getAccountLinkType()))	) {						
			request.addConstraintViolation(ACCOUNT_LINK_TYPE_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_LINK_TYPE);		
			return false;			
		}		
		return true;
	}

	private boolean isValidBankUsFunds(Account account, ValidationRequest request) {
		//IL only optional, NB not required
		if (ApplicationLob.nb.equals(request.getLob()) && Optional.ofNullable(account.getBankUsFunds()).isPresent())	 {			
			request.addConstraintViolation(BANK_US_FUNDS_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_BANK_US_FUNDS);		
			return false;			
		}				
		return true;
	}

	private boolean isValidAccountType(Account account, ValidationRequest request) {
		if (StringUtils.isEmpty(account.getType())) {			
			request.addConstraintViolation(TYPE_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_TYPES);							
			return false;
		}		
		return true;	
	}

	private boolean isValidInvestmentTimeHorizon(Account account, ValidationRequest request) {
		//investmentTimeHorizon NB only, IL should be null
		if ( (ApplicationLob.nb.equals(request.getLob()) && StringUtils.isEmpty(account.getInvestmentTimeHorizon())) /*|| 
				(ApplicationLob.il.equals(request.getLob()) &&  StringUtils.isNotEmpty(account.getInvestmentTimeHorizon()))*/ ) {						
			request.addConstraintViolation(INVESTMENT_TIME_HORIZON_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_INVESTMENT_TIME_HORIZON);			
			return false;
		}
		return true;
	}
	
	private boolean validateAccountInvestmentObjectives(Party primaryApplicant, Account account, ValidationRequest request) {
		
		if (request.getLob().equals(ApplicationLob.nb) && primaryApplicant != null ) {
				return this.investmentObjectivesValidator.validateAccountInvestmentObjectives(account, request);
		}
		return true;
	}
	
	private boolean validateThirdPartyInterest(Account account, ValidationRequest request) {
		if (account.getHasThirdPartyInterest() == null || (account.getHasThirdPartyInterest() != null && account.getHasThirdPartyInterest())) {
			request.addConstraintViolation(HAS_THIRD_PARTY_FIELD_NAME, ErrorCodes.INVALID_ACCOUNT_HAS_THIRD_PARTY_INTEREST);
			return false;
		}
		return true;
	}

	private boolean validateLifProvince(String province, ValidationRequest request) {
		if(!Optional.ofNullable(province).isPresent()) {					
			request.addConstraintViolation(LIF_PROVINCE_FIELD_NAME, ErrorCodes.INVALID_LIF_PROVINCE);
			return false;
		}		
		return true;
	}
	
	private boolean validateSourcesOfAssets(List<String> sourcesOfAssets, ValidationRequest request) {
		if(CollectionUtils.isEmpty(sourcesOfAssets)) {					
			request.addConstraintViolation(SOURCE_OF_ASSETS_NAME, ErrorCodes.INVALID_SRC_OF_ASSESTS);
			return false;
		}		
		return true;
	}
	
	private boolean validateLifFundingInstructions(String fundingInstructions, String province, ValidationRequest request) {
		if(RefDataValues.PROVINCE_NB.equalsIgnoreCase(province) && !Optional.ofNullable(fundingInstructions).isPresent()) {					
			request.addConstraintViolation(FUNDING_INSTRUCTIONS_FIELD_NAME, ErrorCodes.INVALID_FUNDING_INSTRUCTIONS);
			return false;
		}		
		return true;
	}
	
	private boolean validateLifTransferredAmount(BigDecimal transferredAmount, String province, String fundingInstructions, ValidationRequest request) {
		if (RefDataValues.PROVINCE_NB.equalsIgnoreCase(province)
				&& SPECIFY_AMT_OF_TRFR_FUNDING_INSTRUCTION.equalsIgnoreCase(fundingInstructions)
				&& (!Optional.ofNullable(transferredAmount).isPresent()
				|| !isBetween(transferredAmount, new BigDecimal(TRANSFERRED_AMOUNT_MIN_VAL),
						new BigDecimal(TRANSFERRED_AMOUNT_MAX_VAL)))) {
			request.addConstraintViolation(TRANSFERRED_AMOUNT_FIELD_NAME, ErrorCodes.INVALID_TRANSFERRED_AMOUNT);
			return false;
		}		
		return true;
	}
	
	private boolean validateLifTransferredAmountDollarsAndCentsInWords(String transferredAmountDollarsInWords,
			String transferredAmountCentsInWords, String province, String fundingInstructions,
			ValidationRequest request) {
		if (RefDataValues.PROVINCE_NB.equalsIgnoreCase(province)
				&& SPECIFY_AMT_OF_TRFR_FUNDING_INSTRUCTION.equalsIgnoreCase(fundingInstructions)
				&& (StringUtils.isBlank(transferredAmountDollarsInWords)
				|| StringUtils.isBlank(transferredAmountCentsInWords)
				|| (StringUtils.isNotBlank(transferredAmountDollarsInWords)
						&& transferredAmountDollarsInWords.length() > TRANSFERRED_AMOUNT_DOLLARS_IN_WORDS_MAX_SIZE)
				|| (StringUtils.isNotBlank(transferredAmountCentsInWords)
						&& transferredAmountCentsInWords.length() > TRANSFERRED_AMOUNT_CENTS_IN_WORDS_MAX_SIZE))) {
			request.addConstraintViolation(TRANSFERRED_AMOUNT_IN_WORDS_FIELD_NAME,
					ErrorCodes.INVALID_TRANSFERRED_AMOUNT_IN_WORDS);
			return false;
		}
		return true;
	}
	
	private boolean validateLifPensionAssetsOriginateFrom(String pensionAssetsOriginateFrom, String province,
			ValidationRequest request) {
		if (!RefDataValues.PROVINCE_NB.equals(province)
				&& !Optional.ofNullable(pensionAssetsOriginateFrom).isPresent()) {
			request.addConstraintViolation(PENSIONESSETS_ORIGINATEFROM_FIELD_NAME,
					ErrorCodes.INVALID_PENSIONASSETS_ORIGINATE_FROM);
			return false;
		}
		return true;
	}
	
	private boolean validateSpouseOptionType(String spouseOptionType, String province, Party primaryAppParty, ValidationRequest request) {
		if (Optional.ofNullable(primaryAppParty).map(Party::getPersonal).map(PersonalInformation::getIdentity)
				.map(Identity::getMaritalStatus).isPresent()
				&& (primaryAppParty.getPersonal().getIdentity().getMaritalStatus()
						.equalsIgnoreCase(RefDataValues.MARITAL_STATUS_MARRIED)
						|| primaryAppParty.getPersonal().getIdentity().getMaritalStatus()
								.equalsIgnoreCase(RefDataValues.MARITAL_STATUS_COMMON_LAW))
				&& RefDataValues.PROVINCE_ONT.equalsIgnoreCase(province) && StringUtils.isBlank(spouseOptionType)) {
			request.addConstraintViolation(SPOUSE_OPTION_TYPE, ErrorCodes.INVALID_SPOUSE_OPTION_TYPE);
			return false;
		}		
		return true;
	}
}
