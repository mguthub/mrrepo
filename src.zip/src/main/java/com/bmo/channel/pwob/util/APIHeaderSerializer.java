package com.bmo.channel.pwob.util;

import java.io.IOException;
import java.util.Optional;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import net.bmogc.xmlns.api.header.v1.APIHeaderRequest;
import net.bmogc.xmlns.api.header.v1.Correlation;
import net.bmogc.xmlns.api.header.v1.What;
import net.bmogc.xmlns.api.header.v1.Where;
import net.bmogc.xmlns.api.header.v1.Who;

public class APIHeaderSerializer extends StdSerializer<APIHeaderRequest> {
	private static final long serialVersionUID = 1L;

	public APIHeaderSerializer() {
		this(null);
	}

	protected APIHeaderSerializer(Class<APIHeaderRequest> t) {
		super(t);
	}

	@Override
	public void serialize(APIHeaderRequest hubHeader, JsonGenerator jgen, SerializerProvider provider)
			throws IOException, JsonGenerationException {

		jgen.writeStartObject();

		jgen.writeObjectFieldStart("APIHeaderRequest");

		jgen.writeStringField("digitalSignature", hubHeader.getDigitalSignature());
		jgen.writeStringField("headerVersion", hubHeader.getHeaderVersion());
		jgen.writeNumberField("timeoutTime", hubHeader.getTimeoutTime());


		Correlation correlation = hubHeader.getCorrelation();
		jgen.writeObjectFieldStart("correlation");
		jgen.writeStringField("callPath", correlation.getCallPath());
		jgen.writeStringField("myId", correlation.getMyId());
		jgen.writeStringField("myTimeStamp", DateUtils.convertDateToStringWithTimezone(correlation.getMyTimeStamp().toGregorianCalendar().getTime()));
		jgen.writeStringField("requestId", correlation.getRequestId());
		jgen.writeEndObject();


		What what = hubHeader.getWhat();
		jgen.writeObjectFieldStart("what");
		jgen.writeStringField("API", what.getAPI());
		jgen.writeStringField("APIFunction", what.getAPIFunction());
		jgen.writeEndObject();

		Where where = hubHeader.getWhere();
		jgen.writeObjectFieldStart("where");
		jgen.writeStringField("originatorChannel", where.getOriginatorChannel());
		jgen.writeStringField("originatorApplicationCatalogueId", where.getOriginatorApplicationCatalogueId());
		jgen.writeStringField("originatorLocationId", where.getOriginatorLocationId());
		jgen.writeStringField("originatorLocationType", where.getOriginatorLocationType());
		jgen.writeStringField("originatorSessionId", where.getOriginatorSessionId());
		jgen.writeEndObject();
		
		if (Optional.ofNullable(hubHeader).map(APIHeaderRequest::getWho).isPresent()) {
			Who who = hubHeader.getWho();
			jgen.writeObjectFieldStart("who");
			jgen.writeStringField("employeeUserId", who.getEmployeeUserId());
			jgen.writeStringField("employeeUserIdType", who.getEmployeeUserIdType());
			jgen.writeStringField("partyAccessId", who.getPartyAccessId());
			jgen.writeStringField("partyAccessIdType", who.getPartyAccessId());
			jgen.writeStringField("partyMultiFactorAuthenticationIndicator", who.getPartyMultiFactorAuthenticationIndicator());
			jgen.writeEndObject();
		}

		jgen.writeEndObject();
		
		jgen.writeEndObject();
	}
}
