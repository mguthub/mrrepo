/**
 * 
 */
package com.bmo.channel.pwob.service.accounts;

import java.util.List;
import java.util.Map;

/**
 * @author vvallia
 *
 */
public class ValidateAccountRequestBody {
	
	private String applicationId="Onboarding";
	
	private String accountId;
	
	private String channel="WEB";
	
	private String product="FSB";
	
	private String investmentAdvisorCode;
	
	private String networkId;
	
	private Map<String, List<String>> ruleList;
	
	public String getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getProduct() {
		return product;
	}

	public void setProduct(String product) {
		this.product = product;
	}

	public String getInvestmentAdvisorCode() {
		return investmentAdvisorCode;
	}

	public void setInvestmentAdvisorCode(String investmentAdvisorCode) {
		this.investmentAdvisorCode = investmentAdvisorCode;
	}

	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}

	public Map<String, List<String>> getRuleList() {
		return ruleList;
	}

	public void setRuleList(Map<String, List<String>> ruleList) {
		this.ruleList = ruleList;
	}

}
