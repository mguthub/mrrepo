package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

public class IaCodes {
	
	public IaCodes() {
	
	}

	public IaCodes(List<String> iaCodes) {
		super();
		this.iaCodes = iaCodes;
	}

	List<String> iaCodes;

	public List<String> getIaCodes() {
		return iaCodes;
	}

	public void setIaCodes(List<String> iaCodes) {
		this.iaCodes = iaCodes;
	}
	
	
}
