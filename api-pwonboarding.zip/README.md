# Channels Documents API

## Local Setup

### Java 8 installation
Install java 8 on your system 

### Maven installation
Maven is a Java tool, so you must have Java installed in order to proceed.
First, download Maven and follow the installation instructions. After that, type the following in a terminal or in a command prompt:
mvn --version

### Environment variable setup
JAVA_HOME	C:\Program Files\Java\jdk1.8.0_144
M2_HOME		C:\apache-maven-3.3.9
Add to path variable 
Update PATH variable, append Maven bin folder – %M2_HOME%\bin, so that you can run the Maven’s command everywhere.

### Apache Tomcat installation 
Download latest version of Apache Tomcat server on your machine.
   
### BMO Artifactory configuration
Go to url:   https://artifactory-qa.bmogc.net/artifactory
Click on any artifact and generate setting.xml file.
Once setting.xml is generated, copy this xml file to maven config and .M2 directory.
i.e
maven folder  : C:\apache-maven-3.3.9\conf
M2 Folder     :	C:\Users\gsand01\.m2  

### Certificate installation
Follow the instruction from below mentioned link.
https://confluence.bmogc.net/display/PWO/Artifactory+Migration+to+DML+Instance

### GIT installation
Install latest version of GIT.
Clone the PCD repository.

git clone   ****


## Running Locally

These instructions assume the following is already installed:

These instructions assume that you create a directory `c:\bmo-channel-services` for your environment properties file.

1. Download latest version of Eclipse EE
2. Import api-workflow project as a maven project and update the maven project.
3. Create server and set JRE 8 as runtime environment.
4. Go to server run configuration and click on Argument tab. Set below mentioned VM arguments

   -Dapi-workflows.channel.services.env.config.file="C:\bmo-channel-services\api-workflows.properties" 
   -Dlogback.configurationFile="C:\bmo-channel-services\channel-services-logback.xml" 
   -Dapi-party-v2.channel.services.env.config.file="C:\bmo-channel-services\api-party-v2.properties"

5. Run `MockServer` as a java application. This mocks the Hub services on port 21000.
6. Start the Apache Tomcat server.

## Running against a different back-end
Edit the api-workflows.properties file to pick a different back-end.

## Running Integration Tests locally from the command line
Running `mvn clean verify` will run the integration tests locally. This needs to be done with all tests passing before committing code.

## Running Integration Tests from eclipse
The integration tests can also be run from eclipse. You will need to start Liberty and make sure api-workflows is deployed. Also, 
`api-workflows.properties` will need to be configured to use the mock server:

hub.uploaddocument.uri=http://localhost:21000/upload

Once this is done, the tests can be run like any other JUnit test. 

