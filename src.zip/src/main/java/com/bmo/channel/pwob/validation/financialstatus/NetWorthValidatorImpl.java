package com.bmo.channel.pwob.validation.financialstatus;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.NetWorth;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class NetWorthValidatorImpl extends AbstractBaseValidator implements NetWorthValidator{


	private static final int ZERO = 0;
	private static final int MAX_VALUE = 999999999;
	
	@Autowired
	private UserContext userContext;


	public boolean isValid(NetWorth value, ValidationRequest validationRequest) {
		final ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

       
        final BigInteger fixedAssets = value.getFixedAssets();  // BIL:- saving Net worth in this field
        boolean valid = true;
        
    	if(ApplicationLob.nb.equals(userContext.getAuthenticatedUser().getLob())){
    		 final BigInteger liquidAssets = value.getLiquidAssets();
    		
    		if (liquidAssets == null || liquidAssets.intValue() > MAX_VALUE || liquidAssets.intValue() < ZERO) {			
    			validationRequest.addConstraintViolation("liquidAssets",ErrorCodes.INVALID_LIQUID_ASSETS);
    			valid = false;						
    		}    	
    	}
    					
			if (fixedAssets == null || fixedAssets.intValue() > MAX_VALUE || fixedAssets.intValue() < ZERO) {
				valid = false;			
				validationRequest.addConstraintViolation("fixedAssets",ErrorCodes.INVALID_FIXED_ASSETS);
			}		

		return valid;
	}

	
}
