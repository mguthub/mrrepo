/**
 * 
 */
package com.bmo.channel.pwob.validation.residence;

import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.AddressValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

/**
 * @author vvallia
 *
 */
@Component
public class PrimaryAddressValidatorImpl extends AbstractBaseValidator implements PrimaryAddressValidator {
	@Autowired private AddressValidator addressValidator;

	private static final String STREET_ADDRESS_FIELD_NAME = "streetAddress";	

	private static final Pattern PO_BOX_REGEX = Pattern.compile("^\\s*((P(OST )?.?\\s*(O(FF(ICE)?)?)?.?\\s+(B(IN|OX))?)|B(IN|OX)|(CP))", Pattern.CASE_INSENSITIVE);

	@Override
	public boolean validatePrimaryAddress(Address value, ValidationRequest request) {
		boolean valid = true;
		ValidationRequest primValReq = request.createChildValidationRequest("personal.residence.primaryAddress", "personal.residence.primaryAddress");
		//Validate PO Box on Primary Address
		valid = this.validatePrimaryAddressPOBox(value, primValReq) && valid;

		//Validate Address fields
		valid = this.validateAddress(value, primValReq) && valid;

		return valid;
	}

	private boolean validatePrimaryAddressPOBox(Address primaryAddress, ValidationRequest request) {
		request.setFieldValue(primaryAddress.getStreetAddress());
		request.setFieldName(STREET_ADDRESS_FIELD_NAME);		
		request.setErrorCode(ErrorCodes.INVALID_STREET_ADDR);
		if(!this.validField(request)) {
			request.addConstraintViolation();
			return false;
		}
		return true;
	}

	private boolean validField(ValidationRequest request) {
		//if contains any of the pattern - return false		
		if(StringUtils.isNoneBlank(request.getFieldValue()) && StringUtils.isNoneBlank(PO_BOX_REGEX.pattern()) && 
				Pattern.matches(PO_BOX_REGEX.pattern().toLowerCase(), request.getFieldValue().toLowerCase())) {												
			return false;
		}
		return true;
	}

	private boolean validateAddress(Address address, ValidationRequest request) {
		boolean valid = addressValidator.validateUnitStreetCityPostalCountry(request, address);

		if((PartyRole.PRIMARY_APPLICANT.equals(request.getPartyRole()) || PartyRole.TRADING_AUTHORITY.equals(request.getPartyRole()))
				&& !RefDataValues.CANADA_COUNTRY_CODE.equals(address.getCountry())) {
			request.setFieldName("country");
			request.setErrorCode(ErrorCodes.INVALID_PRIMARY_COUNTRY);
			request.addConstraintViolation();
			valid = false;
		}
		if((PartyRole.PRIMARY_APPLICANT.equals(request.getPartyRole()) || PartyRole.TRADING_AUTHORITY.equals(request.getPartyRole()))
				&& (RefDataValues.CANADA_COUNTRY_CODE.equals(address.getCountry()) && !isValidCanadianPostalCode(address.getPostalCode()))){
			request.setFieldName("postalCode");
			request.setErrorCode(ErrorCodes.INVALID_POSTAL_CODE);
			request.addConstraintViolation();			
			valid = false;
		}
		return valid;
	}

}
