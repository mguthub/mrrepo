/**
 * @author akhales
 */
package com.bmo.channel.pwob.convert;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ws.rs.WebApplicationException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.dozer.CustomConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.ILLaunchEndpoint;
import com.bmo.channel.pwob.util.DateUtils;

public class GregorianConvertor implements CustomConverter{
		
	private static Logger logger = LoggerFactory.getLogger(GregorianConvertor.class);
	
	@Override
	public Object convert(Object target, Object source, Class<?> targetClass,Class<?> sourceClass) {
		Date date=null;
		
		if (source == null) 
			return date;
		
		if (source instanceof java.lang.String) {
			String stringDate = (String) source;
			
			try {
				return DateUtils.getXMLGregorianDate(stringDate);

			} catch (Exception ex) {
				logger.error("Failure in date conversion. ", ex);
				throw new WebApplicationException(ex);
			}
		}
		//client data to form
		else if (source instanceof XMLGregorianCalendar) {
			XMLGregorianCalendar sourceDate = (XMLGregorianCalendar) source;
			return new SimpleDateFormat("yyyy-MM-dd").format(sourceDate.toGregorianCalendar().getTime());
		}

		return null;
	}
}
