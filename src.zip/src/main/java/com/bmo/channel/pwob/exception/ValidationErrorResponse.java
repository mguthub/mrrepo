package com.bmo.channel.pwob.exception;

import java.util.List;

import com.bmo.channel.core.exception.ErrorResponse;

public class ValidationErrorResponse extends ErrorResponse {
	private List<ValidationError> validationErrors;

	public List<ValidationError> getValidationErrors() {
		return validationErrors;
	}
	public void setValidationErrors(List<ValidationError> validationErrors) {
		this.validationErrors = validationErrors;
	}
}
