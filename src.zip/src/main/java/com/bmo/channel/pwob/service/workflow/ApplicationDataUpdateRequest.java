package com.bmo.channel.pwob.service.workflow;

import javax.xml.datatype.XMLGregorianCalendar;

public class ApplicationDataUpdateRequest {
	
	String applicationId;
	XMLGregorianCalendar lastUpdatedDateTime;
	String requestorId;
	
	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String workflowId) {
		this.applicationId = workflowId;
	}
	public XMLGregorianCalendar getLastUpdatedDateTime() {
		return lastUpdatedDateTime;
	}
	public void setLastUpdatedDateTime(XMLGregorianCalendar lastUpdatedDateTime) {
		this.lastUpdatedDateTime = lastUpdatedDateTime;
	}
	public String getRequestorId() {
		return requestorId;
	}
	public void setRequestorId(String requestorId) {
		this.requestorId = requestorId;
	}
}
