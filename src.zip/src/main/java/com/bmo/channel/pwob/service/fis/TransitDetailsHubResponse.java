package com.bmo.channel.pwob.service.fis;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.onboarding.Branch;
import com.bmo.channel.pwob.util.ArrayOrObjectDeserializer;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TransitDetailsHubResponse {
	private OperationResponse operationResponse;

	@JsonIgnoreProperties(ignoreUnknown = true)
	private static class OperationResponse {
		private GetFITransitDetailResponse getFITransitDetailResponse;

		@JsonIgnoreProperties(ignoreUnknown = true)
		private static class GetFITransitDetailResponse {
			private List<Record> records;

			private static class Record {
				private String institutionNumber;
				private String languagePreferenceCode;
				private String institutionNameEnglish;
				private String institutionNameFrench;
				private String civicAddress;
				private String postalAddress;
				private String townCity;
				private String provinceCode;
				private String postalCode;
				private String country;

				@JsonProperty("InstitutionNumber")
				public String getInstitutionNumber() {
					return institutionNumber;
				}

				@SuppressWarnings("unused")
				public void setInstitutionNumber(String institutionNumber) {
					this.institutionNumber = institutionNumber;
				}

				@JsonProperty("LanguagePreferenceCode")
				public String getLanguagePreferenceCode() {
					return languagePreferenceCode;
				}

				@SuppressWarnings("unused")
				public void setLanguagePreferenceCode(String languagePreferenceCode) {
					this.languagePreferenceCode = languagePreferenceCode;
				}

				@JsonProperty("InstitutionNameEnglish")
				public String getInstitutionNameEnglish() {
					return institutionNameEnglish;
				}

				@SuppressWarnings("unused")
				public void setInstitutionNameEnglish(String institutionNameEnglish) {
					this.institutionNameEnglish = institutionNameEnglish;
				}

				@JsonProperty("InstitutionNameFrench")
				public String getInstitutionNameFrench() {
					return institutionNameFrench;
				}

				@SuppressWarnings("unused")
				public void setInstitutionNameFrench(String institutionNameFrench) {
					this.institutionNameFrench = institutionNameFrench;
				}

				@JsonProperty("CivicAddress")
				public String getCivicAddress() {
					return this.civicAddress;
				}

				@SuppressWarnings("unused")
				public void setCivicAddress(String civicAddress) {
					this.civicAddress = civicAddress;
				}

				@JsonProperty("PostalAddress")
				public String getPostalAddress() {
					return postalAddress;
				}

				@SuppressWarnings("unused")
				public void setPostalAddress(String postalAddress) {
					this.postalAddress = postalAddress;
				}

				@JsonProperty("TownCity")
				public String getTownCity() {
					return this.townCity;
				}

				@SuppressWarnings("unused")
				public void setTownCity(String townCity) {
					this.townCity = townCity;
				}

				@JsonProperty("ProvinceCode")
				public String getProvinceCode() {
					return provinceCode;
				}

				@SuppressWarnings("unused")
				public void setProvinceCode(String provinceCode) {
					this.provinceCode = provinceCode;
				}

				@JsonProperty("PostalCode")
				public String getPostalCode() {
					return postalCode;
				}

				@SuppressWarnings("unused")
				public void setPostalCode(String postalCode) {
					this.postalCode = postalCode;
				}

				@JsonProperty("Country")
				public String getCountry() {
					return country;
				}

				@SuppressWarnings("unused")
				public void setCountry(String country) {
					this.country = country;
				}
			}

			@JsonProperty("Record")
			public List<Record> getRecord() {
				return records;
			}

			@JsonDeserialize(using = RecordsDeserializer.class)
			public void setRecord(List<Record> records) {
				this.records = records;
			}

			private static class RecordsDeserializer extends ArrayOrObjectDeserializer<Record> {
				public RecordsDeserializer() {
					super(Record.class);
				}
			}
		}

		public GetFITransitDetailResponse getGetFITransitDetailResponse() {
			return getFITransitDetailResponse;
		}

		@SuppressWarnings("unused")
		public void setGetFITransitDetailResponse(GetFITransitDetailResponse getFITransitDetailResponse) {
			this.getFITransitDetailResponse = getFITransitDetailResponse;
		}
	}

	public OperationResponse getOperationResponse() {
		return operationResponse;
	}

	public void setOperationResponse(OperationResponse operationResponse) {
		this.operationResponse = operationResponse;
	}

	public List<Branch> toBranchList(UILocale locale) {
		List<OperationResponse.GetFITransitDetailResponse.Record> records = this.operationResponse.getGetFITransitDetailResponse().getRecord();
		List<Branch> branches = new ArrayList<Branch>();
		
		if(!Optional.ofNullable(records).isPresent()) return branches;

		for (int i = 0; i < records.size(); i++) {
			OperationResponse.GetFITransitDetailResponse.Record record = records.get(i);

			EftRoutingNumber eftRoutingNumber = EftRoutingNumber.buildFromRoutingNumber(record.getInstitutionNumber());

			Branch branch = new Branch();
			branch.setCity(record.getTownCity());
			branch.setCivicAddress(record.getCivicAddress());
			branch.setFiId("0" + eftRoutingNumber.getFiId());

			branch.setFinancialInstitutionName(
					(locale == UILocale.EN_CA) ? record.getInstitutionNameEnglish()
							: record.getInstitutionNameFrench()
					);

			branch.setPostalAddress(record.getPostalAddress());
			branch.setPostalCode(record.getPostalCode());
			branch.setProvince(record.getProvinceCode());
			branch.setTransitId(eftRoutingNumber.getTransitId());

			branches.add(branch);
		}

		return branches;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
