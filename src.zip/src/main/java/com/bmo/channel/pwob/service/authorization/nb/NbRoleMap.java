package com.bmo.channel.pwob.service.authorization.nb;

import java.util.EnumMap;
import java.util.Map;

import com.bmo.channel.pwob.service.authorization.PwobAction;

public class NbRoleMap {
	private static Map<PwobAction, RoleRequirement> roles;

	public static RoleRequirement getRequirements(PwobAction function){
		return roles.get(function);
	}

	static {
		roles = new EnumMap<>(PwobAction.class);

		roles.put(PwobAction.CREATE_APPLICATION, new RoleRequirement(UserRole.APPLICATION_USER));
		roles.put(PwobAction.UPDATE_APPLICATION, new RoleRequirement(UserRole.APPLICATION_USER));
		roles.put(PwobAction.UPDATE_RELATIONSHIP_SUMMARY, new RoleRequirement(UserRole.APPLICATION_USER));
		roles.put(PwobAction.RETRIEVE_RELATIONSHIP_SUMMARY, new RoleRequirement(UserRole.APPLICATION_USER));
		roles.put(PwobAction.IA_APPROVAL, new RoleRequirement(UserRole.IA_APPROVER));
		roles.put(PwobAction.BM_APPROVAL, new RoleRequirement(UserRole.BM_APPROVER));
		roles.put(PwobAction.GENERATE_DOCUMENTS, new RoleRequirement(UserRole.ANY_USER));
		roles.put(PwobAction.UPLOAD_DOCUMENT, new RoleRequirement(UserRole.APPLICATION_USER));
		roles.put(PwobAction.DOCUMENT_ACTION, new RoleRequirement(UserRole.APPLICATION_USER));

		roles.put(PwobAction.DELETE_WORKFLOW, new RoleRequirement(UserRole.ANY_USER));
		roles.put(PwobAction.UNLOCK_DATA, new RoleRequirement(UserRole.ANY_USER));
	}
}
