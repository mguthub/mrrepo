package com.bmo.channel.pwob.service.applications;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.product.BilProduct;
import com.bmo.channel.pwob.model.product.BilProducts;
import com.bmo.channel.pwob.service.product.rsclient.AccountType;
import com.bmo.channel.pwob.service.product.rsclient.GetEligibleProductsForApplicantResponseBody.Lob.ProductList;

public class ProductEligibilityMapper implements Function<ProductList, BilProducts> {

	@Override
	public BilProducts apply(ProductList t) {

		BilProducts bilProds = new BilProducts();
		List<BilProduct> prodList = bilProds.getbilProduct();

		List<String> sortedProduct = new ArrayList<>();
		sortedProduct.add(Account.TFSA_TYPE);
		sortedProduct.add(Account.RSP_TYPE);
		sortedProduct.add(Account.INDIVIDUAL_TYPE);
		sortedProduct.add(Account.JOINT_TYPE);
		sortedProduct.add(Account.RIF_TYPE);
		sortedProduct.add(Account.LIRA_TYPE);

		// go through list and create sorted product list
		if (Optional.ofNullable(t).map(ProductList::getProduct).isPresent()
				&& Optional.ofNullable(t.getProduct().stream().findFirst()).isPresent()) {
			sortedProduct.stream().forEach(p -> {
				Optional<AccountType> accountType = t.getProduct().stream().findFirst().get().getAccountList()
						.getAccountType().stream().filter(f -> p.equals(f.getCode())).findFirst();
				if (accountType.isPresent()) {
					AccountType aType = accountType.get();
					BilProduct prod = new BilProduct();
					prod.setType(aType.getCode());
					prod.setProductNameEn(aType.getNameEN());
					prod.setProductNameFr(aType.getNameFR());
					prodList.add(prod);
				}
			});
		}
		return bilProds;
	}
}
