package com.bmo.channel.pwob.service.credential;

import com.bmo.channel.pwob.model.onboarding.ClientAccessIdResponse;
import com.bmo.channel.pwob.model.onboarding.Credential;
import com.bmo.channel.pwob.model.onboarding.SuggestedUserIds;
/** 
 * For user credential related functionalities.
 *
 */
public interface CredentialService {
	/** Update the user credential in the application. */
	ClientAccessIdResponse reserveUserCredential(final String applicationId, final Credential credential);
    Credential validateExistingAccessId(final String applicationId, final String userId);
    SuggestedUserIds retrieveSuggestedUserIds(final String applicationId, final String userIds);
    ClientAccessIdResponse retrieveApplicationUserId(final String applicationId);
}


