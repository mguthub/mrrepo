package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.account.beneficiary.ValidBeneficiary;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;

import io.swagger.annotations.ApiModelProperty;

@ValidBeneficiary
public class Beneficiary {
	private Name name = new Name();

	@ApiModelProperty(example="046454286", value="Must pass a LuhnCheck")	
	private String socialInsuranceNumber;

	@DataValidationPattern(code=ErrorCodes.INVALID_RELATIONSHIP_TO_PLAN_HOLDER)
	private String relationshipToPlanHolder;

	private Boolean hasPrimaryApplicantSpouse;

	private String beneficiaryRefId;

	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public String getSocialInsuranceNumber() {
		return socialInsuranceNumber;
	}
	public void setSocialInsuranceNumber(String socialInsuranceNumber) {
		this.socialInsuranceNumber = socialInsuranceNumber;
	}
	public String getRelationshipToPlanHolder() {
		return relationshipToPlanHolder;
	}
	public void setRelationshipToPlanHolder(String relationshipToPlanHolder) {
		this.relationshipToPlanHolder = relationshipToPlanHolder;
	}

	/**
	 * @return the beneficiaryRefId
	 */
	public String getBeneficiaryRefId() {
		return beneficiaryRefId;
	}
	/**
	 * @param beneficiaryRefId the beneficiaryRefId to set
	 */
	public void setBeneficiaryRefId(String beneficiaryRefId) {
		this.beneficiaryRefId = beneficiaryRefId;
	}

	public Boolean getHasPrimaryApplicantSpouse() {
		return hasPrimaryApplicantSpouse;
	}
	
	public void setHasPrimaryApplicantSpouse(Boolean hasPrimaryApplicantSpouse) {
		this.hasPrimaryApplicantSpouse = hasPrimaryApplicantSpouse;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
