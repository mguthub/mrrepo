package com.bmo.channel.pwob.validation.party;

import java.text.ParseException;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.employment.EmploymentValidator;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactoryImpl.ValidationRequestBuilder;

public class SpousePartyValidator extends AbstractBaseValidator implements ConstraintValidator<ValidSpouseParty, Party> {
	private static Logger logger = LoggerFactory.getLogger(SpousePartyValidator.class);
	@Autowired
	private UsersService userService;

	@Autowired
	private ValidationRequestFactory requestFactory;

	@Autowired
	private EmploymentValidator employmentValidator;

	@Override
	public void initialize(ValidSpouseParty constraintAnnotation) {	}

	@Override
	public boolean isValid(Party party, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		boolean valid = true;
		
		Application appln = validationContext.getApplication();
		
		ApplicationLob lob = this.userService.currentUser().getLob();		
		
		ValidationRequestBuilder builder = requestFactory.createBuilder(context, lob);	
		ValidationRequest request = builder.build();

		if(this.isSpouseOfPrimaryApplicant(party.getRoles()) || this.isTradingAuthSpouse(appln.getPrimaryApplicant().getSpousePartyRefId(), party)) {
			valid = this.noSpousePartyIfPrimaryApplicantSingle(appln.getPrimaryApplicant(), party, request) && valid;	
			

			if(CollectionUtils.isNotEmpty(appln.getAccounts())) {				
				if(StringUtils.isNotEmpty(appln.getPrimaryApplicant().getSpousePartyRefId())  && appln.getPrimaryApplicant().getSpousePartyRefId().equals(party.getPartyRefId())){
					valid = this.validateSpouseDOB(this.filterRifAccounts(appln.getAccounts()), party, appln.getPrimaryApplicant(),	request.createChildValidationRequest(PERSONAL_IDENTITY_NODE, PERSONAL_IDENTITY_PATH)) && valid;
				}
			}

			if(this.isApplicantMarried(appln.getPrimaryApplicant())) {
				valid = this.validateForUniqueSIN(appln.getPrimaryApplicant(), 
						party, 
						request.createChildValidationRequest(PERSONAL_IDENTITY_NODE, PERSONAL_IDENTITY_NODE))
						&& valid;

				ValidationRequest employmentRequest = builder.withParentPropertyNode(PERSONAL_EMPLOYMENT_NODE).withChildPropertyNode(StringUtils.EMPTY).build();
				valid = this.validateSpouseEmployment(party, employmentRequest) && valid;	
			}
		}
		
		if(CollectionUtils.isNotEmpty(appln.getAccounts())) {	
			if(appln.getPrimaryApplicant().getSpousePartyRefId() != null && appln.getPrimaryApplicant().getSpousePartyRefId().equals(party.getPartyRefId())){
				valid = this.validateSINWhenSpouseAsSuccessor(appln.getAccounts(),party,request.createChildValidationRequest(PERSONAL_IDENTITY_NODE, PERSONAL_IDENTITY_NODE)) && valid;
			}
		}
		
		if(CollectionUtils.isEmpty(party.getRoles()) && 
				(appln.getPrimaryApplicant().getSpousePartyRefId() == null || !(appln.getPrimaryApplicant().getSpousePartyRefId().equals(party.getPartyRefId())))){			

			ValidationRequest employmentRequest = builder.withParentPropertyNode(PERSONAL_EMPLOYMENT_NODE).withChildPropertyNode(StringUtils.EMPTY).build();
			valid = this.validateSpouseEmployment(party, employmentRequest) && valid;	
		}
		
		return valid;
	}			
	
	private List<Account> filterRifAccounts(List<Account> accounts) {
		return accounts.stream().filter(r -> r.isRif() && 
										r.getRifPayment() != null &&										
										r.getRifPayment().getIsSpouseAgeUsed() != null && 
										r.getRifPayment().getIsSpouseAgeUsed())
								.collect(Collectors.toList());
	}
	
	private boolean validateSINWhenSpouseAsSuccessor(List<Account> accounts, Party spouseParty,ValidationRequest request) {
		for(Account account : accounts){
			if((account.isRif() || account.isTfsa())&& (account.getHasSuccessorAnnuitant() != null && account.getHasSuccessorAnnuitant())){
				if(spouseParty.getPersonal().getIdentity() == null || StringUtils.isEmpty(spouseParty.getPersonal().getIdentity().getSocialInsuranceNumber())){
					request.addConstraintViolation(SIN_FIELD_NAME, ErrorCodes.INVALID_SIN);	
					return false;
				}
			}
		}
		return true;
	}

	private boolean isTradingAuthSpouse(String spousePartyRefId, Party party) {
		return CollectionUtils.isNotEmpty(party.getRoles()) && party.getRoles().contains(PartyRole.TRADING_AUTHORITY) &&
				StringUtils.isNotBlank(spousePartyRefId) && spousePartyRefId.equals(party.getPartyRefId());
	}

	private boolean validateSpouseEmployment(Party party, ValidationRequest request) {
		boolean valid = true;
		if(!Optional.ofNullable(party.getPersonal().getEmployment()).isPresent()) { 
			party.getPersonal().setEmployment(new Employment());
		}

		request.setFieldValue(party.getPersonal().getEmployment().getEmploymentStatus());
		valid = this.employmentValidator.validateEmploymentStatus(request) && valid;

		if(this.shouldValidateEmploymentStatus(party.getPersonal().getEmployment().getEmploymentStatus(), request.getLob())) {
			//business name validation
			valid = this.employmentValidator.validateEmployerBusinessName(request, party.getPersonal().getEmployment().getEmployerBusinessName()) && valid;

			//BMO Group
			request.setFieldValue(party.getPersonal().getEmployment().getBmoGroup());
			request.setBooleanFieldValue(party.getPersonal().getEmployment().getIsBmoEmployee());
			valid = this.employmentValidator.validateBMOGroup(request) && valid;
					
			//nature of business validation
			if (employmentValidator.shouldValidateNatureOfBusiness(party.getPersonal().getEmployment())) {
				request.setFieldValue(party.getPersonal().getEmployment().getNatureOfBusiness());
				valid = this.employmentValidator.validateNatureOfBusiness(request) && valid;
			}
			//occupation validation
			request.setFieldValue(party.getPersonal().getEmployment().getOccupation());
			valid = this.employmentValidator.validateOccupation(request) && valid;
		
			if(isValidBMOSubsidiaries(party.getPersonal().getEmployment().getEmployerBusinessName())) {				
				request.setFieldValue(party.getPersonal().getEmployment().getBmoGroup());
				valid = this.employmentValidator.validateLineOfBusiness(request) && valid;
			}
		}
		
		return valid;
	}

	private boolean validateSpouseDOB(List<Account> rifAccounts, Party party, Party primaryParty, ValidationRequest request) {
		boolean valid = true;
		try{
			if (CollectionUtils.isNotEmpty(rifAccounts)) {
				for (Account rifAccount : rifAccounts) {
					if (!Optional.ofNullable(rifAccount).isPresent() || validatePartnerDOB(party, primaryParty)) {						
						request.addConstraintViolation(DOB_FIELD_NAME, ErrorCodes.INVALID_DATE_OF_BIRTH);
						valid = false;
					}
				}
			}
		}catch(DateTimeParseException | ParseException ex){
			logger.warn("Failed to validate spouse party date of birth(DOB). ", ex);
			request.addConstraintViolation(DOB_FIELD_NAME, ErrorCodes.INVALID_DATE);
			valid = false;
		}
		return valid;
	}

	private boolean validateForUniqueSIN(Party primaryAppParty, Party spouseParty, ValidationRequest request) {
		if(this.isSINExist(primaryAppParty) && this.isSINExist(spouseParty) && primaryAppParty.getPersonal().getIdentity().getSocialInsuranceNumber().
				equals(spouseParty.getPersonal().getIdentity().getSocialInsuranceNumber())) {			
			request.addConstraintViolation(SIN_FIELD_NAME, ErrorCodes.INVALID_SIN);	
			return false;
		}
		return true;
	}

	private boolean isSINExist(Party party) {
		return Optional.ofNullable(party.getPersonal().getIdentity()).isPresent() && 
				StringUtils.isNoneBlank(party.getPersonal().getIdentity().getSocialInsuranceNumber());
	}

	public boolean validateDateOfBirth(Identity identity, ValidationRequest request) {
		if(identity == null || StringUtils.isBlank(identity.getDateOfBirth())) {
			request.addConstraintViolation();					
			return false;
		}		
		return true;
	}

	private boolean isApplicantMarried(Party party) {
		boolean isMaritalStatus = !isMaritalStatusNotSpecified(party.getPersonal().getIdentity());
		return isMaritalStatus && isValidSpouse(party.getPersonal().getIdentity().getMaritalStatus());
	}

	/**
	 * Validate for no spouse party when the primary party is single
	 * @param application
	 * @param request
	 * @return
	 */
	private boolean noSpousePartyIfPrimaryApplicantSingle(Party primaryAppParty, Party spouseParty, ValidationRequest request){
		if(primaryAppParty != null && StringUtils.isNotBlank(primaryAppParty.getSpousePartyRefId())){
			if(primaryAppParty.getPersonal().getIdentity().getMaritalStatus()!= null && 
					primaryAppParty.getPersonal().getIdentity().getMaritalStatus().equalsIgnoreCase(RefDataValues.MARITAL_STATUS_SINGLE)){

				if(spouseParty != null && StringUtils.isNotBlank(spouseParty.getPartyRefId())) {
					request.addConstraintViolation(PARTY_REF_ID_FIELD_NAME, ErrorCodes.INVALID_SPOUSE_PARTY_REF_ID);	
					return false;
				}
			}						
		}
		return true;
	}
}
