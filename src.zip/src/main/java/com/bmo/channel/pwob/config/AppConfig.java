/**
 * Creates spring beans at Startup and registers them in spring config  
 * @author akhales
 */
package com.bmo.channel.pwob.config;

import java.util.regex.Pattern;

import javax.ws.rs.HttpMethod;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bmo.channel.common.temp.filter.IvUserInjectionFilter;
import com.bmo.channel.core.event.BmoElkLogFormatterImpl;
import com.bmo.channel.core.event.LogFormatter;
import com.bmo.channel.core.security.XssFilter;

@Configuration
public class AppConfig {
	@Autowired
	private EnvironmentConfig environmentConfig;

	@Bean
	public XssFilter xssFilter() {
		XssFilter filter = new XssFilter();
		filter.setPatterns(environmentConfig.getPatterns());
		filter.addResourceToExclude(HttpMethod.POST, Pattern.compile(".*/.*/document_packages/.*/content"));
		return filter;
	}

	@Bean
	public IvUserInjectionFilter ilLaunchInjectionFilter(){
		return new IvUserInjectionFilter();
	}

	@Bean(name="formatter")
	public LogFormatter logFormatter(){
		LogFormatter formatter = new BmoElkLogFormatterImpl();
		return formatter;
	}

}
