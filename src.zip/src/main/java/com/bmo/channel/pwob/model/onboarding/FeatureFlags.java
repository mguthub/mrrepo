package com.bmo.channel.pwob.model.onboarding;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class FeatureFlags {

	/**
	 * As of R6, BETCH rules are always ACTIVE
	 * @deprecated
	 */
	@Deprecated
	public static final String BETCH_INACTIVE = "INACTIVE";

	public static final String BETCH_ACTIVE = "ACTIVE";
	public static final String BETCH = "BILLC31_ETCH";

	final private Set<FeatureFlag> featureFlags;

	public FeatureFlags(Set<FeatureFlag> featureFlags) {
		if(featureFlags != null) {
			this.featureFlags = Collections.unmodifiableSet(featureFlags);
		} else {
			this.featureFlags = Collections.unmodifiableSet(new HashSet<>());
		}
	}

	public FeatureFlags(FeatureFlag ... featureFlags) {
		this.featureFlags = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(featureFlags)));
	}

	public FeatureFlag get(String flagName) {
		return featureFlags.stream().filter(f -> f.getName().equals(flagName)).findFirst().orElse(null);
	}

	public Set<FeatureFlag> getAll() {
		return featureFlags;
	}
}
