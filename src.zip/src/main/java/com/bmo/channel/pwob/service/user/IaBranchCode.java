package com.bmo.channel.pwob.service.user;

public class IaBranchCode {
	private String iaCode;
	private String branchCode;
	private String networkId;

	public IaBranchCode(String networkId, String iaCode, String branchCode) {
		this.networkId = networkId;
		this.iaCode = iaCode;
		this.branchCode = branchCode;
	}

	public IaBranchCode(String networkId, String iaCode) {
		this.networkId = networkId;
		this.iaCode = iaCode;
		this.branchCode = null;
	}
	
	public String getIaCode() {
		return iaCode;
	}
	public void setIaCode(String iaCode) {
		this.iaCode = iaCode;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getNetworkId() {
		return networkId;
	}

	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}
}
