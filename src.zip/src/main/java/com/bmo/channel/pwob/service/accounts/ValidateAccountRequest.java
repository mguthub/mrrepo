/**
 * 
 */
package com.bmo.channel.pwob.service.accounts;

/**
 * @author vvallia
 *
 */
public class ValidateAccountRequest {
	
	private ValidateAccountRequestBody validateAccountRequestBody;

	public ValidateAccountRequestBody getValidateAccountRequestBody() {
		return validateAccountRequestBody;
	}

	public void setValidateAccountRequestBody(ValidateAccountRequestBody validateAccountRequestBody) {
		this.validateAccountRequestBody = validateAccountRequestBody;
	}

}
