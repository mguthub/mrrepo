package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.validation.Valid;
import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;

import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.applications.Summary;
import com.bmo.channel.pwob.service.applications.FilteringSavedApplicationsService;
import com.bmo.channel.pwob.service.applications.SavedApplicationsService;
import com.bmo.channel.pwob.validation.applications.ValidSavedApplicationsFilter;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Validated
@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(SavedApplicationsEndpoint.V1_PATH)
@Path(SavedApplicationsEndpoint.V1_PATH)
public class SavedApplicationsEndpoint {
	public static final String V1_PATH = "v1/saved_applications";
	
	public static final String BM_Approval= "/my_bm_approvals";

	@Autowired
	private FilteringSavedApplicationsService filteringSavedApplicationsService;
	@Autowired
	private SavedApplicationsService savedApplicationsService;

	@GET
	@ApiOperation(value="Retrieve saved applications", notes="One of appStatus, firstName + LastName, and iaCode are required", 
		response=SavedApplication.class,
		responseContainer = "list")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Applications Not found")})
	public Response get(@Valid @ValidSavedApplicationsFilter @ApiParam(value = "Application Filter") @BeanParam SavedApplicationsFilter filter) {		
		return Response.ok(filteringSavedApplicationsService.retrieveSavedApplications(filter)).build();
	}
	
	@GET
	@Path("/summary")
	@ApiOperation(value="Get a summary of existing applications", notes="multiple iaCodes are allowed, but not possible through swagger UI", response=Summary.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response getSummary(@ApiParam(value = "Ia Codes") @QueryParam("iaCode") String iaCode) {
		return Response.ok(savedApplicationsService.retrieveApplicationsSummary(iaCode)).build();
	}

	@GET
	@Path(BM_Approval)
	@ApiOperation(value="Retrieve all saved applications", notes="firstName + LastName can be used to search the saved applications", 
			response=SavedApplication.class,
			responseContainer = "list")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response getSavedApplicationForBMApproval(@ApiParam(value = "Application Filter") @BeanParam SavedApplicationsFilter filter) {
		return Response.ok(filteringSavedApplicationsService.retrieveSavedApplicationsWaitingForBMApproval(filter)).build();
	}
}
