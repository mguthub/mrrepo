package com.bmo.channel.pwob.config;

import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

@Configuration
public class ValidationRulesConfig {
	@Bean
	public PropertiesFactoryBean validationRules(){
		PropertiesFactoryBean validationRules =  new PropertiesFactoryBean();
		validationRules.setLocation(new ClassPathResource("validationRules.properties"));
		validationRules.setFileEncoding("UTF-8");
		return validationRules;
	}
}
