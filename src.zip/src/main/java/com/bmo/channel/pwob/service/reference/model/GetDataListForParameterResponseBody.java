package com.bmo.channel.pwob.service.reference.model;

import java.util.List;

import com.bmo.channel.pwob.util.ArrayOrObjectDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import net.bmogc.xmlns.hub.cg.common.serviceresponsemsglist.types.v1_0.ServiceResponseMessageList;

public class GetDataListForParameterResponseBody {
	private ServiceResponseMessageList serviceResponseMessageList;
    private List<Parameters> parameters;
    
	public ServiceResponseMessageList getServiceResponseMessageList() {
		return serviceResponseMessageList;
	}
	public void setServiceResponseMessageList(ServiceResponseMessageList serviceResponseMessageList) {
		this.serviceResponseMessageList = serviceResponseMessageList;
	}
	public List<Parameters> getParameters() {
		return parameters;
	}
	
	@JsonDeserialize(using = ParametersDeserializer.class)
	public void setParameters(List<Parameters> parameters) {
		this.parameters = parameters;
	}
	
	private static class ParametersDeserializer extends ArrayOrObjectDeserializer<Parameters> {
		public ParametersDeserializer() {
			super(Parameters.class);
		}
	}
}
