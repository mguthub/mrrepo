/**
 * @author akhales
 */
package com.bmo.channel.pwob.model.onboarding;

import java.math.BigInteger;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.bmo.channel.pwob.validation.reference.ReferenceData;


public class Income {

	private BigInteger annualEmploymentIncome;
    private BigInteger annualInvestmentIncome;
    private BigInteger annualOtherIncome;

	@ReferenceData(code=ErrorCodes.INVALID_ANNUAL_OTHER_INCOME_SOURCE, type=ReferenceType.INCOME_SOURCES)
    private String otherIncomeSource;
	
	@DataValidationPattern(code=ErrorCodes.INVALID_ANNUAL_OTHER_INCOME_DESCRIPTION)
    private String otherIncomeSourceDescription;

    public String getOtherIncomeSourceDescription() {
		return otherIncomeSourceDescription;
	}
	public void setOtherIncomeSourceDescription(String otherIncomeSourceDescription) {
		this.otherIncomeSourceDescription = otherIncomeSourceDescription;
	}
	public BigInteger getAnnualEmploymentIncome() {
		return annualEmploymentIncome;
	}
	public void setAnnualEmploymentIncome(BigInteger annualEmploymentIncome) {
		this.annualEmploymentIncome = annualEmploymentIncome;
	}
	public BigInteger getAnnualInvestmentIncome() {
		return annualInvestmentIncome;
	}
	public void setAnnualInvestmentIncome(BigInteger annualInvestmentIncome) {
		this.annualInvestmentIncome = annualInvestmentIncome;
	}
	public BigInteger getAnnualOtherIncome() {
		return annualOtherIncome;
	}
	public void setAnnualOtherIncome(BigInteger annualOtherIncome) {
		this.annualOtherIncome = annualOtherIncome;
	}
	public String getOtherIncomeSource() {
		return otherIncomeSource;
	}
	public void setOtherIncomeSource(String otherIncomeSource) {
		this.otherIncomeSource = otherIncomeSource;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}