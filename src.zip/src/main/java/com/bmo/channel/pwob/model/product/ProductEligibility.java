package com.bmo.channel.pwob.model.product;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author vvallia
 *
 */
public class ProductEligibility {

    protected String type;
    protected String productNameEN;
    protected String productNameFR;
    protected String eligible;
    protected List<Feature> features;
    protected List<String> outboundEftFrequencies;
	protected ReasonsForRejection reasonsForRejection;
	
    public String getType() {
        return type;
    }

    public void setType(String value) {
        this.type = value;
    }

    public String getProductNameEN() {
        return productNameEN;
    }

    public void setProductNameEN(String value) {
        this.productNameEN = value;
    }
    
    public String getProductNameFR() {
        return productNameFR;
    }

    public void setProductNameFR(String value) {
        this.productNameFR = value;
    }

    public String getEligible() {
        return eligible;
    }

    public void setEligible(String value) {
        this.eligible = value;
    }
    
    public List<Feature> getFeatures() {
        if (features == null) {
        	features = new ArrayList<>();
        }
        return this.features;
    }
    
    public void setFeatures(List<Feature> feature) {
        if (feature == null) {
        	this.features = new ArrayList<>();
        }
        else{
        	this.features=feature;
        }
    }

    public ReasonsForRejection getReasonsForRejection() {
        return reasonsForRejection;
    }

    public void setReasonsForRejection(ReasonsForRejection value) {
        this.reasonsForRejection = value;
    }

	public List<String> getOutboundEftFrequencies() {
		return outboundEftFrequencies;
	}

	public void setOutboundEftFrequencies(List<String> outboundEftFrequencies) {
		this.outboundEftFrequencies = outboundEftFrequencies;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
