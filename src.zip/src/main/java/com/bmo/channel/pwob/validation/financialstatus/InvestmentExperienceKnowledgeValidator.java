package com.bmo.channel.pwob.validation.financialstatus;

import com.bmo.channel.pwob.model.onboarding.InvestmentExperience;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface InvestmentExperienceKnowledgeValidator {
	public boolean isInvestmentExperienceValid(InvestmentExperience value, ValidationRequest validationRequest);
}
