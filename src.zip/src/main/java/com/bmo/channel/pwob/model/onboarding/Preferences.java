package com.bmo.channel.pwob.model.onboarding;
import java.util.LinkedList;
import java.util.List;

import javax.validation.Valid;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

public class Preferences {

	private Boolean sharePersonalInfo;
	private Boolean receiveDirectMarketingMaterials;
	private Boolean discloseBeneficialOwner;
	private Boolean receiveElectronicDelivery;
	private Boolean isReceiveStatementByMail;
	private Boolean isSetupAlternateMailings; //duplicate mailings
	private Boolean isAccountStatements;
	private Boolean isTradeConfirmations;

	@ApiModelProperty(value="Only populate if isSetupAlternateMailings is true")
	@Valid
	private List<AlternateAddress> alternateMailingAddresses = new LinkedList<>();

	@ApiModelProperty(example="online", value="Valid values can be found in the reference service", allowableValues="online,myMail")
	@ReferenceData(type = ReferenceType.DOCUMENT_PREFERENCE_OPTIONS, code = ErrorCodes.INVALID_DOCUMENT_PREFERENCE_OPTION)
	private String documentPreferenceOption;	

	@ApiModelProperty(example="3", value="Valid values can be found in the reference service", allowableValues="1,2,3")
	@ReferenceData(type = ReferenceType.RECEIVE_SECURITY_HOLDER_OPTIONS, code = ErrorCodes.INVALID_RECEIVE_SECURITY_HOLDER_OPTIONS)
	private String receiveSecurityHolderMaterials;

	public Boolean getSharePersonalInfo() {
		return sharePersonalInfo;
	}
	public void setSharePersonalInfo(Boolean sharePersonalInfo) {
		this.sharePersonalInfo = sharePersonalInfo;
	}
	public Boolean getReceiveDirectMarketingMaterials() {
		return receiveDirectMarketingMaterials;
	}
	public void setReceiveDirectMarketingMaterials(Boolean receiveDirectMarketingMaterials) {
		this.receiveDirectMarketingMaterials = receiveDirectMarketingMaterials;
	}
	public Boolean getDiscloseBeneficialOwner() {
		return discloseBeneficialOwner;
	}
	public void setDiscloseBeneficialOwner(Boolean discloseBeneficialOwner) {
		this.discloseBeneficialOwner = discloseBeneficialOwner;
	}
	public Boolean getReceiveElectronicDelivery() {
		return receiveElectronicDelivery;
	}
	public void setReceiveElectronicDelivery(Boolean receiveElectronicDelivery) {
		this.receiveElectronicDelivery = receiveElectronicDelivery;
	}
	public String getReceiveSecurityHolderMaterials() {
		return receiveSecurityHolderMaterials;
	}
	public void setReceiveSecurityHolderMaterials(String receiveSecurityHolderMaterials) {
		this.receiveSecurityHolderMaterials = receiveSecurityHolderMaterials;
	}
	public String getDocumentPreferenceOption() {
		return documentPreferenceOption;
	}
	public void setDocumentPreferenceOption(String documentPreferenceOption) {
		this.documentPreferenceOption = documentPreferenceOption;
	}
	public Boolean getIsReceiveStatementByMail() {
		return isReceiveStatementByMail;
	}
	public void setIsReceiveStatementByMail(Boolean isReceiveStatementByMail) {
		this.isReceiveStatementByMail = isReceiveStatementByMail;
	}
	public Boolean getIsSetupAlternateMailings() {
		return isSetupAlternateMailings;
	}
	public void setIsSetupAlternateMailings(Boolean isSetupAlternateMailings) {
		this.isSetupAlternateMailings = isSetupAlternateMailings;
	}
	public Boolean getIsAccountStatements() {
		return isAccountStatements;
	}
	public void setIsAccountStatements(Boolean isAccountStatements) {
		this.isAccountStatements = isAccountStatements;
	}
	public Boolean getIsTradeConfirmations() {
		return isTradeConfirmations;
	}
	public void setIsTradeConfirmations(Boolean isTradeConfirmations) {
		this.isTradeConfirmations = isTradeConfirmations;
	}
	public List<AlternateAddress> getAlternateMailingAddresses() {
		return alternateMailingAddresses;
	}
	public void setAlternateMailingAddresses(List<AlternateAddress> alternateMailingAddresses) {
		this.alternateMailingAddresses = alternateMailingAddresses;
	}

	
}
