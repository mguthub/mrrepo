package com.bmo.channel.pwob.model.migrations;

import io.swagger.annotations.ApiModelProperty;

public class Migration {
	@ApiModelProperty(example="e6d9e397-a0b2-41f3-8fe5-4ab250c90b5b", value="An application to migrate.")
	private String applicationId;
	@ApiModelProperty(value="Whether to migration application data, relationship data, or both.", 
			allowableValues="APPLICATION,RELATIONSHIP,ALL")
	private Data data;

	public enum Data {
		APPLICATION,
		RELATIONSHIP,
		ALL
	}

	public Migration(String applicationId, Data data) {
		this.applicationId = applicationId;
		this.data = data;
	}
	public Migration() {
	}

	public String getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}
	public Data getData() {
		return data;
	}
	public void setData(Data data) {
		this.data = data;
	}
}
