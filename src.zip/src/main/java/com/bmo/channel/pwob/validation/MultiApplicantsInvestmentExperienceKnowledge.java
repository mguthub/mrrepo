package com.bmo.channel.pwob.validation;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.bmo.channel.pwob.validation.financialstatus.MultiApplicantsInvestmentExpKnowledgeValidator;

@Documented
@Constraint(validatedBy = MultiApplicantsInvestmentExpKnowledgeValidator.class)
@Target({ TYPE })
@Retention(RUNTIME)
public @interface MultiApplicantsInvestmentExperienceKnowledge {
	String message() default "{generic}";
	Class<?>[] groups() default {};
	Class<? extends Payload>[] payload() default {};
}

