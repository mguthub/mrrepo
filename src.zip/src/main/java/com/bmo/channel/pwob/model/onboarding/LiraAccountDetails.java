package com.bmo.channel.pwob.model.onboarding;

import java.math.BigDecimal;
import java.util.List;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

public class LiraAccountDetails {		
	
		@ApiModelProperty(example="true", value="Whether to use spouse's age to calculate when payments should be made", dataType="boolean")
	    private Boolean pensionVariedoOnBasisOfGender;
		
		@ApiModelProperty(example="true", value="Whether to use spouse's age to calculate when payments should be made", dataType="boolean")
		private Boolean pensionAccumulatedBefore1993;
		
	    @ApiModelProperty(dataType = "String", example ="1",value="Whether to my self or spouse. Myself: 1. Spouse: 2", allowableValues="1,2")
		private String pensionAssetsOriginateFrom;	
		
	    @ApiModelProperty(dataType = "String", example ="1",value="either specify the amount to transfer  or total remaining balance. specify the amount to transfer: 1. total remaining balance: 2", allowableValues="1,2")
		private String fundingInstructions;
		
		@ApiModelProperty(example="100", value="An integer amount for the payment", dataType="integer")
		private BigDecimal transferredAmount;	
		
		@ApiModelProperty(example="ninety-nine thousand nine hundred ninety-nine", value="Transferred dollar amount in words", dataType="string")
		private String transferredAmountDollarsInWords;
		
		@ApiModelProperty(example="eighty-eighty", value="Transferred cents amount in words", dataType="string")
		private String transferredAmountCentsInWords;
		
		@ApiModelProperty(example="1", value="Valid values can be found in the reference service")
		@ReferenceData(code=ErrorCodes.INVALID_JURISDICTION_TYPE, type=ReferenceType.JURISDICTION_TYPES)
		private String jurisdictionType;
		
		@ApiModelProperty(example="101", value="Valid values can be found in the reference service")
		private String province;
		
		@ApiModelProperty(dataType = "String", example ="1",value="either LRRSP or RLSP. LRRSP: 1. RLSP: 2", allowableValues="1,2")
		private String federalPensionPlanType;
		
		@ApiModelProperty(example ="['1', '3']", value="Assets being transferred from the source(s) for LIF account", allowableValues="1,2,3,4,5.6.7")
		private List<String> sourcesOfAssets;
		
		@ApiModelProperty(dataType = "String", example ="1", value="either 1 for “I have a Spouse, 2 for ”I have a spouse but I am leaving…”, 3 for ”I have a spouse but none ….” ", allowableValues="1,2,3")
		private String spouseOptionType;

		public Boolean getPensionVariedoOnBasisOfGender() {
			return pensionVariedoOnBasisOfGender;
		}

		public void setPensionVariedoOnBasisOfGender(Boolean pensionVariedoOnBasisOfGender) {
			this.pensionVariedoOnBasisOfGender = pensionVariedoOnBasisOfGender;
		}

		public Boolean getPensionAccumulatedBefore1993() {
			return pensionAccumulatedBefore1993;
		}

		public void setPensionAccumulatedBefore1993(Boolean pensionAccumulatedBefore1993) {
			this.pensionAccumulatedBefore1993 = pensionAccumulatedBefore1993;
		}

		public String getPensionAssetsOriginateFrom() {
			return pensionAssetsOriginateFrom;
		}

		public void setPensionAssetsOriginateFrom(String pensionAssetsOriginateFrom) {
			this.pensionAssetsOriginateFrom = pensionAssetsOriginateFrom;
		}

		public String getFundingInstructions() {
			return fundingInstructions;
		}

		public void setFundingInstructions(String fundingInstructions) {
			this.fundingInstructions = fundingInstructions;
		}
	
		public BigDecimal getTransferredAmount() {
			return transferredAmount;
		}

		public void setTransferredAmount(BigDecimal transferredAmount) {
			this.transferredAmount = transferredAmount;
		}

		public String getTransferredAmountDollarsInWords() {
			return transferredAmountDollarsInWords;
		}

		public void setTransferredAmountDollarsInWords(String transferredAmountDollarsInWords) {
			this.transferredAmountDollarsInWords = transferredAmountDollarsInWords;
		}

		public String getTransferredAmountCentsInWords() {
			return transferredAmountCentsInWords;
		}

		public void setTransferredAmountCentsInWords(String transferredAmountCentsInWords) {
			this.transferredAmountCentsInWords = transferredAmountCentsInWords;
		}

		public String getJurisdictionType() {
			return jurisdictionType;
		}

		public void setJurisdictionType(String jurisdictionType) {
			this.jurisdictionType = jurisdictionType;
		}

		public String getProvince() {
			return province;
		}

		public void setProvince(String province) {
			this.province = province;
		}

		public String getFederalPensionPlanType() {
			return federalPensionPlanType;
		}

		public void setFederalPensionPlanType(String federalPensionPlanType) {
			this.federalPensionPlanType = federalPensionPlanType;
		}

		public List<String> getSourcesOfAssets() {
			return sourcesOfAssets;
		}

		public void setSourcesOfAssets(List<String> sourcesOfAssets) {
			this.sourcesOfAssets = sourcesOfAssets;
		}

		public String getSpouseOptionType() {
			return spouseOptionType;
		}

		public void setSpouseOptionType(String spouseOptionType) {
			this.spouseOptionType = spouseOptionType;
		}
		
}

