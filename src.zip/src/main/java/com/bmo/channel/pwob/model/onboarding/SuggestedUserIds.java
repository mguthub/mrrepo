package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class SuggestedUserIds {
	
	@ApiModelProperty(example = "testUser", value = "Suggested User Id list for the given user id")
	private List<String> availableUserIds;

	
	public List<String> getAvailableUserIds() {
		return availableUserIds;
	}
	public void setAvailableUserIds(List<String> availableUserIds) {
		this.availableUserIds = availableUserIds;
	}
}
