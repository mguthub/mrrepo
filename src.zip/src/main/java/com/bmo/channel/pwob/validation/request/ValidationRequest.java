package com.bmo.channel.pwob.validation.request;

import java.util.List;

import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;

import org.apache.commons.lang3.StringUtils;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.PartyRole;

public class ValidationRequest {
	ValidationRequest(ConstraintValidatorContext context, ApplicationLob applicationLob) {
		this.context = context;
		this.applicationLob = applicationLob;
	}

	private ApplicationLob applicationLob;
	private PartyRole partyRole;
	private ConstraintValidatorContext context;
	private String fieldPath;	
	private String childFieldPath;	
	private String parentFieldPath;	
	private String errorCode;
	private String fieldValue;
	private List<String> fieldValueList;
	private Boolean booleanFieldValue;
	private String fieldName;
	private String parentPropertyNode;
	private String childPropertyNode;
	private String locale;
	private Integer index;

	public ConstraintValidatorContext getContext() {
		return context;
	}
	public String getFieldPath() {
		return fieldPath;
	}
	void setFieldPath(String fieldPath) {
		this.fieldPath = fieldPath;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	
	public ApplicationLob getLob() {
		return applicationLob;
	}
	public String getParentPropertyNode() {
		return parentPropertyNode;
	}
	void setParentPropertyNode(String parentPropertyNode) {
		this.parentPropertyNode = parentPropertyNode;
	}
	public String getChildPropertyNode() {
		return childPropertyNode;
	}
	public void setChildPropertyNode(String childPropertyNode) {
		this.childPropertyNode = childPropertyNode;
	}
	public String getChildFieldPath() {
		return childFieldPath;
	}
	public void setChildFieldPath(String childFieldPath) {
		this.childFieldPath = childFieldPath;
	}
	public Boolean getBooleanFieldValue() {
		return booleanFieldValue;
	}
	public void setBooleanFieldValue(Boolean booleanFieldValue) {
		this.booleanFieldValue = booleanFieldValue;
	}
	public List<String> getFieldValueList() {
		return fieldValueList;
	}
	public void setFieldValueList(List<String> fieldValueList) {
		this.fieldValueList = fieldValueList;
	}
	
	public Integer getIndex() {
		return index;
	}
	public void setIndex(Integer index) {
		this.index = index;
	}
	
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public String getParentFieldPath() {
		return parentFieldPath;
	}
	void setParentFieldPath(String parentFieldPath) {
		this.parentFieldPath = parentFieldPath;
	}
	
	public PartyRole getPartyRole() {
		return partyRole;
	}
	public void setPartyRole(PartyRole partyRole) {
		this.partyRole = partyRole;
	}
	public String calculateFullFieldPath() {		
		StringBuilder sb = new StringBuilder();
		if(StringUtils.isNoneBlank(getFieldPath())) {
			sb.append(getFieldPath()).append(".");
		}
		if(StringUtils.isNoneBlank(getParentFieldPath())) {
			sb.append(getParentFieldPath()).append(".");
		}
		if(StringUtils.isNoneBlank(getChildFieldPath())) {
			sb.append(getChildFieldPath()).append(".");	
		}		
		sb.append(getFieldName());
		return sb.toString();
	}

	public void addConstraintViolation() {
		getContext().disableDefaultConstraintViolation();
		ConstraintViolationBuilder builder = getContext().buildConstraintViolationWithTemplate(getErrorCode());					

		if(StringUtils.isNoneBlank(getParentPropertyNode()) && StringUtils.isNoneBlank(getChildPropertyNode())) {
			builder.addPropertyNode(getParentPropertyNode())
			 	   .addPropertyNode(getChildPropertyNode())
				   .addPropertyNode(getFieldName())
				   .addBeanNode()
				   .addConstraintViolation();		
		} else if(StringUtils.isNoneBlank(getParentPropertyNode()) && StringUtils.isBlank(getChildPropertyNode())) {
			builder.addPropertyNode(getParentPropertyNode())
			   	   .addPropertyNode(getFieldName())
			       .addBeanNode()
			       .addConstraintViolation();		
		} else if(StringUtils.isBlank(getParentPropertyNode()) && StringUtils.isNoneBlank(getChildPropertyNode())) {
			builder.addPropertyNode(getChildPropertyNode())
		   	   .addPropertyNode(getFieldName())
		       .addBeanNode()
		       .addConstraintViolation();	
		} else {
			builder.addPropertyNode(getFieldName())
		       	   .addBeanNode()
		           .addConstraintViolation();	
		}
	}

	public void addConstraintViolation(int index) {
		getContext().disableDefaultConstraintViolation();
		ConstraintViolationBuilder builder = getContext().buildConstraintViolationWithTemplate(getErrorCode());											
		builder.addPropertyNode(getParentPropertyNode())				   
			   .addPropertyNode(getChildPropertyNode())
		   	   .inIterable()
		   	   .atIndex(index)				   
		   	   .addPropertyNode(getFieldName())		   	
		   	   .addBeanNode()
		   	   .addConstraintViolation();
	}

	public void addConstraintViolation(String fieldName, String errorCode) {
		getContext().disableDefaultConstraintViolation();
		ConstraintViolationBuilder builder = getContext().buildConstraintViolationWithTemplate(errorCode);					
		if(StringUtils.isNoneBlank(getParentPropertyNode()) && StringUtils.isNoneBlank(getChildPropertyNode())) {
			builder.addPropertyNode(getParentPropertyNode())
			 	   .addPropertyNode(getChildPropertyNode())
				   .addPropertyNode(fieldName)
				   .addBeanNode()
				   .addConstraintViolation();		
		} else if(StringUtils.isNoneBlank(getParentPropertyNode()) && StringUtils.isBlank(getChildPropertyNode())) {
			builder.addPropertyNode(getParentPropertyNode())
			   	   .addPropertyNode(fieldName)
			       .addBeanNode()
			       .addConstraintViolation();		
		} else if(StringUtils.isBlank(getParentPropertyNode()) && StringUtils.isNoneBlank(getChildPropertyNode())) {
			builder.addPropertyNode(getChildPropertyNode())
		   	   .addPropertyNode(fieldName)
		       .addBeanNode()
		       .addConstraintViolation();	
		} else {
			builder.addPropertyNode(fieldName)
		       	   .addBeanNode()
		           .addConstraintViolation();	
		}	
	}
	
	/**
	 * @param childPropertyNode
	 * @param childFieldPath
	 * @return a new ValidationContext instance with a child field/property in context.
	 */
	public ValidationRequest createChildValidationRequest(String childPropertyNode, String childFieldPath) {
		ValidationRequest validationRequest = new ValidationRequest(this.context, this.applicationLob);
		validationRequest.setFieldPath(this.fieldPath);
		validationRequest.setChildPropertyNode(childPropertyNode);
		validationRequest.setChildFieldPath(childFieldPath);
		validationRequest.setPartyRole(getPartyRole());
		return validationRequest;
	}		
	
}
