package com.bmo.channel.pwob.convert.migration;

import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.RifPaymentDetails;
import com.bmo.channel.pwob.validation.account.RifAccountValidator;

@Component
@Order(value=6)
public class R910DataMigrator implements ApplicationMigrator {
	
	public static final String ACCOUNT_NUM_PATTERN = "^[\\d]{10}$";
	public static final String RSP_ACCOUNT_NAME = "RSP Account ";	
	
	@Autowired
	private EventManager eventManager;
	
	@Override
	public void migrateApplication(Application application, FeatureFlags featureFlags) {
		application.setRelease(Application.RELEASE_VERSION_10);		
		migrateApplicationForTransferAccountNumber(application);
		migratePaymentMethodForNonRegisteredAccount(application);
		migrateStatementTypeForAlternateMailingAddress(application);
		migrateRifMinimumPaymentType(application);
		migrateSpousalRSPAccountName(application);
		migrateApplicationForRSPSpousalIndicator(application);
	}

	@Override
	public boolean isMigrationRequired(Application application, FeatureFlags featureFlags) {
		String release = application.getRelease();
		if(isReleaseDifferent(release)) {
			eventManager.publishWarn(String.format("Migrating application %s because release version is %s", application.getApplicationId(), release));
			return true;
		} else {
			return false;
		}
	}

	private boolean isReleaseDifferent(String release) {
		try {
			Integer iRel = Integer.valueOf(release);
			return iRel <= Integer.parseInt(Application.RELEASE_VERSION_9);
		} catch(NumberFormatException ex) {
			return true;
		}
	}
	
	private void migrateApplicationForTransferAccountNumber(Application application) {
		if (CollectionUtils.isNotEmpty(application.getAccounts())) {
			application.getAccounts().stream()
					.filter(a -> (a.isRif() && Optional.ofNullable(a.getRifPayment()).isPresent()
							&& Optional.ofNullable(a.getRifPayment().getTransferAccountNumber()).isPresent()
							&& !a.getRifPayment().getTransferAccountNumber().matches(ACCOUNT_NUM_PATTERN)))
					.map(b -> {
						b.getRifPayment().setTransferAccountNumber(null);
						return b;
					}).collect(Collectors.toList());
		}
	}
	
	private void migrateStatementTypeForAlternateMailingAddress(Application application) {
		for (Party party : application.getParties()) {
			if (Optional.ofNullable(party.getPreferences()).isPresent()
					&& Optional.ofNullable(party.getPreferences().getIsSetupAlternateMailings()).isPresent()
					&& (Optional.ofNullable(party.getPreferences().getIsAccountStatements()).isPresent()
							|| Optional.ofNullable(party.getPreferences().getIsTradeConfirmations()).isPresent())
					&& CollectionUtils.isNotEmpty(party.getPreferences().getAlternateMailingAddresses())) {
				party.getPreferences().getAlternateMailingAddresses().stream().forEach(a -> {
					a.setIsAccountStatements(party.getPreferences().getIsAccountStatements());
					a.setIsTradeConfirmations(party.getPreferences().getIsTradeConfirmations());
				});
				party.getPreferences().setIsAccountStatements(null);
				party.getPreferences().setIsTradeConfirmations(null);
			}
		}
	}
	
	private void migrateRifMinimumPaymentType(Application application) {
		if (CollectionUtils.isNotEmpty(application.getAccounts())) {
			application.getAccounts().stream()
					.filter(a -> (a.isRif() && Optional.ofNullable(a.getRifPayment()).isPresent()
							&& Optional.ofNullable(a.getRifPayment().getAmountType()).isPresent() && a.getRifPayment()
									.getAmountType().equals(RifAccountValidator.MIN_PAYMENT_AMOUNT_TYPE)))
					.map(b -> {
						b.getRifPayment().setGreaterThanMinimumAmountType(RifAccountValidator.GROSS_AMOUNT);
						return b;
					}).collect(Collectors.toList());
		}
	}	
	
	private void migrateSpousalRSPAccountName(Application application) {
		int rspAccountCount=1;
		if (CollectionUtils.isNotEmpty(application.getAccounts())) {
			for (Account account : application.getAccounts()) {
				if (account.isRsp()) {
					account.setName(RSP_ACCOUNT_NAME +rspAccountCount++);
				}
			}
		}
	}
	
	private void migratePaymentMethodForNonRegisteredAccount(Application application) {
		if (CollectionUtils.isNotEmpty(application.getAccounts()) && checkForNonRegisteredAccounts(application)){
				application.getAccounts().stream()
				.filter(account -> (account.isRif() && Optional.ofNullable(account.getRifPayment()).isPresent()						
						&& Optional.ofNullable(account.getRifPayment().getMethod()).isPresent()
						&& account.getRifPayment().getMethod().equalsIgnoreCase(RifPaymentDetails.METHOD_TRANSFER)
						&& !Optional.ofNullable(account.getRifPayment().getNonRegisteredAccountSelectionType()).isPresent()))
				.map(accType -> {
					accType.getRifPayment().setNonRegisteredAccountSelectionType(RifAccountValidator.NONREG_ACC_SEL_TYPE_EXT_ACC);
					return accType;
				}).collect(Collectors.toList());
			}
		}
	
	private boolean checkForNonRegisteredAccounts(Application application) {
			for(Account acc : application.getAccounts()){
				if(acc.isIndividual() || acc.isJoint()){
					return true;
				}
			}
		return false;
	}
	
	private void migrateApplicationForRSPSpousalIndicator(Application application) {
		if (CollectionUtils.isNotEmpty(application.getAccounts())) {
			application.getAccounts().stream()
					.filter(account -> (account.isRsp() && !Optional.ofNullable(account.getIsSpousal()).isPresent()))
					.map(acc -> {
						acc.setIsSpousal(false);
						return acc;
					}).collect(Collectors.toList());
		}
	}

}

