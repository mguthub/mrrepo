package com.bmo.channel.pwob.validation.preferences;

import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.AlternateAddress;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Preferences;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.AddressValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

/**
 * Validate the Communication Preferences details. 
 *
 */
@Component
public class PreferencesValidatorImpl extends AbstractBaseValidator implements PreferencesValidator {
	public static final String DOCUMENT_PREFERENCE_OPTION_FIELD_NAME = "documentPreferenceOption";
	public static final String IS_RECEIVE_STATEMENT_BY_MAIL_FIELD_NAME = "isReceiveStatementByMail";
	public static final String IS_ACCOUNT_STATEMENTS_FIELD_NAME = "isAccountStatements";
	public static final String IS_SETUP_ALTERNATE_MAILINGS_FIELD_NAME = "isSetupAlternateMailings";
	public static final String IS_TRADE_CONFIRMATIONS_FIELD_NAME = "isTradeConfirmations";
	public static final String ALTERNATE_MAILING_ADDRESSES_FIELD_NAME = "alternateMailingAddresses";
	public static final String DISCLOSE_BENEFICIAL_OWNER_FIELD_NAME = "discloseBeneficialOwner";
	public static final String RECEIVE_DIRECT_MARKETING_MATERIALS_FIELD_NAME = "receiveDirectMarketingMaterials";
	public static final String RECEIVE_ELECTRONIC_DELIVERY_FIELD_NAME = "receiveElectronicDelivery";
	public static final String SHARE_PERSONAL_INFO_FIELD_NAME = "sharePersonalInfo";
	public static final String RECEIVE_SECURITY_HOLDER_MATERIALS_FIELD_NAME = "receiveSecurityHolderMaterials";

	static final String ALTERNATE_MAILING_ADDRESSES_PATH = "preferences.alternateMailingAddresses[]";
	static final String ALTERNATE_MAILING_ADDRESSES_NODE = "preferences.alternateMailingAddresses";

	@Autowired private AddressValidator addressValidator;

	@Autowired private UsersService userService;

	@Autowired private ValidationRequestFactory validationRequestFactory;

	@Override
	public boolean arePreferencesValid(Preferences preferences, ValidationRequest request) {
		ApplicationLob lob = this.userService.currentUser().getLob();
		boolean valid = true;

		if(preferences == null) {
			if(ApplicationLob.il == lob) {
				request.addConstraintViolation(DOCUMENT_PREFERENCE_OPTION_FIELD_NAME, ErrorCodes.INVALID_DOCUMENT_PREFERENCE_OPTION);
			}

			request.addConstraintViolation(DISCLOSE_BENEFICIAL_OWNER_FIELD_NAME, ErrorCodes.INVALID_DISCLOSE_BENEFICIAL_OWNER);
			request.addConstraintViolation(RECEIVE_DIRECT_MARKETING_MATERIALS_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_DIRECT_MARKETING_MATERIALS);
			request.addConstraintViolation(RECEIVE_ELECTRONIC_DELIVERY_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_ELECTRONIC_DELIVERY);
			request.addConstraintViolation(SHARE_PERSONAL_INFO_FIELD_NAME, ErrorCodes.INVALID_SHARE_PERSONAL_INFO);
			request.addConstraintViolation(RECEIVE_SECURITY_HOLDER_MATERIALS_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_SECURITY_HOLDER_MATERIALS);
			return false;
		}

		if(ApplicationLob.nb == lob) {
				valid = validateIsPresent(request, preferences.getIsSetupAlternateMailings(), IS_SETUP_ALTERNATE_MAILINGS_FIELD_NAME, ErrorCodes.INVALID_IS_SETUP_ALTERNATE_MAILINGS) && valid;
				valid = this.validateAlternateMailingAddress(preferences, request) && valid;
		}

		valid = validateIsPresent(request, preferences.getDiscloseBeneficialOwner(), DISCLOSE_BENEFICIAL_OWNER_FIELD_NAME, ErrorCodes.INVALID_DISCLOSE_BENEFICIAL_OWNER) && valid;
		valid = validateIsPresent(request, preferences.getReceiveDirectMarketingMaterials(), RECEIVE_DIRECT_MARKETING_MATERIALS_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_DIRECT_MARKETING_MATERIALS) && valid;
		valid = validateIsPresent(request, preferences.getReceiveElectronicDelivery(), RECEIVE_ELECTRONIC_DELIVERY_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_ELECTRONIC_DELIVERY) && valid;
		valid = validateIsPresent(request, preferences.getSharePersonalInfo(), SHARE_PERSONAL_INFO_FIELD_NAME, ErrorCodes.INVALID_SHARE_PERSONAL_INFO) && valid;
		valid = validateIsPresent(request, preferences.getReceiveSecurityHolderMaterials(), RECEIVE_SECURITY_HOLDER_MATERIALS_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_SECURITY_HOLDER_MATERIALS) && valid;

		/*if(ApplicationLob.il == lob) {
			valid = validateIsPresent(request, preferences.getDocumentPreferenceOption(), DOCUMENT_PREFERENCE_OPTION_FIELD_NAME, ErrorCodes.INVALID_DOCUMENT_PREFERENCE_OPTION) && valid;
		}*/

		return valid;
	}
	
	
	
	@Override
	public boolean arePreferencesValidForJointAccount(Preferences preferences, ValidationRequest request) {
		ApplicationLob lob = this.userService.currentUser().getLob();
		boolean valid = true;

		if(preferences == null) {
			request.addConstraintViolation(DISCLOSE_BENEFICIAL_OWNER_FIELD_NAME, ErrorCodes.INVALID_DISCLOSE_BENEFICIAL_OWNER);
			request.addConstraintViolation(RECEIVE_DIRECT_MARKETING_MATERIALS_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_DIRECT_MARKETING_MATERIALS);
			request.addConstraintViolation(RECEIVE_ELECTRONIC_DELIVERY_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_ELECTRONIC_DELIVERY);
			request.addConstraintViolation(SHARE_PERSONAL_INFO_FIELD_NAME, ErrorCodes.INVALID_SHARE_PERSONAL_INFO);
			request.addConstraintViolation(RECEIVE_SECURITY_HOLDER_MATERIALS_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_SECURITY_HOLDER_MATERIALS);
			return false;
		}

		valid = validateIsPresent(request, preferences.getDiscloseBeneficialOwner(), DISCLOSE_BENEFICIAL_OWNER_FIELD_NAME, ErrorCodes.INVALID_DISCLOSE_BENEFICIAL_OWNER) && valid;
		valid = validateIsPresent(request, preferences.getReceiveDirectMarketingMaterials(), RECEIVE_DIRECT_MARKETING_MATERIALS_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_DIRECT_MARKETING_MATERIALS) && valid;
		valid = validateIsPresent(request, preferences.getReceiveElectronicDelivery(), RECEIVE_ELECTRONIC_DELIVERY_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_ELECTRONIC_DELIVERY) && valid;
		valid = validateIsPresent(request, preferences.getSharePersonalInfo(), SHARE_PERSONAL_INFO_FIELD_NAME, ErrorCodes.INVALID_SHARE_PERSONAL_INFO) && valid;
		valid = validateIsPresent(request, preferences.getReceiveSecurityHolderMaterials(), RECEIVE_SECURITY_HOLDER_MATERIALS_FIELD_NAME, ErrorCodes.INVALID_RECEIVE_SECURITY_HOLDER_MATERIALS) && valid;

		return valid;
	}
	

	private boolean validateIsPresent(ValidationRequest request, Object field, String fieldName, String errorCode) {
		if(!Optional.ofNullable(field).isPresent()) {
			request.addConstraintViolation(fieldName, errorCode);
			return false;
		}
		return true;
	}

	private boolean validateStatementTypes(Boolean isAccountStmt, Boolean isTradeConfirmation, ValidationRequest request) {
		if(this.isInvalidStatementTypes(isAccountStmt, isTradeConfirmation)) {
			this.addConstraintViolation(IS_ACCOUNT_STATEMENTS_FIELD_NAME, ErrorCodes.INVALID_IS_ACCOUNT_STATEMENTS, request);
			this.addConstraintViolation(IS_TRADE_CONFIRMATIONS_FIELD_NAME, ErrorCodes.INVALID_IS_TRADE_CONFIRMATIONS, request);
			return false;
		}
		return true;
	}

	/**
	 * User must choose at least one type of statement
	 */
	boolean isInvalidStatementTypes(Boolean isAccountStmt, Boolean isTradeConfirmation) {
		if(isAccountStmt == null && isTradeConfirmation == null) {
			return true;
		}
		if(isAccountStmt != null) {
			if(isTradeConfirmation != null) {
				return !isAccountStmt && !isTradeConfirmation;
			} else {
				return !isAccountStmt;
			}
		} else {
			return !isTradeConfirmation;
		}
	}

	private boolean validateAlternateMailingAddress(Preferences preferences, ValidationRequest request) {
		if(Optional.ofNullable(preferences.getIsSetupAlternateMailings()).isPresent() && preferences.getIsSetupAlternateMailings()) {
			if(preferences.getAlternateMailingAddresses() == null || CollectionUtils.isEmpty(preferences.getAlternateMailingAddresses()) ) {
				request.addConstraintViolation(ALTERNATE_MAILING_ADDRESSES_FIELD_NAME, ErrorCodes.INVALID_ALTERNATE_MAILING_ADDRESSES);
				return false;
			}
			if(CollectionUtils.isNotEmpty(preferences.getAlternateMailingAddresses()) && preferences.getAlternateMailingAddresses().size() > 10) {
				request.addConstraintViolation(ALTERNATE_MAILING_ADDRESSES_FIELD_NAME, ErrorCodes.INVALID_ALTERNATE_MAILING_ADDRESSES);
				return false;
			}

			return alternateMailingAddressesValid(preferences, request);
		} else {
			return true;
		}
	}

	private boolean alternateMailingAddressesValid(Preferences value, ValidationRequest mainRequest) {
		boolean valid = true;
		ValidationRequest request = validationRequestFactory.createBuilder(mainRequest.getContext(), userService.currentUser().getLob())
				.withParentPropertyNode(ALTERNATE_MAILING_ADDRESSES_NODE).withChildFieldPath(ALTERNATE_MAILING_ADDRESSES_PATH).build();

		for(int index = 0; index < value.getAlternateMailingAddresses().size(); index++) {
			AlternateAddress address = value.getAlternateMailingAddresses().get(index);
			request.setIndex(index);

			valid = addressValidator.validateUnitStreetCityPostalCountry(request, address) && valid;

			request.setFieldValue(address.getRecipient());
			valid = addressValidator.validateRecipient(request) && valid;
			
			valid = this.validateStatementTypes(address.getIsAccountStatements(), address.getIsTradeConfirmations(), request) && valid;
		}
		return valid;
	}
	
	private void addConstraintViolation(String fieldName, String errorCode, ValidationRequest validationRequest) {
		validationRequest.setFieldName(fieldName);
		validationRequest.setErrorCode(errorCode);
		validationRequest.addConstraintViolation(validationRequest.getIndex());
	}	
}
