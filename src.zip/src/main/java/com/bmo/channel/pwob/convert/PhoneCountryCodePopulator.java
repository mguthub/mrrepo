package com.bmo.channel.pwob.convert;

import com.bmo.channel.pwob.model.onboarding.Application;

/**
 * @author Ryan Chambers (rcham02)
 */
public interface PhoneCountryCodePopulator {

	/**
	 * @param application
	 */
	void populate(Application application);
}
