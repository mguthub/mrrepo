package com.bmo.channel.pwob.service.contractv6;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import io.swagger.client.model.GetAllContractPartyRolesRequest;
import io.swagger.client.model.GetAllContractPartyRolesResponse;

@Produces(MediaType.APPLICATION_JSON)
public interface ContractV6EndpointInterface {
	
	@POST
	public GetAllContractPartyRolesResponse getContractDetails(@RequestBody GetAllContractPartyRolesRequest requestWrapper, 
			@HeaderParam("APIHeaderRequest") String requestHeader);
}
