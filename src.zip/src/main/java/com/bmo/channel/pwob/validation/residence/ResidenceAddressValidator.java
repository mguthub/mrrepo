package com.bmo.channel.pwob.validation.residence;


import com.bmo.channel.pwob.model.onboarding.Residence;
import com.bmo.channel.pwob.validation.request.ValidationRequest;


public interface ResidenceAddressValidator {
	boolean validateResidenceAddress(Residence residence, ValidationRequest request);
}
