package com.bmo.channel.pwob.service.authorization.nb;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.BadRequestException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.exception.ForbiddenSecurityException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.exception.ExceptionUtils;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.service.authorization.IlSecurityServiceImpl;
import com.bmo.channel.pwob.service.authorization.LobSecurityService;
import com.bmo.channel.pwob.service.authorization.PwobAction;
import com.bmo.channel.pwob.service.authorization.StatusChangeRequirement;
import com.bmo.channel.pwob.service.authorization.StatusMap;
import com.bmo.channel.pwob.validation.ErrorCodes;

@Component("nbSecurityService")
public class NbSecurityServiceImpl implements LobSecurityService {
	
	private static Logger logger = LoggerFactory.getLogger(NbSecurityServiceImpl.class);

	@Override
	public void authorizeAction(User user, String iaCode, String appStatus, PwobAction action) {
		RoleRequirement roleRequirements = NbRoleMap.getRequirements(action);
		enforcePermissions(user, iaCode, roleRequirements);
		
		StatusChangeRequirement statusRequirements = StatusMap.getRequirements(action);
		enforceStatus(appStatus, statusRequirements, action);

	}

	private void enforcePermissions(User user, String iaCode, RoleRequirement requirements) {
		UserRole roleRequirement = requirements.getRoleLevelRequired();
		List<String> iaCodeList;
		if (roleRequirement == UserRole.BM_APPROVER && CollectionUtils.isNotEmpty(user.getBmApproverFor())) {
			iaCodeList = user.getBmApproverFor();
		} else if (roleRequirement == UserRole.IA_APPROVER && CollectionUtils.isNotEmpty(user.getIaApproverFor())) {
			iaCodeList = user.getIaApproverFor();
		} else if (roleRequirement == UserRole.APPLICATION_USER && CollectionUtils.isNotEmpty(user.getIaCodes())) {
			iaCodeList = user.getIaCodes();
		} else if (roleRequirement == UserRole.ANY_USER && CollectionUtils.isNotEmpty(this.joinAllIACodes(user))) {
			iaCodeList = this.joinAllIACodes(user);
		} else {
			logger.error("The role " + roleRequirement.name() + " is invalid for user " + user.getUserId() + " and ia code " +iaCode );
			throw new ForbiddenSecurityException(ErrorCodes.INVALID_ROLE_FOR_OPERATION);
		}

		enforceIaCode(iaCodeList, iaCode);
	}

	private List<String> joinAllIACodes(User user) {
		Set<String> mergeList = new HashSet<>();

		Collection<String> userIaCodeList = user.getIaCodes();
		if(CollectionUtils.isNotEmpty(userIaCodeList)) {
			mergeList.addAll(userIaCodeList);
		}

		Collection<String> iaApproverIaCodeList = user.getIaApproverFor();
		if(CollectionUtils.isNotEmpty(iaApproverIaCodeList)) {
			mergeList.addAll(iaApproverIaCodeList);
		}

		Collection<String> bmApprovalIaCodeList = user.getBmApproverFor();
		if(CollectionUtils.isNotEmpty(bmApprovalIaCodeList)) {
			mergeList.addAll(bmApprovalIaCodeList);
		}
		return mergeList.stream().collect(Collectors.toList());
	}

	private void enforceIaCode(List<String> iaCodeList, String iaCode) {
		if(StringUtils.isBlank(iaCode)){
			logger.error("The ia code is blank");
			throw new BadRequestException(ErrorCodes.EMPTY_IA_CODE);
		}

		if(!iaCodeList.contains(iaCode)){
			logger.error("The user does not have permission for ia code "+iaCode);
			throw new ForbiddenSecurityException(ErrorCodes.INVALID_IA_CODE_FOR_OPERATION);
		}
	}

	@Override
	public void authorizeReadAccess(User user, String iaCode) {
		if(StringUtils.isBlank(iaCode)){
			logger.error("Cannot get access for null ia code");
			throw new BadRequestException("cannot get access for null ia code");
		}

		boolean authorized = false;
		if(user.getIsBranchManager()) {
			if(user.getBmApproverFor().contains(iaCode)) {
				authorized = true;
			}
		}

		if(CollectionUtils.isNotEmpty(user.getIaCodes())) {
			if(user.getIaCodes().contains(iaCode)) {
				authorized = true;
			}
		}

		if(CollectionUtils.isNotEmpty(user.getIaApproverFor())) {
			if(user.getIaApproverFor().contains(iaCode)) {
				authorized = true;
			}
		}

		if(CollectionUtils.isNotEmpty(user.getSupportingSaFor())) {
			if(user.getSupportingSaFor().stream().anyMatch(s -> s.getIaCodes().contains(iaCode))) {
				authorized = true;
			}
		}

		if(!authorized) {
			logger.error("The user " + user.getUserId() + " is not authorized");
			throw new ForbiddenSecurityException();
		}
	}
	
	private void enforceStatus(String appStatus, StatusChangeRequirement requirements, PwobAction action) {
		if(requirements.getAcceptableAppStatuses().contains(StatusMap.ANY_APP_STATUS)) {
			return;
		}
		else if(StringUtils.isBlank(appStatus)){
			logger.error("The application status is blank");
			throw new WebServiceException(ErrorCodes.EMPTY_SECURITY_FIELDS);
		}

		if(!requirements.getAcceptableAppStatuses().contains(appStatus)){
			logger.error("Action '"+action.name()+"' not allowed with app status: "+appStatus);
			throw ExceptionUtils.buildStatusExceptionForActionNotAllowedContext(action.name(), appStatus);
		}
	}
}
