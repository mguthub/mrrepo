package com.bmo.channel.pwob.convert.migration;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.pwob.convert.migration.reference.BetchReferenceMapper;
import com.bmo.channel.pwob.convert.taxresidency.BetchTaxResidencyMapper;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlag;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;
import com.bmo.channel.pwob.validation.RefDataValues;

/**
 * <ol>
 *   <li>Adds feature flags to <code>application</code></li>
 *   <li>Migrates data, if required</li>
 * </ol>
 * @author Ryan Chambers (rcham02)
 */
@Component
@Order(value=1)
public class BetchApplicationMigrator implements ApplicationMigrator {
	@Autowired
	private EventManager eventManager;

	@Autowired
	private BetchTaxResidencyMapper betchTaxResidencyMapper;

	@Autowired
	private BetchReferenceMapper betchReferenceMapper;

	@Override
	public boolean isMigrationRequired(Application application, FeatureFlags featureFlags) {
		FeatureFlag applicationFlag = application.getFeatureFlag(FeatureFlags.BETCH);
		if(applicationFlag == null || FeatureFlags.BETCH_INACTIVE.equals(applicationFlag.getState())) {
			eventManager.publishWarn(String.format("Application %s needs to be migrated because no flag found in application", application.getApplicationId()));
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void migrateApplication(Application application, FeatureFlags systemFeatureFlags) {
		// continue setting this feature flag until all R4 applications have been migrated
		setApplicationFeatureFlag(application, new FeatureFlag(FeatureFlags.BETCH, FeatureFlags.BETCH_ACTIVE));

		populateBeneficialOwnerCountry(application);
		betchTaxResidencyMapper.updateApplication(application);
		betchReferenceMapper.updateApplication(application);			
	}

	private void setApplicationFeatureFlag(Application application, FeatureFlag systemBetchFlag) {
		List<FeatureFlag> featureFlags = application.getFeatureFlags();
		Optional<FeatureFlag> flag = featureFlags.stream().filter(f -> FeatureFlags.BETCH.equals(f.getName())).findFirst();
		if(flag.isPresent()) {
			flag.get().setState(systemBetchFlag.getState());
		} else {
			featureFlags.add(systemBetchFlag);
		}
	}

	void populateBeneficialOwnerCountry(Application application){
		if(application.getPrimaryApplicant()!=null && application.getPrimaryApplicant().getTaxation()!=null &&
				Optional.ofNullable(application.getPrimaryApplicant().getTaxation().getIsIrsW8FormProvided()).isPresent() && 
				application.getPrimaryApplicant().getTaxation().getIsIrsW8FormProvided().equals(Boolean.TRUE)){
			application.getPrimaryApplicant().getTaxation().setBeneficialOwnerCountry(RefDataValues.CANADA_COUNTRY_CODE);
		}
	}
}
