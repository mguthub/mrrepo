
package com.bmo.channel.pwob.validation.regulatory;

import com.bmo.channel.pwob.model.onboarding.RegulatoryDisclosures;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface RegulatoryDisclosureValidator{
	boolean validateRegulatory(RegulatoryDisclosures disclosure, ValidationRequest request);
	boolean validatePoliticallyExposedPerson(RegulatoryDisclosures disclosure, ValidationRequest request);
}