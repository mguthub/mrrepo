package com.bmo.channel.pwob.service.product;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.core.mapping.DataMapper;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.product.BilProducts;
import com.bmo.channel.pwob.model.product.Feature;
import com.bmo.channel.pwob.model.product.IaProduct;
import com.bmo.channel.pwob.model.product.ProductEligibility;
import com.bmo.channel.pwob.model.product.Products;
import com.bmo.channel.pwob.service.applications.ProductEligibilityMapper;
import com.bmo.channel.pwob.service.product.GetEligibleProductsForApplicantRequest.Request;
import com.bmo.channel.pwob.service.product.rsclient.AccountType;
import com.bmo.channel.pwob.service.product.rsclient.GetEligibleProductsForApplicantResponse;
import com.bmo.channel.pwob.service.product.rsclient.GetEligibleProductsForApplicantResponseBody.Lob.ProductList;
import com.bmo.channel.pwob.service.product.rsclient.GetEligibleProductsForApplicantResponseBody.Lob.ProductList.Product;
import com.bmo.channel.pwob.service.product.rsclient.PwobProduct;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.Constants;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.channel.pwob.util.HubRequestHeaderBuilder.HeaderBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;

import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

@Service
public class ProductServiceImpl implements ProductService {
	
	private static Logger logger = LoggerFactory.getLogger(ProductServiceImpl.class);
	
	public static final String PRODUCT_PATH = "PWOBProduct";
	public static final String PRODUCT_FUNCTION = "GetEligibileProductsForApplicant";
	private static final String PRODUCT_SERVICE_LOB_INVESTOR_LINE = "BIL";
	private static final String PRODUCT_SERVICE_LOB_NESBITT_BURNS = "PCD";

	static final String FEATURE_SPOUSAL = "SPOUSAL";
	static final String STATUS_FAILED = "FAILED";

	@Autowired
	private PwobProduct pwobProduct;

	@Autowired
	private UsersService usersService;

	@Autowired
	private DataMapper mapper;

	@Autowired
	private HubRequestComponent hubRequestComponent;

	ProductList getEligibleProductsForApplicant(String applicationId, Party party) {
		String dateOfBirth = null;
		String provinceCode = null;

		if(party != null && party.getPersonal() != null) {
			PersonalInformation personal = party.getPersonal();
			if(personal.getIdentity() != null) {
				dateOfBirth = determineDob(personal);
			}

			if(personal.getResidence() != null && personal.getResidence().getPrimaryAddress() != null) {
				provinceCode = personal.getResidence().getPrimaryAddress().getProvince();
			}
		}

		return getEligibleProductsForApplicant(applicationId, dateOfBirth, provinceCode);
	}

	ProductList getEligibleProductsForApplicant(String applicationId, String dateOfBirth, String provinceCode) {
		GetEligibleProductsForApplicantRequestBody body = new GetEligibleProductsForApplicantRequestBody();
		if(ApplicationLob.il == usersService.currentUser().getLob()) {
			body.setLob(PRODUCT_SERVICE_LOB_INVESTOR_LINE);
		} else if(ApplicationLob.nb == usersService.currentUser().getLob()){
			body.setLob(PRODUCT_SERVICE_LOB_NESBITT_BURNS);
		}
		body.setDateOfBirth(dateOfBirth);
		body.setProvinceCode(provinceCode);

		String requestHeader = createRequestHeader(applicationId);

		GetEligibleProductsForApplicantRequest request = new GetEligibleProductsForApplicantRequest();
		Request innerRequest = new Request();
		request.setGetEligibleProductsForApplicantRequest(innerRequest);
		innerRequest.setGetEligibleProductsForApplicantRequestBody(body);
		GetEligibleProductsForApplicantResponse response = pwobProduct.getEligibleProductsForApplicantRequest(request, requestHeader);

		
		if (response == null) {
			logger.error("HUB response body is null",applicationId);
			throw new WebServiceException("No hub response body");
		} else if(STATUS_FAILED.equals(response.getStatus())) {
			logger.error("HUB response status: "+response.getStatus(), applicationId);
			throw new WebServiceException("Hub response indicates failure: " + response.toString());
		} else if(response.getGetEligibleProductsForApplicantResponseBody().getLob().getProductList() == null) {
			logger.error("No products in hub response.", applicationId);
			throw new WebServiceException("No products in hub response.");
		}

		return response.getGetEligibleProductsForApplicantResponseBody().getLob().getProductList();
	}

	private String createRequestHeader(String applicationId) {
		HeaderBuilder headerBuilder = hubRequestComponent.getHubBuilder()
			.originatorResource(PRODUCT_PATH)
			.originatorResourceFunction(PRODUCT_FUNCTION)
			.workflowId(applicationId);

		final HUBHeaderRequest requestHeader = headerBuilder.build();
		try {
			return ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
		} catch (JsonProcessingException ex) {
			logger.error("Failed to create request header for application id :",applicationId,ex);
			throw new WebServiceException(ex);
		}
	}

	/**
	 * Product catalogue expects dob in YYYY-MM-DD format. Add any missing zeroes in MM and DD
	 */
	String determineDob(PersonalInformation personal) {
		String dateOfBirth = personal.getIdentity().getDateOfBirth();
		if(StringUtils.isNotBlank(dateOfBirth)) {
			String[] strings = dateOfBirth.split("-");
			StringBuilder sb = new StringBuilder();
			sb.append(strings[0]);
			sb.append("-");
			sb.append(strings[1].length() == 2 ? strings[1] : "0" + strings[1]);
			sb.append("-");
			sb.append(strings[2].length() == 2 ? strings[2] : "0" + strings[2]);
			dateOfBirth = sb.toString();
		}
		return dateOfBirth;
	}

	@Override
	public Products determineProductEligibilities(Application application) {
		return determineProductEligibilities(application.getApplicationId(), application.getPrimaryApplicant());
	}

	@Override
	public Products determineProductEligibilities(String applicationId, Party party) {
		final ProductList productList = getEligibleProductsForApplicant(applicationId, party);

		// there is only one product (FSB) for now
		Products pwobProdList = mapper.map(productList.getProduct().get(0).getAccountList(), Products.class);
		createSpousalVirtualProduct(pwobProdList.getProductEligibilities());
		createDummyLIFProduct(pwobProdList.getProductEligibilities());
		return pwobProdList;	
	}

	@Override
	public boolean isEligibleForProduct(String applicationId, String dateOfBirth, String provinceOfResidence, String accountType) {
		ProductList productList = getEligibleProductsForApplicant(applicationId, dateOfBirth, provinceOfResidence);
		// there is only one product (FSB) for now
		Products pwobProdList = mapper.map(productList.getProduct().get(0).getAccountList(), Products.class);

		List<ProductEligibility> productEligibilities = pwobProdList.getProductEligibilities();
		return isAccountTypeEligible(accountType, productEligibilities);
	}

	boolean isAccountTypeEligible(String accountType, List<ProductEligibility> productEligibilities) {
		Optional<ProductEligibility> first = productEligibilities.stream().filter(e -> accountType.equals(e.getType())).findFirst();
		if(first.isPresent()) {
			return "true".equals(first.get().getEligible());
		}
		return false;
	}

	@Override
	public List<IaProduct> populateFeeCodeList(Application application) {
		final ProductList productList = getEligibleProductsForApplicant(application.getApplicationId(), application.getPrimaryApplicant());
		List<IaProduct> feeCodes = new ArrayList<>() ;
		if(Optional.ofNullable(productList).isPresent()) {
			Product pwobProduct = null;
			IaProduct iaProduct = null;
			for(int i = Constants.ZERO; i < productList.getProduct().size(); i++) {
				pwobProduct =  productList.getProduct().get(i);
				for (AccountType accountType : pwobProduct.getAccountList().getAccountType()) {
					if(CollectionUtils.isNotEmpty(accountType.getFeeCodeList())) {
						iaProduct = new IaProduct();
						iaProduct.setEligible(accountType.getEligibility());
						iaProduct.setProductNameEN(accountType.getNameEN());
						iaProduct.setType(accountType.getCode());
						iaProduct.setFeeCodes(accountType.getFeeCodeList());
						feeCodes.add(iaProduct);
						if(accountType.getCode().equalsIgnoreCase(Account.RSP_TYPE)) {
							Optional<com.bmo.channel.pwob.service.product.rsclient.Feature> featureSpousal = 
									accountType.getFeatureList().stream().filter(f -> FEATURE_SPOUSAL.equalsIgnoreCase(f.getNameEN())).findFirst();
							if(featureSpousal.isPresent()) {
								iaProduct = new IaProduct();
								iaProduct.setEligible(featureSpousal.get().getEligibility());
								iaProduct.setProductNameEN(featureSpousal.get().getNameEN());
								iaProduct.setType(Account.SPOUSAL_RSP_TYPE);
								iaProduct.setFeeCodes(accountType.getFeeCodeList());
								feeCodes.add(iaProduct);
							}
						}
					}
				}
			}	
		}

		if (productList == null) {
			logger.error("Failed to populate fee code list, Empty response from server.");
			throw new WebServiceException("Empty response from server.");
		}
		return feeCodes;
	}

	List<ProductEligibility> createSpousalVirtualProduct(List<ProductEligibility> pwobProdList) {
		Optional<ProductEligibility> product = pwobProdList.stream().filter(a -> a.getType().equalsIgnoreCase(Account.RSP_TYPE) && a.getFeatures()!=null).findFirst();
		if(product.isPresent()) {
			Optional<Feature> feature = product.get().getFeatures().stream().filter(p-> FEATURE_SPOUSAL.equalsIgnoreCase(p.getFeatureNameEN())).findFirst();	

			if(feature.isPresent()){
				ProductEligibility virtualProduct = new ProductEligibility();
				virtualProduct.setType(product.get().getType() + "-" + FEATURE_SPOUSAL);
				virtualProduct.setProductNameEN(feature.get().getFeatureNameEN()+"-"+product.get().getProductNameEN());
				virtualProduct.setProductNameFR(feature.get().getFeatureNameFR()+"-"+product.get().getProductNameFR());
				virtualProduct.setEligible(feature.get().getEligible());
				virtualProduct.setFeatures(new ArrayList<Feature>());
				virtualProduct.setReasonsForRejection(product.get().getReasonsForRejection());
				pwobProdList.add(virtualProduct);
			}
		}
		return pwobProdList;
	}
	
	List<ProductEligibility> createDummyLIFProduct(List<ProductEligibility> pwobProdList) {
		ProductEligibility virtualProduct = new ProductEligibility();
		virtualProduct.setType("100215");
		virtualProduct.setProductNameEN("LIF");
		virtualProduct.setProductNameFR("FRV");
		virtualProduct.setEligible("true");
		virtualProduct.setFeatures(new ArrayList<Feature>());
		virtualProduct.setReasonsForRejection(null);
		pwobProdList.add(virtualProduct);
		return pwobProdList;
}

	@Override
	public BilProducts getEligibleBilProducts() {
				
		ProductList prodList = bilProductsRequest();
		//Data mapper
		return new ProductEligibilityMapper().apply(prodList);		
	}

	protected ProductList bilProductsRequest() {
		GetEligibleProductsForApplicantRequestBody body = new GetEligibleProductsForApplicantRequestBody();
		if(ApplicationLob.il == usersService.currentUser().getLob()) {
			body.setLob(PRODUCT_SERVICE_LOB_INVESTOR_LINE);
		} else if(ApplicationLob.nb == usersService.currentUser().getLob()){
			body.setLob(PRODUCT_SERVICE_LOB_NESBITT_BURNS);
		}
		//body.setDateOfBirth(dateOfBirth);
		//body.setProvinceCode(provinceCode);

		String requestHeader = createRequestHeader("");

		GetEligibleProductsForApplicantRequest request = new GetEligibleProductsForApplicantRequest();
		Request innerRequest = new Request();
		request.setGetEligibleProductsForApplicantRequest(innerRequest);
		innerRequest.setGetEligibleProductsForApplicantRequestBody(body);
		GetEligibleProductsForApplicantResponse response = pwobProduct.getEligibleProductsForApplicantRequest(request, requestHeader);

		
		if (response == null) {
			logger.error("HUB response body is null");
			throw new WebServiceException("No hub response body");
		} else if(STATUS_FAILED.equals(response.getStatus())) {
			logger.error("HUB response status: "+response.getStatus());
			throw new WebServiceException("Hub response indicates failure: " + response.toString());
		} else if(response.getGetEligibleProductsForApplicantResponseBody().getLob().getProductList() == null) {
			logger.error("No products in hub response.");
			throw new WebServiceException("No products in hub response.");
		}

		return response.getGetEligibleProductsForApplicantResponseBody().getLob().getProductList();

	}
}
