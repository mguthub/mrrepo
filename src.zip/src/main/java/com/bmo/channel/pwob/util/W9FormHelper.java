package com.bmo.channel.pwob.util;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.RegulatoryDisclosures;
import com.bmo.channel.pwob.model.onboarding.Residence;
import com.bmo.channel.pwob.model.onboarding.TaxResidency;
import com.bmo.channel.pwob.model.onboarding.Verification;
import com.bmo.channel.pwob.validation.RefDataValues;

@Component
public class W9FormHelper {
	
	
	private boolean checkUSTaxResidenceR4(final List<TaxResidency> taxResidencies) {
		// if Size of tax residency = 1 and residency for tax = USA
		Boolean w9Form = false;
		if (CollectionUtils.isNotEmpty(taxResidencies) && this.isUSACountry(taxResidencies.get(0).getCountry())) {
			w9Form = true;
		}
		return w9Form;
	}

	public void removeW9TaxResidencyUS(Application application) {

		final List<TaxResidency> taxResidencies = application.getPrimaryApplicant().getPersonal().getResidencyForTax();
		// currently only Canadian primary address is allowed in mWealth app
		// (Skip US residency)
		
		Party party = application.getPrimaryApplicant();
		if (w9RemovalRule(application, taxResidencies, party)) {
			// remove W9 form
			application.getPrimaryApplicant().getTaxation().setIsIrsW9FormProvided(null);
			application.getPrimaryApplicant().getTaxation().setTaxIdentificationNumber(null);

		}
	}

	private boolean w9RemovalRule(Application application, final List<TaxResidency> taxResidencies, Party party) {
		return 	Optional.ofNullable(application.getPrimaryApplicant()).isPresent()
				&& Optional.ofNullable(application.getPrimaryApplicant().getPersonal()).isPresent()
				&& Optional.ofNullable(application.getPrimaryApplicant().getTaxation()).isPresent()
				&& checkUSTaxResidenceR4(taxResidencies) && !checkUSCitizenship(party.getPersonal().getIdentity())
				&& !checkUSPrimaryAddress(party.getPersonal().getResidence())
				&& !checkUSPassport(party.getRegulatoryDisclosures());
	}
	
	private boolean isUSACountry(String country) {
		return RefDataValues.USA_COUNTRY_CODE.equalsIgnoreCase(country);
	}

	private boolean checkUSPrimaryAddress(final Residence residence) {
		if(residence == null || residence.getPrimaryAddress() == null) {
			return false;
		}
		return  StringUtils.isNoneBlank(residence.getPrimaryAddress().getCountry()) && this.isUSACountry(residence.getPrimaryAddress().getCountry());
	}
	
	private boolean checkUSCitizenship(final Identity identity) {
		if(CollectionUtils.isNotEmpty(identity.getCitizenships())){
			for (String  citizenship : identity.getCitizenships()) {
		    	if (this.isUSACountry(citizenship)) {
		    		return true;        		
		    	}
		    }
		}
		return false;
	}	
	
	private boolean checkTaxResidencyCountry(final PersonalInformation personal) {
		
		if(Optional.ofNullable(personal).isPresent() &&
				Optional.ofNullable(personal.getResidencyForTax()).isPresent() 
				&& personal.getResidencyForTax().stream().anyMatch(r -> RefDataValues.USA_COUNTRY_CODE.equals(r.getCountry()))){
			return true;
		}else{
			return false;
		}			
	}
	
	private boolean checkUSPassport(final RegulatoryDisclosures regulatoryDisclosures) {
		if(regulatoryDisclosures!= null){
			final Verification verification = regulatoryDisclosures.getVerification();		
			return verification != null && this.isPassportDocument(verification.getDocumentType()) && this.isUSACountry(verification.getCountryOfBirth());
		}
		else{
			return false;
		}
	}
	
	
	
	private boolean isPassportDocument(String documentType) {
		return RefDataValues.DOCUMENT_TYPE_PASSPORT_CARD.equalsIgnoreCase(documentType);
	}

	public boolean isW9FormApplicable(final Residence residence, final Identity identity, final RegulatoryDisclosures regulatoryDisclosures,final PersonalInformation personal) {
		return checkUSCitizenship(identity) || checkUSPrimaryAddress(residence) || checkUSPassport(regulatoryDisclosures) || checkTaxResidencyCountry(personal);
	}
	
	
	
}
