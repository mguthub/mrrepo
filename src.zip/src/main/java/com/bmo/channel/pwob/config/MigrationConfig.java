package com.bmo.channel.pwob.config;

import java.util.concurrent.Executor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.core.executor.MultiTaskExecutorService;
import com.bmo.channel.core.executor.MultiTaskExecutorServiceImpl;

/**
 * Spring config that defines two {@link java.util.concurrent.Executor} instances.
 * <dl>
 * 	<dt>migrationLoadTaskExecutor</dt>
 * 	<dd>A task executor with a single element in the thread pool. Because of this configuration, only a single 
 * 		migration process is possible.</dd>
 * 	<dt>migrationExecutionTaskExecutor</dt>
 * 	<dd>A task executor with multiple (configurable) thread pool size. Each element in the pool can migrate 
 * 		an application. With many elements in the pool, multiple applications can be migrated in parallel.</dd>
 * </dl>
 * @author Ryan Chambers (rcham02)
 */
@Configuration
@EnableAsync
public class MigrationConfig {
	@Value("${migrationExecutionPoolSize:1}")
	private int migrationExecutionPoolSize;
	@Value("${migrationExecutionMaxPoolSize:1}")
	private int migrationExecutionMaxPoolSize;

	@Autowired
	private EventManager eventManager;

	@Bean(name="migrationLoadTaskExecutor")
	public Executor migrationLoadTaskExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setMaxPoolSize(1);
		threadPoolTaskExecutor.setThreadGroupName("MigrationLoadTaskExecutor");
		threadPoolTaskExecutor.setQueueCapacity(0);
		return threadPoolTaskExecutor;
	}

	@Bean(name="migrationExecutionTaskExecutor")
	public AsyncTaskExecutor migrationExecutionTaskExecutor() {
		ThreadPoolTaskExecutor threadPoolTaskExecutor = new ThreadPoolTaskExecutor();
		threadPoolTaskExecutor.setCorePoolSize(migrationExecutionPoolSize);
		threadPoolTaskExecutor.setMaxPoolSize(migrationExecutionMaxPoolSize);
		threadPoolTaskExecutor.setThreadGroupName("MigrationExecuteTaskExecutor");
		return threadPoolTaskExecutor;
	}

	@Bean
	public MultiTaskExecutorService multiTaskExecutorService() {
		return new MultiTaskExecutorServiceImpl(migrationExecutionTaskExecutor(),
			eventManager,
			120L);
	}
}
