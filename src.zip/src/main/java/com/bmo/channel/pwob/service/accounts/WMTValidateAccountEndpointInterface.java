package com.bmo.channel.pwob.service.accounts;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

/**
 * @author vvallia
 *
 */
@Produces(MediaType.APPLICATION_JSON)
public interface WMTValidateAccountEndpointInterface {

	@POST
	@Path("/ValidateAccount")
	public ValidateAccountHUBResponse validateAccount(@RequestBody ValidateAccountRequest validateAccountRequest, @HeaderParam("hubHeader") String header);
}
