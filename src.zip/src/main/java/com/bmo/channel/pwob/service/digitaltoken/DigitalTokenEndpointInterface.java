package com.bmo.channel.pwob.service.digitaltoken;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;


/**
 * @author vvallia
 *
 */
@Produces(MediaType.APPLICATION_JSON)

public interface DigitalTokenEndpointInterface {

	@POST
	@Path("/generate")
	public GenerateTokenResponse generate(@RequestBody GenerateTokenRequest generateTokenRequest );
	@POST
	@Path("/validate")
	public ValidateTokenResponse validate(@RequestBody ValidateTokenRequest generateTokenRequest );
}
