/**
 * @author akhales
 */
package com.bmo.channel.pwob.convert;

import com.bmo.channel.pwob.model.onboarding.Application;

import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.ApplicationData;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RelationshipSummary;

public interface ConvertorService {
	 Application getOnboardApplicationData(String applicationId, ApplicationData applicationData, String appStatus);
	 ApplicationData getApplicationData(Application application);
	 RelationshipSummary convertRelationshipSummary(com.bmo.channel.pwob.model.ia.RelationshipSummary summary);
	 com.bmo.channel.pwob.model.ia.RelationshipSummary convertHubRelationshipSummary(RelationshipSummary hubSummary, Application application);
}
