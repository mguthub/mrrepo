package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;

public class GetCountResponseDeserializer extends StdDeserializer<GetCountResponseWrapper> {

    public GetCountResponseDeserializer() {
        this(null);
    }

    public GetCountResponseDeserializer(Class<GetCountResponseWrapper> t) {
        super(t);
    }

    @Override
    public GetCountResponseWrapper deserialize(JsonParser jp, DeserializationContext dc)
            throws IOException {

        JsonNode node = jp.getCodec().readTree(jp);
        JsonNode response = node.get("GetCountResponse");
        ObjectMapper jsonObjectMapper = new ObjectMapper();
        GetCountResponseWrapper newJsonNode = jsonObjectMapper.treeToValue(response, GetCountResponseWrapper.class);
        return newJsonNode;
    }

}
