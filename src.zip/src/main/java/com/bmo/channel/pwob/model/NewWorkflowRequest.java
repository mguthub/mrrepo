package com.bmo.channel.pwob.model;

import javax.validation.constraints.Pattern;

import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.newworkflowrequest.ValidNewWorkflowRequest;
import com.fasterxml.jackson.annotation.JsonIgnore;

@ValidNewWorkflowRequest
public class NewWorkflowRequest {
	private String ecifId;

	private String risToken;
	
	@Pattern(regexp="[a-zA-ZÀ-Ÿà-ÿ\\s\\-'’ ]{2,20}", message=ErrorCodes.INVALID_FIRST_NAME)
	private String firstName;
	
	@Pattern(regexp="[a-zA-ZÀ-Ÿà-ÿ\\s\\-'’ ]{2,20}", message=ErrorCodes.INVALID_LAST_NAME)
	private String lastName;
	
	@Pattern(regexp="[a-zA-Z0-9]{1,3}", message=ErrorCodes.INVALID_NEW_WORKFLOW_REQUEST_IA_CODE)
	private String iaCode;
	
	private String locale;
	
	public String getEcifId(){
		return ecifId;
	}
	@JsonIgnore
	public void setEcifId(String ecifId){
		this.ecifId=ecifId;
	}
	public String getIaCode() {
		return iaCode;
	}
	public void setIaCode(String iaCode) {
		this.iaCode = iaCode;
	}
	public String getFirstName(){
		return firstName;
	}
	public void setFirstName(String firstName){
		this.firstName=firstName;
	}
	public String getLastName(){
		return lastName;
	}
	public void setLastName(String lastName){
		this.lastName=lastName;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public String getRisToken() {
		return risToken;
	}
	public void setRisToken(String risToken) {
		this.risToken = risToken;
	}
}
