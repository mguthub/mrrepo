package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.service.illaunch.ILLaunchService;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Path(ILLaunchEndpoint.V1_PATH)
public class ILLaunchEndpoint {
	public static final String V1_PATH = "il_launch";
	
	private static Logger logger = LoggerFactory.getLogger(ILLaunchEndpoint.class);
		
	@Autowired
	ILLaunchService ilLaunchService;
	
	
	@POST
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_HTML)
    public Response launchIL(@FormParam("OLAP_ExternalInterface") String formData) {
		
		try
		{	
			if (ilLaunchService.isOlapOnly(formData)) {
				return Response.ok(ilLaunchService.redirectToOlap(formData)).build();
			}
			else {
				return Response.ok(ilLaunchService.parseAndRedirectToApp(formData)).build();
			}
		}catch (Exception ex) {
			logger.error("Launching of IL Services failed. ",ex);
			return Response.ok(Status.INTERNAL_SERVER_ERROR).build();
		}
    }
}
