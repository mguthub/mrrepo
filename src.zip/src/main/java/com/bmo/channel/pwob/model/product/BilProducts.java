package com.bmo.channel.pwob.model.product;

import java.util.ArrayList;
import java.util.List;

public class BilProducts {
	
	private List<BilProduct> bilProduct;

	public List<BilProduct> getbilProduct() {
		
		if(bilProduct == null){
			bilProduct = new ArrayList<>();
		}		
		return this.bilProduct;
	}

	public void setbilProduct(List<BilProduct> bilProduct) {
		this.bilProduct = bilProduct;
	}

}
