package com.bmo.channel.pwob.user;

public interface UserContext {
	
	public static final String IV_USER_HEADER = "iv-user";
	public static final String IV_GROUPS_HEADER="iv-groups";
	public static final String GROUP_NAME_NB="PWOB_PCD_USERS";
	public static final String GROUP_NAME_IL="CAN_WEALTH_ONBOARD_IL";
	public static final String X_BMO_BUSINESS_CATEGORY= "x_bmo_business_category";
	public static final String SSO_ID = "x_bmo_sso_id";
	public static final String WORKFLOW_ID = "workflow_id";
		
	public AuthenticatedUser getAuthenticatedUser();
}
