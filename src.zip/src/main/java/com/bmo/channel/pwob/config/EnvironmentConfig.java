package com.bmo.channel.pwob.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.FeatureFlag;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;

/**
 * Configuration for environment specific properties.
 */
@Component
public class EnvironmentConfig {
	@Value("#{'${env.phone.areacodes}'.split(',')}")
	private List<String> usaPhoneAreaCodes;

	@Value("#{'${env.xss.patterns}'.split('~')}")
	private List<String> xssPatterns;

	@Value("${application.host.uri}")
	private String applnHostUrl;

	@Value("${enable.fake.injection:false}")
	private String injectionEnabled;

	@Value("${feature.flags}")
	private String rawFeatureFlags;

	private List<Pattern> patterns = null;

	public List<String> getUsaPhoneAreaCodes() {
		return usaPhoneAreaCodes;
	}

	public void setUsaPhoneAreaCodes(final List<String> usaPhoneAreaCodes) {
		this.usaPhoneAreaCodes = usaPhoneAreaCodes;
	}

	public String getApplnHostUrl() {
		return applnHostUrl;
	}

	public List<Pattern> getPatterns() {
		if (patterns == null) {
			patterns = new ArrayList<>(xssPatterns.size());
			for (String pattern : xssPatterns) {
				patterns.add(Pattern.compile(pattern, Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL));
			}
		}
		return patterns;
	}

	public List<String> getXssPatterns() {
		return xssPatterns;
	}

	public void setXssPatterns(final List<String> xssPatterns) {
		this.xssPatterns = xssPatterns;
	}

	public String getInjectionEnabled() {
		return injectionEnabled;
	}

	public void setInjectionEnabled(String injectionEnabled) {
		this.injectionEnabled = injectionEnabled;
	}

	public void setApplnHostUrl(String applnHostUrl) {
		this.applnHostUrl = applnHostUrl;
	}

	public void setRawFeatureFlags(String rawFeatureFlags) {
		this.rawFeatureFlags = rawFeatureFlags;
	}

	public FeatureFlag getFeatureFlag(String name) {
		if(StringUtils.isEmpty(name) || StringUtils.isEmpty(rawFeatureFlags)) {
			return null;
		}

		Optional<String> feature = Arrays.stream(rawFeatureFlags.split(",")).filter(s -> s.startsWith(name)).findFirst();
		if(feature.isPresent()) {
			String string = feature.get();
			return parseRawFeatureFlag(string);
		} else {
			return null;
		}
	}

	private FeatureFlag parseRawFeatureFlag(String string) {
		String f[] = string.split(":");
		if(f.length > 1) {
			return new FeatureFlag(f[0], f[1]);
		} else {
			return new FeatureFlag(f[0]);
		}
	}

	public FeatureFlags getFeatureFlags() {
		if(StringUtils.isEmpty(rawFeatureFlags)) {
			return new FeatureFlags(new HashSet<>());
		}
		String[] kvs = rawFeatureFlags.split(",");
		return new FeatureFlags(Arrays.stream(kvs).map(kv -> parseRawFeatureFlag(kv)).collect(Collectors.toSet()));
	}
}
