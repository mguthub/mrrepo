package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;

import io.swagger.annotations.ApiModelProperty;

public class AlternateAddress extends  Address {
	
	@ApiModelProperty(example="John")
	@DataValidationPattern(code=ErrorCodes.INVALID_RECIPIENT)
	private String recipient;
	
	private Boolean isAccountStatements;
	
	private Boolean isTradeConfirmations;
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);	
	}


	public String getRecipient() {
		return recipient;
	}


	public void setRecipient(String recipient) {
		this.recipient = recipient;
	}


	public Boolean getIsAccountStatements() {
		return isAccountStatements;
	}


	public void setIsAccountStatements(Boolean isAccountStatements) {
		this.isAccountStatements = isAccountStatements;
	}


	public Boolean getIsTradeConfirmations() {
		return isTradeConfirmations;
	}


	public void setIsTradeConfirmations(Boolean isTradeConfirmations) {
		this.isTradeConfirmations = isTradeConfirmations;
	}

}
