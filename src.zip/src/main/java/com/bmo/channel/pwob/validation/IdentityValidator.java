/**
 * 
 */
package com.bmo.channel.pwob.validation;

import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;
import com.bmo.channel.pwob.validation.residence.DependentValidator;

/**
 * @author vvallia
 *
 */
// TODO The ValidIdentity annotation should be removed, and this logic moved to the Party Validator
public class IdentityValidator extends AbstractBaseValidator  implements ConstraintValidator<ValidIdentity, Party>{
	@Autowired private DependentValidator dependentValidator;

	@Autowired private ValidationRequestFactory requestFactory;

	@Autowired private UsersService userService;

	@Override
	public void initialize(ValidIdentity constraintAnnotation) {
		// none required
	}

	@Override
	public boolean isValid(final Party party,  final ConstraintValidatorContext context) {
		final ValidationContextHolder validationContext = ValidationManager.validationContext.get();

		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		boolean valid = true;

		if(party!=null && (isPrimaryApplicantRole(party.getRoles())) || isJointApplicantRole(party.getRoles())){
			ValidationRequest request = requestFactory.createBuilder(context, 
					userService.currentUser().getLob()).withChildPropertyNode(PERSONAL_IDENTITY_NODE).withChildFieldPath(PERSONAL_IDENTITY_PATH).build();

			if(party.getPersonal().getIdentity()!=null) {
				if(party.getIsPrimaryApplicantSpouse() == null || !party.getIsPrimaryApplicantSpouse()) {
					request.setFieldName(MARITAL_STATUS_NODE);
					request.setFieldValue(party.getPersonal().getIdentity().getMaritalStatus());
					request.setErrorCode(ErrorCodes.INVALID_MARITAL_STATUS);
					valid = this.validateAndAddConstraintViolation(request) && valid;
				}
				
				request.setFieldName(SIN_FIELD_NAME);
				request.setFieldValue(party.getPersonal().getIdentity().getSocialInsuranceNumber());
				request.setErrorCode(ErrorCodes.INVALID_SIN);
				valid = this.validateAndAddConstraintViolation(request) && valid;

				if(party.getPreferences() != null && Optional.ofNullable(party.getPreferences().getReceiveElectronicDelivery()).isPresent()
							&& party.getPreferences().getReceiveElectronicDelivery()){				
					request.setFieldName(PRIMARY_EMAIL_ADD_FIELD_NAME);
					request.setErrorCode(ErrorCodes.INVALID_PRIMARY_EMAIL);
					request.setFieldValue(party.getPersonal().getIdentity().getPrimaryEmailAddress());
					valid = this.validateAndAddConstraintViolation(request) && valid;
				}

				request.setFieldName(DOB_FIELD_NAME);
				request.setErrorCode(ErrorCodes.INVALID_DATE_OF_BIRTH);
				request.setFieldValue(party.getPersonal().getIdentity().getDateOfBirth());
				valid = this.validateDateOfBirth(request) && valid;

				valid = this.validateCitizenship(party.getPersonal().getIdentity(),request) && valid;
				
				boolean isPrimaryApplicantSpouse = false;
				if(Optional.ofNullable(party.getIsPrimaryApplicantSpouse()).isPresent() && party.getIsPrimaryApplicantSpouse()){
					    isPrimaryApplicantSpouse = true;
				};

				valid = this.dependentValidator.validateDependents(party.getPersonal().getIdentity(),isPrimaryApplicantSpouse ,request) && valid;
			} else{
				valid=false;
				request.setFieldValue(null);

				request.setFieldName(MARITAL_STATUS_NODE);
				request.setErrorCode(ErrorCodes.INVALID_MARITAL_STATUS);
				request.addConstraintViolation(); 

				request.setFieldName(SIN_FIELD_NAME);
				request.setErrorCode(ErrorCodes.INVALID_SIN);
				request.addConstraintViolation(); 

				request.setFieldName(PRIMARY_EMAIL_ADD_FIELD_NAME);
				request.setErrorCode(ErrorCodes.INVALID_PRIMARY_EMAIL);
				request.addConstraintViolation(); 

				request.setFieldName(DOB_FIELD_NAME);
				request.setErrorCode(ErrorCodes.INVALID_DATE_OF_BIRTH);
				request.addConstraintViolation(); 

				request.setFieldName(CITIZENSHIP_FIELD_NAME);
				request.setErrorCode(ErrorCodes.INVALID_CITIZENSHIP);
				request.addConstraintViolation(); 

				request.setErrorCode(ErrorCodes.INVALID_HAS_DEPENDENTS);
				request.setFieldName(HAD_DEPENDENTS_FIELD_NAME);
				request.addConstraintViolation();

				request.setErrorCode(ErrorCodes.INVALID_NUM_OF_DEPENDENTS);
				request.setFieldName(NUM_OF_DEPENDENTS_FIELD_NAME);
				request.addConstraintViolation();
			}
		}
		
		return valid;
	}		
	
	@Override
	protected boolean validateAndAddConstraintViolation(ValidationRequest request) {		
		boolean valid = StringUtils.isNotBlank(request.getFieldValue()) && validateField(request);				
		if(!valid) {
			request.addConstraintViolation();
			return false;
		}
		return true;
	}
	
	private boolean validateCitizenship(Identity identity, ValidationRequest request) {
		if(identity == null || CollectionUtils.isEmpty(identity.getCitizenships()) || identity.getCitizenships().size() > 4) {			
			request.setFieldName(CITIZENSHIP_FIELD_NAME);
			request.setErrorCode(ErrorCodes.INVALID_CITIZENSHIP);
			request.addConstraintViolation();
			return false;
		} 
		return true;		
	}
	
	private boolean validateDateOfBirth(ValidationRequest request) {
		if(StringUtils.isNotBlank(request.getFieldValue()) && !isValidDOB(request.getFieldValue())) {
			request.setErrorCode(ErrorCodes.INVALID_DATE);
			request.addConstraintViolation();
			return false;
		}
		else{
			return validateAndAddConstraintViolation(request);
		}		
	}

}
