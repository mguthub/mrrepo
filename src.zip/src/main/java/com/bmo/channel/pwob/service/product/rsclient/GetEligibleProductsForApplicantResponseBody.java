package com.bmo.channel.pwob.service.product.rsclient;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonProperty;

public class GetEligibleProductsForApplicantResponseBody {
	@JsonProperty("LOB")
    protected Lob lob;

    public Lob getLob() {
        return lob;
    }
    public void setLob(Lob lob) {
        this.lob = lob;
    }

    public static class Lob {
        protected String name;
        protected ProductList productList;

        public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public ProductList getProductList() {
			return productList;
		}

		public void setProductList(ProductList productList) {
			this.productList = productList;
		}

		public static class ProductList {

            protected List<Product> product;

            public List<Product> getProduct() {
				return product;
			}
			public void setProduct(List<Product> product) {
				this.product = product;
			}

			public static class Product {

                protected String name;
                protected AccountList accountList;

                public String getName() {
					return name;
				}
				public void setName(String name) {
					this.name = name;
				}

				public AccountList getAccountList() {
					return accountList;
				}
				public void setAccountList(AccountList accountList) {
					this.accountList = accountList;
				}
            }
        }
    }

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
