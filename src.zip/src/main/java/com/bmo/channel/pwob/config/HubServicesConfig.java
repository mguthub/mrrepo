package com.bmo.channel.pwob.config;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.configuration.jsse.TLSParameterJaxBUtils;
import org.apache.cxf.configuration.security.KeyManagersType;
import org.apache.cxf.configuration.security.KeyStoreType;
import org.apache.cxf.configuration.security.TrustManagersType;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.feature.LoggingFeature;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxrs.client.ClientConfiguration;
import org.apache.cxf.jaxrs.client.JAXRSClientFactoryBean;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.service.accounts.WMTValidateAccountEndpointInterface;
import com.bmo.channel.pwob.service.contractv6.ContractV6EndpointInterface;
import com.bmo.channel.pwob.service.digitaltoken.DigitalTokenEndpointInterface;
import com.bmo.channel.pwob.service.document.DocumentUpdateUploadEndpointInterface;
import com.bmo.channel.pwob.service.document.OnboardApplicationDocumentationEndpointInterface;
import com.bmo.channel.pwob.service.fis.FinancialInstitutionsEndpointInterface;
import com.bmo.channel.pwob.service.product.rsclient.PwobProduct;
import com.bmo.channel.pwob.service.reference.ReferenceDataServiceEndpointInterface;
import com.bmo.channel.pwob.service.risprefill.RisAccountSearchEndpointInterface;
import com.bmo.channel.pwob.service.workflowstatus.WorkflowStatusEndpointInterface;
import com.bmo.channel.pwob.util.OnboardAppRetrieveInInterceptor;
import com.bmo.channel.workflows.parties.proxy.v2.PartiesV2;
import com.fasterxml.jackson.jaxrs.json.JacksonJsonProvider;

import net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.http.v1_0.OnboardApplicationPreparation;
import net.bmogc.xmlns.hub.cg.document.cmiscontent._interface.v1.CMISContent;
import net.bmogc.xmlns.hub.cg.document.documentation._interface.v1.Documentation;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.DocumentTrackingService;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.OnboardApplication;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.WorkflowInitiationService;
import net.bmogc.xmlns.hub.cg.wealthmanagement.investmentadvisorunit.intf.v2_0.InvestmentAdvisorUnitV2;
import net.bmogc.xmlns.hub.cg.wealthmanagement.wealthcredential.intf.v1_0.WealthCredential;

@Configuration
public class HubServicesConfig {
	
	private static Logger logger = LoggerFactory.getLogger(HubServicesConfig.class);
	
	@Value("${dp.key.password}")
	private String dpKeyPassword;

	@Value("${dp.key.location}")
	private String dpKeyLocation;

	@Value("${hub.service.wis.uri}")
	private String wisUrl;

	@Value("${hub.service.wss.uri}")
	private String wssUrl;

	@Value("${hub.service.onboard.uri}")
	private String onboardApplicationUrl;

	@Value("${hub.service.iaunit.uri}")
	private String iaUnitUrl;

	@Value("${hub.service.product.uri}")
	private String productUrl;

	@Value("${channel.parties.v2.uri}")
	private String partyV2Url;

	@Value("${hub.service.dts.uri}")
	private String documentTrackerUrl;

	@Value("${hub.service.cmis.uri}")
	private String cmisContentUrl;

	@Value("${hub.service.uploaddocument.uri}")
	private String documentUploadUrl;

	@Value("${hub.service.application.preparation.uri}")
	private String onboardPreparationUrl;

	@Value("${hub.service.application.documentation.uri}")
	private String onboardDocumentationUrl;

	@Value("${hub.service.documentation.uri}")
	private String documentationUrl;
	
	@Value("${hub.service.wmtAccount.uri}")
	private String wmtValidateAccountUrl;

	@Value("${hub.service.wealthcredential.uri}")
	private String wealthCredentialUrl;

	@Value("${hub.service.refdatav2.uri}")
	private String refDataUrl;
	
	@Value("${hub.service.fi.uri}")
	private String financialInstitutionsUrl;
	
	@Value("${hub.service.digitaltoken.uri}")
	private String digitalTokenUrl;
	
	@Value("${hub.service.ris.prefill.uri}")
	private String risPrefillUrl;
	
	@Value("${hub.service.contract.uri}")
	private String contractUrl;
	
	@Bean
	public LoggingFeature loggingFeature(){
		LoggingFeature loggingFeature = new LoggingFeature();
		loggingFeature.setLimit(1024000);
		loggingFeature.setPrettyLogging(true);
		return loggingFeature;
	}

	@Bean
	public JacksonJsonProvider jsonProvider(){
		return new JacksonJsonProvider();
	}

	@Bean
	public Map<String,String> jsonHeaders(){
		Map<String, String> headers = new HashMap<>();
		headers.put("Accept","application/json");
		headers.put("Content-Type","application/json;charset=utf-8");
		return headers;
	}

	/****************************************************************
	********************  Hub Service Beans  ************************
	*****************************************************************/

	@Bean
	public WorkflowInitiationService workflowHubClient(){
		WorkflowInitiationService service = configureWsProxy(wisUrl, WorkflowInitiationService.class).create(WorkflowInitiationService.class);
		configureConduitWs(ClientProxy.getClient(service));
		return service;
	}

//	@Bean
//	public WorkflowStatusService wssHubClient(){
//		WorkflowStatusService service = configureWsProxy(wssUrl, WorkflowStatusService.class).create(WorkflowStatusService.class);
//		configureConduitWs(ClientProxy.getClient(service));
//		return service;
//	}

	@Bean
	public WorkflowStatusEndpointInterface WorkflowStatusEndpointInterface(){
		WorkflowStatusEndpointInterface service = configureRsClient(wssUrl, WorkflowStatusEndpointInterface.class).create(WorkflowStatusEndpointInterface.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}

	@Bean
	public OnboardApplication onboardApplication(){
		JaxWsProxyFactoryBean factoryBean = configureWsProxy(onboardApplicationUrl, OnboardApplication.class);
		factoryBean.setInInterceptors(Arrays.asList(new OnboardAppRetrieveInInterceptor()));

		OnboardApplication service = factoryBean.create(OnboardApplication.class);
		configureConduitWs(ClientProxy.getClient(service));
		return service;
	}

	@Bean
	public InvestmentAdvisorUnitV2 investorAdvisorUnit(){
		InvestmentAdvisorUnitV2 service = configureWsProxy(iaUnitUrl, InvestmentAdvisorUnitV2.class).create(InvestmentAdvisorUnitV2.class);
		configureConduitWs(ClientProxy.getClient(service));
		return service;
	}

	@Bean
	public PwobProduct productHubClient(){
		PwobProduct service = configureRsClient(productUrl, PwobProduct.class).create(PwobProduct.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}

	@Bean
	public DocumentTrackingService documentTrackingService(){
		DocumentTrackingService service = configureWsProxy(documentTrackerUrl, DocumentTrackingService.class).create(DocumentTrackingService.class);
		configureConduitWs(ClientProxy.getClient(service));
		return service;
	}

	@Bean
	public CMISContent cmisContent(){
		CMISContent service = configureWsProxy(cmisContentUrl, CMISContent.class).create(CMISContent.class);
		configureConduitWs(ClientProxy.getClient(service));
		return service;
	}

	@Bean
	public OnboardApplicationPreparation onboardApplicationPreparationService(){
		OnboardApplicationPreparation service = configureWsProxy(onboardPreparationUrl, OnboardApplicationPreparation.class).create(OnboardApplicationPreparation.class);
		configureConduitWs(ClientProxy.getClient(service));
		return service;
	}

	@Bean
	public OnboardApplicationDocumentationEndpointInterface onboardApplicationDocumentationEndpointInterface(){
		OnboardApplicationDocumentationEndpointInterface service = configureRsClient(onboardDocumentationUrl, OnboardApplicationDocumentationEndpointInterface.class).create(OnboardApplicationDocumentationEndpointInterface.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}
	
	@Bean
	public PartiesV2 channelPartyApiProxy(){
		PartiesV2 service = configureRsClient(partyV2Url, PartiesV2.class).create(PartiesV2.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}

	@Bean
	public DocumentUpdateUploadEndpointInterface documentUpdateUploadEndpointInterface(){
		DocumentUpdateUploadEndpointInterface service = configureRsClient(documentUploadUrl, DocumentUpdateUploadEndpointInterface.class).create(DocumentUpdateUploadEndpointInterface.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}

	@Bean
	public Documentation documentation() {
		Documentation service = configureWsProxy(documentationUrl, Documentation.class).create(Documentation.class);
		configureConduitWs(ClientProxy.getClient(service));
		return service;
	}
	
	@Bean
	public WMTValidateAccountEndpointInterface wmtValidateAccountEndpointInterface(){
		WMTValidateAccountEndpointInterface service = configureRsClient(wmtValidateAccountUrl, WMTValidateAccountEndpointInterface.class).create(WMTValidateAccountEndpointInterface.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}

	@Bean
	public WealthCredential wealthCredential() {
		final WealthCredential service = configureWsProxy(wealthCredentialUrl, WealthCredential.class).create(WealthCredential.class);
		configureConduitWs(ClientProxy.getClient(service));
		return service;
	}

	@Bean
	public ReferenceDataServiceEndpointInterface referenceData() {
		ReferenceDataServiceEndpointInterface service = configureRsClient(refDataUrl, ReferenceDataServiceEndpointInterface.class).create(ReferenceDataServiceEndpointInterface.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}
	
	@Bean
	public FinancialInstitutionsEndpointInterface financialInstitutionsEndpointInterface(){
		FinancialInstitutionsEndpointInterface service = configureRsClient(financialInstitutionsUrl, FinancialInstitutionsEndpointInterface.class).create(FinancialInstitutionsEndpointInterface.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}
	
	@Bean
	public DigitalTokenEndpointInterface digitalTokenEndpointInterface(){
		DigitalTokenEndpointInterface service = configureRsClient(digitalTokenUrl, DigitalTokenEndpointInterface.class).create(DigitalTokenEndpointInterface.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}
	
	@Bean
	public RisAccountSearchEndpointInterface risAccountSearchEndpointInterface(){
		RisAccountSearchEndpointInterface service = configureRsClient(risPrefillUrl, RisAccountSearchEndpointInterface.class).create(RisAccountSearchEndpointInterface.class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}
	
	@Bean
	public ContractV6EndpointInterface contractV6EndpointInterface(){
		ContractV6EndpointInterface service = configureRsClient(contractUrl, ContractV6EndpointInterface .class).create(ContractV6EndpointInterface .class);
		configureConduitRs(WebClient.getConfig(service));
		return service;
	}

	private JaxWsProxyFactoryBean configureWsProxy(String address, Class<?> serviceClass){
		JaxWsProxyFactoryBean factoryBean = new JaxWsProxyFactoryBean();
		factoryBean.setAddress(address);
		factoryBean.setServiceClass(serviceClass);
		factoryBean.setFeatures(Arrays.asList(loggingFeature()));
		return factoryBean;
	}

	private JAXRSClientFactoryBean configureRsClient(String address, Class<?> serviceClass){
		JAXRSClientFactoryBean factoryBean = new JAXRSClientFactoryBean();
		factoryBean.setServiceClass(serviceClass);
		factoryBean.setAddress(address);
		factoryBean.setFeatures(Arrays.asList(loggingFeature()));
		factoryBean.setProvider(jsonProvider());
		factoryBean.setHeaders(jsonHeaders());
		return factoryBean;
	}

	/***********************************************************
	********************  HTTP Conduit  ************************
	************************************************************/

	private void configureConduitWs(Client client){
		configureConduit((HTTPConduit) client.getConduit());
	}

	private void configureConduitRs(ClientConfiguration client){
		configureConduit((HTTPConduit) client.getConduit());
	}

	private void configureConduit(HTTPConduit conduit){
		conduit.setClient(clientPolicy());
		conduit.setTlsClientParameters(tlsClientParameters());
	}

	@Bean
	public HTTPClientPolicy clientPolicy(){
		HTTPClientPolicy clientPolicy = new HTTPClientPolicy();
		clientPolicy.setConnectionTimeout(30000);
		clientPolicy.setReceiveTimeout(60000);
		return clientPolicy;
	}

	@Bean
	public TLSClientParameters tlsClientParameters(){
		TLSClientParameters tlsClientParameters = new TLSClientParameters();
		tlsClientParameters.setDisableCNCheck(true);

		try {
			KeyStoreType storeType = new KeyStoreType();
			storeType.setPassword(dpKeyPassword);
			storeType.setFile(dpKeyLocation);
			storeType.setType("JKS");

			KeyManagersType keyManagers = new KeyManagersType();
			keyManagers.setKeyStore(storeType);
			keyManagers.setKeyPassword(dpKeyPassword);

			TrustManagersType trustManagers = new TrustManagersType();
			trustManagers.setKeyStore(storeType);

			tlsClientParameters.setTrustManagers(TLSParameterJaxBUtils.getTrustManagers(trustManagers));
			tlsClientParameters.setKeyManagers(TLSParameterJaxBUtils.getKeyManagers(keyManagers));

			return tlsClientParameters;

		} catch (IOException | GeneralSecurityException ex) {
			logger.error("Failure in setting tlsClient parameters. ",ex);
			throw new WebServiceException(ex);
		}
	}
}
