package com.bmo.channel.pwob.service.product.rsclient;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetEligibleProductsForApplicantResponse {
	private GetEligibleProductsForApplicantResponseBody getEligibleProductsForApplicantResponseBody;
	private String status;
	private HubError hubError;

	public GetEligibleProductsForApplicantResponseBody getGetEligibleProductsForApplicantResponseBody() {
		return getEligibleProductsForApplicantResponseBody;
	}
	public void setGetEligibleProductsForApplicantResponseBody(
			GetEligibleProductsForApplicantResponseBody getEligibleProductsForApplicantResponseBody) {
		this.getEligibleProductsForApplicantResponseBody = getEligibleProductsForApplicantResponseBody;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public HubError getHubError() {
		return hubError;
	}
	public void setHubError(HubError hubError) {
		this.hubError = hubError;
	}

	@JsonIgnoreProperties(ignoreUnknown = true)
	public static class HubError {
		private String errorCode;
		private String detailedMessageText;
		private String stackTrace;
		public String getErrorCode() {
			return errorCode;
		}
		public void setErrorCode(String errorCode) {
			this.errorCode = errorCode;
		}
		public String getDetailedMessageText() {
			return detailedMessageText;
		}
		public void setDetailedMessageText(String detailedMessageText) {
			this.detailedMessageText = detailedMessageText;
		}
		public String getStackTrace() {
			return stackTrace;
		}
		public void setStackTrace(String stackTrace) {
			this.stackTrace = stackTrace;
		}

		@Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this);
		}
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
