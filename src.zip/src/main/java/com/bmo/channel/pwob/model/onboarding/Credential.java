package com.bmo.channel.pwob.model.onboarding;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Credential {
	@ApiModelProperty(example = "333", value = "Primary Account number attached to this userId")
	private String primaryAccountNumber;
	
	@ApiModelProperty(example = "testUser", value = "Unique User Id for the Credential")
	private String userId;

	@ApiModelProperty(example = "P.J.", value = "First name for the owner of userId")
	private String firstName;

	@ApiModelProperty(example = "Tucker", value = "Last name for the owner of userId")
	private String lastName;
	
	public String getPrimaryAccountNumber() {
		return primaryAccountNumber;
	}
	public void setPrimaryAccountNumber(final String primaryAccountNumber) {
		this.primaryAccountNumber = primaryAccountNumber;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(final String userId) {
		this.userId = userId;
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
