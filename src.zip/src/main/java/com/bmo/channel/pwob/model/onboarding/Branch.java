package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;
import io.swagger.annotations.ApiModelProperty;

public class Branch {
	@ApiModelProperty(example="00034", value="Transit ID")
	private String transitId;
	
	@ApiModelProperty(example="0001", value="Financial institution ID")
	private String fiId;
	
	@ApiModelProperty(example="BANK OF MONTREAL", value="Financial institution name")
	private String financialInstitutionName;
	
	@ApiModelProperty(example="P.O. BOX 100", value="Postal address")
	private String postalAddress;
	
	@ApiModelProperty(example="780 MAIN STREET", value="Civic address")
	private String civicAddress;
	
	@ApiModelProperty(example="MONCTON", value="City name")
	private String city;
	
	@ApiModelProperty(example="ON", value="Province name")
	private String province;
	
	@ApiModelProperty(example="E1C 8K7", value="Postal code")
	private String postalCode;

	public String getTransitId() {
		return transitId;
	}

	public void setTransitId(String transitId) {
		this.transitId = transitId;
	}

	public String getFiId() {
		return fiId;
	}

	public void setFiId(String fiId) {
		this.fiId = fiId;
	}
	
	public String getFinancialInstitutionName() {
		return financialInstitutionName;
	}

	public void setFinancialInstitutionName(String financialInstitutionName) {
		this.financialInstitutionName = financialInstitutionName;
	}

	public String getPostalAddress() {
		return postalAddress;
	}

	public void setPostalAddress(String postalAddress) {
		this.postalAddress = postalAddress;
	}

	public String getCivicAddress() {
		return civicAddress;
	}

	public void setCivicAddress(String civicAddress) {
		this.civicAddress = civicAddress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
