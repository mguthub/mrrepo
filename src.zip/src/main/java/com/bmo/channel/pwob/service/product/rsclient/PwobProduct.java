package com.bmo.channel.pwob.service.product.rsclient;

import javax.ws.rs.Consumes;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.bmo.channel.pwob.service.product.GetEligibleProductsForApplicantRequest;

/**
 * Jax RS interface class for Pwob Product JSON API.
 * @author Ryan Chambers (rcham02)
 */
@Produces(MediaType.APPLICATION_JSON)
public interface PwobProduct {
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public GetEligibleProductsForApplicantResponse getEligibleProductsForApplicantRequest(@RequestBody GetEligibleProductsForApplicantRequest request, 
		@HeaderParam("APIHeaderRequest") String requestHeader);
}
