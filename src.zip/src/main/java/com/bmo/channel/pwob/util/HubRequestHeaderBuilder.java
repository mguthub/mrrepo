package com.bmo.channel.pwob.util;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang3.StringUtils;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;

import net.bmogc.xmlns.hub.header.v1.Correlation;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;
import net.bmogc.xmlns.hub.header.v1.What;
import net.bmogc.xmlns.hub.header.v1.Where;
import net.bmogc.xmlns.hub.header.v1.Who;

/**
 * Generates a variety of hub service request headers.
 */

public class HubRequestHeaderBuilder {
		
	private final String callPath;
	private final String originatorResource;
	private final String originatorResourceFunction;
	private final String originatorChannel;
	private final String originatorLocationId;
	private final String originatorLocationType;
	private final String userId;
	private final String userType;

	/* credit card number, ecif id etc */
	private final String partyAccessId;

	/* can be unknow */
	private final String partyAccessType;
	private final String partyId;
	private final String partyIdType;
	private final String partyMultiFactorAuthenticationIndicator;
	private final String partyRoleType;
	private final String digitalSignature;
	private final String appCatId;
	private final String requestId;
	private final String workflowId;
	private final String packageId;
	private final String documentId;
	private final ApplicationLob lob;
	private final String originatorSessionId;
	
	private HubRequestHeaderBuilder(final HeaderBuilder builder) {
        this.callPath = builder.callPath;
        this.originatorResource = builder.originatorResource;
        this.originatorResourceFunction = builder.originatorResourceFunction;
        this.originatorChannel = builder.originatorChannel;
        this.originatorLocationId = builder.originatorLocationId;
        this.originatorLocationType = builder.originatorLocationType;
        this.userId = builder.userId;
        this.userType = builder.userType;
        this.partyAccessId = builder.partyAccessId;
        this.partyAccessType = builder.partyAccessType;
        this.partyId = builder.partyId;
        this.partyIdType = builder.partyIdType;
        this.partyMultiFactorAuthenticationIndicator = builder.partyMultiFactorAuthenticationIndicator;
        this.partyRoleType = builder.partyRoleType;
        this.digitalSignature = builder.digitalSignature;
        this.appCatId = builder.appCatId;
        this.requestId = builder.requestId;
        this.workflowId = builder.workflowId;
        this.packageId = builder.packageId;
        this.documentId = builder.documentId;
        this.lob = builder.lob;
        this.originatorSessionId = builder.originatorSessionId;
      
    }
	
	public HUBHeaderRequest build() {
		
		
		final HUBHeaderRequest hubHeaderRequest = new HUBHeaderRequest();
		final Correlation correlation = new Correlation();
		final What what = new What();
		final Where where = new Where();		
		final XMLGregorianCalendar date = DateUtils.getTimestamp();		
		String keyValues="";
		
		correlation.setCallPath(callPath);
		correlation.setMyId(requestId);
		correlation.setMyTimeStamp(date);
		correlation.setRequestId(requestId);

		what.setAPI(originatorResource);
		what.setAPIFunction(originatorResourceFunction);
		
		if(StringUtils.isNoneBlank(this.workflowId)) {
			keyValues ="{\"workflowID\":\"" + this.workflowId ;
		    if (StringUtils.isNoneBlank(this.packageId)) {
				keyValues =keyValues + "\"packageId\":\"" + this.packageId;
			}
			if (StringUtils.isNoneBlank(this.documentId)) {
				keyValues =keyValues + "\"documentId\":\"" + this.documentId;
			}
			what.setKeyValues(keyValues +"\"}");	
		}
		
		where.setOriginatorApplicationCatalogueId(appCatId);
		where.setOriginatorChannel(originatorChannel);
		where.setOriginatorLocationId(originatorLocationId);
		where.setOriginatorLocationType(originatorLocationType);
	
		hubHeaderRequest.setCorrelation(correlation);
		hubHeaderRequest.setDigitalSignature(digitalSignature);
		hubHeaderRequest.setHeaderVersion("1.0");
		hubHeaderRequest.setWhat(what);
		hubHeaderRequest.setWhere(where);
		
		if(ApplicationLob.nb == lob) {
			
			//Where object 
			where.setOriginatorSessionId(requestId);			
			
			final Who who = new Who();
			who.setEmployeeUserId(userId);
			who.setEmployeeUserIdType(userType);
			who.setPartyAccessId(partyAccessId);
			who.setPartyAccessIdType(partyAccessType);
			who.setPartyId(partyId);
			who.setPartyIdType(partyIdType);
			who.setPartyMultiFactorAuthenticationIndicator(partyMultiFactorAuthenticationIndicator);
			who.setPartyRoleType(partyRoleType);
			hubHeaderRequest.setWho(who);
			
		} else if(ApplicationLob.il == lob  && StringUtils.isNotEmpty(partyId)   ){
			where.setOriginatorSessionId(originatorSessionId);
			
			final Who who = new Who();
		//	who.setEmployeeUserId(userId);
		//	who.setEmployeeUserIdType(userType);
			who.setPartyAccessId(partyAccessId);
			who.setPartyAccessIdType(partyAccessType);
			who.setPartyId(partyId);
			who.setPartyIdType(partyIdType);
			who.setPartyMultiFactorAuthenticationIndicator(partyMultiFactorAuthenticationIndicator);
			who.setPartyRoleType(partyRoleType);
			hubHeaderRequest.setWho(who);			
			
		}else if (ApplicationLob.il == lob){
			where.setOriginatorSessionId(originatorSessionId);
		}		
		
		return hubHeaderRequest;
	}
	
	public static class HeaderBuilder {

		private String workflowId;
		private String callPath = "PWOB";
		private String originatorResource;
		private String originatorResourceFunction;
		private String originatorChannel = "BRN";
		private String originatorLocationId = "99999999";
		private String originatorLocationType = "PCD";
		private String userId;
		private String userType = "AD";
		private String partyAccessId;
		private String partyAccessType = "ADID";
		private String partyId;
		private String partyIdType="ECIFID";
		private String partyMultiFactorAuthenticationIndicator = "N";
		private String partyRoleType="CUSTOMER";
		private String digitalSignature = "digitalSignature";
		// this is the banking web apps app cat id
		private String appCatId = "15255";
		private String requestId;
		
		private String packageId;
		private String documentId;
		private ApplicationLob lob;
		private String originatorSessionId;
		
		public HeaderBuilder originatorSessionId(String originatorSessionId){
			this.originatorSessionId = originatorSessionId;
			return this;
		}		
		
		public HeaderBuilder lob(final ApplicationLob lob) {
			this.lob = lob;
			return this;
		}
		
		public HeaderBuilder appCatId(final String appCatId) {
			this.appCatId = appCatId;
			return this;
		}

		public HeaderBuilder callPath(final String callPath) {
			this.callPath = callPath;
			return this;
		}

		public HeaderBuilder originatorResource(final String originatorResource) {
			this.originatorResource = originatorResource;
			return this;
		}

		public HeaderBuilder originatorResourceFunction(final String originatorResourceFunction) {
			this.originatorResourceFunction = originatorResourceFunction;
			return this;
		}

		public HeaderBuilder originatorChannel(final String originatorChannel) {
			this.originatorChannel = originatorChannel;
			return this;
		}

		public HeaderBuilder originatorLocationId(final String originatorLocationId) {
			this.originatorLocationId = originatorLocationId;
			return this;
		}

		public HeaderBuilder originatorLocationType(final String originatorLocationType) {
			this.originatorLocationType = originatorLocationType;
			return this;
		}

		public HeaderBuilder userId(final String userId) {
			this.userId = userId;
			return this;
		}

		public HeaderBuilder userType(final String userType) {
			this.userType = userType;
			return this;
		}

		public HeaderBuilder partyAccessId(final String partyAccessId) {
			this.partyAccessId = partyAccessId;
			return this;
		}

		public HeaderBuilder partyAccessType(final String partyAccessType) {
			this.partyAccessType = partyAccessType;
			return this;
		}

		public HeaderBuilder partyId(final String partyId) {
			this.partyId = partyId;
			return this;
		}

		public HeaderBuilder partyIdType(final String partyIdType) {
			this.partyIdType = partyIdType;
			return this;
		}

		public HeaderBuilder partyMultiFactorAuthenticationIndicator(
				final String partyMultiFactorAuthenticationIndicator) {
			this.partyMultiFactorAuthenticationIndicator = partyMultiFactorAuthenticationIndicator;
			return this;
		}

		public HeaderBuilder partyRoleType(final String partyRoleType) {
			this.partyRoleType = partyRoleType;
			return this;
		}

		public HeaderBuilder digitalSignature(final String digitalSignature) {
			this.digitalSignature = digitalSignature;
			return this;
		}

		public HUBHeaderRequest build() {
			final HubRequestHeaderBuilder hubRequestHeaderBuilder = new HubRequestHeaderBuilder(this);
			return hubRequestHeaderBuilder.build();
		}
		
		public HeaderBuilder requestId(final String requestId) {
			this.requestId = requestId;
			return this;
		}
		
		public HeaderBuilder workflowId(final String workflowId) {
			this.workflowId = workflowId;
			return this;
		}
		
		public HeaderBuilder packageId(final String packageId) {
			this.packageId = packageId;
			return this;
		}
		
		public HeaderBuilder documentId(final String documentId) {
			this.documentId = documentId;
			return this;
		}
	}
}
