package com.bmo.channel.pwob.model.onboarding;

import io.swagger.annotations.ApiModelProperty;

public class EsignPackageInfo {

	public EsignPackageInfo(String packageId, String signerId) {
		super();
		this.packageId = packageId;
		this.signerId = signerId;
	}
	
	@ApiModelProperty(example="cb46bfdd-a81d-47d3-b623-c6161a276840", value="package id of generated documents")
	private String packageId;
	
	@ApiModelProperty(example="8a8e5d25ecfdab4da949cbe4e6fe127c1101b413", value="signer id of document")
	private String signerId;
	
	public String getPackageId() {
		return packageId;
	}
	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}
	public String getSignerId() {
		return signerId;
	}
	public void setSignerId(String signerId) {
		this.signerId = signerId;
	}
	
	
}
