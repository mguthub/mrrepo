package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

import javax.validation.Valid;

import com.bmo.channel.pwob.validation.MultiApplicantsInvestmentExperienceKnowledge;
import com.sun.istack.NotNull;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author vkankan
 *
 */
@MultiApplicantsInvestmentExperienceKnowledge
public class MultiApplicantsInvestmentExperience {
	
	@Valid
	@NotNull
	private String invExpRefId;
	
	@ApiModelProperty(value="Joint Account applicant party ref ids")
	private List<String> partyRefIds;
	
	@Valid
	private InvestmentExperience multiApplicantInvestmentExperience = new InvestmentExperience();

	public String getInvExpRefId() {
		return invExpRefId;
	}

	public void setInvExpRefId(String invExpRefId) {
		this.invExpRefId = invExpRefId;
	}

	public InvestmentExperience getMultiApplicantInvestmentExperience() {
		return multiApplicantInvestmentExperience;
	}

	public void setMultiApplicantInvestmentExperience(InvestmentExperience multiApplicantInvestmentExperience) {
		this.multiApplicantInvestmentExperience = multiApplicantInvestmentExperience;
	}

	public List<String> getPartyRefIds() {
		return partyRefIds;
	}

	public void setPartyRefIds(List<String> partyRefIds) {
		this.partyRefIds = partyRefIds;
	}
	
}
