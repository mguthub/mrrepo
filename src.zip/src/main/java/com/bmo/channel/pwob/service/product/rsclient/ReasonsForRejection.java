package com.bmo.channel.pwob.service.product.rsclient;

import java.util.List;

public class ReasonsForRejection {
    protected List<Msg> msg;

    public List<Msg> getMsg() {
		return msg;
	}
	public void setMsg(List<Msg> msg) {
		this.msg = msg;
	}
}