package com.bmo.channel.pwob.convert;

import java.util.Date;

import javax.ws.rs.WebApplicationException;
import javax.xml.datatype.XMLGregorianCalendar;

import org.dozer.CustomConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.ILLaunchEndpoint;
import com.bmo.channel.pwob.util.DateUtils;
import com.fasterxml.jackson.databind.util.ISO8601Utils;

public class GregorianDateTimeConvertor implements CustomConverter{
	
	private static Logger logger = LoggerFactory.getLogger(GregorianDateTimeConvertor.class);
	
	@Override
	public Object convert(Object target, Object source, Class<?> targetClass,Class<?> sourceClass) {
		Date date=null;
		
		if (source == null) 
			return date;
		
		if (source instanceof java.lang.String) {
			String stringDate = (String) source;
			
			try {
				XMLGregorianCalendar xmlGregorianDate = DateUtils.getDateTimestamp(stringDate);
				return xmlGregorianDate;
	
			} catch (Exception ex) {
				logger.error("Failure in DateTime stamp conversion. ", ex);
				throw new WebApplicationException(ex);
			}
		}
		//client data to form
		else if (source instanceof XMLGregorianCalendar) {
			XMLGregorianCalendar sourceDate = (XMLGregorianCalendar) source;
			return ISO8601Utils.format(sourceDate.toGregorianCalendar().getTime(),true);
		}
	
		return null;
	}
}
