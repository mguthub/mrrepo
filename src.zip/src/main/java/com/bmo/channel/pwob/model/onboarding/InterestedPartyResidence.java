package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;


public class InterestedPartyResidence {
	
	@Valid
	private Address primaryAddress = new Address();


	public Address getPrimaryAddress() {
		return primaryAddress;
	}

	public void setPrimaryAddress(Address primaryResidentialAddress) {
		this.primaryAddress = primaryResidentialAddress;
	}


}
