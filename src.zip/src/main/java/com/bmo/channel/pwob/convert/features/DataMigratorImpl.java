package com.bmo.channel.pwob.convert.features;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.config.EnvironmentConfig;
import com.bmo.channel.pwob.convert.migration.ApplicationMigrator;
import com.bmo.channel.pwob.convert.migration.RelationshipSummaryMigrator;
import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;

@Component
public class DataMigratorImpl implements DataMigrator {
	@Autowired
	private EnvironmentConfig environmentConfig;

	@Autowired
	private List<ApplicationMigrator> applicationMigrators;

	@Autowired
	private List<RelationshipSummaryMigrator> relationshipSummaryMigrators;

	@Override
	public void migrateApplication(Application application) {
		if(application == null) {
			return;
		}

		for (ApplicationMigrator applicationMigrator : applicationMigrators) {
			FeatureFlags systemFeatureFlags = environmentConfig.getFeatureFlags();
			if(applicationMigrator.isMigrationRequired(application, systemFeatureFlags)) {
				applicationMigrator.migrateApplication(application, systemFeatureFlags);
				if(applicationMigrator.isMigrationRequired(application, systemFeatureFlags)) {
					// migrator has a bug, because migration should not be required after it runs
					throw new WebServiceException(
							String.format("Migrator %s has not correctly migrated workflow %s", 
									applicationMigrator.getClass().getSimpleName(), 
									application.getApplicationId()));
				}
			}
		}
	}

	void setApplicationMigrators(List<ApplicationMigrator> applicationMigrators) {
		this.applicationMigrators = applicationMigrators;
	}
	void setRelationshipSummaryMigrators(List<RelationshipSummaryMigrator> relationshipSummaryMigrators) {
		this.relationshipSummaryMigrators = relationshipSummaryMigrators;
	}

	@Override
	public void migrationRelationshipSummary(RelationshipSummary relationshipSummary, Application application) {
		if(relationshipSummary == null) {
			return;
		}

		if(CollectionUtils.isNotEmpty(relationshipSummaryMigrators)) {
			for (RelationshipSummaryMigrator migrator : relationshipSummaryMigrators) {
				FeatureFlags systemFeatureFlags = environmentConfig.getFeatureFlags();
				if(migrator.isMigrationRequired(relationshipSummary, systemFeatureFlags, application)) {
					migrator.migrateRelationshipSummary(relationshipSummary, systemFeatureFlags, application);
					if(migrator.isMigrationRequired(relationshipSummary, systemFeatureFlags, application)) {
						// migrator has a bug, because migration should not be required after it runs
						throw new WebServiceException(
								String.format("Migrator %s has not correctly migrated workflow %s", 
										migrator.getClass().getSimpleName(), 
										application.getApplicationId()));
					}
				}
			}
		}
	}
}
