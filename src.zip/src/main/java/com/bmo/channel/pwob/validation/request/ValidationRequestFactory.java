package com.bmo.channel.pwob.validation.request;

import javax.validation.ConstraintValidatorContext;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactoryImpl.ValidationRequestBuilder;

public interface ValidationRequestFactory {

	ValidationRequestBuilder createBuilder(ConstraintValidatorContext context, ApplicationLob applicationLob);
	ValidationRequest create(ConstraintValidatorContext context, ApplicationLob applicationLob);

}
