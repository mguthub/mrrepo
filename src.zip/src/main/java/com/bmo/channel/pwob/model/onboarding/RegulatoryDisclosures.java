package com.bmo.channel.pwob.model.onboarding;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;


public class RegulatoryDisclosures {

	public RegulatoryDisclosures() {
		this.reportingInsiderRelationships = new ArrayList<>();
		this.significantShareholdings = new ArrayList<>();
		this.insiderRelationships = new ArrayList<>();				
		this.controlRelationships = new ArrayList<>();
	}

	private Boolean iirocMember;

	@ApiModelProperty(example="PEAK Securities Inc.", value="Only populate if irrocMember is true, valid values can be found in the reference service")
	@ReferenceData(type = ReferenceType.IIROC_ORGANIZATIONS, code = ErrorCodes.INVALID_IIROC_ORGANIZATIONS)
	private String iirocOrganization;

	private Boolean haveInsiderRelationship;

	@ApiModelProperty(value="Only populate if haveInsiderRelationship is true")
	@Valid
	private List<Relationship> insiderRelationships = new ArrayList<>();
	
	@ApiModelProperty(value="Only populate if controlRelationship is true")
	@Valid
	private List<Relationship> controlRelationships;		

	private Boolean isReportingInsider;

	@ApiModelProperty(value="Only populate if reportingInsiderRelationship is true")
	@Valid
	private List<Relationship> reportingInsiderRelationships = new ArrayList<>();

	private Boolean significantShareholder;

	@ApiModelProperty(value="Only populate if significantShareholdings is true")
	@Valid
	private List<Relationship> significantShareholdings = new ArrayList<>();
	
	@Valid
	private Verification verification = new Verification();
	
	private Boolean controlRelationship;

	private Boolean isPoliticallyExposedPerson;
	
	@ReferenceData(type = ReferenceType.POLITICALLY_EXPOSED_PERSON_TYPE, code = ErrorCodes.INVALID_POLITICALLY_EXPOSED_TYPE)
	private String politicallyExposedPersonType;
	
	private String politicallyExposedPersonPosition;
	
	public Boolean getIirocMember() {
		return iirocMember;
	}
	public void setIirocMember(Boolean iirocMember) {
		this.iirocMember = iirocMember;
	}
	public String getIirocOrganization() {
		return iirocOrganization;
	}
	public void setIirocOrganization(String iirocOrganization) {
		this.iirocOrganization = iirocOrganization;
	}
	public Boolean getHaveInsiderRelationship() {
		return haveInsiderRelationship;
	}
	public void setHaveInsiderRelationship(Boolean haveInsiderRelationship) {
		this.haveInsiderRelationship = haveInsiderRelationship;
	}
	public List<Relationship> getInsiderRelationships() {
		return insiderRelationships;
	}
	public void setInsiderRelationships(List<Relationship> insiderRelationships) {
		this.insiderRelationships = insiderRelationships;
	}
	public Boolean getIsReportingInsider() {
		return isReportingInsider;
	}
	public void setIsReportingInsider(Boolean isReportingInsider) {
		this.isReportingInsider = isReportingInsider;
	}
	public List<Relationship> getReportingInsiderRelationships() {
		return reportingInsiderRelationships;
	}
	public void setReportingInsiderRelationships(List<Relationship> reportingInsiderRelationships) {
		this.reportingInsiderRelationships = reportingInsiderRelationships;
	}
	public Boolean getSignificantShareholder() {
		return significantShareholder;
	}
	public void setSignificantShareholder(Boolean significantShareholder) {
		this.significantShareholder = significantShareholder;
	}

	public List<Relationship> getSignificantShareholdings() {
		return significantShareholdings;
	}

	public void setSignificantShareholdings(List<Relationship> significantShareholdings) {
		this.significantShareholdings = significantShareholdings;
	}
	public List<Relationship> getControlRelationships() {
		return controlRelationships;
	}
	public void setControlRelationships(List<Relationship> controlRelationships) {
		this.controlRelationships = controlRelationships;
	}		
	public Boolean getControlRelationship(){
		return controlRelationship;
	}
	public void setControlRelationship(Boolean controlRelationship){
		this.controlRelationship=controlRelationship;
	}
	public Verification getVerification() {
		return verification;
	}
	public void setVerification(Verification verification) {
		this.verification = verification;
	}
	public Boolean getIsPoliticallyExposedPerson() {
		return isPoliticallyExposedPerson;
	}
	public void setIsPoliticallyExposedPerson(Boolean isPoliticallyExposedPerson) {
		this.isPoliticallyExposedPerson = isPoliticallyExposedPerson;
	}
	public String getPoliticallyExposedPersonType() {
		return politicallyExposedPersonType;
	}
	public void setPoliticallyExposedPersonType(String politicallyExposedPersonType) {
		this.politicallyExposedPersonType = politicallyExposedPersonType;
	}
	public String getPoliticallyExposedPersonPosition() {
		return politicallyExposedPersonPosition;
	}
	public void setPoliticallyExposedPersonPosition(String politicallyExposedPersonPosition) {
		this.politicallyExposedPersonPosition = politicallyExposedPersonPosition;
	}
	
}
