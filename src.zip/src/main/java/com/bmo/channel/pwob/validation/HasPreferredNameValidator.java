package com.bmo.channel.pwob.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Name;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

/**
 * Validates that if user has indicated they have a preferred name that it is provided.
 * @author Ryan Chambers (rcham02)
 */
public class HasPreferredNameValidator implements ConstraintValidator<HasPreferredName, Identity>  {
	private static final String FIRST_NAME_FIELD_NAME = "firstName";
	private static final String LAST_NAME_FIELD_NAME = "lastName";
	private static final String PREFERRED_NAME_FIELD_NODE = "preferredName";
	private static final String PREFERRED_LANGUAGE = "preferredLanguage";

	@Autowired ValidationRequestFactory validationRequestFactory;

	@Autowired
	private NameValidator nameValidator;

	@Autowired	
	private UsersService userService;

	@Override
	public void initialize(HasPreferredName constraint) {
		// none required
	}

	@Override
	public boolean isValid(Identity identity, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(identity == null || validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		// skip if no preferred name
		Boolean hasPreferredName = identity.getHasPreferredName();
		if(hasPreferredName == null || !hasPreferredName) {
			return true;
		}

		boolean valid = true;

		Name preferredName = identity.getPreferredName();

		ValidationRequest prefNameValReq = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).withChildPropertyNode(PREFERRED_NAME_FIELD_NODE).build();

		if(preferredName == null) {
			prefNameValReq.addConstraintViolation(FIRST_NAME_FIELD_NAME, ErrorCodes.INVALID_FIRST_NAME);
			prefNameValReq.addConstraintViolation(LAST_NAME_FIELD_NAME, ErrorCodes.INVALID_LAST_NAME);

			valid = false;
		} else {
			valid = nameValidator.validateFirstName(preferredName, prefNameValReq) && valid;
			valid = nameValidator.validateLastName(preferredName, prefNameValReq) && valid;
			valid = nameValidator.validateTitle(preferredName, prefNameValReq) && valid;				
		}

		// Validate preferred Language
		// why is this validation in this class?
		if(StringUtils.isBlank(identity.getPreferredLanguage())) {
			ValidationRequest validationRequest = validationRequestFactory.create(context, userService.currentUser().getLob());
			validationRequest.addConstraintViolation(PREFERRED_LANGUAGE, ErrorCodes.INVALID_PREFERRED_LANGUAGE);
			valid = false;
		}

		return valid;
	}
}
