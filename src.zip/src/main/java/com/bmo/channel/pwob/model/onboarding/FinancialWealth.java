package com.bmo.channel.pwob.model.onboarding;

import java.util.ArrayList;
import java.util.List;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.bmo.channel.pwob.validation.reference.ReferenceListData;

import io.swagger.annotations.ApiModelProperty;


public class FinancialWealth {

	@ApiModelProperty(example="['5', '6']", value="Accepts values from 1-6, see reference service for more information")
	@ReferenceListData(type = ReferenceType.WEALTH_SOURCES, code = ErrorCodes.INVALID_SRC_WEALTH)
	private List<String> sourcesOfWealth = new ArrayList<>();

	@DataValidationPattern(code = ErrorCodes.INVALID_OTHER_SOURCE_WEALTH)
	private String otherSourceOfWealth;

	@DataValidationPattern(code = ErrorCodes.INVALID_OTHER_INVESTMENT_INSTITUTION)
	private String otherInvestmentInstitution;

	private Boolean hasOtherInvestmentAccounts;

	private Boolean isBorrowingToInvest;

	public List<String> getSourcesOfWealth() {
		return sourcesOfWealth;
	}
	public void setSourcesOfWealth(List<String> sourcesOfWealth) {
		this.sourcesOfWealth = sourcesOfWealth;
	}

	public Boolean getHasOtherInvestmentAccounts() {
		return hasOtherInvestmentAccounts;
	}
	public void setHasOtherInvestmentAccounts(Boolean hasOtherInvestmentAccounts) {
		this.hasOtherInvestmentAccounts = hasOtherInvestmentAccounts;
	}

	public String getOtherInvestmentInstitution() {
		return otherInvestmentInstitution;
	}

	public void setOtherInvestmentInstitution(String otherInvestmentInstitution) {
		this.otherInvestmentInstitution = otherInvestmentInstitution;
	}

	public Boolean getIsBorrowingToInvest() {
		return isBorrowingToInvest;
	}

	public void setIsBorrowingToInvest(Boolean isBorrowingToInvest) {
		this.isBorrowingToInvest = isBorrowingToInvest;
	}

	public String getOtherSourceOfWealth() {
		return otherSourceOfWealth;
	}

	public void setOtherSourceOfWealth(String otherSourceOfWealth) {
		this.otherSourceOfWealth = otherSourceOfWealth;
	}
}
