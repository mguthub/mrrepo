package com.bmo.channel.pwob.service.workflow;

import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.NextStepsData;
import com.bmo.channel.pwob.model.onboarding.Party;

import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.Metadata;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationResponse;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.ApplicationData;

public interface WorkflowService {
	Application saveApplication(NewWorkflowRequest request);
	
	/**
	 * @param application An {@link Application} to be updated.
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service">Workflow Service Confluence Documentation</a>
	 */
	Application updateApplication(Application request);

	Application retrieveApplication(String workflowId);	

	/**
	 * Retrieves an application from Onboard Application service.
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-RetrieveExistingApplication">Workflow Service Confluence Documentation</a>
	 */
	RetrieveApplicationResponse retrieveApplicationResponse(String applicationId, String ecifId);

	void delete(String applicationId);	

	void validate(Application application);

	Application deriveWorkflow(final RetrieveApplicationResponse response, String appStatus);

	Application removePartyFromApplication(String applicationId, String partyRefId);

	void storeUpdatedApplication(Application updatedApplication, ApplicationData originalApplicationData, String applicationId,RetrieveApplicationResponse.Body body);			
	ApplicationData mergeApplicationWithExistingApplicationData(Application updatedApplication,	ApplicationData originalApplicationData);

	/**
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-PrepareWSSmetadata">Workflow Service Confluence Documentation</a>
	 */
	Metadata prepareMetaData(Application application, String requestorId);

	Application addJointApplicantToApplication(String applicationID,Party party);

	Application removeAccountFromApplication(String applicationId, String accountRefId);
	
	Application createBilApplication(Application request);

	NextStepsData retrieveNextStepsData(String workflowId);

	Application updateBilApplication(Application application, String user, String wcid);

}
