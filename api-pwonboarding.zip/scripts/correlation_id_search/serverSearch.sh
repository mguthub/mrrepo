cd /opt/IBM/WebSphere/Liberty/usr/servers/$2/logs
tac channel-services-messages.log | awk '/\-\-\-\-\-\", \"corrID\":\"'"$1"'\"/,/ID:/' | tac