/**
 * @author akhales
 */

package com.bmo.channel.pwob.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeConstants;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.WebServiceException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bmo.channel.core.util.DateUtil;
import com.fasterxml.jackson.databind.util.ISO8601DateFormat;

public class DateUtils {
	
	private static Logger logger = LoggerFactory.getLogger(DateUtils.class);
	
	private static final String YYYY_MM_DD_T_HH_MM_SS_SSS = "yyyy-MM-dd'T'HH:mm:ss.SSS";
	private static final String YYYY_MM_DD_T_HH_MM_SSXXX = "yyyy-MM-dd'T'HH:mm:ssXXX";	                                                         
	private static final String YYYY_MM_DD_HH_MM_SS_SSS = "yyyy-MM-dd HH:mm:ss.SSS";

	public static String convertDateToString(final Date date) {
		if (date == null) {
			return null;
		}

		final SimpleDateFormat df = new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS_SSS);
		return df.format(date);
	}

	public static String convertDateToStringWithTimezone(final Date date) {
		if (date == null) {
			return null;
		}

		final SimpleDateFormat df = new SimpleDateFormat(YYYY_MM_DD_T_HH_MM_SS_SSS);
		return df.format(date);
	}

	public static Date convertStringToDateTime(String st, String format) {
		if (StringUtils.isEmpty(st)) {
			return null;
		}

		SimpleDateFormat df = new SimpleDateFormat(format);
		df.setLenient(false);

		try {
			return df.parse(st);
		} catch (ParseException ex) {
			logger.error("Failure in date time conversion: ",st, ex);
			throw new WebServiceException(ex);
		}
	}

	public static Date convertStringToDateTimeNoTimezone(String st) {
		if (StringUtils.isEmpty(st)) 
			return null;

		SimpleDateFormat df = new SimpleDateFormat(YYYY_MM_DD_T_HH_MM_SSXXX);
		df.setLenient(false);
		
		try{
			return df.parse(st);
		}catch(Exception ex){
			logger.error("Failure in date time noTimeZone conversion: :",st, ex);
			throw new WebServiceException(ex);
		}
	}

	public static XMLGregorianCalendar getXMLGregorianDate(String st) {

		if (StringUtils.isEmpty(st)) 
			return null;

		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		df.setLenient(false);

		Date date;
		try {
			date = df.parse(st);
			return  DateUtil.getXmlGregorianCalendarDate(date);
		} catch (ParseException ex) {
			logger.error("Failure in Gregorian date time conversion: ",st, ex);
			throw new WebServiceException(ex);
		}
	}
	
	public static XMLGregorianCalendar getTimestamp(){
		try {
			GregorianCalendar gcal = new GregorianCalendar();
			gcal.setTime(new Date());
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
		} catch (DatatypeConfigurationException ex) {
			logger.error("Failure in Gregorian time stamp conversion: ", ex);
			throw new WebServiceException(ex);
		}
	}

	public static XMLGregorianCalendar getDateTimestamp(String isoDate) {
		try {
			Date date = new ISO8601DateFormat().parse(isoDate);
			GregorianCalendar gcal = new GregorianCalendar();
			gcal.setTime(date);
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(gcal);
		} catch (DatatypeConfigurationException | ParseException ex) {
			logger.error("Failure in Gregorian dateTime stamp conversion: ",isoDate, ex);
			throw new WebServiceException(ex);
		}
	}

	public static String getXmlGregorianCalendarAsString() {
		return getTimestamp().toString();
	}

	public static String getXmlGregorianCalendarAsString(XMLGregorianCalendar gcal) {
		if(gcal!=null)
			return convertDateToStringWithTimezone(gcal.toGregorianCalendar().getTime());
		else
			return null;
	}

	public static String convertToDefaultDatePattern(String date,String pattern) throws ParseException{
		SimpleDateFormat df =  new SimpleDateFormat(pattern);
		return df.format(df.parse(date));
	}
	/**
	 * isBefore - Parameters beforeDate, afterDate 
	 * true - beforeDate should be the previous dates from afterDate
	 * 		- Date Parse exception also returns true 
	 * false- beforeDate is not one of the previous dates from afterDate
	 */
	
	public static boolean isBefore(String beforeDate, String afterDate,String pattern) throws DateTimeParseException,ParseException{
		return LocalDate.parse(convertToDefaultDatePattern(afterDate,pattern)).isBefore(LocalDate.parse(convertToDefaultDatePattern(beforeDate,pattern)));
	}
	
	/**
	 * isBetween - Checks if the date fall in a given date range.
	 * true - If date falls in the range between start date and end date.
	 * false- If date falls outside the range between start date and end date.
	 */
	public static boolean isBetween(XMLGregorianCalendar date, XMLGregorianCalendar start, XMLGregorianCalendar end) {
		return (date.compare(start) == DatatypeConstants.GREATER || date.compare(start) == DatatypeConstants.EQUAL)
				&& (date.compare(end) == DatatypeConstants.LESSER || date.compare(end) == DatatypeConstants.EQUAL);
	}
}
