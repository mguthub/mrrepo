/**
 * 
 */
package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.service.digitaltoken.DigitalTokenPayload;
import com.bmo.channel.pwob.service.digitaltoken.DigitalTokenService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author vvallia
 *
 */
@Produces({MediaType.APPLICATION_XML + ";charset=utf-8"})
@Api(DigitalTokensEndpoint.V1_PATH)
@Path(DigitalTokensEndpoint.V1_PATH)
public class DigitalTokensEndpoint {

	@SuppressWarnings("unused")
	private Logger logger = LoggerFactory.getLogger(DigitalTokensEndpoint.class);
	
	public static final String V1_PATH = "v1/digital_tokens";
	
	@Autowired
	private DigitalTokenService digitalTokenService;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{cachedToken}")
	 @ApiOperation(value="Validate cached token to retieve the OLAP payload ")
		@ApiImplicitParams({
			@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
			@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	    @ApiResponses(value={
	    		@ApiResponse(code=404, message="OLAP Payload Not found"),
	            @ApiResponse(code=500, message="Internal server error")})
	public Response retrieve(@PathParam("cachedToken") String cachedToken) {
		DigitalTokenPayload payload = new DigitalTokenPayload();
		
		String response =digitalTokenService.validateToken(cachedToken);
		if (response!=null) {
			payload.setPayload(response); 
			return Response.ok(payload).build();
		}
		else { 
		     return Response.status(Status.NOT_FOUND).build();
		}
	}

}
