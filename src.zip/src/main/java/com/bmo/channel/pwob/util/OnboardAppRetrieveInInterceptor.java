package com.bmo.channel.pwob.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * This interceptor is added to the OnboardApplication retrieveApplication() process in order to handle invalid xml issues.
 * The SOAP response object is generated with un-escaped XML characters from HUB and failed while de-serializing on channel side.
 * The InInterceptor convert the invalid SOAP message into valid message object before de-serializing to Java object.
 * @author snagamo
 *
 */
public class OnboardAppRetrieveInInterceptor extends AbstractPhaseInterceptor<Message> {
	
	private static Logger logger = LoggerFactory.getLogger(OnboardAppRetrieveInInterceptor.class); 
	
    public OnboardAppRetrieveInInterceptor() {
        super(Phase.RECEIVE);
    }

    @Override
    public void handleMessage(Message message) {
        message.put(Message.ENCODING, "UTF-8");
        InputStream is = message.getContent(InputStream.class);

        if (is != null) {
            CachedOutputStream cos = new CachedOutputStream();
            try {
                IOUtils.copy(is, cos);
                String soapMessage = new String(cos.getBytes());
                cos.flush();
                cos.close();
                is.close();

                logger.debug("Soap message : "+soapMessage);

                // unescape the xml elements
                String newSoapMessage = StringEscapeUtils.unescapeXml(soapMessage);                

                InputStream newIs = new ByteArrayInputStream(newSoapMessage.getBytes());

                message.setContent(InputStream.class, newIs);

                logger.debug("New soap message : "+newSoapMessage);
            } catch (Exception ioe) {
            	logger.error("There was an error handling SOAP message: ", ioe);
            }
        }
    }
}