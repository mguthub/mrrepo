/**
 * @author Sasi Nagamony (snagamo)
 */
package com.bmo.channel.pwob.model.onboarding;

public class TradingAuthority {

	private Boolean isSpouseLiveInSameAddress;

	public Boolean getIsSpouseLiveInSameAddress() {
		return isSpouseLiveInSameAddress;
	}
	public void setIsSpouseLiveInSameAddress(Boolean isSpouseLiveInSameAddress) {
		this.isSpouseLiveInSameAddress = isSpouseLiveInSameAddress;
	}
}
