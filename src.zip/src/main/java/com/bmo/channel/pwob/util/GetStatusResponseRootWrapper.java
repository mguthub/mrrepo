package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class GetStatusResponseRootWrapper {

    public GetStatusResponseWrapper getGetStatusResponse() {
        return getStatusResponse;
    }

    public void setGetStatusResponse(GetStatusResponseWrapper getStatusResponse) {
        this.getStatusResponse = getStatusResponse;
    }

    @JsonProperty("root")
    @JsonDeserialize(using = GetStatusResponseDeserializer.class)
    GetStatusResponseWrapper getStatusResponse;

}

