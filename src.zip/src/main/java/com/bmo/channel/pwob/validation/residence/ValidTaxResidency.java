package com.bmo.channel.pwob.validation.residence;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

@Documented
@Constraint(validatedBy = TaxResidencyValidator.class)
@Target({ TYPE })
@Retention(RUNTIME)
public @interface ValidTaxResidency {
	String message() default "{generic}";
	Class<?>[] groups() default {};
	Class<? extends Payload>[] payload() default {};
}
