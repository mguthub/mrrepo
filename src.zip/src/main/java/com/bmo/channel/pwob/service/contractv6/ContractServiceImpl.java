package com.bmo.channel.pwob.service.contractv6;

import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.accounts.AccountDetailsResponse;
import com.bmo.accounts.AccountDetailsResponse.IndividualPartyList;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.onboarding.PartyTypeEnum;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.client.model.ContractInquiry;
import io.swagger.client.model.ContractPartyRole;
import io.swagger.client.model.ECIFContractResolver;
import io.swagger.client.model.GetAllContractPartyRolesRequest;
import io.swagger.client.model.GetAllContractPartyRolesResponse;
import io.swagger.client.model.PartyIdentification;
import io.swagger.client.model.Person;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

@Service
public class ContractServiceImpl implements ContractService {
	private static Logger logger = LoggerFactory.getLogger(ContractServiceImpl.class);
	public static final String CLIENT_GROUP_IDENTIFIER = "100051";
	public static final String ECIF_IDENTIFIER = "100058";
	
	@Autowired
	ContractV6EndpointInterface contractV6EndpointInterface;
	
	@Autowired
	private HubRequestComponent hubRequestComponent;

	@Override
	public String retrieveEcifId(AccountDetailsResponse risModel) {
		try {
			GetAllContractPartyRolesResponse response = contractV6EndpointInterface.getContractDetails(createContractRequest(risModel), generateHeaderString(createHeader()));
			return deteremineEcifId(response, risModel);
		} catch (JsonProcessingException e) {
			throw new WebServiceException(e);
		}
	}
	
	public String deteremineEcifId(GetAllContractPartyRolesResponse response, AccountDetailsResponse risModel) {
		
		String ecif = "";
		try {
			if (Optional.ofNullable(risModel).map(AccountDetailsResponse::getIndividualPartyList)
					.map(IndividualPartyList::getIndividualParty).isPresent()) {

				// get reference party ID from RIS
				String partyId = risModel.getIndividualPartyList().getIndividualParty().stream()
						.filter(p -> p.getPartyType().equals(PartyTypeEnum.PRIMARY_APPLICANT)).findFirst().get()
						.getPartyId();			
									
				// PartyId present in RIS, check it's presence in Contract response
				if(StringUtils.isNotBlank(partyId) && Optional.ofNullable(response).isPresent() && CollectionUtils.isNotEmpty(response.getContractPartyRole())){
					Optional<ContractPartyRole> contRole = response.getContractPartyRole().stream().filter(party ->
						Optional.ofNullable(party).map(ContractPartyRole::getPerson).map(Person::getPartyIdentification).get().stream().filter(identification -> 
							CLIENT_GROUP_IDENTIFIER.equals(identification.getIdentificationType()) && partyId.equals(identification.getIdentificationNumber())).findFirst().isPresent()).findFirst();
					if(contRole.isPresent()) {
						Optional<String> ecifId = contRole.get().getPerson().getPartyIdentification().stream().filter(identity -> ECIF_IDENTIFIER.equals(identity.getIdentificationType())).map(PartyIdentification::getIdentificationNumber).findFirst();
						if(ecifId.isPresent()) {
							ecif = ecifId.get();
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("Failure to retreive ecifId: ",e);
			ecif = "";
		}
		return ecif;
	}
	
	private GetAllContractPartyRolesRequest createContractRequest(AccountDetailsResponse risModel) {
		GetAllContractPartyRolesRequest request = new GetAllContractPartyRolesRequest();
		ContractInquiry inquiry = new ContractInquiry();
		inquiry.setPartyInquiryLevel("1");
		inquiry.setFilter("ACTIVE"); 
		inquiry.setEcIFContractResolver(new ECIFContractResolver());		
		inquiry.getEcIFContractResolver().setAdminContractId(risModel.getAccountId());
		// PCD adminSystemID: 100010
		inquiry.getEcIFContractResolver().setAdminSystemType("100010");		
		request.setContractInquiry(inquiry);
		return request;
	}
	
	private HUBHeaderRequest createHeader() {
		return hubRequestComponent
				.getHubBuilder()
				.originatorResource("Contract")
				.originatorResourceFunction("GetAllContractPartyRoles")
				.build();
	}
	
	String generateHeaderString(final HUBHeaderRequest requestHeader) throws JsonProcessingException {
		return ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
	}
}
