package com.bmo.channel.pwob.security;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bmo.channel.pwob.user.UserContextImpl;

public class AuthorisationFilter implements Filter {
	
	private Logger logger = LoggerFactory.getLogger(AuthorisationFilter.class);

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
			throws IOException, ServletException {
		if(request instanceof HttpServletRequest) {
			HttpServletRequest servletRequest = (HttpServletRequest) request;
			HttpServletResponse servletResponse = (HttpServletResponse) response;
			
			//add condition to check for PCD/BIL headers presence
			if((StringUtils.isNotBlank(servletRequest.getHeader(UserContextImpl.X_BMO_BUSINESS_CATEGORY)) && StringUtils.isNotBlank(servletRequest.getHeader(UserContextImpl.IV_USER_HEADER)))
					|| (StringUtils.isNotBlank(servletRequest.getHeader(UserContextImpl.IV_GROUPS_HEADER)) && StringUtils.isNotBlank(servletRequest.getHeader(UserContextImpl.IV_USER_HEADER)))){

				chain.doFilter(request, response);				
			}else{
				logger.error("Missing header");
				servletResponse.setStatus(Response.Status.UNAUTHORIZED.getStatusCode());
			}		
				
		} else {
			// need to do something here?
		}
	}
	
	@Override
	public void destroy() {
	}
}
