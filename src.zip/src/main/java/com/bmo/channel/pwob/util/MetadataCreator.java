package com.bmo.channel.pwob.util;

import java.util.Date;

public class MetadataCreator {
	public static String createMetadata(final String documentPackageId, final String userId, final String category) {
		final Date date = new Date();
		final StringBuilder result = new StringBuilder();
		result.append("<?xml version=\"1.0\"?>");
		result.append("<values>");
		result.append("<CaptureMethod>EMPLOYEE UPLOADED</CaptureMethod>");
		result.append("<Category><![CDATA[" + category + "]]></Category>");
		result.append("<ScanCaptureUserID><![CDATA[" + userId + "]]></ScanCaptureUserID>");
		result.append("<ScanCaptureDate><![CDATA[" + DateUtils.convertDateToString(date) + "]]></ScanCaptureDate>");
		result.append("<SignatureStatus><![CDATA[SIGNED]]></SignatureStatus>");
		result.append("<DocumentPackageID><![CDATA[" + documentPackageId + "]]></DocumentPackageID>");
		result.append("</values>");
		return result.toString();
	}
}
