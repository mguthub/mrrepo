package com.bmo.channel.pwob.service.reference.mapping;

import java.util.List;
import java.util.stream.Collectors;

import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.model.DataAndMapping;

public class CodeAndValueMapper extends AbstractBaseReferenceMapper {

	public CodeAndValueMapper(){}
	
	@Override
	public List<Reference> mapToReferenceListEN(DataAndMapping dataAndMapping) {
		return dataAndMapping.getReferenceData().stream().map(v -> toReference(v)).collect(Collectors.toList());
	}
	
	@Override
	public List<Reference> mapToReferenceListFR(DataAndMapping dataAndMapping) {
		return dataAndMapping.getReferenceData().stream().map(v -> toReferenceFR(v)).collect(Collectors.toList());
		
	}

}
