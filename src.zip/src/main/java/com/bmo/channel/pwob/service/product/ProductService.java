package com.bmo.channel.pwob.service.product;

import java.util.List;

import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.product.BilProducts;
import com.bmo.channel.pwob.model.product.IaProduct;
import com.bmo.channel.pwob.model.product.Products;

public interface ProductService {
	Products determineProductEligibilities(Application application);
	Products determineProductEligibilities(String applicationId, Party party);
	List<IaProduct> populateFeeCodeList(Application application);
	boolean isEligibleForProduct(String applicationId, String dateOfBirth, String provinceOfResidence, String accountType);
	BilProducts getEligibleBilProducts();
}
