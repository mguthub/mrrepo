package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.annotation.JsonProperty;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Workflow;

import javax.xml.bind.annotation.*;
import java.util.ArrayList;
import java.util.List;


public class GetStatusResponseWrapper {

    @JsonProperty("Body")
    protected GetStatusResponseWrapper.Body body;
    

	/**
     * Gets the value of the body property.
     *
     * @return
     *     possible object is
     *     {@link GetStatusResponseWrapper.Body }
     *
     */
    public GetStatusResponseWrapper.Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     *
     * @param value
     *     allowed object is
     *     {@link GetStatusResponseWrapper.Body }
     *
     */
    public void setBody(GetStatusResponseWrapper.Body value) {
        this.body = value;
    }

    public static class Body {
    	
    	protected List<GetStatusResponseWrapper.Body> bodyList = new ArrayList<>();
        
        public List<GetStatusResponseWrapper.Body> getBodyList() {
    		return bodyList;
    	}

    	public void setBodyList(List<GetStatusResponseWrapper.Body> bodyList) {
    		this.bodyList = bodyList;
    	}

        protected Body.Workflows workflows;
        protected String count;
        protected String moreRecordsExist;
        
        

        /**
         * Gets the value of the workflows property.
         *
         * @return
         *     possible object is
         *     {@link Body.Workflows }
         *
         */
        public Body.Workflows getWorkflows() {
            return workflows;
        }

        /**
         * Sets the value of the workflows property.
         *
         * @param value
         *     allowed object is
         *     {@link Body.Workflows }
         *
         */
        public void setWorkflows(Body.Workflows value) {
            this.workflows = value;
        }

        /**
         * Gets the value of the count property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getCount() {
            return count;
        }

        /**
         * Sets the value of the count property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setCount(String value) {
            this.count = value;
        }

        /**
         * Gets the value of the moreRecordsExist property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getMoreRecordsExist() {
            return moreRecordsExist;
        }

        /**
         * Sets the value of the moreRecordsExist property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setMoreRecordsExist(String value) {
            this.moreRecordsExist = value;
        }


        public static class Workflows {

            @XmlElement(required = true)
            protected List<Workflow> workflow;

            /**
             * Gets the value of the workflow property.
             *
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the workflow property.
             *
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getWorkflow().add(newItem);
             * </pre>
             *
             *
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link Workflow }
             *
             *
             */
            public List<Workflow> getWorkflow() {
                if (workflow == null) {
                    workflow = new ArrayList<Workflow>();
                }
                return this.workflow;
            }

        }

    }

}
