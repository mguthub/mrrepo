/**
 * @author akhales
 */
package com.bmo.channel.pwob.validation.account;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.EftDetails;
import com.bmo.channel.pwob.model.onboarding.LiraAccountDetails;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.RifPaymentDetails;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactoryImpl.ValidationRequestBuilder;

public class RifAccountValidator extends AbstractBaseValidator implements ConstraintValidator<ValidRifAccount, Account> {
	private static Logger logger = LoggerFactory.getLogger(RifAccountValidator.class);
	public static final String RIF_TYPE = Account.RIF_TYPE;
	public static final String IS_SPOUSAL_RIF = "isSpousalRif";
	public static final String MIN_PAYMENT_AMOUNT_TYPE = "1";
	public static final String GREATER_THAN_MIN_PAYMENT_AMOUNT_TYPE = "2";
	public static final String GREATER_THAN_MIN_AMOUNT_MOUNT_TYPE_FIELD = "greaterThanMinimumAmountType";
	public static final String AMOUNT_TYPE = "amountType";
	public static final String AMOUNT = "amount";
	public static final String RIF_PAYMENT_DETAILS = "rifPayment";
	public static final String OUTBOUND_EFT_DETAILS = "outboundEftDetails";
	public static final String AMOUNT_PATTERN = "^[" + GENERIC_NUMERIC_PATTERN + "]{1,8}$";
	public static final String RIF_WITH_HOLDING_TAX_FEDERAL = "1";
	public static final String RIF_WITH_HOLDING_TAX_QUEBEC = "2";
	public static final String RIF_WITH_HOLDING_TAX_FLAT = "3";

	public static final String NONREG_ACC_SEL_TYPE_EXT_ACC = "1";
	public static final String NONREG_ACC_SEL_TYPE_ACC_ON_APP= "2";

	public static final String GROSS_AMOUNT = "1";
	public static final String NET_AMOUNT = "2";

	private static final String SPOUSE_AGE_USED_FIELD_NAME = "isSpouseAgeUsed";

	public static final String ACCOUNT_NUM_PATTERN = "^[" + GENERIC_NUMERIC_PATTERN + "]{1,15}$";	
	//public static final String ACCOUNT_NUM_NONREG_PATTERN = "^[A-Za-z0-9 ]{0,30}$";
	public static final String ACCOUNT_NUM_NONREG_PATTERN ="^[\\p{IsLatin}\\s-0-9_ +!#$*()=,<.>;:&/ ]{0,30}$";       
	
	public static final String TAX_AMOUNT_PATTERN = "^[" + GENERIC_NUMERIC_PATTERN + "]{1,7}$";

	public static final String ACCOUNT_OWNER_PATTERN = "^[\\.\\'\\-\\d\\s \\p{IsLatin}]{2,20}$";
	public static final String VERIFIED_BY_FIRST_NAME = "spouseElectionVerifiedByFirstName";
	public static final String VERIFIED_BY_LAST_NAME = "spouseElectionVerifiedByLastName";
	public static final String DATE_VERIFIED = "spouseElectionVerifiedDate";
	public static final String CONTRIBUTOR_FIELD_NAME = "contributor";
	
	public static final String WITH_HOLDING_TAX_PERCENTAGE_PATTERN = "^[" + GENERIC_NUMERIC_PATTERN + "]{1,5}$";

	@Autowired 
	private ValidationRequestFactory validationRequestFactory;

	@Autowired
	private UsersService userService;

	@Override
	public void initialize(ValidRifAccount constraintAnnotation) { 
		// none required
	}

	@Override
	public boolean isValid(Account account, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();		
		Party  primaryParty = validationContext.getApplication().getPrimaryApplicant();
		boolean nonRegAccountsOpened =   nonRegAccounts(validationContext.getApplication().getAccounts());
		//Spouse DOB
		Party party = validationContext.getApplication().getSpouseParty();
		//ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).withChildPropertyNode(RIF_PAYMENT_DETAILS).build();
		ValidationRequestBuilder builder = validationRequestFactory.createBuilder(context, userService.currentUser().getLob());
        ValidationRequest request = builder.withChildPropertyNode(RIF_PAYMENT_DETAILS).build();
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}
		boolean valid = true;

		if(Optional.ofNullable(account.getRifPayment()).isPresent()) {
			if(account.isRif()) {
				valid = isValidSpouseAgeUsed(account, request, primaryParty) && valid;
				valid = this.validateAmountType(account, request) && valid;
				valid = this.validateGreaterThanMinimumAmountType(account, request) && valid;
				valid = this.validateAmount(account, request) && valid;
				valid = this.validateFrequency(account, request) && valid;
				valid = this.validateStartMonth(account, request) && valid;
				valid = this.validateWhenInMonth(account, request) && valid;
				valid = this.validateIsSpousalRIF(account, request) && valid;
				valid = this.validateSpousalRIFContributor(account, request) && valid;
				valid = this.validateWithholdingTax(account, request, isQuebecResident(primaryParty)) && valid;
				valid = this.validateMethod(account, request,nonRegAccountsOpened) && valid;
				request = builder.withChildPropertyNode(OUTBOUND_EFT_DETAILS).build();
				valid = this.validateOwnershipOfBankAccountVerification(account, request) && valid;	
			} else if (account.isLif()) {
				valid = this.validateAmountType(account, request) && valid;
				valid = this.validateGreaterThanMinimumAmountType(account, request) && valid;
				valid = this.validateAmount(account, request) && valid;
				valid = this.validateFrequency(account, request) && valid;
				valid = this.validateStartMonth(account, request) && valid;
				valid = this.validateWhenInMonth(account, request) && valid;
				valid = this.validateStartYear(account, request) && valid;
				valid = this.validateWithholdingTax(account, request, isQuebecJurisdiction(account)) && valid;
				valid = this.validateMethod(account, request,nonRegAccountsOpened) && valid;
				request = builder.withChildPropertyNode(OUTBOUND_EFT_DETAILS).build();
				valid = this.validateOwnershipOfBankAccountVerification(account, request) && valid;	
			}
		}
		
		return valid;		
	}
	
	private boolean nonRegAccounts(List<Account> accounts){		
		for(Account acc: accounts){
			if(Account.INDIVIDUAL_TYPE.equals(acc.getType())			
					|| Account.JOINT_TYPE.equals(acc.getType())){
				return true;
			}
		}
		return false;
	}
	
	private boolean isValidSpouseAgeUsed(Account account, ValidationRequest request, Party primaryApplicant) {
		request.setFieldName(SPOUSE_AGE_USED_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_SPOUSE_AGE_USED);
		boolean valid = true;
		Boolean hasSpouseAgeUsed = account.getRifPayment().getIsSpouseAgeUsed();
		Boolean isPrimaryApplicantHasSpouse = this.isValidSpouse(primaryApplicant.getPersonal().getIdentity().getMaritalStatus());
		if(isPrimaryApplicantHasSpouse && !Optional.ofNullable(hasSpouseAgeUsed).isPresent()) {
			request.addConstraintViolation();	
			valid = false;
		}
		else if(!isPrimaryApplicantHasSpouse && hasSpouseAgeUsed != null && hasSpouseAgeUsed) {
			request.addConstraintViolation();						
			valid = false;
		}			
		return valid;
	}

	private boolean validateWithholdingTax(Account account, ValidationRequest request, boolean isQuebecResident) {
		boolean valid = true;
		if(account.getRifPayment().getHasIncreasedWitholdingTax() != null &&
				account.getRifPayment().getHasIncreasedWitholdingTax()){
			if(StringUtils.isBlank(account.getRifPayment().getWithHoldingTaxType())) {
				request.addConstraintViolation("withHoldingTaxType", ErrorCodes.INVALID_WITH_HOLDING_TAX);				
				valid = false;
			} else {
				if(((account.getRifPayment().getWithHoldingTaxType().equalsIgnoreCase(RIF_WITH_HOLDING_TAX_FEDERAL)) ||
						(isQuebecResident && account.getRifPayment().getWithHoldingTaxType().equalsIgnoreCase(RIF_WITH_HOLDING_TAX_QUEBEC)) ) && 
						(account.getRifPayment().getWithHoldingTaxPercentage() == null || 
						!doesPatternMatch(String.valueOf(account.getRifPayment().getWithHoldingTaxPercentage()),WITH_HOLDING_TAX_PERCENTAGE_PATTERN))) {
						request.addConstraintViolation("withHoldingTaxPercentage", ErrorCodes.INVALID_WITH_HOLDING_TAX_PERCENTAGE);						
						valid = false;
				}
				if((isQuebecResident) && (account.getRifPayment().getWithHoldingTaxType().equalsIgnoreCase(RIF_WITH_HOLDING_TAX_QUEBEC)) && 
						(account.getRifPayment().getWithHoldingQuebecTaxPercentage() == null || 
						!doesPatternMatch(String.valueOf(account.getRifPayment().getWithHoldingQuebecTaxPercentage()),WITH_HOLDING_TAX_PERCENTAGE_PATTERN))) {
						request.addConstraintViolation("withHoldingQuebecTaxPercentage", ErrorCodes.INVALID_WITH_HOLDING_QUEBEC_TAX_PERCENTAGE);						
						valid = false;
				}
				if(account.getRifPayment().getWithHoldingTaxType().equalsIgnoreCase(RIF_WITH_HOLDING_TAX_FLAT) && 
						(account.getRifPayment().getWithHoldingTaxAmount() == null 
						||!doesPatternMatch(String.valueOf(account.getRifPayment().getWithHoldingTaxAmount()),TAX_AMOUNT_PATTERN))) {
					request.addConstraintViolation("withHoldingTaxAmount", ErrorCodes.INVALID_WITH_HOLDING_TAX_AMOUNT);					
					valid = false;
				}
				if(account.isLif() && isQuebecResident && account.getRifPayment().getWithHoldingTaxType().equalsIgnoreCase(RIF_WITH_HOLDING_TAX_FLAT) && 
						(account.getRifPayment().getWithHoldingQuebecTaxAmount() == null 
						||!doesPatternMatch(String.valueOf(account.getRifPayment().getWithHoldingQuebecTaxAmount()),TAX_AMOUNT_PATTERN))) {
					request.addConstraintViolation("withHoldingQuebecTaxAmount", ErrorCodes.INVALID_WITH_HOLDING_QUEBEC_TAX_AMOUNT);					
					valid = false;
				}
			}			
		}
		else{
				if(StringUtils.isNoneBlank(account.getRifPayment().getWithHoldingTaxType())){
					request.addConstraintViolation("withHoldingTaxType", ErrorCodes.INVALID_WITH_HOLDING_TAX);
					valid=false;
				}
				if(account.getRifPayment().getWithHoldingTaxPercentage()!=null){
					request.addConstraintViolation("withHoldingTaxPercentage", ErrorCodes.INVALID_WITH_HOLDING_TAX_PERCENTAGE);	
					valid=false;
				}
				if(account.getRifPayment().getWithHoldingQuebecTaxPercentage()!=null){
					request.addConstraintViolation("withHoldingQuebecTaxPercentage", ErrorCodes.INVALID_WITH_HOLDING_QUEBEC_TAX_PERCENTAGE);	
					valid=false;
				}
				if(account.getRifPayment().getWithHoldingTaxAmount()!=null){
					request.addConstraintViolation("withHoldingTaxAmount", ErrorCodes.INVALID_WITH_HOLDING_TAX_AMOUNT);	
					valid=false;
				}
				if(account.isLif() && account.getRifPayment().getWithHoldingQuebecTaxAmount()!=null){
					request.addConstraintViolation("withHoldingQuebecTaxAmount", ErrorCodes.INVALID_WITH_HOLDING_QUEBEC_TAX_AMOUNT);	
					valid=false;
				}
		}
		return valid;
	}
	
	private boolean validateFrequency(Account account, ValidationRequest request) {
		if(StringUtils.isBlank(account.getRifPayment().getFrequency())) {
			request.addConstraintViolation("frequency", ErrorCodes.INVALID_RIF_FREQUENCY);			
			return false;
		}
		return true;
	}
	
	private boolean validateStartMonth(Account account, ValidationRequest request) {
		if(account.getRifPayment().getStartMonth() == null) {
			request.addConstraintViolation("startMonth", ErrorCodes.INVALID_START_MONTH);			
			return false;
		}
		return true;
	}
	
	private boolean validateStartYear(Account account, ValidationRequest request) {
		if(account.getRifPayment().getStartYear() == null) {
			request.addConstraintViolation("startYear", ErrorCodes.INVALID_START_YEAR);			
			return false;
		}
		return true;
	}
	
	private boolean validateWhenInMonth(Account account, ValidationRequest request) {
		if(StringUtils.isBlank(account.getRifPayment().getWhenInMonth())) {
			request.addConstraintViolation("whenInMonth", ErrorCodes.INVALID_WHEN_IN_MONTH);			
			return false;
		}
		return true;
	}	

	private boolean validateMethod(Account account, ValidationRequest request,boolean nonRegAccounts) {
		boolean valid = true;
		if(StringUtils.isBlank(account.getRifPayment().getMethod())) {
			request.addConstraintViolation("method", ErrorCodes.INVALID_PAYMENT_METHOD);			
			valid = false;
		} else { 
			if(account.getRifPayment().getMethod().equalsIgnoreCase(RifPaymentDetails.METHOD_TRANSFER)) {
				if(nonRegAccounts){
					if(validateNonRegisteredAccountSelectionType(account,request)){
						valid = true && valid;
						valid = validateTransferAccountNumber(account,request) && valid;
					}else{
						valid = false;
					}
					
				}else{
				    valid = validateTransferAccountNumber(account,request) && valid;
				}
			} 
			if(!account.getRifPayment().getMethod().equalsIgnoreCase(RifPaymentDetails.METHOD_TRANSFER) && 
					StringUtils.isNoneBlank(account.getRifPayment().getTransferAccountNumber())){
				request.addConstraintViolation("transferAccountNumber", ErrorCodes.INVALID_TRANSFER_ACCOUNT_NUMBER);				
				valid = false;
			}
			if(account.getRifPayment().getMethod().equalsIgnoreCase(RifPaymentDetails.METHOD_EFT)) {
				ValidationRequest outboundValReq = request.createChildValidationRequest(OUTBOUND_EFT_DETAILS, null);
				valid = this.validateEftPayment(account.getOutboundEftDetails(), outboundValReq) && valid;
			} 
		}		
		return valid;
	}

	private boolean validateEftPayment(EftDetails eftDetails, ValidationRequest request) {
		boolean valid = true;
		if(Optional.ofNullable(eftDetails).isPresent()) {
			valid = this.validateInstitutionCode(eftDetails.getInstitutionCode(), request) && valid;
			valid = this.validateInstitutionName(eftDetails.getInstitutionName(), request) && valid;
			valid = this.validateTransitCode(eftDetails.getTransitCode(), request) && valid;
			valid = this.validateAccountNumber(eftDetails.getAccountNumber(), request) && valid;
			valid = this.validateAccountOwner(eftDetails.getAccountOwner(), request) && valid;
		} else {
			request.addConstraintViolation("institutionCode", ErrorCodes.INVALID_EFT_INSTITUTION_CODE);
			request.addConstraintViolation("institutionName", ErrorCodes.INVALID_EFT_INSTITUTION_NAME);
			request.addConstraintViolation("transitCode", ErrorCodes.INVALID_EFT_TRANSIT_CODE);
			request.addConstraintViolation("accountNumber", ErrorCodes.INVALID_ACCOUNT_NUMBER);
			request.addConstraintViolation("accountOwner", ErrorCodes.INVALID_EFT_ACCOUNT_OWNER);
			valid = false;
		}
		return valid;
	}
	
	private boolean validateInstitutionCode(String institutionCode, ValidationRequest request) {
		if(StringUtils.isBlank(institutionCode)) {
			request.addConstraintViolation("institutionCode", ErrorCodes.INVALID_EFT_INSTITUTION_CODE);
			return false;
		}
		return true;
	}
	
	private boolean validateInstitutionName(String institutionName, ValidationRequest request) {
		if(StringUtils.isBlank(institutionName)) {
			request.addConstraintViolation("institutionName", ErrorCodes.INVALID_EFT_INSTITUTION_NAME);
			return false;
		}
		return true;
	}
	
	private boolean validateTransitCode(String transitCode, ValidationRequest request) {
		if(StringUtils.isBlank(transitCode)) {
			request.addConstraintViolation("transitCode", ErrorCodes.INVALID_EFT_TRANSIT_CODE);
			return false;
		}
		return true;
	}
	
	private boolean validateAccountNumber(String accountNumber, ValidationRequest request) {
		if(StringUtils.isBlank(accountNumber) || !this.doesPatternMatch(accountNumber, ACCOUNT_NUM_PATTERN)) {
			request.addConstraintViolation("accountNumber", ErrorCodes.INVALID_ACCOUNT_NUMBER);
			return false;
		}
		return true;
	}
	
	private boolean validateAccountOwner(String accountOwner, ValidationRequest request) {
		if(StringUtils.isBlank(accountOwner) || !this.doesPatternMatch(accountOwner, ACCOUNT_OWNER_PATTERN)) {
			request.addConstraintViolation("accountOwner", ErrorCodes.INVALID_EFT_ACCOUNT_OWNER);
			return false;
		}
		return true;
	}
	
	private boolean validateTransferAccountNumber(Account account, ValidationRequest request) {
		if(StringUtils.isBlank(account.getRifPayment().getTransferAccountNumber())
				||((NONREG_ACC_SEL_TYPE_EXT_ACC.equals(account.getRifPayment().getNonRegisteredAccountSelectionType()) || StringUtils.isBlank(account.getRifPayment().getNonRegisteredAccountSelectionType())) && !this.doesPatternMatch(account.getRifPayment().getTransferAccountNumber(), ACCOUNT_NUM_PATTERN)) 
				||(NONREG_ACC_SEL_TYPE_ACC_ON_APP.equals(account.getRifPayment().getNonRegisteredAccountSelectionType()) && !this.doesPatternMatch(account.getRifPayment().getTransferAccountNumber(), ACCOUNT_NUM_NONREG_PATTERN))) {
			request.addConstraintViolation("transferAccountNumber", ErrorCodes.INVALID_TRANSFER_ACCOUNT_NUMBER);			
			return false;
		}
			return true;
	}
	
	private boolean validateNonRegisteredAccountSelectionType(Account account, ValidationRequest request) {
		if(StringUtils.isBlank(account.getRifPayment().getNonRegisteredAccountSelectionType()) ||	
				(!NONREG_ACC_SEL_TYPE_EXT_ACC.equals(account.getRifPayment().getNonRegisteredAccountSelectionType()) && !NONREG_ACC_SEL_TYPE_ACC_ON_APP.equals(account.getRifPayment().getNonRegisteredAccountSelectionType()))
						) {
			request.addConstraintViolation("nonRegisteredAccountSelectionType", ErrorCodes.INVALID_NONREG_ACCOUNT_SEL_TYPE);			
			return false;
		}
		return true;
	}
	
	private boolean validateAmountType(Account account, ValidationRequest request) {
		if(StringUtils.isBlank(account.getRifPayment().getAmountType())) {
			request.addConstraintViolation(AMOUNT_TYPE, ErrorCodes.INVALID_AMOUNT_TYPE);
			return false;
		}
		return true;
	}

	private boolean validateGreaterThanMinimumAmountType(Account account, ValidationRequest request) {		
		if(GREATER_THAN_MIN_PAYMENT_AMOUNT_TYPE.equals(account.getRifPayment().getAmountType()) && 
				StringUtils.isBlank(account.getRifPayment().getGreaterThanMinimumAmountType())) {
			request.addConstraintViolation(GREATER_THAN_MIN_AMOUNT_MOUNT_TYPE_FIELD, ErrorCodes.INVALID_GREATER_THAN_MIN_AMT_TYPE);			
			return false;
		}
		return true;
	}

	private boolean validateAmount(Account account, ValidationRequest request) {		
		if(GREATER_THAN_MIN_PAYMENT_AMOUNT_TYPE.equals(account.getRifPayment().getAmountType()) && 
				(!Optional.ofNullable(account.getRifPayment().getAmount()).isPresent() || 
						!this.doesPatternMatch(String.valueOf(account.getRifPayment().getAmount()), AMOUNT_PATTERN)) ) {
			request.addConstraintViolation(AMOUNT, ErrorCodes.INVALID_AMOUNT);			
			return false;
		}
		return true;
	}

	private boolean validateVerifierFirstName(Account account, ValidationRequest request, Party party,
			Party primaryParty) {
		boolean valid = true;
		Boolean hasSpouseAgeUsed = account.getRifPayment().getIsSpouseAgeUsed();
		try {

			if (Optional.ofNullable(hasSpouseAgeUsed).isPresent() && hasSpouseAgeUsed 
					&& (!Optional.ofNullable(account.getRifPayment().getSpouseElectionVerifiedByFirstName()).isPresent()
							|| !this.doesPatternMatch(account.getRifPayment().getSpouseElectionVerifiedByFirstName(),
									NAME_PATTERN))) {
				request.addConstraintViolation(VERIFIED_BY_FIRST_NAME, ErrorCodes.INVALID_VERIFIED_EMPLOYEE_FIRST_NAME);
				valid = false;
			}
		}  catch (DateTimeParseException e) {
			logger.warn("Failure in date conversion to varify first name of spouse party. ", e);
			logger.info(e.getMessage(), e);
			request.addConstraintViolation(DOB_FIELD_NAME, ErrorCodes.INVALID_DATE);
			valid = false;
		}
		return valid;
	}

	private boolean validateVerifierLastName(Account account, ValidationRequest request, Party party,
			Party primaryParty) {
		boolean valid = true;
		Boolean hasSpouseAgeUsed = account.getRifPayment().getIsSpouseAgeUsed();
		try {
			if (Optional.ofNullable(hasSpouseAgeUsed).isPresent() && hasSpouseAgeUsed
					&& (!Optional.ofNullable(account.getRifPayment().getSpouseElectionVerifiedByLastName()).isPresent()
							|| !this.doesPatternMatch(account.getRifPayment().getSpouseElectionVerifiedByLastName(),
									NAME_PATTERN))) {
				request.addConstraintViolation(VERIFIED_BY_LAST_NAME, ErrorCodes.INVALID_VERIFIED_EMPLOYEE_LAST_NAME);
				valid = false;
			}

		}  catch (DateTimeParseException ex) {
			logger.warn("Failure in date conversion to verify last name of spouse party.", ex);
			logger.info(ex.getMessage(), ex);	
			valid = addDOBConstriantViolation(request, DOB_FIELD_NAME,ErrorCodes.INVALID_DATE);
		}
		return valid;
	}

	private boolean validateVerifiedDate(Account account, ValidationRequest request, Party party, Party primaryParty) {
		boolean valid = true;
		Boolean hasSpouseAgeUsed = account.getRifPayment().getIsSpouseAgeUsed();

		try {
			if (Optional.ofNullable(hasSpouseAgeUsed).isPresent()  && hasSpouseAgeUsed 
					&& (!Optional.ofNullable(account.getRifPayment().getSpouseElectionVerifiedDate()).isPresent()
							|| !isValidVerificationDate(account.getRifPayment().getSpouseElectionVerifiedDate()))) {

				request.addConstraintViolation(DATE_VERIFIED, ErrorCodes.INVALID_VERIFIED_DATE);
				valid = false;
			}


		} catch (DateTimeParseException ex) {
			logger.warn("Failure in date verification for spouse election.", ex);
			logger.info(ex.getMessage(), ex);	
			valid = addDOBConstriantViolation(request, DOB_FIELD_NAME,ErrorCodes.INVALID_DATE);
		}
		return valid;
	}

	/**
	 * @param dateString
	 * @return  true if: 1) dateString is: valid yyyy-MM-dd format <b>AND</b> 2) is either today or a day earlier than today.
	 */
	boolean isValidVerificationDate(String dateString) {
		try {
			Date today = new Date();
			Date date = new SimpleDateFormat(DEFAULT_DATE_PATTERN).parse(dateString);
			return org.apache.commons.lang3.time.DateUtils.isSameDay(date, today) || today.after(date);
		} catch (ParseException ex) {
			logger.error("Failure in date conversion to check validity: ",dateString, ex);
			return false;
		}
	}

	private boolean addDOBConstriantViolation(ValidationRequest request, String fieldName, String errorCode){
		request.addConstraintViolation(fieldName, errorCode);
		return false;
	}
	
	private boolean isQuebecResident(Party primaryParty){	
		if (Optional.ofNullable(primaryParty.getPersonal()).isPresent()
				&& Optional.ofNullable(primaryParty.getPersonal().getResidence()).isPresent()
				&& Optional.ofNullable(primaryParty.getPersonal().getResidence().getPrimaryAddress()).isPresent()
				&& Optional.ofNullable(primaryParty.getPersonal().getResidence().getPrimaryAddress().getProvince())
						.isPresent()
				&& RefDataValues.PROVINCE_QBC.equalsIgnoreCase(
						primaryParty.getPersonal().getResidence().getPrimaryAddress().getProvince())) {
			return true;
		}
		return false;
	}
	
	private boolean isQuebecJurisdiction(Account account) {
		if (Optional.ofNullable(account).map(Account::getLiraAccountDetails).map(LiraAccountDetails::getProvince)
				.isPresent()
				&& RefDataValues.PROVINCE_QBC.equalsIgnoreCase(account.getLiraAccountDetails().getProvince())) {
			return true;
		}
		return false;
	}
	
	private boolean validateOwnershipOfBankAccountVerification(Account account, ValidationRequest request){	
		if (Optional.ofNullable(account.getRifPayment()).isPresent()
				&& Optional.ofNullable(account.getRifPayment().getMethod()).isPresent()
				&& RifPaymentDetails.METHOD_EFT.equalsIgnoreCase(account.getRifPayment().getMethod())
				&& Optional.ofNullable(account.getOutboundEftDetails()).isPresent() 
				&& (!Optional.ofNullable(account.getOutboundEftDetails().isOwnershipOfBankAccountVerified()).isPresent() || !account.getOutboundEftDetails().isOwnershipOfBankAccountVerified())) {
					request.addConstraintViolation("ownershipOfBankAccountVerified", ErrorCodes.INVALID_EFT_OWNERSHIP_BANK_ACCOUNT_VERIFIED);
			return false;
		}
		return true;
	}
	
	private boolean validateIsSpousalRIF(Account account, ValidationRequest request) {
		if(!Optional.ofNullable(account.getIsSpousal()).isPresent()) {
			request.addConstraintViolation(IS_SPOUSAL_RIF, ErrorCodes.INVALID_SPOUSAL_RIF);
			return false;
		}
		return true;
	}

	
	private boolean validateSpousalRIFContributor(Account account, ValidationRequest request) {
		boolean valid = true;
		
		ValidationRequest contributorValReq = request.createChildValidationRequest(CONTRIBUTOR_FIELD_NAME, null);
		if(Optional.ofNullable(account.getIsSpousal()).isPresent() && account.getIsSpousal()){
		
			valid = this.validateContributorFirstName(account, contributorValReq) && valid;
			valid = this.validateContributorLastName(account, contributorValReq) && valid;
			valid = this.validateContributorSocialInsuranceNumber(account, contributorValReq) && valid;
			valid = this.validateContributorDateOfBirth(account, contributorValReq) && valid;
		
		}		
		return valid;
	}

	private boolean validateContributorFirstName(Account account, ValidationRequest request) {
	
		if (!Optional.ofNullable(account.getContributor().getName()).isPresent()
				||(Optional.ofNullable(account.getContributor().getName()).isPresent()
						&& !Optional.ofNullable(account.getContributor().getName().getFirstName()).isPresent()
						|| !this.doesPatternMatch(account.getContributor().getName().getFirstName(),NAME_PATTERN))) {
				request.addConstraintViolation(NAME_PATH.concat(".").concat(FIRST_NAME_FIELD_NAME), ErrorCodes.INVALID_FIRST_NAME);
			return false;
		}
			return true;
	}

	private boolean validateContributorLastName(Account account, ValidationRequest request) {
	
		if (!Optional.ofNullable(account.getContributor().getName()).isPresent()
				||(Optional.ofNullable(account.getContributor().getName()).isPresent()
						&& !Optional.ofNullable(account.getContributor().getName().getLastName()).isPresent()
						|| !this.doesPatternMatch(account.getContributor().getName().getLastName(),NAME_PATTERN))) {
			request.addConstraintViolation(NAME_PATH.concat(".").concat(LAST_NAME_FIELD_NAME), ErrorCodes.INVALID_LAST_NAME);
			return false;
		}
			return true;
	}


	private boolean validateContributorSocialInsuranceNumber(Account account, ValidationRequest request) {
	
		if (!Optional.ofNullable(account.getContributor().getSocialInsuranceNumber()).isPresent()
			|| (Optional.ofNullable(account.getContributor().getSocialInsuranceNumber()).isPresent() 
			&& !verifySinPattern(account.getContributor().getSocialInsuranceNumber()))) {
			request.addConstraintViolation(SIN_FIELD_NAME, ErrorCodes.INVALID_SIN);
			return false;
		}	
			return true;
	}

	private boolean validateContributorDateOfBirth(Account account, ValidationRequest request) {

	if(!Optional.ofNullable(account.getContributor().getDateOfBirth()).isPresent() 
			|| (Optional.ofNullable(account.getContributor().getDateOfBirth()).isPresent()
			&& !isValidVerificationDate(account.getContributor().getDateOfBirth()))) {
		request.addConstraintViolation(DOB_FIELD_NAME, ErrorCodes.INVALID_DATE_OF_BIRTH);
		return false;
	}
		return true;
	}	

}