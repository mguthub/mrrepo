package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Relationship {

	private String companyName;
	private String companyTradingSymbol;
	private String country;
	private String companyExchangeCountry ;
	private String companyExchangeCode;
	
	
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getCompanyTradingSymbol() {
		return companyTradingSymbol;
	}
	public void setCompanyTradingSymbol(String companyTradingSymbol) {
		this.companyTradingSymbol = companyTradingSymbol;
	}	
	
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCompanyExchangeCountry() {
		return companyExchangeCountry;
	}
	public void setCompanyExchangeCountry(String companyExchangeCountry) {
		this.companyExchangeCountry = companyExchangeCountry;
	}
	public String getCompanyExchangeCode() {
		return companyExchangeCode;
	}
	public void setCompanyExchangeCode(String companyExchangeCode) {
		this.companyExchangeCode = companyExchangeCode;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((companyName == null) ? 0 : companyName.hashCode());
		result = prime * result + ((companyTradingSymbol == null) ? 0 : companyTradingSymbol.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Relationship other = (Relationship) obj;
		if (companyName == null) {
			if (other.companyName != null)
				return false;
		} else if (!companyName.equals(other.companyName))
			return false;
		if (companyTradingSymbol == null) {
			if (other.companyTradingSymbol != null)
				return false;
		} else if (!companyTradingSymbol.equals(other.companyTradingSymbol))
			return false;
		return true;
	}


}
