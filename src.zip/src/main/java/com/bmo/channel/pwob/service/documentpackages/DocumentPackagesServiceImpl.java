package com.bmo.channel.pwob.service.documentpackages;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.xml.ws.Holder;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.exception.ExceptionUtils;
import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.DocumentUpdateUploadRequest;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.DocumentUpdateUploadResponse;
import com.bmo.channel.pwob.service.applications.SavedApplicationsService;
import com.bmo.channel.pwob.service.authorization.PwobAction;
import com.bmo.channel.pwob.service.authorization.SecurityService;
import com.bmo.channel.pwob.service.document.DocumentUpdateUploadEndpointInterface;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentDto;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentPackageDto;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentUploadDto;
import com.bmo.channel.pwob.service.documentpackages.dto.Error;
import com.bmo.channel.pwob.service.documentpackages.dto.Image;
import com.bmo.channel.pwob.service.documentpackages.dto.LabelDto;
import com.bmo.channel.pwob.service.documentpackages.dto.MetaInfo;
import com.bmo.channel.pwob.service.documentpackages.dto.PackageStatus;
import com.bmo.channel.pwob.service.documentpackages.dto.SignerDto;
import com.bmo.channel.pwob.service.iacode.IaCodesService;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.Constants;
import com.bmo.channel.pwob.util.DocumentUtilFactory;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.channel.pwob.util.HubRequestHeaderBuilder.HeaderBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;

import net.bmogc.xmlns.hub.cg.document.cmiscontent._interface.v1.CMISContent;
import net.bmogc.xmlns.hub.cg.document.cmiscontent.types.v1.Failure;
import net.bmogc.xmlns.hub.cg.document.cmiscontent.types.v1.GetContentRequest;
import net.bmogc.xmlns.hub.cg.document.cmiscontent.types.v1.GetContentResponse;
import net.bmogc.xmlns.hub.cg.document.documentation._interface.v1.Documentation;
import net.bmogc.xmlns.hub.cg.document.documentation.types.v1.ModifyPackagesDestinationsRequest;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.ApplicationIntegrityException;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.DocumentTrackingService;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.InputViolationException;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.SystemException;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.AddPackagesToPendingPackagesRequest;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.AddPackagesToPendingPackagesResponse;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.DocumentPackageThin;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.DocumentStatus;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.DocumentThin;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.GetDocumentPackagesRequest;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.GetDocumentPackagesResponse;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.Labels;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.Metadata;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.Metadata.KeyValueGroup;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.PackageIds;
import net.bmogc.xmlns.hub.cg.document.documenttrackingservice.types.v3.Selector;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderResponse;
@Service
public class DocumentPackagesServiceImpl implements DocumentPackagesService {

	private static Logger logger = LoggerFactory.getLogger(DocumentPackagesServiceImpl.class);
	private static final String DOCUMENT_ERROR_KEY = "QASystemStatus";
	private static final String DOCUMENT_ERROR_ANOTHER_KEY = "QAUserStatus";
	private static final String USER_STATUS_NOT_VERIFIED = "Not Verified";
	private static final String DOCUMENT_NUMBEROFPAGES_KEY = "NumberOfPages";
	private static final String DOCUMENT_META_VALUE_VERIFIED = "Verified";
	private static final String AUTO_QA_PASSED = "AutoQA-Passed";
	private static final String RETRIEVE = "retrieve";
	private static final String SIGNATURE_STATUS = "SignatureStatus";
	private static final String REQUESTOR_ID = "requestorId";
	private static final String ERROR_PAGE_NUMBER_MISMATCH = "Page Number Mismatch";
	private static final String DTS_ERROR_PAGE_NUMBER_MISMATCH = "AutoQA-Failed - Page Number Mismatch";
	private static final String PACKAGE_STATUS = "PackageStatus";
	private static final String PACKAGE_STATUS_STAGED = "Staged";
	private static final String DESTINATION_DTS = "DTS";
	private static final String DESTINATION_ESIGN = "ESIGN";
	private static final String DESTINATION_DTS_PENDING = "DTS_PENDING";
	private static final String PENDING_REFERENCE_EXPIRATION = "PendingReferenceExpiration";
	private static final String STATUS_PENDING = "PENDING";
	private static final String SIGNATURE_TYPE = "SignatureType";
	private static final String SIGNATURE_TYPE_WET_SIGN = "wetSign";
	
	@Autowired
	private DocumentTrackingService documentTrackingService;
	
	@Autowired
	private CMISContent cmisContentService;
	
	@Resource
	private DocumentUpdateUploadEndpointInterface documentUpdateUploadEndpointInterface;
	
	@Autowired
	private HubRequestComponent hubRequestComponent;
	
	@Autowired
	private SecurityService securityService;

	@Autowired 
	private SavedApplicationsService savedApplicationService;
	
	@Autowired
	private UserContext userContext;
	
	@Autowired
	private UsersService usersService;
	
	@Autowired
	private Documentation documentationService;
	
	@Autowired
	private IaCodesService iaCodesService;
	
	@Value("${document.upload.process.flow}")
	private String documentUploadProcessFlow;
	
	@Override
	public List<DocumentPackageDto> retrieveDocumentPackages(final String workflowId, boolean isAuthorised) {
		
		SavedApplication savedApp = this.savedApplicationService.retrieveSavedApplication(workflowId);
	
		if(!isAuthorised){			
			securityService.authorizeReadAccess(savedApp.getIaCode());
		}		
		
		List<DocumentPackageDto> packageList =  retrieveDocumentPackages(workflowId);	
		return packageList;		
	}
	
	@Override
	public void assignUsersToeSignDocs(final String workflowId) {
		
		SavedApplication savedApp = this.savedApplicationService.retrieveSavedApplication(workflowId);
		List<DocumentPackageDto> packageList =  retrieveDocumentPackages(workflowId);		
		
		List<String> esignPackList = new ArrayList<String>();
		packageList.stream().filter(pack -> PackageStatus.ESIGN_PENDING.getDescription().equals(pack.getStatus())).forEach(pck ->esignPackList.add(pck.getId()));		
		if(!esignPackList.isEmpty()){
			extendESignExpiration(workflowId, esignPackList, savedApp);				
		}	
		
	}
	
	private List<DocumentPackageDto> retrieveDocumentPackages(final String workflowId) {
		List<DocumentPackageDto> packages = null;
		
		final GetDocumentPackagesResponse response = getDocumentPackages(workflowId,null,null,null);

		if (response != null && response.getBody() != null && response.getBody().getDocumentPackagesThin() != null) {
			packages = new ArrayList<>();
			List<DocumentDto> documents = null;
			List<String> packageErrors = null;
			for (DocumentPackageThin documentPackage : response.getBody().getDocumentPackagesThin().getDocumentPackageThin()) {
				DocumentPackageDto packageInfo = new DocumentPackageDto();
				packageErrors = new ArrayList<>();
				packageInfo.setLabels(createLabels(documentPackage.getLabels()));
				packageInfo.setId(documentPackage.getPackageId());
				
				if (documentPackage.getCreationDate() != null) {
					packageInfo.setPackageCreateDate(documentPackage.getCreationDate().toString());
				}
				
				// adding document list
				documents = new ArrayList<>();
	
				for (DocumentThin documentThin : documentPackage.getDocumentThin()) {
                    populateDocumentDto(documentThin, documents, packageErrors);
                    
				}
				
				if (documentPackage.getStatus() != null) {
					packageInfo.setStatus(derivePackageStatus(documentPackage, packageErrors));
				}
				
				if(documentPackage.getMetadata() != null) {
					String key = null;
					for (KeyValueGroup keyValueGroup : documentPackage.getMetadata().getKeyValueGroup()) {
						key = keyValueGroup.getKey();
						if(key.equalsIgnoreCase("SignatureType")) {							
							if(StringUtils.isNotEmpty((String)keyValueGroup.getValue().get(Constants.ZERO))){
								if("wetSign".equalsIgnoreCase((String)keyValueGroup.getValue().get(Constants.ZERO))
										|| ("eSignOrWetSign".equalsIgnoreCase((String)keyValueGroup.getValue().get(Constants.ZERO)) 
												&& "Completed".equalsIgnoreCase(packageInfo.getStatus()))){
									populateLatestDocumentReceivedDate(packageInfo,documentPackage.getDocumentThin());
								}
							}
						}
					}
				}
				
				packageInfo.setType(documentPackage.getType());
				
				packageInfo.setDocuments(documents);
				if(documentPackage.getMetadata() != null && documentPackage.getMetadata().getKeyValueGroup() != null) {
					extractPackageSignersSignatureTypeFromMetadata(documentPackage.getMetadata(), packageInfo);
					packageInfo.setLocale(extractPackageLanguageFromMetadata(documentPackage.getMetadata()));
				}
				else{
					packageInfo.setSigners(new ArrayList<SignerDto>());
					packageInfo.setLocale(null);
				}
				packageInfo.setErrors(packageErrors);
				
				packages.add(packageInfo);
			}
		} else {
			logger.error("Document Packages not Found for workflow id: "+workflowId);
			throw new NotFoundException("Document Packages not Found.");
		}
		return packages;
	}
	
	private void populateLatestDocumentReceivedDate(DocumentPackageDto packageInfo, List<DocumentThin> documentThins) {
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		for (DocumentThin documentThin : documentThins) {
			String key = null;
			if(documentThin.getMetadata() != null) {
				for (KeyValueGroup keyValueGroup : documentThin.getMetadata().getKeyValueGroup()) {
					key = keyValueGroup.getKey();
					if(key.equalsIgnoreCase("ScanCaptureDate")) {
						if(StringUtils.isNotEmpty((String)keyValueGroup.getValue().get(Constants.ZERO))){
							if(StringUtils.isNotEmpty(packageInfo.getDocumentReceivedDate())){
								try {
									if(sdf.parse(packageInfo.getDocumentReceivedDate()).before(sdf.parse((String)keyValueGroup.getValue().get(Constants.ZERO)))){									
										packageInfo.setDocumentReceivedDate((String)keyValueGroup.getValue().get(Constants.ZERO));
									}
								} catch (ParseException ex) {									
									logger.error("Failure in date conversion.",ex);
								}
							}else{
								packageInfo.setDocumentReceivedDate((String)keyValueGroup.getValue().get(Constants.ZERO));								
							}
						}
					}						
				}
				}
			}
		}
	
	
	private void populateDocumentDto(final DocumentThin documentThin, final List<DocumentDto> documents, final List<String> packageErrors) {
		final DocumentDto documentDto = new DocumentDto(createLabels(documentThin.getLabels()));
		documentDto.setId(documentThin.getDocumentId());
		documentDto.setReferenceId(documentThin.getReferenceId());
		documentDto.setType(documentThin.getType());
		
		documentDto.setSignatureStatus(getDocumentSignatureStatus(documentThin));
		
		Integer noOfPages = getDocumentNumberOfPages(documentThin);
		if (noOfPages != null) {
			documentDto.setNumberOfPages(noOfPages);
		}
		
		List<String> docErrors = getDocumentErrors(documentThin);
		packageErrors.addAll(docErrors);
		documentDto.setErrors(docErrors);
		
		documentDto.setDocumentStatus(this.getDocumentStatus(documentThin, docErrors));										
		
		if(Optional.ofNullable(documentThin.getMetadata()).isPresent()) {
            extractDocumentSignersFromMetadata(documentThin.getMetadata(), documentDto);
            //Fetching and setting DocumentVersion
            extractDocumentVersionFromMetadata(documentThin.getMetadata(), documentDto);
		} else {
            documentDto.setSigners(new ArrayList<String>());
            documentDto.setDocumentVersion("");
		} 

		documents.add(documentDto);
	}
	
	private void extractDocumentVersionFromMetadata(final Metadata metadata, final DocumentDto documentDto){
        String documentVersion=null;
        if(Optional.ofNullable(metadata.getKeyValueGroup()).isPresent()) {
        	String key =null;
            for (KeyValueGroup keyValueGroup : metadata.getKeyValueGroup()) {
               key=keyValueGroup.getKey();
               if(key.equalsIgnoreCase("DocumentVersion")) {
                 documentVersion=keyValueGroup.getValue().get(0);
                 logger.info("Value for documentVersion is: "+documentVersion);
               }
            }
        }
        documentDto.setDocumentVersion(documentVersion);
	} 

	private String getDocumentStatus(DocumentThin documentThin, List<String> docErrors) {
		
		String status = PackageStatus.COMPLETED.getDescription();
		boolean qaUserSatusisNotVerified = false;
		
		if(documentThin.getMetadata() != null && documentThin.getMetadata().getKeyValueGroup() != null) {			
			for (KeyValueGroup keyValueGroup : documentThin.getMetadata().getKeyValueGroup()) {
				String key = keyValueGroup.getKey();
				if (key.equalsIgnoreCase(DOCUMENT_ERROR_ANOTHER_KEY) && USER_STATUS_NOT_VERIFIED.equalsIgnoreCase(keyValueGroup.getValue().get(Constants.ZERO))) {
					qaUserSatusisNotVerified = true;
				}
			}
		}
		
		if (documentThin.getDocumentStatus() == DocumentStatus.PENDING) {
			status = PackageStatus.OUTSTANDING.getDescription();
		} else if (qaUserSatusisNotVerified && CollectionUtils.isNotEmpty(docErrors)) {
			status = PackageStatus.ERROR.getDescription();
		} 	
		
		return status;
	}
	
	private String getDocumentSignatureStatus(final DocumentThin documentThin) {
		String status = null;
		if(documentThin.getMetadata() != null && documentThin.getMetadata().getKeyValueGroup() != null) {			
			for (KeyValueGroup keyValueGroup : documentThin.getMetadata().getKeyValueGroup()) {
				String key = keyValueGroup.getKey();
				if (key.equalsIgnoreCase(SIGNATURE_STATUS)) {
					status = keyValueGroup.getValue().get(Constants.ZERO);
					break;
				}
			}
		}
		return status;
	}

	private GetDocumentPackagesResponse getDocumentPackages(final String workflowId,String packageId,String documentId,String ecifId) {
		GetDocumentPackagesResponse response = null;
		final GetDocumentPackagesRequest request = createRequestPayloads(workflowId);
		final HUBHeaderRequest requestHeader = createRequestHeader("documentTrackingService", "getDocumentPackage", workflowId,packageId,documentId,ecifId);
		final HUBHeaderResponse responseHeader = new HUBHeaderResponse();

		try {
			response = documentTrackingService.getDocumentPackages(request, requestHeader, new Holder<HUBHeaderResponse>(responseHeader));
		} catch (ApplicationIntegrityException | InputViolationException | SystemException e) {
			logger.error("error generated in documentTrackingService.getDocumentPackages ",workflowId, e);
			ExceptionUtils.throwGenerateDocumentPackagesErrors(e);
		} 
		return response;
	}
	
	private String derivePackageStatus(final DocumentPackageThin documentPackage, final List<String> packageErrors) {
		String status = PackageStatus.COMPLETED.getDescription();
		
		if (!packageErrors.isEmpty()) {
			status = PackageStatus.ERROR.getDescription();
			return status;
		}
		
		for (DocumentThin documentThin : documentPackage.getDocumentThin()) {
			//Set the package status based on DocumentStatus.
			if (documentThin.getDocumentStatus() == DocumentStatus.PENDING) {
				status = PackageStatus.OUTSTANDING.getDescription();
				break;
			}
		}
		
		if (!status.equals(PackageStatus.COMPLETED.getDescription()) && 
				PACKAGE_STATUS_STAGED.equalsIgnoreCase(getPackageMetaData(documentPackage.getMetadata(), PACKAGE_STATUS))) {
			status = PackageStatus.ESIGN_PENDING.getDescription();
		}
		
		return status;
	}
	
	private String getPackageMetaData(final Metadata metadata, final String key) {
		String status = null;
		if(metadata != null && metadata.getKeyValueGroup() != null) {
			for (KeyValueGroup keyValueGroup : metadata.getKeyValueGroup()) {
				if(key.equalsIgnoreCase(keyValueGroup.getKey())) {
					status = keyValueGroup.getValue().get(Constants.ZERO);
					break;
				}
			}
		}
		return status;
	}
	
	final List<String> getDocumentErrors(final DocumentThin documentThin) {
		final List<String> errors = new ArrayList<>();
		if(documentThin.getMetadata() != null && documentThin.getMetadata().getKeyValueGroup() != null) {			
			for (KeyValueGroup keyValueGroup : documentThin.getMetadata().getKeyValueGroup()) {
				String key = keyValueGroup.getKey();
				if (key.equalsIgnoreCase(DOCUMENT_ERROR_KEY)) {
					addError(key,keyValueGroup,errors);
					break;
				}
			}
		}
		return errors;
	}
	
	final void addError(String key,KeyValueGroup keyValueGroup, List<String> errors){
		if (!keyValueGroup.getValue().get(Constants.ZERO).equalsIgnoreCase(DOCUMENT_META_VALUE_VERIFIED)
				&& !keyValueGroup.getValue().get(Constants.ZERO).equalsIgnoreCase(AUTO_QA_PASSED)) {
			
			if (keyValueGroup.getValue().get(Constants.ZERO).equalsIgnoreCase(DTS_ERROR_PAGE_NUMBER_MISMATCH)) {
				errors.add(ERROR_PAGE_NUMBER_MISMATCH);
			} else {
                errors.addAll(keyValueGroup.getValue());
			}
			
		}
	}
	
	final Integer getDocumentNumberOfPages(final DocumentThin documentThin) {
		Integer pages = null;
		if(documentThin.getMetadata() != null && documentThin.getMetadata().getKeyValueGroup() != null) {			
			for (KeyValueGroup keyValueGroup : documentThin.getMetadata().getKeyValueGroup()) {
				String key = keyValueGroup.getKey();
				if (key.equalsIgnoreCase(DOCUMENT_NUMBEROFPAGES_KEY) && keyValueGroup.getValue().get(Constants.ZERO) != null) {
					pages = Integer.valueOf(keyValueGroup.getValue().get(Constants.ZERO));
					break;
				}
			}
		}
		return pages;
	}
	
	/**
	 * This is to get the workflow document packages ids.
	 * 
	 * @param workflowId Workflow id to get the document packages.
	 * @param documentPackageId Document package id to be find document ids if documentIds is null.
	 * @param documentIds Documents ids to be filled in the method.
	 * @param type To retrieve documents CMISContent requires the repositoryId not the document id.
	 * @param packageData To hold the package status to call either ModifyPackagesDestinations or AddPackagesToPendingPackages.
	 * @return List if ids.
	 */
	public List<String> workflowDocumentPackages(final String workflowId, final String documentPackageId, final List<String> documentIds, final String type,
			final Map<String, String> packageData) {
		List<String> packageIdList = null;
		
    	try {
    		final GetDocumentPackagesResponse response = getDocumentPackages(workflowId,documentPackageId,null,null);

    		if (response != null && response.getBody() != null && response.getBody().getDocumentPackagesThin() != null) {
    			packageIdList = new ArrayList<>();
    			for (DocumentPackageThin documentPackage : response.getBody().getDocumentPackagesThin().getDocumentPackageThin()) {
    				packageIdList.add(documentPackage.getPackageId());
    				
    				if (documentPackageId.equals(documentPackage.getPackageId())) {
    					if (packageData != null) { //Only require in esign.
    						packageData.put(PACKAGE_STATUS, getPackageMetaData(documentPackage.getMetadata(), PACKAGE_STATUS));
    					}
    					setDocumentIds(documentIds, type, documentPackage);
    					break;
    				}
    			}
    		}
		} catch (Exception e) {
			logger.error("error generated in hub server WS [{}]","getWorkflowData()", e);
			throw new WebServiceException(e);
    	}
    	
		return packageIdList;
	}

	private void setDocumentIds(final List<String> documentIds, final String type, final DocumentPackageThin documentPackage) {
		List<String> documentRepositoryIds = null;
		if (documentIds.isEmpty() && StringUtils.isBlank(type)) {
			for (DocumentThin documentThin : documentPackage.getDocumentThin()) {
				documentIds.add(documentThin.getDocumentId());
			}
		} else {
			// Replace documents ids received form UI with actual repository ids to get the content from CMIS.
			documentRepositoryIds = this.getDocumentRepositoryIds(documentIds, documentPackage.getDocumentThin());
			documentIds.clear();
			documentIds.addAll(documentRepositoryIds);
		}
	}
	
	private List<String> getDocumentRepositoryIds(final List<String> documentIds, final List<DocumentThin> documentThins) {
		final List<String> documentRepositoryIds = new ArrayList<>();
		for (DocumentThin documentThin : documentThins) {
			if (documentIds.isEmpty() || documentIds.contains(documentThin.getDocumentId())) { // In print all documentIds will be empty.
				documentRepositoryIds.add(documentThin.getEcmInfo().getRepositoryId());
			}
		}
		return documentRepositoryIds;
	}
	
	private String extractPackageLanguageFromMetadata(final Metadata metadata) {
		String language = null;
		Optional<String> locale= metadata.getKeyValueGroup().stream().filter(a->"PackageLanguage".equalsIgnoreCase(a.getKey())).map(b-> b.getValue().get(Constants.ZERO)).findAny();
		if(locale.isPresent()) {
			language = locale.toString();
		}
		return language;
	}
	

	private List<LabelDto> createLabels(final Labels labels) {
		List<LabelDto> result = new ArrayList<>();
		if(labels != null) {
			for (Labels.Label hubLabel : labels.getLabel()) {
				result.add(new LabelDto(hubLabel.getLocale(), hubLabel.getValue()));
			}
		}
		return result;
	}

	/**
	 *  Signer/SignatureType metadata has the following format:
	 *  <metadata>
	 *  	<keyValueGroup>
	 *  		<key>Signer.001.Id</key>
	 *  		<value>etc</value>
	 *  	</keyValueGroup>
	 *  	<keyValueGroup>
	 *  		<key>Signer.001.Name.First</key>
	 *  		<value>Fred</value>
	 *  	</keyValueGroup>
	 *  	<keyValueGroup>
	 *  		<key>Signer.002.Id</key>
	 *  		<value>etc 2</value>
	 *  	</keyValueGroup>
	 *  	<keyValueGroup>
     *          <key>SignatureType</key>
     *          <destination>CHANNEL</destination>
     *          <dataType>string</dataType>
     *          <value>wetSign</value>
     *      </keyValueGroup>
	 *  </metadata>
	 */
	private void extractPackageSignersSignatureTypeFromMetadata(final Metadata metadata, final DocumentPackageDto documentPackageDto) {
		List<SignerDto> result = new ArrayList<>();
		String signatureType = null;
		final Map<String, SignerDto> signers = new LinkedHashMap<>();
		String keyType = null;
		String value = null;
		for (KeyValueGroup keyValueGroup : metadata.getKeyValueGroup()) {
			String key = keyValueGroup.getKey();
			if(isSignerKey(key)) {
				String signerIndex = extractSignerIndex(key);

				SignerDto signer = signers.get(signerIndex);
				if(signer == null) {
					signer = new SignerDto();
					signers.put(signerIndex, signer);
				}

				// keyType can be one of Id, Name.First, Name.Last, Status
				keyType = key.substring("Signer.00x.".length());
				value = keyValueGroup.getValue().get(Constants.ZERO);
				if("Id".equalsIgnoreCase(keyType)) {
					signer.setId(value);
				} else if("Name.First".equalsIgnoreCase(keyType)) {
					signer.setFirstName(value);
				} else if("Name.Last".equalsIgnoreCase(keyType)) {
					signer.setLastName(value);
				} else if("Status".equalsIgnoreCase(keyType)) {
					signer.setSignedPackage(value);
				} else if("Role".equalsIgnoreCase(keyType)) {
					signer.setRole(value);
				}
			} else if (key.equalsIgnoreCase(SIGNATURE_TYPE)) {
				signatureType = keyValueGroup.getValue().get(Constants.ZERO);
			}
		}
		result.addAll(signers.values());
		
		documentPackageDto.setSigners(result);
		documentPackageDto.setSignatureType(signatureType);
		
	}
	
	private void extractDocumentSignersFromMetadata(final Metadata metadata, final DocumentDto documentDto) {
		final List<String> signers = new ArrayList<>();
		String key = null;
		for (KeyValueGroup keyValueGroup : metadata.getKeyValueGroup()) {
			key = keyValueGroup.getKey();
			if(key.equalsIgnoreCase("DocumentSignersNames")) {
				signers.addAll(keyValueGroup.getValue());
			}
		}
		documentDto.setSigners(signers);
	}

	/**
	 * Extract the signer details.
	 * 
	 * @param key metadata group key
	 * @return extract 3-digit index from key to get signer index.
	 * Ex:- Signer.001.Id -> 001
	 */
	private String extractSignerIndex(final String key) {
		return key.substring("Signer.".length(), "Signer.".length() + Constants.THREE);
	}

	/**
	 * Check a signer or not.
	 * 
	 * @param key metadata group key
	 * @return true if the key indicates it is related to signer. Ex:- Signer.001.Id, Signer.002.Name.First, etc.
	 */
	private boolean isSignerKey(final String key) {
		return key.startsWith("Signer.00");
	}

	private GetDocumentPackagesRequest createRequestPayloads(final String workflowId) {
		final GetDocumentPackagesRequest request = new GetDocumentPackagesRequest();
		final GetDocumentPackagesRequest.Body body = hubRequestComponent.requestBodyWithRequestorInfo(new GetDocumentPackagesRequest.Body(), REQUESTOR_ID);
			
		body.setCorrelationId(workflowId);
		body.setDocumentPackageThin(new Selector());
		request.setBody(body);
		
		return request;
	}

	@Override
	public DocumentDto viewDocument(final String workflowId, final String repositoryId, final String documentPackageId, final List<String> documentIds) {
		SavedApplication savedApp = this.savedApplicationService.retrieveSavedApplication(workflowId);
		securityService.authorizeReadAccess(savedApp.getIaCode());
		DocumentDto documentDto = null;

		final byte[] content = retrieveDocumentContent(workflowId, repositoryId, documentPackageId, documentIds, savedApp.getCustomerId());

		if(content != null) {
			documentDto = new DocumentDto();
			if (documentIds != null && documentIds.size() == Constants.ONE) {
				documentDto.setId(documentIds.get(Constants.ZERO));
			}
			final List<String> file = new ArrayList<>();
			file.add(Base64.encodeBase64String(content));
			documentDto.setContent(file);
		}
		return documentDto;
	}

	@Override
	public byte[] retrieveDocumentContent(final String workflowId, final String repositoryId, final String documentPackageId, List<String> documentIds, boolean isAuthorised, String partyId) {
		if(!isAuthorised){
			SavedApplication savedApp = this.savedApplicationService.retrieveSavedApplication(workflowId);
			securityService.authorizeReadAccess(savedApp.getIaCode());
			partyId = savedApp.getCustomerId();
		}

		return retrieveDocumentContent(workflowId, repositoryId, documentPackageId, documentIds, partyId);
	}

	private byte[] retrieveDocumentContent(final String workflowId, final String repositoryId, final String documentPackageId, List<String> documentIds, final String partyId) {
		// Validate the package id with workflow data.
		List<String> docIdList = documentIds;
		if (CollectionUtils.isEmpty(docIdList)) {
			docIdList = new ArrayList<>();
		}
		final List<String> documentPackageIds = workflowDocumentPackages(workflowId, documentPackageId, docIdList, RETRIEVE, null);
		if (documentPackageIds == null || documentPackageIds.isEmpty()) {
			logger.error("Document Packages not Found for documentPackageId: "+documentPackageId);
			throw new NotFoundException("Document Package not Found.");
		} else if(!documentPackageIds.contains(documentPackageId) || docIdList.isEmpty()) {
			logger.error("Document id(s) not found in the package with documentPackageId: "+documentPackageId);
			throw new NotFoundException("Document id(s) not found in the package");
		}

		HUBHeaderRequest requestHeader;

		final HUBHeaderResponse hubHeaderResponse = new HUBHeaderResponse();
		final List<StringBuilder> contents = new ArrayList<>();										
		byte[] content = null;
		for (String documentId : docIdList) {
			GetContentRequest getContentRequest = new GetContentRequest();
			GetContentRequest.Body body = new GetContentRequest.Body();
			body.setRepositoryId(repositoryId);
			body.setObjectId(documentId);
			getContentRequest.setBody(body);

			requestHeader = createRequestHeader("CMISContent", "getContent", workflowId, documentPackageId, documentId, partyId);

			try {
				GetContentResponse getContentResponse = cmisContentService.getContent(getContentRequest, requestHeader, new Holder<>(hubHeaderResponse));
				GetContentResponse.Body responseBody = getContentResponse.getBody();
				if (responseBody != null) {
					content = responseBody.getContentStream().getContent();
					StringBuilder builder = new StringBuilder(Base64.encodeBase64String(content));
					contents.add(builder);
				}
				
				if (responseBody != null) {
					Failure failure = responseBody.getFailure();
					if (failure != null) {
						if(failure.getCode() != null && failure.getCode().equals(ExceptionUtils.NOT_FOUND)) {
							return null;
						}
						final WebServiceException webEx = new WebServiceException();
						webEx.addContextInfo(ExceptionUtils.MSG_KEY, failure.getMessage());
						throw webEx;
					}
				} else {
					final WebServiceException webEx = new WebServiceException();
					webEx.addContextInfo(ExceptionUtils.MSG_KEY, ExceptionUtils.HUBERROR);
					throw webEx;
				}
			} catch (Exception  ex) {
				logger.error("Failed to retrieve document content for documentPackageId ",documentPackageId, ex);
				throw new WebServiceException(ex);		
			}
			
		}
		if (!contents.isEmpty()) {
			try {
				content = DocumentUtilFactory.mergeAll(contents, DocumentUtilFactory.PDF);
			} catch (Exception ex) {
				logger.error("Failed to merge all contents for documentPackageId ",documentPackageId, ex);
				throw new WebServiceException(ex);
			}
		}
		return content;
	}

	@Override
	public void activateESigning(final String workflowId) {
		
		SavedApplication savedApp = this.savedApplicationService.retrieveSavedApplication(workflowId);
		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.DOCUMENT_ACTION);
		
		this.assignUsersToeSignDocs(workflowId);
	}

	private void extendESignExpiration(final String workflowId, final List<String> documentPackageId, final SavedApplication savedApp) {
		final AddPackagesToPendingPackagesRequest request = new AddPackagesToPendingPackagesRequest();
		final AddPackagesToPendingPackagesRequest.Body body = hubRequestComponent.requestBodyWithRequestorInfo(new AddPackagesToPendingPackagesRequest.Body(), REQUESTOR_ID, "userId"); 
				
		final PackageIds packageIds = new PackageIds();
		documentPackageId.stream().forEach(id ->packageIds.getPackageId().add(id));
				
		final AddPackagesToPendingPackagesRequest.Body.Expiry expiry = new AddPackagesToPendingPackagesRequest.Body.Expiry();
		final AddPackagesToPendingPackagesRequest.Body.Expiry.Interval interval = new AddPackagesToPendingPackagesRequest.Body.Expiry.Interval();
		interval.setUnit(Constants.DAY);
		interval.setValue(Constants.SIXTY);
		expiry.setInterval(interval);
		
		String branchCode = usersService.currentUser().getBranchCode();		
		List<net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetUsersForInvestmentAdvisorCodeResponseType.PcdUsers.PcdUser> userList = iaCodesService.usersForIaCode(savedApp.getIaCode(), branchCode);
		
		if(userList.size() > 0) {			
			body.getUserId().addAll(userList.stream().map(f -> f.getNetworkId()).collect(Collectors.toList()));
		}
		
		//body.getUserId().addAll(userList);	
		body.setExpiry(expiry);
		body.setPackageIds(packageIds);
		request.setBody(body);
		
		String packId = documentPackageId.stream().findFirst().get();		
		
		final HUBHeaderRequest requestHeader = createRequestHeader("documentTrackingService", "addPackagesToPendingPackages", workflowId,packId,null,savedApp.getCustomerId());

		HUBHeaderResponse responseHeader = null;

		try {
			final AddPackagesToPendingPackagesResponse response = documentTrackingService.addPackagesToPendingPackages(request, requestHeader, new Holder<HUBHeaderResponse>(responseHeader));
			
			if (response.getBody() != null && !response.getBody().getFailure().isEmpty()) {
                if(response.getBody().getFailure().get(Constants.ZERO).getCode().equals(ExceptionUtils.MISSING_IN_DTS)) {
                	logger.error("No document package found for work flow id: ", workflowId);
                	//throw new NotFoundException("Document Package not Found.");
				} else {
					logger.error("Action 'convert to esign' is not allowed with status 'esign already active' for for work flow id: ", workflowId);
					//throw ExceptionUtils.buildStatusExceptionForActionNotAllowedContext("convert to esign", "esign already active");
				}
			}
		} catch (Exception ex) {
			logger.error("Failed to extend ESign expiration for document package id: ",documentPackageId, ex);
    		ExceptionUtils.throwGenerateDocumentPackagesErrors(ex);
		}
	}

	@Override
	public void paperSigning(final String workflowId, final String documentPackageId) {
		SavedApplication savedApp = this.savedApplicationService.retrieveSavedApplication(workflowId);
		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.DOCUMENT_ACTION);
		
		final List<String> docIdList = new ArrayList<>();
		final List<String> documentPackageIds = workflowDocumentPackages(workflowId, documentPackageId, docIdList, null, null);
		if (documentPackageIds == null || documentPackageIds.isEmpty() || !documentPackageIds.contains(documentPackageId) || docIdList.isEmpty()) {
			logger.error("Document Package not Found for documentPackageId: "+ documentPackageId);
			throw new NotFoundException("Document Package not Found.");
		}
		
		HUBHeaderResponse responseHeader = null;
		final ModifyPackagesDestinationsRequest request = new ModifyPackagesDestinationsRequest();
		final ModifyPackagesDestinationsRequest.Body body = hubRequestComponent.requestBodyWithRequestorInfo(new ModifyPackagesDestinationsRequest.Body(), REQUESTOR_ID, "userId");
		
		final ModifyPackagesDestinationsRequest.Body.Packages packages = new ModifyPackagesDestinationsRequest.Body.Packages();
		final ModifyPackagesDestinationsRequest.Body.Packages.Package pack = new ModifyPackagesDestinationsRequest.Body.Packages.Package();
		
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations removeDestinations = new ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations();
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations.Destination removeDestinationEsign = new ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations.Destination();
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations.Destination removeDestinationDTS = new ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations.Destination();
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations.Destination removeDestinationDTSPending = new ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations.Destination();
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations.Destination.KeyValue removeKeyValue = new ModifyPackagesDestinationsRequest.Body.Packages.Package.RemoveDestinations.Destination.KeyValue();
		
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.AddDestinations addDestinations = new ModifyPackagesDestinationsRequest.Body.Packages.Package.AddDestinations();
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.AddDestinations.Destination addDestination = new ModifyPackagesDestinationsRequest.Body.Packages.Package.AddDestinations.Destination();
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.AddDestinations.Destination.KeyValue addKeyValue = new ModifyPackagesDestinationsRequest.Body.Packages.Package.AddDestinations.Destination.KeyValue();
		final ModifyPackagesDestinationsRequest.Body.Packages.Package.AddDestinations.Destination.KeyValue addKeyValueSignatureType = new ModifyPackagesDestinationsRequest.Body.Packages.Package.AddDestinations.Destination.KeyValue();
		
		removeDestinationEsign.setType(DESTINATION_ESIGN);
		removeDestinations.getDestination().add(removeDestinationEsign);
		
		removeDestinationDTSPending.setType(DESTINATION_DTS_PENDING);
		removeDestinations.getDestination().add(removeDestinationDTSPending);
		
		removeDestinationDTS.setType(DESTINATION_DTS);
		removeKeyValue.setKey(PENDING_REFERENCE_EXPIRATION);
		removeDestinationDTS.getKeyValue().add(removeKeyValue);
		removeDestinations.getDestination().add(removeDestinationDTS);
		
		addKeyValue.setKey(PACKAGE_STATUS);
		addKeyValue.setValue(STATUS_PENDING);
		addKeyValueSignatureType.setKey(SIGNATURE_TYPE);
		addKeyValueSignatureType.setValue(SIGNATURE_TYPE_WET_SIGN);
		
		addDestination.setType(DESTINATION_DTS);
		addDestination.getKeyValue().add(addKeyValue);
		addDestination.getKeyValue().add(addKeyValueSignatureType);
		addDestinations.getDestination().add(addDestination);
		
		pack.setAddDestinations(addDestinations);
		pack.setRemoveDestinations(removeDestinations);
		pack.setPackageId(documentPackageId);
		packages.getPackage().add(pack);
		
		body.setRequestorId(userContext.getAuthenticatedUser().getUserId());
		body.setPackages(packages);
		request.setBody(body);
		
		final HUBHeaderRequest requestHeader = createRequestHeader("documentationService", "modifyPackagesDestinations", workflowId,documentPackageId,null,savedApp.getCustomerId());
		
		try {
			documentationService.modifyPackagesDestinations(request, requestHeader, new Holder<HUBHeaderResponse>(responseHeader));
		} catch (Exception e) {
			logger.error("error generated in documentation.modifyDestinations ", e);
    		ExceptionUtils.throwGenerateDocumentPackagesErrors(e);
		}
	}

	@Override
	public DocumentUpdateUploadResponse updateDocument(final String workflowId, final String documentPackageId, String contentType, final DocumentUploadDto request) {
		SavedApplication savedApp = savedApplicationService.retrieveSavedApplication(workflowId);
		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.UPLOAD_DOCUMENT);

		final List<String> documentIds = new ArrayList<>();
		workflowDocumentPackages(workflowId, documentPackageId, documentIds, null, null);
		if (documentIds.isEmpty()) {
			logger.error("Document id not found for package id:  ", documentPackageId);
			throw new NotFoundException("Document id not found for that package");
		}
		DocumentUpdateUploadResponse documentUpdateUploadResponse = null;
		try {
			if (request.getContent().size() > Constants.ONE) {
				final List<StringBuilder> contents = new ArrayList<>();
				StringBuilder builder = null;
				byte[] completeFile = null;
				for (String fileData : request.getContent()) {
					builder = new StringBuilder(fileData);
					contents.add(builder);
				}
				completeFile = DocumentUtilFactory.mergeAll(contents, contentType);
				final List<String> fileData = new ArrayList<>();
				fileData.add(Base64.encodeBase64String(completeFile));
				request.setContent(fileData);
				// In merge it will generate a combined pdf. Anyway it stores only pdfs in filenet.
				contentType = DocumentUtilFactory.PDF;
			}
			
			final DocumentUpdateUploadRequest documentUpdateUploadRequest = new DocumentUpdateUploadRequest();
			final Image image = new Image();
			
			image.setValue(request.getContent().get(Constants.ZERO));
			
			documentUpdateUploadRequest.setProcessFlow(documentUploadProcessFlow);
			documentUpdateUploadRequest.setImage(image);
			enrichRequest(documentUpdateUploadRequest, contentType, documentPackageId);
			
			final HUBHeaderRequest requestHeader = createRequestHeader("imageCaptureService", "documentUpdateUploadEndpoint", workflowId,documentPackageId,null,savedApp.getCustomerId());
		
			final String hubHeader = generateHeaderString(requestHeader);
			documentUpdateUploadResponse = documentUpdateUploadEndpointInterface.captureDocument(documentUpdateUploadRequest, hubHeader);
		} catch (Exception ex) {
			logger.error("Error in capturing document for package id:  ", documentPackageId,ex);
			
			throw new WebServiceException(ex);
		}
		
		if(documentUpdateUploadResponse != null && !ExceptionUtils.STATUS_SUCCESS.equalsIgnoreCase(documentUpdateUploadResponse.getStatus())) {
			final String msg = extractErrorMessage(documentUpdateUploadResponse.getErrors());
			final WebServiceException webEx = new WebServiceException();
			webEx.addContextInfo(ExceptionUtils.MSG_KEY, msg);
			throw webEx;
		}
		
		return documentUpdateUploadResponse;
	}

	String generateHeaderString(final HUBHeaderRequest requestHeader) throws JsonProcessingException {
		return ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
	}
	
	private String extractErrorMessage(final List<Error> errors) {
		final StringBuilder sb = new StringBuilder();
		for (Error error : errors) {
			sb.append(error.getMessage()).append(Constants.SPACE_STRING);
		}
		return sb.toString();
	}
	
	void enrichRequest(final DocumentUpdateUploadRequest request, final String contentType, String documentPackageId) throws Exception {
		request.getImage().setExt(Constants.DOT + contentType);
		final MetaInfo metaInfo = new MetaInfo();
		metaInfo.setValue(hubRequestComponent.getMetaInfo(documentPackageId));
		request.setMetaInfo(metaInfo);
	}

	@Override
	public byte[] print(final String workflowId, final String repositoryId, final String documentPackageId) {
		SavedApplication savedApp = this.savedApplicationService.retrieveSavedApplication(workflowId);
		securityService.authorizeReadAccess(savedApp.getIaCode());
		
		try {
			return retrieveDocumentContent(workflowId, repositoryId, documentPackageId, null, savedApp.getCustomerId());
		} catch (Exception ex) {
			logger.error("Failed to retrieve document content for workflow id: ",workflowId, ex);
			throw new WebServiceException(ex);
		}
	}

	private HUBHeaderRequest createRequestHeader(final String service, final String resourceFunction, final String workflowId, String packageId, String documentId, String ecifId) {
		HeaderBuilder headerBuilder = hubRequestComponent.getHubBuilder()
			.originatorResource(service)
			.originatorResourceFunction(resourceFunction)
			.workflowId(workflowId)
			.packageId(packageId)
			.documentId(documentId)
			.partyId(ecifId);
		
		final HUBHeaderRequest requestHeader = headerBuilder.build();
		
		return requestHeader;
	}
}
