package com.bmo.channel.workflows.parties.service;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.common.domain.party.Person;
import com.bmo.channel.core.util.RequestIdContext;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.workflows.parties.proxy.v2.PartiesV2;

@Service
public class PartiesServiceImpl implements PartiesService {
	static final String NB_LOB_TYPE = "200002";

	@Resource
	PartiesV2 channelPartyApiProxy;

	@Autowired
	PartyMapper partyMapper;

	@Autowired
	RequestIdContext requestIdContext;

	@Autowired
	UserContext userContext;

	@Override
	public String createParty(String firstName, String lastName) {
		Person payload = partyMapper.mapPartyCreate(firstName, lastName);
		populateLobSpecificFields(payload);
		Person response = channelPartyApiProxy.createParty(payload, requestIdContext.getRequestId());

		return response.getEcifId();
	}

	void populateLobSpecificFields(Person payload) {
		if(ApplicationLob.nb == userContext.getAuthenticatedUser().getLob()) {
			payload.setLobType(NB_LOB_TYPE);
		}
	}

	@Override
	public Party getParty(String ecifId) {
		Person person = channelPartyApiProxy.getParty(ecifId, requestIdContext.getRequestId());
		Party party = partyMapper.mapPerson(person);
		return party;
	}
}
