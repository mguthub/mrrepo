package com.bmo.channel.pwob.validation.residence;

import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

/**
 * Validates dependents.
 * @author Ryan Chambers (rcham02)
 */
@Component
public class DependentValidatorImpl extends AbstractBaseValidator implements DependentValidator {

	@Override
	public boolean validateDependents(Identity identity, boolean isPrimaryApplicantSpouse, ValidationRequest request) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(identity == null || validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		boolean valid = true;
		boolean validateDependents = true;
		if(isPrimaryApplicantSpouse){
			if(identity.getAreDependentsSameAsSpouse() == null){
				request.setErrorCode(ErrorCodes.INVALID_ARE_DEPENDENTS_SAMEASSPOUSE);
				request.setFieldName(ARE_DEPENDENTS_SAMEASSPOUSE_FIELD_NAME);
				request.addConstraintViolation();
				valid = false;
				validateDependents = false;
			}else if(identity.getAreDependentsSameAsSpouse()){
				validateDependents = false;
			}
		}
		
		if(validateDependents && !isSpecifyDependentsValid(identity, request.getLob())) {
			request.setErrorCode(ErrorCodes.INVALID_HAS_DEPENDENTS);
			request.setFieldName(HAD_DEPENDENTS_FIELD_NAME);
			request.addConstraintViolation();
			valid = false;
		}

		if(!areNumDependentsValid(identity)) {
			request.setErrorCode(ErrorCodes.INVALID_NUM_OF_DEPENDENTS);
			request.setFieldName(NUM_OF_DEPENDENTS_FIELD_NAME);
			request.addConstraintViolation();
			valid = false;
		}
		return valid;
	}

	/**
	 * @param personalInformation
	 * @param lob
	 * @return True if dependents are specified (true) and is required. False otherwise
	 */
	boolean isSpecifyDependentsValid(Identity identity, ApplicationLob lob) {
		if(ApplicationLob.nb == lob) {
			// must not be specified
			return identity.getHasDependents() != null;
		} else {
			//return identity.getHasDependents() == null;
			return identity.getHasDependents() != null;
		}
	}

	boolean areNumDependentsValid(Identity identity) {
		if(identity.getHasDependents() == null) {
			return true;
		}

		if(identity.getHasDependents()) {
			Integer num = identity.getNumOfDependents();
			if(num == null) {
				return false;
			} else {
				return num > 0 && num <= 99;
			}
		} else {
			// must be null or 0 if has dependents = false
			return identity.getNumOfDependents() == null || identity.getNumOfDependents() == 0;
		}
	}
}
