package com.bmo.channel.pwob.validation.applications;

import java.util.EnumSet;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.SavedApplicationsFilter;
import com.bmo.channel.pwob.service.authorization.SecurityService;
import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.service.reference.ReferencesService;

public class SavedApplicationsFilterValidator implements ConstraintValidator<ValidSavedApplicationsFilter, SavedApplicationsFilter> {

	enum FilterScenario{ 
		PAGE, NAME, IA_CODE, CUSTOMER_ID;
	}

	@Autowired
	private ReferencesService referencesService;
	
	@Autowired
	private SecurityService securityService;
	
	@Override
	public void initialize(ValidSavedApplicationsFilter constraintAnnotation) {	}

	@Override
	public boolean isValid(SavedApplicationsFilter filter, ConstraintValidatorContext context) {	
		
		if(!this.isValidScenario(filter) || !this.isValidAppStatus(filter.getAppStatus())) {
			return false;
		}
		return true;		
	}

	private boolean isValidAppStatus(String status) {
		if(Optional.ofNullable(status).isPresent()) {
			Optional<Reference> statusRef = 
					referencesService.ofType(ReferenceType.APPLICATION_STATUS, UILocale.EN_CA)
					.stream()
					.filter(c -> c.getCode().equalsIgnoreCase(status))
					.findFirst();

			return statusRef.isPresent();
		}
				
		return true;
	}
	
	private EnumSet<FilterScenario> calculateFilterScenarios(SavedApplicationsFilter filter) {
		
		EnumSet<FilterScenario> result = EnumSet.noneOf(FilterScenario.class);
		
		if (Optional.ofNullable(filter.getPageNum()).isPresent() || Optional.ofNullable(filter.getNumPerPage()).isPresent())
			result.add(FilterScenario.PAGE);			
		
		if (StringUtils.isNoneBlank(filter.getFirstName()) || StringUtils.isNoneBlank(filter.getLastName()))
			result.add(FilterScenario.NAME);
		
		if (filter.getIaCodes() != null && !filter.getIaCodes().isEmpty())
			result.add(FilterScenario.IA_CODE);
		
		if(filter.getCustomerIds() != null && !filter.getCustomerIds().isEmpty())
			result.add(FilterScenario.CUSTOMER_ID);
		
		return result;
		
	}
	
	/**
	 * The valid IA code request in filter must be the in current user's iaCodes list or in the iaCodes list of any Ias the user may support
	 * @param filter
	 * @return
	 */
	private boolean isValidIaCodeRequest(SavedApplicationsFilter filter) {
		
		if (CollectionUtils.isNotEmpty(filter.getIaCodes())) {
			for(String iaCode: filter.getIaCodes()){
				securityService.authorizeReadAccess(iaCode);
			}
		}
		
		return true;
	}

	
	private boolean isValidCustomerIdRequest(SavedApplicationsFilter filter) {
		// TODO - implement for IL
		return true;
	}
	
	/**
	 * must be a valid filter and 
	 * if no app status, "page" filter must be not specified and
	 * if it's ia code request, then validate ia code and
	 * if it's network id request, then validate network id
	 * if page is presented, then both params need to be presented
	 * @param filter
	 * @return
	 */
	private boolean isValidScenario(SavedApplicationsFilter filter) {
		EnumSet<FilterScenario> filterScenarios = calculateFilterScenarios(filter);
		boolean valid = filterScenarios.size() == 1 && 
			(StringUtils.isBlank(filter.getAppStatus()) ? !filterScenarios.contains(FilterScenario.PAGE) : true) &&
			(filterScenarios.contains(FilterScenario.PAGE) ? Optional.ofNullable(filter.getPageNum()).isPresent() && Optional.ofNullable(filter.getNumPerPage()).isPresent() : true) &&
			(filterScenarios.contains(FilterScenario.IA_CODE) ? this.isValidIaCodeRequest(filter) : true) &&
			(filterScenarios.contains(FilterScenario.CUSTOMER_ID) ? isValidCustomerIdRequest(filter) : true);
		if(valid) {
			return true;
		}

		// TODO WMPWO-1997 if status set, return true until pagination is implemented
		return StringUtils.isNotBlank(filter.getAppStatus());
	}
}
