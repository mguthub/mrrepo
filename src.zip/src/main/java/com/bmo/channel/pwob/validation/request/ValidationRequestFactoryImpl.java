package com.bmo.channel.pwob.validation.request;

import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.validation.field.FieldPathExtractor;

@Component
public class ValidationRequestFactoryImpl implements ValidationRequestFactory {

	@Autowired
	private FieldPathExtractor fieldPathExtractor;

	@Override
	public ValidationRequest create(ConstraintValidatorContext context, ApplicationLob applicationLob) {
		ValidationRequest validationRequest = new ValidationRequest(context, applicationLob);
		validationRequest.setFieldPath(fieldPathExtractor.determineFieldPath(context));
		return validationRequest;
	}

	@Override
	public ValidationRequestBuilder createBuilder(ConstraintValidatorContext context, ApplicationLob applicationLob) {
		return new ValidationRequestBuilder(create(context, applicationLob));
	}

	public static class ValidationRequestBuilder {
		private ValidationRequest validationRequest;

		ValidationRequestBuilder(ValidationRequest validationRequest) {
			this.validationRequest = validationRequest;
		}

		public ValidationRequest build() {
			return validationRequest;
		}

		public ValidationRequestBuilder withParentPropertyNode(String parentPropertyNode) {
			validationRequest.setParentPropertyNode(parentPropertyNode);
			return this;
		}

		public ValidationRequestBuilder withParentFieldPath(String parentFieldPath) {
			validationRequest.setParentFieldPath(parentFieldPath);
			return this;
		}

		public ValidationRequestBuilder withChildPropertyNode(String childPropertyNode) {
			validationRequest.setChildPropertyNode(childPropertyNode);
			return this;
		}

		public ValidationRequestBuilder withChildFieldPath(String childFieldPath) {
			validationRequest.setChildFieldPath(childFieldPath);
			return this;
		}
	}
}
