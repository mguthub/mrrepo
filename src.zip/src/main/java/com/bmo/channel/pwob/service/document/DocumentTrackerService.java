package com.bmo.channel.pwob.service.document;

public interface DocumentTrackerService {
	public Boolean generateDocumentPackages(final String workflowId);
	public void unlock(String workflowId);	
}
