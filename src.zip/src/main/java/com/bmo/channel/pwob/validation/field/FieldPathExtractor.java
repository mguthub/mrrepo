package com.bmo.channel.pwob.validation.field;

import javax.validation.ConstraintValidatorContext;

public interface FieldPathExtractor {

	String determineFieldPath(ConstraintValidatorContext context);

}
