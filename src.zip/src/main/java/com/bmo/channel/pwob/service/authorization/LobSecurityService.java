package com.bmo.channel.pwob.service.authorization;

import com.bmo.channel.pwob.model.user.User;

/**
 * Service for applying Line of Business (LOB)-specific security checks.
 * @author Ryan Chambers (rcham02)
 */
public interface LobSecurityService {

	void authorizeAction(User user, String userAccessCode, String appStatus, PwobAction action);

	void authorizeReadAccess(User user, String userAccessCode);

}
