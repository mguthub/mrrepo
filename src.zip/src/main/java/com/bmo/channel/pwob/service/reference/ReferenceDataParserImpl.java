package com.bmo.channel.pwob.service.reference;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.mapping.ReferenceMapper;
import com.bmo.channel.pwob.service.reference.model.DataAndMapping;
import com.bmo.channel.pwob.service.reference.model.GetDataListForParameterResponseBody;
import com.bmo.channel.pwob.service.reference.model.Parameters;
import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.RefDataSet;
import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.ValueType;

@Component
public class ReferenceDataParserImpl implements ReferenceDataParser {
	
	private static Logger logger = LoggerFactory.getLogger(ReferenceDataParserImpl.class);
	private static final int REFERENCE_BEGIN_SNIPPET_LENGTH = "<![CDATA[<?xml version=\"1.0\" encoding=\"UTF-8\"?>".length();
	private static final int REFERENCE_END_SNIPPET_LENGTH = "]]>".length();
	private static final int MAPPING_BEGIN_SNIPPET_LENGTH = "<![CDATA[".length();
	private static final int MAPPING_END_SNIPPET_LENGTH = "]]>".length();
	private static final String RIS_ECIF_MAPPING_SEPERATOR = "\\^\\^";
	private static final String RIS_ECIF_VALUE_SEPERATOR = "~~";
	
	@Autowired ReferencesService ReferencesService;
	
	@Override
	public Map<UILocale, List<Reference>> extractReferenceList(ReferenceType referenceType, GetDataListForParameterResponseBody dataListForParameter, UILocale locale) {
		//List<Reference> references;
		Map<UILocale, List<Reference>> refMap = new HashMap<>();
		
		Map<String, String> codeListMap = new HashMap<>();
		for(Parameters param: dataListForParameter.getParameters()) {
			codeListMap.put(param.getCode(), param.getValue());
		}

		DataAndMapping referenceData = new DataAndMapping();
		if(StringUtils.isEmpty(codeListMap.get(referenceType.getDataRefCode()))){
			logger.debug("Reference service error - Reference data xml not found for "+ referenceType.name());
			throw new NotFoundException("Reference service error - Reference data xml is null for" + referenceType.name());
		}
		referenceData.setReferenceData(parseReferenceData(codeListMap.get(referenceType.getDataRefCode())));
		if (referenceType.getMappingRefCode() != null) {
			referenceData.setMappingData(parseMappingData(codeListMap.get(referenceType.getMappingRefCode())));
		}
		else {
			referenceData.setMappingData(null);
		}
		
		try {
			ReferenceMapper mapper = referenceType.getReferenceMapper().newInstance();
			
			// loop for both locale values
			
			Arrays.asList(UILocale.values()).stream().forEach(loc ->{
				List<Reference> references;
				if(loc.equals(UILocale.EN_CA)){
					references = mapper.mapToReferenceListEN(referenceData);
					references.removeIf(Objects::isNull);
					refMap.put(UILocale.EN_CA, references);
				} else if(loc.equals(UILocale.FR_CA)){
					
				//if french translation not found, log error message 
				Optional<ValueType> val = referenceData.getReferenceData().stream().filter(trans -> null == trans.getTranslations().getTranslation() || trans.getTranslations().getTranslation().isEmpty()).findFirst();
				if(val.isPresent()){ 
					logger.error("Reference service: "+" Type -> " +referenceType.name() + ", French translation not present");
				}
					references = mapper.mapToReferenceListFR(referenceData);
					references.removeIf(Objects::isNull);
					refMap.put(UILocale.FR_CA, references);
				}
			});			
							
			return refMap;

		} catch (InstantiationException | IllegalAccessException ex) {
			logger.error("Failed to extract reference data",ex);
			throw new WebServiceException(ex);
		}
		catch (NullPointerException ex){
			logger.error("Failed to extract reference data",ex);
			throw new NotFoundException("Reference service error - Reference data of source " + referenceType.name()+" not valid. Exception:" + ex.getCause());
		}
	}

	List<ValueType> parseReferenceData(String referenceDataXml) {
		String dataXml = removeCdataTagsForRefData(referenceDataXml);

		try {
			JAXBContext jaxbContext = JAXBContext.newInstance(RefDataSet.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			RefDataSet refDataSet = (RefDataSet) jaxbUnmarshaller.unmarshal(new ByteArrayInputStream(dataXml.getBytes("UTF-8")));
			return sortReferences(refDataSet.getRefDataValue());
		} catch (JAXBException | UnsupportedEncodingException ex) {
			logger.error("Failed to parse reference data: ",referenceDataXml,ex);
			throw new WebServiceException(ex);
		}
	}
	
	List<ValueType> sortReferences(List<ValueType> refDataValue) {
		refDataValue.sort(new Comparator<ValueType>() {
			public int compare(ValueType o1, ValueType o2) {
				if (o1.getSortOrder() == null && o2.getSortOrder() != null)
					return -1;
				if (o1.getSortOrder() != null && o2.getSortOrder() == null)
					return 1;
				if (o1.getSortOrder() == null && o2.getSortOrder() == null)
					return 0;
					
				if (StringUtils.isBlank(o1.getSortOrder().getValue()) && StringUtils.isNotBlank(o2.getSortOrder().getValue()))
					return -1;
				if (StringUtils.isNotBlank(o1.getSortOrder().getValue()) && StringUtils.isBlank(o2.getSortOrder().getValue()))
					return 1;
				if (StringUtils.isBlank(o1.getSortOrder().getValue()) && StringUtils.isBlank(o2.getSortOrder().getValue()))
					return 0;
					
				Integer int1;
				Integer int2;
				
				try{
					int1 = Integer.parseInt(o1.getSortOrder().getValue());
				}
				catch(NumberFormatException ex) {
					logger.error("Failed to parse valueType to sort references: ",o1.getSortOrder().getValue(),ex);
					return -1;
				}
				
				try{
					int2 = Integer.parseInt(o2.getSortOrder().getValue());
				}
				catch(NumberFormatException ex) {
					logger.error("Failed to parse valueType to sort references: ",o2.getSortOrder().getValue(),ex);
					return 1;
				}
				
				return int1 - int2;
			}
		});
		
		return refDataValue;
	}

	Map<String, String> parseMappingData(String rawMapping) {
		rawMapping = removeCdataTagsForMapping(rawMapping);
		Map<String, String> mappings = new HashMap<>();
		
		String [] rawEntries = rawMapping.split(RIS_ECIF_MAPPING_SEPERATOR);
		for (int i=0; i<rawEntries.length; i++) {
			String [] entry = rawEntries[i].split(RIS_ECIF_VALUE_SEPERATOR);
			mappings.put(entry[1], entry[0]);
		}
		
		return mappings;
	}

	/**
	 * Format of XML received is:
	 * <![CDATA[<?xml version="1.0" encoding="UTF-8"?><p:RefDataSet ...  </p:RefDataSet>]]>
	 * Remove the two enclosing and one trailing CDATA tags.
	 * @param xml
	 * @return xml with initial two enclosing and one trailing CDATA tags removed
	 */
	String removeCdataTagsForRefData(String xmlValue) {
		return xmlValue.substring(REFERENCE_BEGIN_SNIPPET_LENGTH, xmlValue.length() - REFERENCE_END_SNIPPET_LENGTH);
	}
	
	String removeCdataTagsForMapping(String xmlValue) {
		return xmlValue.substring(MAPPING_BEGIN_SNIPPET_LENGTH, xmlValue.length() - MAPPING_END_SNIPPET_LENGTH);
	}
}
