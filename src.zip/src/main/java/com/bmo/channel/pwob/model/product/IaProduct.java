package com.bmo.channel.pwob.model.product;

import java.util.ArrayList;
import java.util.List;

import com.bmo.channel.pwob.service.product.rsclient.AccountType.FeeCodeList;

/**
 * @author vvallia
 *
 */
public class IaProduct extends ProductEligibility {
	protected List<FeeCodeList> feeCodes;

	public List<FeeCodeList> getFeeCodes() {
		if (feeCodes == null) {
			feeCodes = new ArrayList<>();
		}
		return this.feeCodes;
	}

	public void setFeeCodes(List<FeeCodeList> feeCodes) {
		if (feeCodes == null) {
			this.feeCodes = new ArrayList<>();
		} else {
			this.feeCodes = feeCodes;
		}
	}
}
