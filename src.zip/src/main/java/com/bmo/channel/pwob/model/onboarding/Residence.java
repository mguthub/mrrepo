package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Residence {
		
	private Boolean hasAlternateAddress;

	@Valid
	private Address primaryAddress;
	
	@Valid	
	private Address previousAddress;

	@Valid	
	private Phone primaryPhone;

	@Valid	
	private Phone secondaryPhone;	
	
	@ApiModelProperty(value="Only populate for Joint Applicant")
	private String primaryAddressSourceOption ;	
	
	@ApiModelProperty(value="Only populate for Joint Applicant")
	private String alternateAddressSourceOption;	

	@Valid
	@ApiModelProperty(value="Only populate if hasAlternateAddress is true")	
	private AlternateAddress alternateAddress;

	public Address getPreviousAddress() {
		return previousAddress;
	}

	public void setPreviousAddress(Address previousResidentialAddress) {
		this.previousAddress = previousResidentialAddress;
	}

	public Phone getPrimaryPhone() {
		return primaryPhone;
	}

	public void setPrimaryPhone(Phone primaryPhone) {
		this.primaryPhone = primaryPhone;
	}

	public Phone getSecondaryPhone() {
		return secondaryPhone;
	}

	public void setSecondaryPhone(Phone secondaryPhone) {
		this.secondaryPhone = secondaryPhone;
	}

	public Boolean getHasAlternateAddress() {
		return hasAlternateAddress;
	}

	public void setHasAlternateAddress(Boolean hasAlternateAddress) {
		this.hasAlternateAddress = hasAlternateAddress;
	}

	public AlternateAddress getAlternateAddress() {
		return alternateAddress;
	}

	public void setAlternateAddress(AlternateAddress alternateAddress) {
		this.alternateAddress = alternateAddress;
	}	

	public Address getPrimaryAddress() {
		return primaryAddress;
	}

	public void setPrimaryAddress(Address primaryAddress) {
		this.primaryAddress = primaryAddress;
	}
	
	public String getAlternateAddressSourceOption() {
		return alternateAddressSourceOption;
	}

	public void setAlternateAddressSourceOption(String alternateAddressSourceOption) {
		this.alternateAddressSourceOption = alternateAddressSourceOption;
	}
	
	public String getPrimaryAddressSourceOption() {
		return primaryAddressSourceOption;
	}

	public void setPrimaryAddressSourceOption(String primaryAddressSourceOption) {
		this.primaryAddressSourceOption = primaryAddressSourceOption;
	}

}
