package com.bmo.channel.pwob.service.applications;

import java.util.List;

import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.applications.Summary;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.SavedApplicationsResponse;

public interface SavedApplicationsService {
	SavedApplicationsResponse retrieveSavedApplicationsByAppStatusWithPagination(String appStatus, int pageNumber, int numberPerPage);
	SavedApplicationsResponse retrieveSavedApplicationsByAppStatusFirstNameLastName(String appStatus, String firstName, String lastName);
	SavedApplicationsResponse retrieveSavedApplicationsByFirstNameLastName(String firstName, String lastName);
	
	//get a specific app status by iaCode
	SavedApplicationsResponse retrieveSavedApplicationsByIaCode(String appStatus, List<String> iaCode);
	//get all apps by iaCode
	SavedApplicationsResponse retrieveSavedApplicationsByIaCode(List<String> iaCode);
	SavedApplicationsResponse retrieveSavedApplicationsByCustomerId(List<String> ecifId);
	
	Summary retrieveApplicationsSummary(String iaCode);
	
	SavedApplication retrieveSavedApplication(String workflowId);
	SavedApplicationsResponse retrieveSavedApplicationsByAppStatusIaCodesFirstNameLastName(String appStatus, List<String> iaCodes, String firstName, String lastName);
}
