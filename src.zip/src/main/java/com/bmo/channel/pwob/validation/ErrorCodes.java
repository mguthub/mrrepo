package com.bmo.channel.pwob.validation;

public interface ErrorCodes {

	public final String INVALID_APPLY_INVESTMENT_OBJECTIVES_TO_ACCOUNTS = "invalidApplyInvestmentObjectivesToAccounts";

	public final String INVALID_CREDIT_BUREAU_CONSENT = "invalidCreditBureauConsent";

	public final String INVALID_NUM_OF_DEPENDENTS = "invalidNumOfDependents";
	public final String INVALID_COAPPLICANT_TITLE = "invalidCoApplicantTitle";
	public final String INVALID_TITLE = "invalidTitle";
	public final String INVALID_LOB = "invalidLob";
	public final String INVALID_LOCALE = "invalidLocale";
	public final String INVALID_CLIENT_METADATA = "invalidClientMetadata";
	public final String INVALID_VERSION = "invalidVersion";
	public final String INVALID_COUNTRY = "invalidCountry";
	public final String INVALID_PROVINCE = "invalidProvince";
	public final String INVALID_IS_PLACE_OF_BIRTH_US = "invalidIsPlaceOfBirthUS";
	public final String INVALID_HAS_DEPENDENTS = "invalidHasDependents";
	public final String INVALID_ARE_DEPENDENTS_SAMEASSPOUSE = "invalidAreDependentsSameAsSpouse";
	public final String INVALID_PRIMARY_COUNTRY = "primaryResidenceMustBeCanada";
	
	public final String INVALID_UNIT_NUMBER = "invalidUnitNumber";
	public final String INVALID_STREET_ADDR = "invalidStreetAddress";
	public final String INVALID_POSTAL_CODE = "invalidPostalCode";
	public final String INVALID_CITY = "invalidCity";

	public final String INVALID_FIRST_NAME = "invalidFirstName";
	public final String INVALID_MIDDLE_NAME = "invalidMiddleName";
	public final String INVALID_LAST_NAME = "invalidLastName";
	public final String INVALID_PHONE = "invalidPhone";
	public final String INVALID_BUSINESS_PHONE = "invalidBusinessPhone";
	
	public final String INVALID_PHONE_EXT = "invalidPhoneExt";
	public final String INVALID_PHONE_FOR_EXTENSION = "invalidPhoneForExtension";
	public final String INVALID_PHONE_COUNTRY_CODE = "invalidPhoneCountryCode";
	public final String INVALID_SIN = "invalidSocialInsuranceNumber";
	public final String INVALID_BUSINESS_NAME = "invalidBusinessName";
	public final String INVALID_PRIMARY_EMAIL = "invalidPrimaryEmailAddress";

	public final String INVALID_OTHER_SRC = "invalidOtherSources";
	public final String INVALID_HAS_OTHER_INVESTMENT_ACCT = "invalidHasOtherInvestmentAcct";
	public final String INVALID_OTHER_INVESTMENT_INSTITUTION = "invalidOtherInvestmentInstitution";
	public final String INVALID_SPOUSE_FIRST_NAME = "invalidSpouseFirstName";
	public final String INVALID_SPOUSE_MIDDLE_NAME = "invalidSpouseMiddleName";
	public final String INVALID_SPOUSE_LAST_NAME = "invalidSpouseLastName";
	public final String INVALID_SRC_WEALTH = "invalidSourceOfWealth";
	public final String INVALID_OTHER_SOURCE_WEALTH = "invalidOtherSourceOfWealth";
	
	public final String INVALID_ACCOUNT_IS_SPOUSAL = "invalidIsSpousal";
	public final String INVALID_ACCOUNT = "invalidAccount";
	public final String INVALID_ACCOUNT_NAME = "invalidAccountName";
	public final String INVALID_ACCOUNT_TYPES = "invalidAccountTypes";
	public final String INVALID_ACCOUNT_NUMBER = "invalidAccountNumber";
	public final String INVALID_SUB_TYPE = "invalidAccountSubtypes";
	public final String INVALID_ACCOUNT_INTENDED_USE = "invalidAccountIntendedUse";	
	public final String INVALID_ACCOUNT_INVESTMENT_TIME_HORIZON = "invalidAccountInvestmentTimeHorizon";
	public final String INVALID_SUCCESSOR_ANNUITANT = "invalidSuccessorAnnuitant";
	public final String INVALID_SPOUSE_AGE_USED = "invalidSpouseAgeUsed";

	public final String INVALID_ACCOUNT_SUBTYPES="invalidAccountFeatures";
	public final String INVALID_ACCOUNT_LINK_DEBIT_CARD ="invalidAccountLinkDebitCard";
	public final String INVALID_ACCOUNT_DEBIT_CARD ="invalidAccountDebitCard";
	public final String INVALID_ACCOUNT_LINK_TYPE = "invalidAccountLinkType";
	public final String INVALID_INTENDED_USE_DESCRIPTION = "invalidOtherDescription";
	public final String INVALID_ACCOUNT_REF_IDS = "sameRefIdUsedOnMultipleAccounts";

	public final String INVALID_ACCOUNT_BANK_US_FUNDS = "invalidBankUsFunds";
	
	public final String INVALID_ACCOUNT_OPTIONS_TRADING = "invalidOptionsTrading";
	public final String INVALID_ACCOUNT_HAS_OPTIONS_TRADING = "invalidHasOptionsTrading";
	public final String INVALID_ACCOUNT_KNOWLEDGE = "invalidAccountKnowledge";
	public final String INVALID_ACCOUNT_OPTION_TYPE_EXPERIENCES = "invalidOptionTypeExperiences";
	public final String INVALID_ACCOUNT_OPTION_TYPES = "invalidOptionTypes";
	
	public final String INVALID_ACCOUNT_HAS_BENEFICIARIES = "invalidHasBeneficiaries";
	public final String INVALID_ACCOUNT_BENEFICIARIES = "invalidBeneficiaries";
	public final String INVALID_ACCOUNT_TYPE_FOR_BENEFICIARIES = "accountTypeShouldNotHaveBeneficiaryInformation";
	public final String INVALID_ACCOUNT_HAS_THIRD_PARTY_INTEREST = "invalidHasThirdPartyInterest";

	public final String INVALID_PAST_INVESTMENT_EXPERIENCE = "invalidPastInvestmentExperience";
	public final String INVALID_ALT_INVESTMENT_EXPERIENCE = "invalidAltInvestmentExperience";
	public final String INVALID_INVESTMENT_KNOWLEDGE = "invalidInvestmentKnowledge";
	public final String INVALID_DATE = "invalidDate";
	public final String INVALID_FLAG_IS_MOBILE_FLAG="invalidFlagIsMobilePhone";
	public final String INVALID_FLAG_IS_BMO_EMPLOYEE="invalidFlagIsBMOEmployee";
	public final String INVALID_FLAG_IS_RETIRED_BMO_EMPLOYEE="invalidFlagRetiredBmoEmployee";
	public final String INVALID_FLAG_HAS_OTHER_INVESTMENT_ACCOUNTS="invalidFlagHasOtherInvestmentAccounts";
	public final String INVALID_IS_BORROWING_TO_INVEST="invalidIsBorrowingToInvest";
	public final String INVALID_FLAG_LIVED_IN_LESS_THAN_TWO_YEARS="invalidFlagLivedInLessThanTwoYears";
	public final String INVALID_PRIMARY_ADDRESS_SOURCE="invalidPrimaryAddressSource";	
	public final String INVALID_FLAG_HAS_PREFERRED_NAME="invalidFlagHasPreferredName";
	public final String INVALID_PREFERRED_LANGUAGE = "invalidPreferredLanguage";
	public final String INVALID_INVESTMENT_OBJECTIVES = "invalidInvestmentObjectives";
	public final String INVALID_IS_POLITICALLY_EXPOSED_PERSON = "invalidIsPoliticallyExposedPerson";
	public final String INVALID_POLITICALLY_EXPOSED_POSITION = "invalidPoliticallyExposedPersonPosition";
	public final String INVALID_POLITICALLY_EXPOSED_TYPE = "invalidPoliticallyExposedType";
	public final String INVALID_IIROC_ORGANIZATIONS = "invalidIirocOrganizations";
	public final String INVALID_IIROC_MEMBER = "invalidIirocMember";
	public final String INVALID_RECEIVE_SECURITY_HOLDER_OPTIONS = "invalidReceiveSecurityHolderOptions";
	public final String INVALID_FLAG_SHARE_PERSONAL_INFO="invalidFlagSharePersonalInfo";
	public final String INVALID_FLAG_RECEIVE_DIRECT_MARKETING_MATERIALS="invalidFlagReceiveDirectMarketingMaterials";
	public final String INVALID_FLAG_DISCLOSE_BENEFICIAL_OWNER="invalidFlagDiscloseBeneficialOwner";
	public final String INVALID_FLAG_RECEIVE_ELECTRONIC_DELIVERY="invalidFlagReceiveElectronicDelivery";		
	public final String INVALID_FLAG_HAVE_INSIDER_RELATIONSHIP="invalidFlagHaveInsiderRelationship";
	public final String INVALID_INSIDER_RELATIONSHIPS="invalidInsiderRelationships";
	public final String INVALID_FLAG_CONTROL_RELATIONSHIP = "invalidFlagControlRelationship";
	public final String INVALID_CONTROL_RELATIONSHIPS="invalidControlRelationships";
	public final String INVALID_FLAG_IS_REPORTING_INSIDER="invalidFlagIsReportingInsider";
	public final String INVALID_REPORTING_INSIDER_RELATIONSHIPS = "invalidReportingInsiderRelationships";
	public final String INVALID_FLAG_SIGNIFICANT_SHAREHOLDER="invalidFlagSignificantShareholder";	
	public final String INVALID_SIGNIFICANT_SHAREHOLDINGS="invalidSignificantShareholdings";	
	public final String INVALID_FLAG_INVESTMENT_OBJECTIVES="invalidFlagInvestmentObjectives";
	public final String INVALID_BMO_COMPANY_CODES="invalidBmoCompanyCodes";
	public final String INVALID_BMO_GROUP="invalidBmoGroup";
	public final String INVALID_RETIRED_BMO_GROUP="invalidRetiredBmoGroup";
	public final String INVALID_OCCUPATION_TYPES="invalidOccupationTypes";
	public final String INVALID_BUSINESS_NATURES="invalidNatureOfBusiness";
	public final String INVALID_EMPLOYER_BUSINESS_NAME = "invalidEmployerBusinessName";
	public final String INVALID_EMPLOYMENT_STATUS="invalidEmploymentStatus";
	public final String INVALID_JOB_TITLE = "invalidJobTitle";
	public final String INVALID_PASSWORD = "invalidPassword";

	public final String INVALID_RISK_TOLERANCE = "invalidRiskTolerance";
	public final String INVALID_RISK_TOLERANCE_LOW = "invalidRiskToleranceLow";
	public final String INVALID_RISK_TOLERANCE_MEDIUM = "invalidRiskToleranceMedium";
	public final String INVALID_RISK_TOLERANCE_HIGH = "invalidRiskToleranceHigh";
	
	public final String INVALID_RISK_TOLERANCE_NOT_EQUAL_100 = "riskToleranceNotSumTo100";			
		
	public final String INVALID_TARGET_ALLOCATION = "invalidTargetAllocation";	
	public final String INVALID_TARGET_ALLOCATION_CASH = "invalidTargetAllocationCash";
	public final String INVALID_TARGET_ALLOCATION_EQUITIES = "invalidTargetAllocationEquities";
	public final String INVALID_TARGET_ALLOCATION_FIXED_INCOME = "invalidTargetAllocationFixedIncome";
	
	public final String INVALID_TARGET_ALLOCATION_TOTAL_CASH_EQUITIES_FIXEDINCOME_100 = "invalidTargetAllocationTotalCashEquitiesFixedIncome100";

	public final String INAVLID_REGULATORY_DISCLOSURES_TOTAL_SHAREHOLDERS_100 = "RegulatoryDisclosuresTotalShareHolders00";

	public final String INVALID_NEW_WORKFLOW_REQUEST = "firstAndLastNamesMustBePresentOrAnEcifId";
	public final String INVALID_NEW_WORKFLOW_REQUEST_IA_CODE = "invalidIACode";
	
	public final String INVALID_MARITAL_STATUS = "invalidMaritalStatus";
	public final String INVALID_ENTITLEMENT = "invalidEntitlement";
	public final String INVALID_ENTITLEMENT_ALLOCATION = "invalidEntitlementAllocation";
	public final String INVALID_RELATIONSHIP_TO_PLAN_HOLDER = "invalidRelationshipToPlanHolder";
	public final String INVALID_HAS_CONTINGENT_BENEFICIARY = "invalidHasContingentBeneficiary";
	public final String INVALID_CONTINGENT_BENEFICIARY_NUMBER = "invalidNumberOfContingentBeneficiaries";
	public final String INVALID_DATE_OF_BIRTH = "invalidDateOfBirth";
	public final String INVALID_TAX_RESIDENCIES = "invalidResidencyForTax";
	public final String INVALID_CANADIAN_TAX_RESIDENCY = "invalidResidencyForTaxForCanada";
	public final String INVALID_TAX_RESIDENCY_DUPLICATE_COUNTRY = "invalidDuplicateTaxResidencyCountry";

	public final String INVALID_HAS_TAX_RESIDENCY = "invalidHasTaxResidency";
	public final String INVALID_TAX_ID_MISSING_REASON = "invalidTaxIdMissingReason";
	public final String INVALID_TAX_ID_MISSING_REASON_DESC = "invalidTaxIdMissingReasonDesc";		

	public final String INVALID_APPLICATION_ID = "invalidApplicationId";
	public final String INVALID_CITIZENSHIP = "invalidCitizenship";
	
	public final String INVALID_ALTERNATE_ADDRESS = "invalidAlternateAddress";
	public final String INVALID_HAS_ALTERNATE_ADDRESS = "invalidHasAlternateAddress";
	
	/** Financial information - Income details. */
	public final String INVALID_ANNUAL_EMPLOYMENT_INCOME = "invalidAnnualEmploymentIncome";
	public final String INVALID_ANNUAL_INVESTMENT_INCOME = "invalidAnnualInvestmentIncome";
	public final String INVALID_ANNUAL_OTHER_INCOME = "invalidAnnualOtherIncome";
	public final String INVALID_ANNUAL_OTHER_INCOME_SOURCE = "invalidOtherIncomeSource";
	public final String INVALID_ANNUAL_OTHER_INCOME_DESCRIPTION = "invalidOtherIncomeSourceDescription";
	public final String INVALID_LIQUID_ASSETS = "invalidLiquidAssets";
	public final String INVALID_FIXED_ASSETS = "invalidFixedAssets";
	
	/** Communication preferences. */
	public final String INVALID_DISCLOSE_BENEFICIAL_OWNER = "invalidDiscloseBeneficialOwner";
	public final String INVALID_RECEIVE_DIRECT_MARKETING_MATERIALS = "invalidReceiveDirectMarketingMaterials";
	public final String INVALID_RECEIVE_ELECTRONIC_DELIVERY = "invalidReceiveElectronicDelivery";
	public final String INVALID_SHARE_PERSONAL_INFO = "invalidSharePersonalInfo";
	public final String INVALID_RECEIVE_SECURITY_HOLDER_MATERIALS = "invalidReceiveSecurityHolderMaterials";
	public final String INVALID_DOCUMENT_PREFERENCE_OPTION = "invalidDocumentPreferenceOption";
	public final String INVALID_IS_RECEIVE_STATEMENTS_BY_MAIL = "invalidIsReceiveStatementByMail";	
	public final String INVALID_IS_ACCOUNT_STATEMENTS = "invalidIsAccountStatements";
	public final String INVALID_IS_TRADE_CONFIRMATIONS = "invalidIsTradeConfirmations";
	public final String INVALID_IS_SETUP_ALTERNATE_MAILINGS = "invalidIsSetupAlternateMailings";
	public final String INVALID_ALTERNATE_MAILING_ADDRESSES = "invalidAlternateMailingAddresses";
	public final String INVALID_RECIPIENT = "invalidRecipient";
	
	/** ID Verification fields	 */
	public final String INVALID_EXPIRY_DATE = "invalidexpiryDate";
	public final String INVALID_ID_NUMBER = "invalidIdNumber";
	//public final String INVALID_VERIFIED_BY = "invalidVerifiedBy";
	public final String INVALID_ID_VERIFICATION_METHOD = "invalidIdVerificationMethod";
	public final String INVALID_DOCUMENT_TYPE = "invalidDocumentType";
	public final String INVALID_COUNTRY_OF_BIRTH = "invalidCountryOfBirth";
	public final String INVALID_IS_PLACE_OF_BIRTH = "invalidIsPlaceOfBirthUS";
	
	public final String INVALID_VERIFICATION = "invalidVerification";
	public final String INVALID_VERIFIED_EMPLOYEE_FIRST_NAME="invalidEmployeeFirstName";
	public final String INVALID_VERIFIED_EMPLOYEE_LAST_NAME="invalidEmployeeLastName";
	public final String INVALID_VERIFIED_DATE="invalidVerifiedDate";
	public final String INVALID_ID_PROVIDED_MATCH_APPLICANT_INFORMATION="invalidIdProvidedMatchApplicantInformation";
	public final String INVALID_REASON_FOR_DISCREPANCY="invalidReasonForDiscrepancy";
	
	/** Internal Approvals **/
	public final String INVALID_TIME_UNIT = "invalidTimeUnit";
	public final String INVALID_REFERRAL_SOURCE = "invalidReferralSource";
	public final String INVALID_PAYMENT_TYPE = "invalidPaymentType";
	
	/** invalid ia code **/
	public final String INVALID_IA_CODE = "invalidIaCode";
	public final String EMPTY_IA_CODE = "noIaCodeSpecified";
	
	/** internal approvals **/
	public final String INVALID_ATTESTATION_DATE="invalidDateFormatInAttestations";
	public final String INVALID_FEE_TYPE_FOR_PAYMENT_TYPE = "invalidFeeTypeForPaymentType";
	
	/** security **/
	public final String INVALID_ROLE_FOR_OPERATION="invalidRoleForDesiredOperation";
	public final String INVALID_APP_STATUS_FOR_OPERATION="invalidAppStatusForOperation";
	public final String INVALID_IA_CODE_FOR_OPERATION="userDoesNotHavePermissionForApplicationIaCode";
	public final String IMPROPER_PERMISSIONS_INITIALIZATION="anImproperIaCodeListValueWasSetInPermissionMap";
	public final String EMPTY_SECURITY_FIELDS = "securityFieldsNotProperlySet";
	public final String USER_NOT_FOUND = "hubDoesNotRecognizeNetworkId";
	
	/** Taxation **/
	public final String INVALID_BENEFICIAL_OWNER_COUNTRY="invalidBeneficialOwnerCountry";
	public final String INVALID_TAX_IDENTIFICATION_NUMBER="invalidTaxIdentificationNumber";
	public final String INVALID_SOCIAL_SECURITY_NUMBER="invalidSocialSecurityNumber";
	public final String INVALID_IS_IRS_W8_FORM_PROVIDED="invalidIsIrsW8FormProvided";
	public final String INVALID_IS_IRS_W9_FORM_PROVIDED="invalidIsIrsW9FormProvided";
	
	/** Capture Guarantee Information **/
	public final String INVALID_GUARANTEE_ACCOUNT_NUMBER="invalidGuaranteeAccountNumber";
	public final String INVALID_GUARANTEE_RELATIONSHIP="invalidGuaranteeRelationship";
	public final String INVALID_OTHER_PARTIES_SPECIFIED = "invalidAreOtherPartiesSpecified";
	public final String INVALID_GUARANTEE_REF_MAPPING="invalidGuaranteeClientRefId";
	public final String NO_GUARANTEE_REF_MAPPING="noGuaranteeRefMapping";
	
	/** Capture Guarantor Information **/
	public final String INVALID_GUARANTOR_ACCOUNT_NUMBER="invalidGuarantorAccountNumber";
	public final String INVALID_GUARANTOR_IS_YOUR_SPOUSE="invalidGuarantorIsYourSpouse";
	public final String INVALID_GUARANTOR_IS_IN_SAME_ADDRESS="invalidGuarantorIsInSameAddress";
	public final String INVALID_GUARANTOR_REF_MAPPING="invalidGuarantorClientRefId";
	public final String NO_GUARANTOR_REF_MAPPING="noGuarantorRefMapping";
	
	/** TradingAuthority **/
    public final String INVALID_TRADING_AUTHORITY_PARTY_REF_ID = "invalidTradingAuthorityPartyRefId";   
    public final String INVALID_SPOUSE_PARTY_REF_ID="invalidSpousePartyRefId";   
    public final String INVALID_PRIMARY_APPLICANT_PARTY_REF_ID="multiplePrimaryApplicantPartiesAreNotAllowed";   
    
    /** New date Time field **/
    public final String INVALID_CLIENT_ID_CAPTURETIME="invalidclientIdCaptureTime";
    
    /** Internal Approvals RelationshipSummary **/
    public final String INVALID_REFERRER_FIRST_NAME="invalidReferrerFirstName";
    public final String INVALID_REFERRER_LAST_NAME="invalidReferrerLastName";
    public final String INVALID_TRANSIT_NUMBER="invalidTransitNumber";
    public final String INVALID_TISM_CODE="invalidTismCode";
    
    /** IA Approval **/
    public final String INVALID_REGISTERED_IN_CLIENT_PROVINCE_OF_RESIDENCE="invalidRegisteredInClientProvinceOfResidence";
    public final String INVALID_DISCUSSED_RISK_TOLERANCE_AND_OBJECTIVES="invalidDiscussedRiskToleranceAndObjectives";
    public final String INVALID_REVIEWED_SUITABLITY="invalidReviewedSuitability";
    
    /** BM Approval **/
    public final String INVALID_CONFIRMED_IA_ARE_LICENSED_IN_CLIENT_JURISDICTION="invalidconfirmedIaAreLicensedInClientJurisdiction";
    public final String INVALID_REVIEWED_ACCOUNT_SUITABLITY="invalidReviewedAccountSuitability";
	public final String INVALID_OTHER_PARTIES_INFO = "invalidOtherPartyInfo";
	
	public final String INVALID_APPROVAL_COMMENT ="invalidApprovalComment";
	public final String INVALID_APPROVAL_DOCEDITCOMMENT ="invalidApprovalDocumentEditComment";
	public final String INVALID_RELATIONSHIP_COMMENT ="invalidRelationshipComment";
	public final String INVALID_RELATIONSHIP_DOCEDITCOMMENT ="invalidRelationshipDocumentEditComment";
	
	
	/** Empty Party **/
	public final String INVALID_EMPTY_PARTY="invalidEmptyParty";

	public final String INVALID_BENEFICIARY_REF_ID = "invalidBeneficiaryRefId";
	public final String INVALID_BENEFICIARY_DUPLICATE_SIN = "invalidBeneficiaryDuplicateSinAsSuccessor";
	public final String INVALID_HAS_PRIMARY_APPLICANT_SPOUSE = "invalidHasPrimaryApplicantSpouse";
	public final String INVALID_EMPTY_CONTINGENT_BENEFICIARY="invalidEmptyContingentBeneficiary";
	public final String NO_MAPPING_BENEFICIARY_ACC_BENEFICIARY="invalidMappingBeneficiaryAccBeneficiary";
	public final String NO_MAPPING_CONTINGENT_BENEFICIARY ="invalidMappingContingentBeneficiary";
	public final String INVALID_MAPPING_CONTINGENT_BENEFICIARY_ACC_BENEFICIARY="invalidMappingContingentBeneficiaryAccBeneficiary";
	public final String INVALID_ACC_BENEFICIARY_ID = "invalidAccBeneficiaryRefId";
	public final String INVALID_CONTINGENT_BENEFICIARY_ID="invalidContingentBeneficiaryRefId";
	
	public final String INVALID_ACCOUNT_PRIMARY_APPLICANT_PARTY_REF_ID = "invalidPrimaryApplicantPartyRefId";
	
	//Lira Account
	public final String INVALID_JURISDICTION_TYPE ="invalidJurisdictionType";
	public final String INVALID_FEDERAL_PENSIONPLAN_TYPE ="invalidFederalPensionPlanType";
	public final String INVALID_PENSION_VARIED_ONBASISOF_GENDER ="invalidPensionVariedOnBasisOfGender";		
	public final String INVALID_PENSIONASSETS_ORIGINATE_FROM ="invalidPensionAssetsOriginateFrom";
	public final String INVALID_PENSIONACCUMULATED_BEFORE1993 ="invalidPensionAccumulatedBefore1993";
	public final String INVALID_FUNDING_INSTRUCTIONS ="invalidFundingInstructions";
	public final String INVALID_TRANSFERRED_AMOUNT ="invalidTransferredAmount";	
	public final String INVALID_TRANSFERRED_AMOUNT_IN_WORDS ="invalidTransferredAmountWords";
	public final String INVALID_LIRA_PROVINCE ="invalidLiraProvince";	
	public final String INVALID_LIF_PROVINCE ="invalidLifProvince";
	
	//Joint Account
	public final String INVALID_IS_PRIMARY_APPLICANT_SPOUSE ="invalidPrimaryApplicantSpouse";
	public final String INVALID_ADD_JOINT_APPLICANT ="invalidJointApplicant";
	public final String INVALID_JOINT_ACCOUNT_DETAILS ="invalidJointAccountDetails";
	public final String INVALID_RIGHTS_OF_SURVIVORSHIP ="invalidRightsOfSurvivorship";
	public final String INVALID_ACCOUNT_NAME_ORDER ="invalidAccountNameOrder";	
	public final String INVALID_JOINT_APPLICANT_PARTY_REF_IDS = "invalidJointApplicantPartyRefIds";	
	public final String INVALID_MULTI_APPLICANTS_INVESTMENT_EXP = "invalidMultiApplicantsInvestmentExperience";
	
	public final String INVALID_PRIMARY_APPLICANT_INVESTMENT_EXP = "invalidPrimaryApplicantInvestmentExperience";
	
	public final String INVALID_FEE_TYPE = "invalidFeeType";
	
	public final String INVALID_AMOUNT_TYPE = "invalidAmountType";
	public final String INVALID_AMOUNT = "invalidAmount";
	public final String INVALID_GREATER_THAN_MIN_AMT_TYPE = "invalidGreaterThanMinimumAmountType";
	public final String INVALID_RIF_FREQUENCY = "invalidRifFrequency";
	public final String INVALID_SPOUSAL_RIF = "invalidIsSpousalRif";
	public final String INVALID_START_MONTH = "invalidStartMonth";
	public final String INVALID_START_YEAR = "invalidStartYear";
	public final String INVALID_WHEN_IN_MONTH = "invalidWhenInMonth";
	public final String INVALID_PAYMENT_METHOD = "invalidMethod";
	public final String INVALID_WITH_HOLDING_TAX = "invalidWithHoldingTax";
	public final String INVALID_WITH_HOLDING_TAX_PERCENTAGE = "invalidWithHoldingTaxPercentage";
	public final String INVALID_WITH_HOLDING_QUEBEC_TAX_PERCENTAGE = "invalidWithHoldingQuebecTaxPercentage";
	public final String INVALID_WITH_HOLDING_TAX_AMOUNT = "invalidWithHoldingTaxAmount";
	public final String INVALID_WITH_HOLDING_QUEBEC_TAX_AMOUNT = "invalidWithHoldingQuebecTaxAmount";
	public final String INVALID_HAS_THIRD_PARTY_INTEREST = "invalidHasThirdPartyInterest";
	public final String INVALID_TRANSFER_ACCOUNT_NUMBER = "invalidTransferAccountNumber";	
	public final String INVALID_NONREG_ACCOUNT_SEL_TYPE="invalidNonRegisteredAccountSelectionType";

	public final String INVALID_EFT_FREQUENCY = "invalidEftFrequency";
	public final String INVALID_EFT_START_DATE = "invalidStartDate";
	public final String INVALID_EFT_INSTITUTION_CODE = "invalidInstitutionCode";
	public final String INVALID_EFT_INSTITUTION_NAME = "invalidInstitutionName";
	public final String INVALID_EFT_TRANSIT_CODE = "invalidTransitCode";
	public final String INVALID_EFT_ACCOUNT_OWNER = "invalidAccountOwner";
	public final String INVALID_EFT_OWNERSHIP_BANK_ACCOUNT_VERIFIED = "invalidOwnershipOfBankAccountVerified";

	public final String INVALID_HAS_DECLINED_ACCESS = "invalidHasDeclinedAccess";
	public final String INVALID_GATEWAY_USER_ID = "invalidCredentialUserId";

	public final String INVALID_JOINT_PRODUCT_ELIGIBILITY_PROVINCE = "invalidJointAccountEligibilityProvince";
	public final String INVALID_JOINT_PRODUCT_ELIGIBILITY_DOB = "invalidJointAccountEligibilityDOB";
	
	public final String INVALID_SPOUSAL_RSP = "invalidIsSpousalRsp";
	
	public final String DESERIALIZED_OBJECT_OF_WRONG_TYPE = "deserializedObjectWasOfWrongType";
	public final String EXISTING_ECIF_RECORD_NOT_FOUND = "existingEcifRecordNotFound";
	public final String NO_USERS_FOUND_FOR_CODE = "noUsersFoundForIaCodeAndBranch";
	public final String BMO_CLIENT_RELATIONSHIP_TYPE = "invalidBmoClientRelationshipType";
	public final String INVALID_BMO_PRODUCT = "invalidBmoProduct";
	public final String INVALID_IS_APPLICANT_EXISTING_CLIENT = "invalidIsApplicantExistingClient";
	public final String INVALID_BMO_ACCOUNT_NUMBER = "invalidBmoAccountNumber";

	public final String INVALID_SRC_OF_ASSESTS = "invalidSourceOfAssets";
	public final String INVALID_SPOUSE_OPTION_TYPE = "invalidSpouseOptionType";
	
}