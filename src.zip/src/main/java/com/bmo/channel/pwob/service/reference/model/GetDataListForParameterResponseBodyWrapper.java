package com.bmo.channel.pwob.service.reference.model;

public class GetDataListForParameterResponseBodyWrapper {
	GetDataListForParameterResponseBody getDataListForParameterResponse;

	public GetDataListForParameterResponseBody getGetDataListForParameterResponse() {
		return getDataListForParameterResponse;
	}

	public void setGetDataListForParameterResponse(GetDataListForParameterResponseBody getDataListForParameterResponse) {
		this.getDataListForParameterResponse = getDataListForParameterResponse;
	}
}
