/**
 * 
 */
package com.bmo.channel.pwob.validation.otherparties;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Guarantor;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

/**
 * @author vvallia
 *
 */
@Component
public class GuarantorValidator extends AbstractBaseValidator {

	
	
	@Autowired ValidationRequestFactory validationRequestFactory;
	
	@Autowired
	private UsersService userService;



	public boolean isValid(Application application, ConstraintValidatorContext context ) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();			
		
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}
		
		boolean valid = true;
		
		List<Guarantor> guarantors =  application.getGuarantors();	
		
		List<String> validGuarantors = guarantors.stream().map(t -> t.getGuarantorRefId()).collect(Collectors.toList());	
		
		List<String> guarantorClntRefIds;

		if(CollectionUtils.isNotEmpty(guarantors)){
			 int guarantorIndex = 0;
				for (Guarantor guarantor : guarantors) {

					ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob())
							.withParentPropertyNode("guarantors[" + guarantorIndex + "].personalInfo.residence")
							.withParentFieldPath("residence")
							.withChildPropertyNode("primaryAddress")
							.withChildFieldPath("primaryAddress")
							.build();

					if (guarantor.getPersonalInfo() != null && guarantor.getPersonalInfo().getResidence() != null && 
							guarantor.getPersonalInfo().getResidence().getPrimaryAddress() != null) {
						Address primaryAddress = guarantor.getPersonalInfo().getResidence().getPrimaryAddress();
						if(StringUtils.isBlank(primaryAddress.getStreetAddress())){
							valid = false;
							request.setFieldName("streetAddress");
		    				request.setErrorCode(ErrorCodes.INVALID_STREET_ADDR);
		    				request.addConstraintViolation();
						}
						if(StringUtils.isBlank(primaryAddress.getCity())){
							valid = false;
							request.setFieldName("city");
		    				request.setErrorCode(ErrorCodes.INVALID_CITY);
		    				request.addConstraintViolation();
						}
						if(StringUtils.isBlank(primaryAddress.getPostalCode())
								|| (StringUtils.isNotBlank(primaryAddress.getPostalCode()) 
								&& RefDataValues.CANADA_COUNTRY_CODE.equals(primaryAddress.getCountry()) 
								&& !isValidCanadianPostalCode(primaryAddress.getPostalCode()))){
							valid = false;
							request.setFieldName("postalCode");
		    				request.setErrorCode(ErrorCodes.INVALID_POSTAL_CODE);
		    				request.addConstraintViolation();
						}
						if(StringUtils.isBlank(primaryAddress.getCountry())){
							valid = false;
							request.setFieldName("country");
		    				request.setErrorCode(ErrorCodes.INVALID_COUNTRY);
		    				request.addConstraintViolation();
						}
						else if((RefDataValues.CANADA_COUNTRY_CODE.equals(primaryAddress.getCountry()) || RefDataValues.USA_COUNTRY_CODE.equals(primaryAddress.getCountry())) && 
								StringUtils.isBlank(primaryAddress.getProvince())){
							valid = false;
							request.setFieldName("province");
		    				request.setErrorCode(ErrorCodes.INVALID_PROVINCE);
		    				request.addConstraintViolation();
						}
					}
					else if(guarantor.getPersonalInfo() != null && guarantor.getPersonalInfo().getResidence() != null 
							&& guarantor.getPersonalInfo().getResidence().getPrimaryAddress() == null){
						valid = false;
						request.setFieldName("streetAddress");
		    			request.setErrorCode(ErrorCodes.INVALID_STREET_ADDR);
		    			request.addConstraintViolation();
						request.setFieldName("city");
		    			request.setErrorCode(ErrorCodes.INVALID_CITY);
		    			request.addConstraintViolation();
						request.setFieldName("postalCode");
		    			request.setErrorCode(ErrorCodes.INVALID_POSTAL_CODE);
		    			request.addConstraintViolation();
						request.setFieldName("country");
		    			request.setErrorCode(ErrorCodes.INVALID_COUNTRY);
		    			request.addConstraintViolation();
						request.setFieldName("province");
		    			request.setErrorCode(ErrorCodes.INVALID_PROVINCE);
		    			request.addConstraintViolation();
					}
					guarantorIndex++;
		        }
			}	

			List<Account> accounts = application.getAccounts();
			int accIndex = 0;
			for(Account account : accounts){
				if(Optional.ofNullable(account.getAreOtherPartiesSpecified()).isPresent())	{							 	 
					if(account.getAreOtherPartiesSpecified() && account.isIndividual()){
						if(this.isMarginSubTypeSelected(account) && CollectionUtils.isNotEmpty(account.getGuarantorRefIds()) && 
								accIndex < account.getGuarantorRefIds().size()){
							guarantorClntRefIds = account.getGuarantorRefIds();
							String guarantorClntRefId = guarantorClntRefIds.get(accIndex);
							if (CollectionUtils.isNotEmpty(validGuarantors) && !validGuarantors.contains(guarantorClntRefId)){
								createConstraintViolation(context, ErrorCodes.INVALID_GUARANTOR_REF_MAPPING, "accounts[" + accIndex + "].guarantorRefId");
								valid = false;
							}
						}
					}
				} 
				accIndex++;
			}					
		return valid;
	}
	
}
