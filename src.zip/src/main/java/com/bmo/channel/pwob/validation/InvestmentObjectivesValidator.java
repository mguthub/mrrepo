package com.bmo.channel.pwob.validation;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.InvestmentObjectives;
import com.bmo.channel.pwob.model.onboarding.RiskTolerance;
import com.bmo.channel.pwob.model.onboarding.TargetAllocation;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface InvestmentObjectivesValidator {
	boolean validateTargetAllocation(TargetAllocation targetAllocation, ValidationRequest validationRequest);
	boolean validateRiskTolerance(RiskTolerance riskTolerance, ValidationRequest validationRequest);
	boolean validateInvestmentObjectives(InvestmentObjectives investmentObjectives, ValidationRequest validationRequest);
	boolean validateAccountInvestmentObjectives(Account account, ValidationRequest validationRequest);
}
