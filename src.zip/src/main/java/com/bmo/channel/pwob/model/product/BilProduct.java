package com.bmo.channel.pwob.model.product;

public class BilProduct {
	
	private String type;
	private String productNameEn;
	private String productNameFr;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getProductNameEn() {
		return productNameEn;
	}
	public void setProductNameEn(String productNameEn) {
		this.productNameEn = productNameEn;
	}
	public String getProductNameFr() {
		return productNameFr;
	}
	public void setProductNameFr(String productNameFr) {
		this.productNameFr = productNameFr;
	}

}
