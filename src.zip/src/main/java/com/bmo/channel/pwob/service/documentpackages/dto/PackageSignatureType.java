package com.bmo.channel.pwob.service.documentpackages.dto;

public enum PackageSignatureType {
	ESIGN("eSign"), WETSIGN("wetSign"), ESIGNORWETSIGN("eSignOrWetSign");
	
	private String description;
	
	PackageSignatureType (final String description) {
		this.description = description;
	}
	
	public String getDescription() {
		return this.description;
	}
}
