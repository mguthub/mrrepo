package com.bmo.channel.pwob.util;

public interface HubRequestComponent {

	public  HubRequestHeaderBuilder.HeaderBuilder getHubBuilder();

	public  <T> T requestBodyWithRequestorInfo(T t, String... strings);

	public String getMetaInfo(String documentPackageId);

}