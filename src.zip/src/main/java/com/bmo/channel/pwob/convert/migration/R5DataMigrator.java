package com.bmo.channel.pwob.convert.migration;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;
import com.bmo.channel.pwob.util.W9FormHelper;

@Component
@Order(value=2)
public class R5DataMigrator implements ApplicationMigrator {
	@Autowired
	private EventManager eventManager;
	
	@Autowired
	private W9FormHelper w9FormHelper;

	@Override
	public void migrateApplication(Application application, FeatureFlags featureFlags) {
		application.getClientMetadata().put(Application.RELEASE_METADATA_KEY, Application.RELEASE_VERSION_5);

		//data migration R4 to R5: Residency for Tax Purposes = USA
		w9FormHelper.removeW9TaxResidencyUS(application);
	}

	@Override
	public boolean isMigrationRequired(Application application, FeatureFlags featureFlags) {
		// release not populated until R6, so if populated it's after R5
		if(StringUtils.isNotBlank(application.getRelease())) {
			return false;
		}
		String release = application.getClientMetadata().get(Application.RELEASE_METADATA_KEY);
		if(isReleaseDifferent(release)) {
			eventManager.publishWarn(String.format("Migrating application %s because release version is " + release, release));
			return true;
		} else {
			return false;
		}
	}

	private boolean isReleaseDifferent(String release) {
		// this logic may need to change in the future, because
		// if application version is say, 6, then this will return true, even though the R5 migration should not be run
		return !Application.RELEASE_VERSION_5.equals(release);
	}
}
