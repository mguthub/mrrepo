package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.module.SimpleModule;

import net.bmogc.xmlns.api.header.v1.APIHeaderRequest;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

public enum ChannelObjectMapper {
	INSTANCE;
	
	private final static ObjectMapper MAPPER = new ObjectMapper();
	static {
		SimpleModule module = new SimpleModule();
		module.addSerializer(HUBHeaderRequest.class, new HubHeaderSerializer());
		module.addSerializer(APIHeaderRequest.class, new APIHeaderSerializer());
		MAPPER.registerModule(module);
		MAPPER.setSerializationInclusion(JsonInclude.Include.NON_NULL);
	}
	
	private ChannelObjectMapper() {}
	
	public ObjectMapper getObjectMapper(){
		return MAPPER;
	}
}
