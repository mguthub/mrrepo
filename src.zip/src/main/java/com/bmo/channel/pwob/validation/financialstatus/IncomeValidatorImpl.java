package com.bmo.channel.pwob.validation.financialstatus;

import java.math.BigInteger;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Income;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.Patterns;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class IncomeValidatorImpl extends AbstractBaseValidator implements IncomeValidator{

	private static final int ZERO = 0;
	private static final int MAX_VALUE = 999999999;
	
	@Autowired
	private UserContext userContext;
	
	public boolean isValid(Income value, ValidationRequest validationRequest) {
		final ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

        final BigInteger annualEmploymentIncome = value.getAnnualEmploymentIncome();       

        boolean valid = true;
		if (annualEmploymentIncome == null || annualEmploymentIncome.intValue() > MAX_VALUE || annualEmploymentIncome.intValue() < ZERO) {			
			validationRequest.addConstraintViolation("annualEmploymentIncome",ErrorCodes.INVALID_ANNUAL_EMPLOYMENT_INCOME);
			valid = false;
		}

		if(ApplicationLob.nb.equals(userContext.getAuthenticatedUser().getLob())){
			 final BigInteger annualInvestmentIncome = value.getAnnualInvestmentIncome();
		     final BigInteger annualOtherIncome = value.getAnnualOtherIncome();
			
			if (annualInvestmentIncome == null || annualInvestmentIncome.intValue() > MAX_VALUE || annualInvestmentIncome.intValue() < ZERO) {			
				validationRequest.addConstraintViolation("annualInvestmentIncome",ErrorCodes.INVALID_ANNUAL_INVESTMENT_INCOME);
				valid = false;
			}

			if (annualOtherIncome == null || annualOtherIncome.intValue() > MAX_VALUE || annualOtherIncome.intValue() < ZERO) {			
				validationRequest.addConstraintViolation("annualOtherIncome",ErrorCodes.INVALID_ANNUAL_OTHER_INCOME);
				valid = false;
			} 

			if (annualOtherIncome != null && annualOtherIncome.intValue() != ZERO && StringUtils.isBlank(value.getOtherIncomeSource())) {			
				validationRequest.addConstraintViolation("otherIncomeSource",ErrorCodes.INVALID_ANNUAL_OTHER_INCOME_SOURCE);
				valid = false;
			}

			if (value.getOtherIncomeSource() != null && value.getOtherIncomeSource().equals(RefDataValues.INCOME_SOURCE_OTHER) 
					&& StringUtils.isBlank(value.getOtherIncomeSourceDescription())) {			
				validationRequest.addConstraintViolation("otherIncomeSourceDescription",ErrorCodes.INVALID_ANNUAL_OTHER_INCOME_DESCRIPTION);
				valid = false;
			} 
			else if (value.getOtherIncomeSource() != null && !value.getOtherIncomeSource().equals(RefDataValues.INCOME_SOURCE_OTHER) 
					&& StringUtils.isNotBlank(value.getOtherIncomeSourceDescription())) {			
				validationRequest.addConstraintViolation("otherIncomeSourceDescription",ErrorCodes.INVALID_ANNUAL_OTHER_INCOME_DESCRIPTION);
				valid = false;
			}
		}
		
		return valid;
	}

	boolean isInvalidOtherIncomeSource(String otherIncomeSource) {
		return StringUtils.isBlank(otherIncomeSource) || ! otherIncomeSource.matches("^[" + Patterns.ALPHANUMERIC + "]{1,100}$");
	}
}
