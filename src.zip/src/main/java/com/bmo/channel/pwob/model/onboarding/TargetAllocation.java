package com.bmo.channel.pwob.model.onboarding;

import java.math.BigInteger;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class TargetAllocation {

	private BigInteger cash;
	private BigInteger fixedIncome;
	private BigInteger equities;

	public BigInteger getCash() {
		return cash;
	}
	public void setCash(BigInteger cash) {
		this.cash = cash;
	}
	public BigInteger getFixedIncome() {
		return fixedIncome;
	}
	public void setFixedIncome(BigInteger fixedIncome) {
		this.fixedIncome = fixedIncome;
	}
	public BigInteger getEquities() {
		return equities;
	}
	public void setEquities(BigInteger equities) {
		this.equities = equities;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
