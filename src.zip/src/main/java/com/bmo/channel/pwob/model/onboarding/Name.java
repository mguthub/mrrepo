package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;
import com.fasterxml.jackson.annotation.JsonInclude;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Name {
	
	@ApiModelProperty(example="100002", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.TITLES, code=ErrorCodes.INVALID_TITLE)
	private String title;

    @DataValidationPattern(code=ErrorCodes.INVALID_FIRST_NAME)
	private String firstName;
	@DataValidationPattern(code=ErrorCodes.INVALID_MIDDLE_NAME)
	private String middleName;
	@DataValidationPattern(code=ErrorCodes.INVALID_LAST_NAME)
	private String lastName;
	
	private Boolean risPrefilled;	
	

	public String getTitle() {
		return title;
	}

	public void setTitle(String Title) {
		this.title = Title;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Boolean getRisPrefilled() {
		return risPrefilled;
	}

	public void setRisPrefilled(Boolean risPrefilled) {
		this.risPrefilled = risPrefilled;
	}
}
