package com.bmo.channel.pwob.service.risprefill;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.accounts.AccountDetails;
import com.bmo.accounts.AccountDetailsResponse;
import com.bmo.channel.core.mapping.DataMapper;
import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Name;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.service.party.PartyFactory;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.risprefill.RisPrefillValidator;
import com.bmo.onboarding.AgreementInformation;
import com.bmo.onboarding.IndividualParty;
import com.bmo.onboarding.PartyTypeEnum;
import com.bmo.onboarding.Person;

@Service
public class RisMappingServiceImpl implements RisMappingService {

	@Autowired
	DataMapper dataMapper;

	@Autowired
	PartyFactory partyFactory;

	@Autowired
	RisPrefillValidator risPrefillValidator;

	@Override
	public List<Party> mapRisPayload(AccountDetailsResponse accountDetails) {
		IndividualParty risPrimary = fetchRisPrimaryParty(accountDetails);
		
		if(risPrimary != null) {
			Party primary = partyFactory.createPrimaryApplicantParty(new Party());
			
			List<Party> parties = Arrays.asList(primary, partyFactory.createSpouseParty(primary, new Party()));
			PartyListWrapper wrapper = new PartyListWrapper(parties);
			
			dataMapper.map(risPrimary, wrapper);
			parties = wrapper.getParties();	
			
			//Conditional mappings
			parties = conditionalMappings(risPrimary, primary, parties);	
			
			this.setRisPrefilled(primary);
			
			// RIS data validation
			// validation of primary applicant title 

			risPrefillValidator.titleValidator(primary);
			risPrefillValidator.primaryApplicantPhoneValidator(primary);
			risPrefillValidator.primaryApplicantAddressValidator(primary);
			risPrefillValidator.taxResidencyValidator(primary);
			risPrefillValidator.citizenshipValidator(primary);
			risPrefillValidator.preferredNameValidator(primary);
			risPrefillValidator.maritalStatusValidator(primary);
			// Adding Primary applicant's dob validation
			risPrefillValidator.dateOfBirthValidator(primary);

			for (Party party:parties) {
				risPrefillValidator.employmentDetailsValidator(party);
				// Validation for spousal DOB is not required hence commenting the validation
				//risPrefillValidator.dateOfBirthValidator(party);
			}

			risPrefillValidator.preferredLangValidator(primary);
			return parties;
		}		
		return Collections.emptyList();
	}

	private List<Party> conditionalMappings(IndividualParty risPrimary, Party primary, List<Party> parties) {
		
		//Remove spouse, if applicant is Single
		parties = singleApplicant(risPrimary, primary, parties);
		
		// Multiple citizenships
		multipleCitizenships(risPrimary, primary);
		dependentsFlag(risPrimary, primary);
		
		return parties;
	}

	private void dependentsFlag(IndividualParty risPrimary, Party primary) {
						
		if(Optional.ofNullable(risPrimary.getNumberOfDependents()).isPresent() && risPrimary.getNumberOfDependents()>0){
			primary.getPersonal().getIdentity().setHasDependents(true);
			primary.getPersonal().getIdentity().setNumOfDependents(risPrimary.getNumberOfDependents());
		}else{
			primary.getPersonal().getIdentity().setHasDependents(false);			
		}		
	}

	private void multipleCitizenships(IndividualParty risPrimary, Party primary) {
				
			//get other citizenships and add to primary applicant 
			if(Optional.ofNullable(risPrimary.getPersonalInformation()).map(Person::getDualCitizenship).isPresent()){
				String dualCitz = risPrimary.getPersonalInformation().getDualCitizenship();
				primary.getPersonal().getIdentity().getCitizenships().add(dualCitz);
			}			
		}	

	private List<Party> singleApplicant(IndividualParty risPrimary, Party primary, List<Party> parties) {
		//If primary applicant is single (Remove spouse party)				
		if(Optional.ofNullable(risPrimary).map(IndividualParty::getPersonalInformation).map(Person::getMaritalStatus).isPresent()){
			String maritalStatus = risPrimary.getPersonalInformation().getMaritalStatus();
			if(!(RefDataValues.MARITAL_STATUS_MARRIED.equalsIgnoreCase(maritalStatus) || RefDataValues.MARITAL_STATUS_COMMON_LAW.equalsIgnoreCase(maritalStatus)))
			{
				parties = Arrays.asList(primary);
			}else{
				parties.get(1).setSpousePartyRefId(primary.getPartyRefId());
				primary.setSpousePartyRefId(parties.get(1).getPartyRefId());
				risPrefillValidator.spouseNameValidator(parties.get(1));
			}
		}else{
			parties = Arrays.asList(primary);
		}
		return parties;
	}

	@Override
	public void fetchPayloadName(NewWorkflowRequest request, AccountDetailsResponse accountDetails) {
		request.setFirstName(null);
		request.setLastName(null);

		IndividualParty primary = fetchRisPrimaryParty(accountDetails);
		
		if (primary != null && primary.getPersonalInformation() != null) {
			request.setFirstName(primary.getPersonalInformation().getFirstName());
			request.setLastName(primary.getPersonalInformation().getLastName());
		}
		//set IA code
		if(Optional.ofNullable(accountDetails).map(AccountDetailsResponse::getAccountDetails).map(AccountDetails::getInvestmentAdvisorCode).isPresent()){
			request.setIaCode(accountDetails.getAccountDetails().getInvestmentAdvisorCode());
		}
	}
	
	public void setRisPrefilled(Party primary) {
		primary.getPersonal().getIdentity().getLegalName().setRisPrefilled(true);
		
		if(Optional.ofNullable(primary.getPersonal()).map(PersonalInformation::getIdentity).map(Identity::getPreferredName).isPresent()){
			Name preferredName = primary.getPersonal().getIdentity().getPreferredName();
			
			if(Optional.ofNullable(preferredName.getFirstName()).isPresent()
					|| Optional.ofNullable(preferredName.getLastName()).isPresent()
					|| Optional.ofNullable(preferredName.getMiddleName()).isPresent()){
				preferredName.setRisPrefilled(true);
			}else{
				primary.getPersonal().getIdentity().setPreferredName(null);
			}
		}
	}
	
	
	public void prefillEmailId(Party primary,AgreementInformation agreementInformation) {
		if(agreementInformation != null && agreementInformation.getEmailAddressList() != null){
			if(agreementInformation.getEmailAddressList().getEmailAddress() != null && agreementInformation.getEmailAddressList().getEmailAddress().get(0) != null){
				primary.getPersonal().getIdentity().setPrimaryEmailAddress(agreementInformation.getEmailAddressList().getEmailAddress().get(0));
			}
		}
	}
	
	public IndividualParty fetchRisPrimaryParty(AccountDetailsResponse accountDetails) {
		if (accountDetails.getIndividualPartyList() != null 
				&& accountDetails.getIndividualPartyList().getIndividualParty() != null
				&& CollectionUtils.isNotEmpty(accountDetails.getIndividualPartyList().getIndividualParty())) {
			
			Optional<IndividualParty> opt = accountDetails.getIndividualPartyList().getIndividualParty().stream()
				.filter(p -> p.getPartyType().equals(PartyTypeEnum.PRIMARY_APPLICANT)).findFirst();
			if (opt.isPresent()) {
				return opt.get();
			}
		}
		return null;
	}

	
	public class PartyListWrapper {
		private List<Party> parties;

		public PartyListWrapper(List<Party> parties) {
			setParties(parties);
		}
		
		public List<Party> getParties() {
			return parties;
		}

		public void setParties(List<Party> parties) {
			this.parties = parties;
		}
	}
}
