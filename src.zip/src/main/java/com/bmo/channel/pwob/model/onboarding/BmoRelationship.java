package com.bmo.channel.pwob.model.onboarding;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

//add validations
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BmoRelationship {

	@ApiModelProperty(value="check applicant is existing bmo client")
	private Boolean isApplicantExistingClient;
	
	@ApiModelProperty(value="Only populate if isApplicantExistingClient is true")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	@ReferenceData(type=ReferenceType.BMO_CLIENT_RELATIONSHIP_TYPE, code=ErrorCodes.BMO_CLIENT_RELATIONSHIP_TYPE)
	private String bmoProduct;
	
	@ApiModelProperty(value="Only populate if isApplicantExistingClient is true")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String bmoAccountNumber;

	public Boolean getIsApplicantExistingClient() {
		return isApplicantExistingClient;
	}

	public void setIsApplicantExistingClient(Boolean isApplicantExistingClient) {
		this.isApplicantExistingClient = isApplicantExistingClient;
	}

	public String getBmoProduct() {
		return bmoProduct;
	}

	public void setBmoProduct(String bmoProduct) {
		this.bmoProduct = bmoProduct;
	}

	public String getBmoAccountNumber() {
		return bmoAccountNumber;
	}

	public void setBmoAccountNumber(String bmoAccountNumber) {
		this.bmoAccountNumber = bmoAccountNumber;
	}

	public BmoRelationship(Boolean isApplicantExistingClient, String bmoProduct, String bmoAccountNumber) {
		super();
		this.isApplicantExistingClient = isApplicantExistingClient;
		this.bmoProduct = bmoProduct;
		this.bmoAccountNumber = bmoAccountNumber;
	}

	public BmoRelationship() {
		super();
	}
}
