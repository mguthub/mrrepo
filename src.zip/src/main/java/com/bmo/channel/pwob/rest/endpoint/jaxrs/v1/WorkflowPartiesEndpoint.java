package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.validation.constraints.NotNull;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.service.workflow.WorkflowService;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.ValidationManager.IdType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
/**
 * Sub-route for Parties.
 * @author Ryan Chambers rcham02
 */
@Api(WorkflowsEndpoint.V1_PATH + "/{id}/parties")
@Path(WorkflowsEndpoint.V1_PATH + "/{id}/parties")
public class WorkflowPartiesEndpoint {

	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private ValidationManager validationManager;

	@DELETE
	@Path("/{partyRefId}")
    @ApiOperation(value="Remove a spouse party from an application", response=Application.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
    @ApiResponses(value={
            @ApiResponse(code=200, message="Success"), 
            @ApiResponse(code=500, message="Internal server error"), 
            @ApiResponse(code=401, message="User cannot be identified"),
            @ApiResponse(code=400, message="Invalid party")})
	public Response removeParty(
		@ApiParam(value = "Application ID") @PathParam("id") String applicationId,
		@ApiParam(value = "Party ref ID to be deleted") @PathParam("partyRefId") String partyRefId) {
		// TODO this should be in WorkflowService, not in the Endpoint
        validationManager.validateId(applicationId, IdType.Application);
        validationManager.validateId(partyRefId, IdType.Party);

        Application updated = workflowService.removePartyFromApplication(applicationId, partyRefId);

		return Response.ok(updated).build();
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/jointParty")
	@ApiOperation(value="Get workflow data", response=Application.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Application saveJointApplicant(@NotNull Party party,@ApiParam(value = "Application ID") @PathParam("id") @NotEmpty String workflowId) {	
		return workflowService.addJointApplicantToApplication(workflowId,party);
	}
	
}
