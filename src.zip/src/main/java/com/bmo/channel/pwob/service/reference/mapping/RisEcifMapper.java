package com.bmo.channel.pwob.service.reference.mapping;

import java.util.List;
import java.util.stream.Collectors;

import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.model.DataAndMapping;

public class RisEcifMapper extends AbstractBaseReferenceMapper {

	@Override
	public List<Reference> mapToReferenceListEN(DataAndMapping dataAndMapping) {
		List<Reference> collect = dataAndMapping.getReferenceData().stream().map(v -> {
			return MapRisToEcif(v, dataAndMapping.getMappingData());
		}).collect(Collectors.toList());
		return new DuplicatesFilter().filterOutDuplicates(collect);
	}

	@Override
	public List<Reference> mapToReferenceListFR(DataAndMapping dataAndMapping) {
		List<Reference> collect = dataAndMapping.getReferenceData().stream().map(v -> {			
			return MapRisToEcifFR(v, dataAndMapping.getMappingData());
		}).collect(Collectors.toList());
		return new DuplicatesFilter().filterOutDuplicates(collect);
	}

}
