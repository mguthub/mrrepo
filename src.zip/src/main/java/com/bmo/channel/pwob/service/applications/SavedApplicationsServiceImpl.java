package com.bmo.channel.pwob.service.applications;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import javax.xml.ws.WebServiceException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.ForbiddenSecurityException;
import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.UnauthorizedSecurityException;
import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.applications.Summary;
import com.bmo.channel.pwob.model.onboarding.AppStatus;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.SavedApplicationsResponse;
import com.bmo.channel.pwob.service.authorization.SecurityService;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.service.workflowstatus.WorkflowStatusEndpointInterface;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.util.APIHeaderRequestComponent;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.DateUtils;
import com.bmo.channel.pwob.util.GetCountRequestWrapper;
import com.bmo.channel.pwob.util.GetCountResponseRootWrapper;
import com.bmo.channel.pwob.util.GetCountResponseWrapper;
import com.bmo.channel.pwob.util.GetCountResponseWrapper.Body;
import com.bmo.channel.pwob.util.GetStatusRequestWrapper;
import com.bmo.channel.pwob.util.GetStatusResponseRootWrapper;
import com.bmo.channel.pwob.util.GetStatusResponseWrapper;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.fasterxml.jackson.core.JsonProcessingException;

import net.bmogc.xmlns.api.header.v1.APIHeaderRequest;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.ByAccess;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.ByStatus;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Filter.KeyValuePair;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Workflow;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Workflowcount;

@Service
public class SavedApplicationsServiceImpl implements SavedApplicationsService {
	private static Logger logger = LoggerFactory.getLogger(SavedApplicationsServiceImpl.class);

	static final String FIRST_NAME = "firstName";
	static final String LAST_NAME = "lastName";
	static final String CURRENT_STEP = "currentStep";
	public static final String DETAILS_LEVEL_SUMMARY = "summary";
	static final String DETAILS_LEVEL_COUNT = "count";
	public static final String ECIF_BY_ACCESS = "ECIF\\";
	public static final Integer BATCH_SIZE = 999;

	@Autowired
	private WorkflowStatusEndpointInterface workflowStatusEndpointInterface;

	@Autowired
	private UsersService usersService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private NamePopulator namePopulator;

	@Autowired
	private APIHeaderRequestComponent apiHeaderRequestComponent;
	
    @Autowired
    private UserContext userContext;

	public static final String WSS_SERVICE_NAME = "WSS";
	public static final String WSS_GET_STATUS = "GetStatus";
	public static final String WSS_GET_COUNT = "GetCount";
	public static final String WSS_SET_STATUS = "SetStatus";
	public static final String WSS_SET_META = "SetMetadata";
	public static final String WSS_MORE_RECORDS_EXIST = "1";

	/**
	 * <b> Note: </b> This is NOT the same workflow template id value passed for WIS, even though it seems like it is.
	 */
	private static final String PWOB = "PWOB";
	private static final String MYWEALTH = "myWealth-BIL";

	@Override
	public SavedApplicationsResponse retrieveSavedApplicationsByAppStatusWithPagination(String appStatus, int pageNumber, int numberPerPage) {
		SavedApplicationsResponse response;
		// retrieve IA and Conditionally approved application
		if (AppStatus.IA_APPROVAL.toString().equalsIgnoreCase(appStatus)) {
			response = retrieveIAApplications(determineIaCodes(appStatus), DETAILS_LEVEL_SUMMARY, null, null, appStatus, pageNumber, numberPerPage);
		}// Other applications 
		else {
			response = retrieveApplications(determineIaCodes(appStatus), DETAILS_LEVEL_SUMMARY, null, null, appStatus, pageNumber, numberPerPage);
		}
		return response;
	}

	@Override
	public SavedApplicationsResponse retrieveSavedApplicationsByAppStatusFirstNameLastName(String appStatus, String firstName, String lastName) {		
		return retrieveApplications(determineIaCodes(appStatus), DETAILS_LEVEL_SUMMARY, firstName, lastName, appStatus);		
	}

	@Override
	public SavedApplicationsResponse retrieveSavedApplicationsByAppStatusIaCodesFirstNameLastName(String appStatus, List<String> iaCodes, String firstName, String lastName) {
		return retrieveApplications(iaCodes, DETAILS_LEVEL_SUMMARY, firstName, lastName, appStatus);		
	}

	@Override
	public SavedApplicationsResponse retrieveSavedApplicationsByFirstNameLastName(String firstName, String lastName) {
		User currentUser = usersService.currentUser();
		List<Workflow> workflows = new ArrayList<>();
		Set<String> iaCodes = new HashSet<>();

		GetStatusResponseWrapper.Body.Workflows w;

		// for branch manager, combine their bmApproverFor codes into their iaCodes on the WSS call
		if(currentUser.getIsBranchManager()) {
			iaCodes.addAll(currentUser.getBmApproverFor());
		}

		if(CollectionUtils.isNotEmpty(currentUser.getIaCodes())) {
			iaCodes.addAll(currentUser.getIaCodes());
			
			w = callWss(iaCodes, DETAILS_LEVEL_SUMMARY, firstName, lastName, null).getWorkflows();
			if(w != null && w.getWorkflow() != null) {
				workflows.addAll(w.getWorkflow().stream().filter(a->!a.getWorkflowStatus().equalsIgnoreCase(AppStatus.CANCELLED.toString())).collect(Collectors.toList()));
			}
		}

		return new SavedApplicationsResponse(convertToSavedApplications(workflows));
	}

	List<KeyValuePair> createCriteriaForFirstAndLastName(String firstName, String lastName) {
		List<KeyValuePair> result = new ArrayList<>();
		if(StringUtils.isNotBlank(firstName)) {
			result.add(createCriteria(FIRST_NAME, firstName));
		}
		if(StringUtils.isNotBlank(lastName)) {
			result.add(createCriteria(LAST_NAME, lastName));
		}
		return result;
	}

	private SavedApplicationsResponse retrieveApplications(Collection<String> iaCodes, 
			String detailsLevel, String firstName, String lastName, String appStatus) {
		return retrieveApplications(iaCodes, detailsLevel, firstName, lastName, appStatus, null, null);
	}

	private SavedApplicationsResponse retrieveApplications(Collection<String> iaCodes, 
			String detailsLevel, String firstName, String lastName, String appStatus, Integer pageNumber, Integer numberPerPage) {		
		GetStatusResponseWrapper.Body responseBody = callWss(iaCodes, detailsLevel, firstName, lastName, appStatus, pageNumber, numberPerPage);
		logger.info("ResponseList Size:"+responseBody.getBodyList().size());
		List<SavedApplication> savedApplications=new ArrayList<>();
		SavedApplicationsResponse response = new SavedApplicationsResponse(savedApplications);
		List<Workflow> workflowList=new ArrayList<>();
		List <GetStatusResponseWrapper.Body> responseList=responseBody.getBodyList();
		
		if(Optional.ofNullable(responseBody).isPresent()) {
				if(!responseList.isEmpty()) {
						for(GetStatusResponseWrapper.Body resp : responseList) {
							if( Optional.ofNullable(resp.getWorkflows()).isPresent() ) {
								workflowList.addAll(resp.getWorkflows().getWorkflow());
								if(Optional.ofNullable(resp.getMoreRecordsExist()).isPresent() && resp.getMoreRecordsExist().equals(WSS_MORE_RECORDS_EXIST)){
									response.setMoreRecordsExist(true);
								}
								else{
									response.setMoreRecordsExist(false);
								}
							}
							else {
								response.setMoreRecordsExist(false);
								response = new SavedApplicationsResponse(savedApplications);
							}
						}
						response = new SavedApplicationsResponse(convertToSavedApplications(workflowList));
					} 
				else {	
					if( Optional.ofNullable(responseBody.getWorkflows()).isPresent() ) {
						response = new SavedApplicationsResponse(convertToSavedApplications(responseBody.getWorkflows().getWorkflow()));
						if(responseBody.getMoreRecordsExist() != null && responseBody.getMoreRecordsExist().equals(WSS_MORE_RECORDS_EXIST)){
							response.setMoreRecordsExist(true);
						}
						else{
							response.setMoreRecordsExist(false);
						}
					} else {
						response.setMoreRecordsExist(false);
					}
				}
			}
		return response;
	}

	
	private SavedApplicationsResponse retrieveIAApplications(Collection<String> iaCodes, 
			String detailsLevel, String firstName, String lastName, String appStatus, Integer pageNumber, Integer numberPerPage) {	
		
		List<Workflow> workflowsIA = new ArrayList<>();
		List<Workflow> workflowsIACond = new ArrayList<>();
		logger.info("In retrieveIAApplications");
		//IA approved applications
		GetStatusResponseWrapper.Body responseBody = callWss(iaCodes, detailsLevel, firstName, lastName, appStatus, pageNumber, numberPerPage);
		//Conditionally approved applications
		GetStatusResponseWrapper.Body responseBodyCondApp = callWss(iaCodes, detailsLevel, firstName, lastName, AppStatus.CONDITIONALLY_APPROVED.toString(), pageNumber, numberPerPage);
		
		List <GetStatusResponseWrapper.Body> responseList=responseBody.getBodyList();
		List <GetStatusResponseWrapper.Body> responseCondAppList=responseBodyCondApp.getBodyList();
		
		if(Optional.ofNullable(responseBody).isPresent()) {
			if(!responseList.isEmpty()) {
				for(GetStatusResponseWrapper.Body resp : responseList) {
					if( Optional.ofNullable(resp.getWorkflows()).isPresent() ) {
						workflowsIA.addAll(resp.getWorkflows().getWorkflow().stream().collect(Collectors.toList()));
					}
				}
			}
			else {	
				if( Optional.ofNullable(responseBody.getWorkflows()).isPresent() )
						workflowsIA = responseBody.getWorkflows().getWorkflow().stream().collect(Collectors.toList());
			}
		}
		
		if(Optional.ofNullable(responseBodyCondApp).isPresent()) {
			if(!responseCondAppList.isEmpty()) {
				for(GetStatusResponseWrapper.Body respCondApp : responseCondAppList) {
					if( Optional.ofNullable(respCondApp.getWorkflows()).isPresent() ) {
						workflowsIACond.addAll(respCondApp.getWorkflows().getWorkflow().stream().collect(Collectors.toList()));
					}
				}
			}
			else {
				if( Optional.ofNullable(responseBodyCondApp.getWorkflows()).isPresent() ) 
						workflowsIACond = responseBodyCondApp.getWorkflows().getWorkflow().stream().collect(Collectors.toList());
			}
		}
		
		// Merge both lists
		List<Workflow> workflows = Stream.concat(workflowsIA.stream(), workflowsIACond.stream()).collect(Collectors.toList());
		
		SavedApplicationsResponse response;
		if (null != workflows) {
			response = new SavedApplicationsResponse(convertToSavedApplications(workflows));
			if (null != responseBody && responseBody.getMoreRecordsExist() != null
					&& responseBody.getMoreRecordsExist().equals(WSS_MORE_RECORDS_EXIST)
					|| (null != responseBodyCondApp && responseBodyCondApp.getMoreRecordsExist() != null
							&& responseBodyCondApp.getMoreRecordsExist().equals(WSS_MORE_RECORDS_EXIST))) {
				response.setMoreRecordsExist(true);
			} else {
				response.setMoreRecordsExist(false);
			}
		} else {
			response = new SavedApplicationsResponse(new ArrayList<>());
			response.setMoreRecordsExist(false);
		}
		
		return response;
	}
	
	private List<SavedApplication> convertToSavedApplications(List<Workflow> workflows) {
		List<SavedApplication> savedApplications;
		if(workflows != null) {
			savedApplications = workflows.stream().
					map(new SavedApplicationMapper()).
					sorted((a1, a2) -> sortApplications(a1, a2)).
					collect(Collectors.toList());
		} else {
			savedApplications = new ArrayList<>();
		}

		// WSS returns network id, not user name, so populate it here
		namePopulator.populateLastUpdatedByNames(savedApplications);
		return savedApplications;
	}

	int sortApplications(SavedApplication a1, SavedApplication a2) {
		if(a1.getLastUpdated() == null && a2.getLastUpdated() == null) {
			return 0;
		}
		if(a1.getLastUpdated() == null) {
			return 1;
		}
		if(a2.getLastUpdated() == null) {
			return -1;
		}
		try {
			return -1 * forgivingDateParse(a1).compareTo(forgivingDateParse(a2));
		} catch (Exception ex) {
			logger.error("Failed to sort saved applications",ex);
			throw new WebServiceException(ex);
		}
	}

	private Date forgivingDateParse(SavedApplication savedApp) {
		try {
			return DateUtils.convertStringToDateTimeNoTimezone(savedApp.getLastUpdated());
		} catch(WebServiceException e) {
			logger.warn("Failure in date conversion.", e);
			if(e.getCause().getClass().isAssignableFrom(ParseException.class)) {
				// got invalid format, but return something so screen can load
				try {
	                return DateUtils.convertStringToDateTime(savedApp.getLastUpdated(), "yyyy-MM-dd'T'HH:mm:ss");
				} catch(WebServiceException e2) {
					logger.info(e2.getMessage(), e2);
					if(e.getCause().getClass().isAssignableFrom(ParseException.class)) {
						logger.error(String.format("Found invalid last update date %s for workflow id %s", 
								savedApp.getLastUpdated(),
								savedApp.getAccounts()));
						return new Date();
					} else {
						throw e;
					}
				}
			} else {
				throw e;
			}
		}
	}

	private GetStatusResponseWrapper.Body callWss(final Collection<String> iaCodes, String detailsLevel,
			String firstName, String lastName, String appStatus) {
		return callWss(iaCodes, detailsLevel, firstName, lastName, appStatus, null, null);
	}

	
	private GetCountResponseWrapper.Body getCount(List<String> iaCodes, List<String> appStatus) {
		
		securityService.authorizeReadAccessToAll(iaCodes);
		GetCountRequestWrapper getCountRequest = new GetCountRequestWrapper();
		GetCountRequestWrapper.Body body = new GetCountRequestWrapper.Body();
		getCountRequest.setBody(body);

		if (CollectionUtils.isNotEmpty(iaCodes)) {
			ByAccess byAccess = new ByAccess();
			byAccess.getAccess().addAll(iaCodes);
			body.setByAccess(byAccess);
		} else {
			logger.error("User do not have access to IA codes"); 
			throw new ForbiddenSecurityException("User do not have access to IA code");
		}

		ByStatus byStatus = new ByStatus();
		byStatus.getStatus().addAll(appStatus);
		body.setByStatus(byStatus);

		try {
			GetCountResponseRootWrapper getCountResponseRootWrapper = workflowStatusEndpointInterface.getCount(getCountRequest, generateHeaderString(createHeader(WSS_GET_COUNT)));
			return getCountResponseRootWrapper.getGetCountResponse().getBody();
		} catch (JsonProcessingException ex) {
			logger.error("Failed to get user count for IA codes and app status", ex); 
			throw new WebServiceException(ex);
		}

	}

	/**
//	 * @param criteria: one of summary, steps, actions
	 * @param iaCodes
	 * @param detailsLevel
	 * @param firstName 
	 * @param pageNumber 
	 * @param pageSize 
	 * @return
	 */
	private GetStatusResponseWrapper.Body callWss(final Collection<String> iaCodes, String detailsLevel,
			String firstName, String lastName, String appStatus, Integer pageNumber, Integer pageSize) {
		securityService.authorizeReadAccessToAll(iaCodes);

		GetStatusRequestWrapper getStatusRequest = new GetStatusRequestWrapper();
		GetStatusRequestWrapper.BodyWrapper body = new GetStatusRequestWrapper.BodyWrapper();
		GetStatusResponseWrapper.Body finalBody = new GetStatusResponseWrapper.Body();
		
		getStatusRequest.setBody(body);
		body.setDetailsLevel(detailsLevel);

		if(CollectionUtils.isNotEmpty(iaCodes)) {
					logger.info("Total Number of IA codes:"+iaCodes.size());
					//If number of iaCodes are less than 1000
					if(iaCodes.size()<=BATCH_SIZE){
					ByAccess byAccess = new ByAccess();
					body.setByAccess(byAccess);
					byAccess.getAccess().addAll(iaCodes);
					populateStatusRequest(body,firstName,lastName,appStatus);
					finalBody=getStatusResponse(getStatusRequest);
					return finalBody;
			}
			else {
					List<GetStatusResponseWrapper.Body> bodyList = new ArrayList<>();
					// Split the list if number of iaCodes are greater than 999
					split((List<String>) iaCodes).stream().forEach(lstiaCodes  -> {
						ByAccess byAccess = new ByAccess();
						body.setByAccess(byAccess);
						int lstiaCodesCounter=1;
						// get the summary for each list
						logger.info("For batch: "+lstiaCodesCounter+" size is:"+lstiaCodes.size());
						byAccess.getAccess().addAll(lstiaCodes);
						populateStatusRequest(body,firstName,lastName,appStatus);
						bodyList.add(getStatusResponse(getStatusRequest));
						lstiaCodesCounter++;
					});
					finalBody.setBodyList(bodyList);
					return finalBody;
			}
	}
	else {
			logger.error("No user has access to all IA codes"); 
			throw new ForbiddenSecurityException("No user has access to all IA codes");
		}
	}
	
	private void populateStatusRequest(GetStatusRequestWrapper.BodyWrapper body,String firstName, String lastName, String appStatus) {
		logger.info("PopulateStatusRequest starts");
		if(StringUtils.isNotEmpty(firstName)) {
			body.setFirstName(firstName);
		}
		if(StringUtils.isNotEmpty(lastName)) {
			body.setLastName(lastName);
		}
		if(StringUtils.isNotEmpty(appStatus)) {
			body.setWorkflowStatus(appStatus);
		}
		body.setPageNumber("1");
		// default value suggested by Vlad B.
		body.setPageSize("300");
		logger.info("PopulateStatusRequest ends");
	}

	private GetStatusResponseWrapper.Body getStatusResponse(GetStatusRequestWrapper getStatusRequest) {
		GetStatusResponseRootWrapper getStatusResponse = new GetStatusResponseRootWrapper();
		try {
				getStatusResponse = workflowStatusEndpointInterface.getStatus(getStatusRequest, generateHeaderString(createHeader(WSS_GET_STATUS)));
				return getStatusResponse.getGetStatusResponse().getBody();
		} catch ( JsonProcessingException ex) {
			logger.error("Failure in workflow status service response.",ex); 
			throw new WebServiceException(ex);
		}
	}
	
	private APIHeaderRequest createHeader(String value) {
		return apiHeaderRequestComponent
				.getHubBuilder()
				.originatorResource(WSS_SERVICE_NAME)
				.originatorResourceFunction(value)
				.build();
	}

	//todo for RestAPI json
	String generateHeaderString(final APIHeaderRequest requestHeader) throws JsonProcessingException {
		String temp = ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
		logger.info("Header string: ",temp); 
		return temp;
	}

	List<String> determineIaCodes(String appStatus) {
		return usersService.currentUser().getIaCodes();
	}

	List<KeyValuePair> createFilterForAppStatus(String appStatus) {
		return new ArrayList<>(Arrays.asList(createCurrentStepCriteria(appStatus)));
	}

	private KeyValuePair createCurrentStepCriteria(String appStatus) {
		return createCriteria(CURRENT_STEP, appStatus);
	}

	private KeyValuePair createCriteria(String key, String value) {
		KeyValuePair kv = new KeyValuePair();
		kv.setKey(key);
		kv.setValue(value);
		return kv;
	}

	@Override
	public SavedApplication retrieveSavedApplication(String workflowId) {
		GetStatusRequestWrapper getStatusRequest = new GetStatusRequestWrapper();
		GetStatusRequestWrapper.BodyWrapper body = new GetStatusRequestWrapper.BodyWrapper();
		GetStatusRequestWrapper.BodyWrapper.ByWorkflow byWorkflow = new GetStatusRequestWrapper.BodyWrapper.ByWorkflow();
		byWorkflow.setWorkflowId(workflowId);

		ApplicationLob lob = userContext.getAuthenticatedUser().getLob();

		if (ApplicationLob.nb == lob)
			byWorkflow.setWorkflowTemplateId(PWOB);
		else if (ApplicationLob.il == lob)
			byWorkflow.setWorkflowTemplateId(MYWEALTH);

		body.setByWorkflow(byWorkflow);
		body.setDetailsLevel(DETAILS_LEVEL_SUMMARY);
		getStatusRequest.setBody(body);
		try {
			GetStatusResponseRootWrapper response = workflowStatusEndpointInterface.getStatus(getStatusRequest, generateHeaderString(createHeader(WSS_GET_STATUS)));
			if(Optional.ofNullable(response).isPresent() && Optional.ofNullable(response.getGetStatusResponse().getBody().getWorkflows()).isPresent() &&
					CollectionUtils.isNotEmpty(response.getGetStatusResponse().getBody().getWorkflows().getWorkflow())) {
				Workflow workflow = response.getGetStatusResponse().getBody().getWorkflows().getWorkflow().get(0);
				return new SavedApplicationMapper().apply(workflow);
			} else {
				logger.error("Application could not be found in WSS with workflow id: "+workflowId); 
				throw new NotFoundException("Application could not be found in WSS");
			}
		} catch ( JsonProcessingException ex) {
			logger.error("Failed to save application with workflow id: ",workflowId, ex);
			throw new WebServiceException(ex);
		}		
	}

	@Override
	public Summary retrieveApplicationsSummary(String iaCode) {
		List<String> iaCodes;
		List<String> appStatus;
		
		if(StringUtils.isEmpty(iaCode)) {
			List<String> userIaCodes = usersService.currentUser().getIaCodes();
			if(CollectionUtils.isNotEmpty(userIaCodes)) {
				iaCodes = userIaCodes;
			} else {
				// BM may not have any IA codes
				iaCodes = new ArrayList<>();
			}
		} else {
			securityService.authorizeReadAccess(iaCode);
			iaCodes = new ArrayList<>(Arrays.asList(iaCode));
		}
		
		//list of all App status
		appStatus = Stream.of(AppStatus.values()).map(AppStatus::toString).collect(Collectors.toList());
		Summary summary = new Summary();
		
		if(CollectionUtils.isEmpty(iaCodes)) {
			return summary;
		} else {
			//remove duplicate IaCodes			
			iaCodes = iaCodes.stream().collect(Collectors.toSet()).stream().collect(Collectors.toList());			
			
			//If number of iaCodes are less than 1000
			if(iaCodes.size()<=BATCH_SIZE){
				return getCountSummary(iaCodes,appStatus);				
			}else{				
				
				List<Summary> sumList = new ArrayList<>();
				Summary sumConsolidated = new Summary();
						
				// Split the list if number of iaCodes are greater than 999
				split(iaCodes).stream().forEach(lst  -> {
					int lstCounter=1;
					// get the summary for each list
					logger.info("For batch: "+lstCounter+" size is:"+lst.size());
					sumList.add(getCountSummary(lst,appStatus));
					lstCounter++;
				});
				
				//Consolidate the Summary 
				sumList.stream().forEach(finalCount -> {
					int indiVidualCounter=1;
					sumConsolidated.setDataCollection(sumConsolidated.getDataCollection() + finalCount.getDataCollection());
					logger.info("For batch:"+indiVidualCounter+" DataCollection Count:"+sumConsolidated.getDataCollection() + finalCount.getDataCollection());
					sumConsolidated.setApproved(sumConsolidated.getApproved() + finalCount.getApproved());
					logger.info("For batch:"+indiVidualCounter+" Approved Count:"+sumConsolidated.getApproved() + finalCount.getApproved());
					sumConsolidated.setBmApproval(sumConsolidated.getBmApproval() + finalCount.getBmApproval());
					logger.info("For batch:"+indiVidualCounter+" BmApproval Count:"+sumConsolidated.getBmApproval() + finalCount.getBmApproval());
					sumConsolidated.setDocumentCollection(sumConsolidated.getDocumentCollection() + finalCount.getDocumentCollection());
					logger.info("For batch:"+indiVidualCounter+" DocumentCollection Count:"+sumConsolidated.getDocumentCollection() + finalCount.getDocumentCollection());
					sumConsolidated.setIaApproval(sumConsolidated.getIaApproval() + finalCount.getIaApproval());
					logger.info("For batch:"+indiVidualCounter+" IaApproval Count:"+sumConsolidated.getIaApproval() + finalCount.getIaApproval());
					sumConsolidated.setIaRemediation(sumConsolidated.getIaRemediation() + finalCount.getIaRemediation());
					logger.info("For batch:"+indiVidualCounter+" IaRemediation Count:"+sumConsolidated.getIaRemediation() + finalCount.getIaRemediation());
					sumConsolidated.setAccountSetup(sumConsolidated.getAccountSetup() + finalCount.getAccountSetup());		
					logger.info("For batch:"+indiVidualCounter+" AccountSetup Count:"+sumConsolidated.getAccountSetup() + finalCount.getAccountSetup());
					indiVidualCounter++;
				}  );
				
				return sumConsolidated;				
			}						
					
		}		
		
	}
	
	public List<List<String>> split(List<String> iaCodes) {
		return IntStream.range(0, getNumberOfPartitions(iaCodes))
				.mapToObj(i -> iaCodes.subList(i * BATCH_SIZE, Math.min((i + 1) * BATCH_SIZE, iaCodes.size())))
				.collect(Collectors.toList());
	}		
	
	public static  int getNumberOfPartitions(List<String> list) {
	    return (list.size() + BATCH_SIZE- 1) / BATCH_SIZE;
	}   
	
	public Summary getCountSummary(List<String> iaCodes, List<String> appStatus){
		
		Summary summary = new Summary();
		List<Workflowcount> workFlowCount;
		int iaApprovalCount;
		int iaConApprovalCount;
		
		GetCountResponseWrapper.Body countResponse = getCount(iaCodes, appStatus);
		
		if(Optional.ofNullable(countResponse).map(GetCountResponseWrapper.Body::getCounts).map(Body.Counts::getWorkflowcount).isPresent()){			
			workFlowCount = countResponse.getCounts().getWorkflowcount();
		}else{
			logger.info("WSS GetCount Response has null value");
			workFlowCount = new ArrayList<Workflowcount>();
		}	
		
		summary.setDataCollection(appCount(workFlowCount, AppStatus.DATA_COLLECTION.toString()));
		summary.setApproved(appCount(workFlowCount, AppStatus.COMPLETE.toString()));
		summary.setBmApproval(appCount(workFlowCount, AppStatus.BM_APPROVAL.toString()));
		summary.setDocumentCollection(appCount(workFlowCount, AppStatus.DOCUMENT_COLLECTION.toString()));
		iaApprovalCount = appCount(workFlowCount, AppStatus.IA_APPROVAL.toString());
		iaConApprovalCount = appCount(workFlowCount, AppStatus.CONDITIONALLY_APPROVED.toString());
		summary.setIaApproval(iaApprovalCount + iaConApprovalCount);
		summary.setIaRemediation(appCount(workFlowCount, AppStatus.IA_REMEDIATION.toString()));
		summary.setAccountSetup(appCount(workFlowCount, AppStatus.ACCOUNT_SETUP.toString()));
				
		return summary;		
		
	}	
	
	public int appCount(List<Workflowcount> workFlowCount, String status){
		Optional<Workflowcount> count = workFlowCount.stream().filter(wCount -> wCount.getApplicationStatus().equals(status)).findFirst();
		if(count.isPresent()){
			return Integer.parseInt(count.get().getCount());
		}
		else return 0;
	}

	List<String> bmApprovalIaCodes(List<String> iaCodes) {
		Set<String> iaCodesWithBMApproval = new HashSet<>();
		iaCodesWithBMApproval.addAll(iaCodes);
		List<String> bmApproverFor = usersService.currentUser().getBmApproverFor();
		if(CollectionUtils.isNotEmpty(bmApproverFor)) {
			iaCodesWithBMApproval.addAll(bmApproverFor);
		}
		return new ArrayList<>(iaCodesWithBMApproval);
	}
	
	@Override
	public SavedApplicationsResponse retrieveSavedApplicationsByCustomerId(List<String> ecifId) {
		if (usersService.currentUser().getLob().equals(ApplicationLob.il)) {
			return retrieveSavedApplicationsByIaCode(
					ecifId.stream().
					map(c -> ECIF_BY_ACCESS.concat(c)).
					collect(Collectors.toList()));
		} else {
			throw new UnauthorizedSecurityException(ErrorCodes.INVALID_LOB);
		}
	}
	
	@Override
	public SavedApplicationsResponse retrieveSavedApplicationsByIaCode(List<String> iaCode) {
		return retrieveSavedApplicationsByIaCode(null, iaCode);
	}

	@Override
	public SavedApplicationsResponse retrieveSavedApplicationsByIaCode(String appStatus, List<String> iaCode) {
		return this.retrieveApplications(iaCode, DETAILS_LEVEL_SUMMARY, null, null, appStatus);
	}
}
