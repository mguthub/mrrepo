package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class FinancialInstitutionsResponse {
	private List<FinancialInstitution> financialInstitutions;
	
	public FinancialInstitutionsResponse(List<FinancialInstitution> financialInstitutions) {
		this.financialInstitutions = financialInstitutions;
	}
	
	public List<FinancialInstitution> getFinancialInstitutions() {
		return financialInstitutions;
	}

	public void setFinancialInstitutions(List<FinancialInstitution> financialInstitutions) {
		this.financialInstitutions = financialInstitutions;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
