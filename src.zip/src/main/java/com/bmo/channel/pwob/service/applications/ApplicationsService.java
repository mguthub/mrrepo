package com.bmo.channel.pwob.service.applications;

import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Party;

/**
 * For creating/updating an Application
 * @author Ryan Chambers rcham02
 */
public interface ApplicationsService {
	/**
	 * Remove a spouse Party from application. Will fail if partyRefId is not a spouse.
	 */
	Application removeSpousePartyFromApplication(Application updatedApp, String partyRefId);
	
	Application addJointApplicantToApplication(Application updatedApp, Party jointApplicantParty);

	Application removeAccountFromApplication(Application existingApp, String accountRefId);
}
