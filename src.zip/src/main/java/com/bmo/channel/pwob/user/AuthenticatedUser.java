package com.bmo.channel.pwob.user;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;

public class AuthenticatedUser {
	final private String networkId;
	final private ApplicationLob lob;
	final private String domain;

	public AuthenticatedUser(String networkId, String domain, ApplicationLob lob) {
		this.networkId = networkId;
		this.domain = domain;
		this.lob = lob;
	}

	public String getUserId() {
		return networkId;
	}

	public String getNetworkId() {
		return networkId;
	}
	public ApplicationLob getLob() {
		return lob;
	}
	public String getDomain() {
		return domain;
	}
}
