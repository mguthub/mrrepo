package com.bmo.channel.pwob.validation;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Name;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class NameValidatorImpl extends AbstractBaseValidator implements NameValidator {
	public static final String NAME_PATH = "name";
	public static final String FIRST_NAME_FIELD_NAME = "firstName";
	public static final String LAST_NAME_FIELD_NAME = "lastName";
	public static final String TITLE_FIELD_NAME = "title";

	@Override
	public boolean validateFirstName(Name name, ValidationRequest validationRequest) {
		ValidationRequest nameValReq = createNameValReq(validationRequest);
		nameValReq.setFieldValue(name.getFirstName());
		nameValReq.setFieldName(FIRST_NAME_FIELD_NAME);
		nameValReq.setErrorCode(ErrorCodes.INVALID_FIRST_NAME);
		return validateAndAddConstraintViolation(nameValReq);
	}

	@Override
	public boolean validateLastName(Name name, ValidationRequest validationRequest) {
		ValidationRequest nameValReq = createNameValReq(validationRequest);
		nameValReq.setFieldValue(name.getLastName());
		nameValReq.setFieldName(LAST_NAME_FIELD_NAME);
		nameValReq.setErrorCode(ErrorCodes.INVALID_LAST_NAME);
		return validateAndAddConstraintViolation(nameValReq);
	}

	@Override
	public boolean validateTitle(Name name, ValidationRequest validationRequest) {
		ValidationRequest nameValReq = createNameValReq(validationRequest);
		nameValReq.setFieldValue(name.getTitle());
		nameValReq.setFieldName(TITLE_FIELD_NAME);
		nameValReq.setErrorCode(ErrorCodes.INVALID_TITLE);
		if(StringUtils.isNotBlank(nameValReq.getFieldValue())) {
			return this.validateField(nameValReq);
		}
		return true;
	}

	private ValidationRequest createNameValReq(ValidationRequest validationRequest) {
		ValidationRequest nameValReq = validationRequest.createChildValidationRequest(validationRequest.getChildPropertyNode(), NAME_PATH);
		return nameValReq;
	}
}
