package com.bmo.channel.pwob.service.iacode;

import java.util.List;


import com.bmo.channel.pwob.user.AuthenticatedUser;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetDetailedUserInformationResponseType;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetUsersForInvestmentAdvisorCodeResponseType.PcdUsers.PcdUser;

public interface IaCodesService {
	public GetDetailedUserInformationResponseType getUserInformation(AuthenticatedUser authenticatedUser);
	
	public List<PcdUser> usersForIaCode(String iaCode, String branchCode);
	
	public List<net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser> iaUsersForIaCode(String iaCode, String branchCode);

}
