package com.bmo.channel.pwob.service.authorization.nb;

enum UserRole {
	BM_APPROVER,
	IA_APPROVER,
	APPLICATION_USER,
	ANY_USER
}