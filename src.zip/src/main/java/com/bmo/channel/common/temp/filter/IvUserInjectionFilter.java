package com.bmo.channel.common.temp.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.config.EnvironmentConfig;
import com.bmo.channel.pwob.user.UserContextImpl;

/**
 * This filter will: 
 * Inject iv-user and iv-groups headers into an incoming response if the enable.fake.injection environment property equals "true"
 * It was made specifically for the ILLaunchEndpoint for testing purposes and SHOULD NOT be enabled in production
 * 
 * @author Connor Fraser cfrase06
 */

public class IvUserInjectionFilter implements Filter{
	
	public static final String INJECTED_USER = "PWOBOFFQA1@pcdqa.OfficeQA";
	public static final String INJECTED_GROUPS = "PWOB_BIL_USERS";
	
	@Autowired
	EnvironmentConfig environmentConfig;
	
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		// no init required
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		if("true".equals(environmentConfig.getInjectionEnabled())) {
			final HttpServletRequest httpRequest = (HttpServletRequest) request;
		    HttpServletRequestWrapper wrapper = new HttpServletRequestWrapper(httpRequest) {
		        @Override
		        public String getHeader(String name) {
		            if (name.equals(UserContextImpl.IV_USER_HEADER)) {
		                return INJECTED_USER;
		            }
		            if (name.equals(UserContextImpl.IV_GROUPS_HEADER)) {
		                return INJECTED_GROUPS;
		            }
		            return super.getHeader(name);
		        }
		    };
		    chain.doFilter(wrapper, response);
		}
		else{
			chain.doFilter(request, response);
		}
	}

	@Override
	public void destroy() {
		// no clean-up required
	}
	
}
