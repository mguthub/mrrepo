package com.bmo.channel.pwob.service.fis;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.onboarding.FinancialInstitution;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class FinancialInstitutionsHubResponse {
	private OperationResponse operationResponse;
	
	@JsonIgnoreProperties(ignoreUnknown = true)
	static class OperationResponse {
		private GetFIListResponse getFIListResponse;
		
		@JsonIgnoreProperties(ignoreUnknown = true)
		static class GetFIListResponse {
			private List<Record> records;

			@JsonIgnoreProperties(ignoreUnknown = true)
			static class Record {
				private String institutionNumber;
				private String institutionNameEnglish;
				private String institutionNameFrench;

				@JsonProperty("InstitutionNumber")
				public String getInstitutionNumber() {
					return institutionNumber;
				}
				public void setInstitutionNumber(String institutionNumber) {
					this.institutionNumber = institutionNumber;
				}
				
				@JsonProperty("InstitutionNameEnglish")
				public String getInstitutionNameEnglish() {
					return institutionNameEnglish;
				}
				public void setInstitutionNameEnglish(String institutionNameEnglish) {
					this.institutionNameEnglish = institutionNameEnglish;
				}

				@JsonProperty("InstitutionNameFrench")
				public String getInstitutionNameFrench() {
					return institutionNameFrench;
				}
				public void setInstitutionNameFrench(String institutionNameFrench) {
					this.institutionNameFrench = institutionNameFrench;
				}
			}

			@JsonProperty("Record")
			public List<Record> getRecord() {
				return records;
			}
			public void setRecord(List<Record> records) {
				this.records = records;
			}	
		}

		public GetFIListResponse getGetFIListResponse() {
			return getFIListResponse;
		}
		public void setGetFIListResponse(GetFIListResponse getFIListResponse) {
			this.getFIListResponse = getFIListResponse;
		}
	}
	
	public OperationResponse getOperationResponse() {
		return operationResponse;
	}
	public void setOperationResponse(OperationResponse operationResponse) {
		this.operationResponse = operationResponse;
	}

	public List<FinancialInstitution> toFIList(UILocale locale) {
		List<OperationResponse.GetFIListResponse.Record> records = this.operationResponse.getGetFIListResponse().getRecord();
		List<FinancialInstitution> financialInstitutions = new ArrayList<>();

		if(CollectionUtils.isNotEmpty(records)) {
			for (OperationResponse.GetFIListResponse.Record record : records) {
				FinancialInstitution fi = new FinancialInstitution();
				fi.setFiId(record.getInstitutionNumber());

				if (locale == UILocale.FR_CA) {
					fi.setName(record.getInstitutionNameFrench());
				} else {
					// default to English
					fi.setName(record.getInstitutionNameEnglish());
				}

				financialInstitutions.add(fi);
			}
		}

		return financialInstitutions;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
