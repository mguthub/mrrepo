package com.bmo.channel.pwob.service.documentpackages.dto;


public class GetDocumentResponseDto {

	private DocumentDto document;

	public GetDocumentResponseDto(final DocumentDto documentDto) {
		this.document = documentDto;
	}

	public DocumentDto getDocument() {
		return document;
	}
	public void setDocument(final DocumentDto document) {
		this.document = document;
	}
}
