package com.bmo.channel.pwob.service.reference.model;

import java.util.ArrayList;
import java.util.List;

public class GetDataListForParameterRequestBody {
	protected List<ParamsInquiry> paramsInquiry;
	
	public List<ParamsInquiry> getParamsInquiry() {
        if (paramsInquiry == null) {
            paramsInquiry = new ArrayList<ParamsInquiry>();
        }
        return this.paramsInquiry;
    }
}
