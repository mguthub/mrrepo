/**
 * Implementation of service cache to add/remove element in/from to cache

 * @author akhales
 */
package com.bmo.channel.common.ehcache;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.Cache;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.support.SimpleValueWrapper;

public class CacheService extends AbstractEhCache{
	private static Logger logger = LoggerFactory.getLogger(CacheService.class);

	public CacheService(EhCacheCacheManager ehCacheManager) {
		this.initializeEhCache(ehCacheManager);
	}

	/**
	 * 
	 * @param obj : adding to cache.
	 * @param key : Prefix cache key defined in WFCacheKey.java
	 * @param id  : object id
	 */
	public void add(Object obj,final String key,String id,String cacheName) {
		long start = System.currentTimeMillis();

		try {
			Cache cache = getCache(cacheName);
			if (cache == null) {
				return;
			}

			cache.put(this.initialKey(id, key), obj);
			logger.debug("Object added to cache id [{}]",id);
		} catch (Exception ex) {
			logger.error("Error putting element to cache id=[{}]",id,ex);
		} finally {
			long end = System.currentTimeMillis();
			logger.debug("cache .add() execution time [{}] milliseconds",start-end);
		}
	}	

	/**
	 * 
	 * @param obj : An object adding to cache.
	 * @param key : Prefix cache key defined in WFCacheKey.java
	 * @param id  : object id
	 * @return   a found object in the cache
	 */
	public Object get(final String key,String id,String cacheName)  {
		long start = System.currentTimeMillis();
		Object response = null;

		try {
			if (key == null ) {
				logger.error("Null cachekey. Object cannot be added to {} [{}]" , cacheName, key);
				return response;
			}	

			if (StringUtils.isEmpty(id) ){ 
				logger.error("Null id. Object cannot be retrieved from {} [{}]" , cacheName, id);
				return response;
			}

			Cache cache = this.getCache(cacheName);
			if (cache == null) 
				return response;

			SimpleValueWrapper simpleValueWrapper  = (SimpleValueWrapper) cache.get(this.initialKey(id, key));
			if (simpleValueWrapper !=null) 
				response = simpleValueWrapper.get();	

			return response;
		}catch (Exception ex){
 			logger.error("Error getting element from cache.",ex);
		} finally {
			long end = System.currentTimeMillis();
			logger.debug("cache .get() execution time [{}] milliseconds",start-end);
		}
		return null;
	}

	public void removeCache(String cacheName) {
		
		try {
			Cache cache = getCache(cacheName);
			if (cache == null) 
				return ;
			cache.clear();

		}catch (Exception ex) {
			logger.debug("Error clearing cache cacheName [{}]",cacheName, ex);
		}
	}
	
	private Cache  getCache(String cacheName) {
		Cache response=null;


		if (MapUtils.isEmpty(this.getCachNames())) {
			logger.error("EhCacheManager not found. Please contact administrator.");
			return response;
		}
		
		String name = getCachNames().get(cacheName);

		if (StringUtils.isEmpty(name)) {
			logger.error("EhCache Map is empty. cache name was not found.[{}]",cacheName);
			return response;
		}	

		response = getEhCacheManager().getCache(name);
		if (response== null ) 
			logger.error( "No instance of " + cacheName + " available. Please contact administrator.");
		
		return response;
	}
}
