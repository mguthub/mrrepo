/**
 * 
 */
package com.bmo.channel.pwob.service.accounts;

import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 * @author vvallia
 *
 */
public class ValidateAccountResponse {
	
	@JsonIgnore
	private boolean isValidAccountNumber;
	
	private String accountId;
	
	public boolean isIsValidAccountNumber() {
		return isValidAccountNumber;
	}
	
	public void setValidAccountNumber(boolean isValidAccountNumber) {
		this.isValidAccountNumber = isValidAccountNumber;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
}
