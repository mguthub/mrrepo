package com.bmo.channel.pwob.service.product.rsclient;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountType {
    protected String code;
    protected String nameEN;
    protected String nameFR;
    protected String eligibility;
    protected List<Feature> feature;
    protected List<AccountType.FeeCodeList> feeCodeList;
    protected AccountType.OptionTradingLevels optionTradingLevels;
    protected AccountType.OutboundEftFrequencies outboundEftFrequencies;
    protected ReasonsForRejection reasonsForRejection;

    public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}

	public String getNameEN() {
		return nameEN;
	}
	public void setNameEN(String nameEN) {
		this.nameEN = nameEN;
	}

	public String getNameFR() {
		return nameFR;
	}
	public void setNameFR(String nameFR) {
		this.nameFR = nameFR;
	}

	public String getEligibility() {
		return eligibility;
	}
	public void setEligibility(String eligibility) {
		this.eligibility = eligibility;
	}

	public List<Feature> getFeatureList() {
		return feature;
	}
	public void setFeatureList(List<Feature> feature) {
		this.feature = feature;
	}

	public List<AccountType.FeeCodeList> getFeeCodeList() {
		return feeCodeList;
	}
	public void setFeeCodeList(List<AccountType.FeeCodeList> feeCodeList) {
		this.feeCodeList = feeCodeList;
	}

	public AccountType.OptionTradingLevels getOptionTradingLevels() {
		return optionTradingLevels;
	}
	public void setOptionTradingLevels(AccountType.OptionTradingLevels optionTradingLevels) {
		this.optionTradingLevels = optionTradingLevels;
	}

	public AccountType.OutboundEftFrequencies getOutboundEftFrequencies() {
		return outboundEftFrequencies;
	}
	public void setOutboundEftFrequencies(AccountType.OutboundEftFrequencies outboundEftFrequencies) {
		this.outboundEftFrequencies = outboundEftFrequencies;
	}

	public ReasonsForRejection getReasonsForRejection() {
		return reasonsForRejection;
	}
	public void setReasonsForRejection(ReasonsForRejection reasonsForRejection) {
		this.reasonsForRejection = reasonsForRejection;
	}

	public static class FeeCodeList {
        protected List<String> feeCode;
    	@JsonProperty("Type")
        protected String type;
		public List<String> getFeeCode() {
			return feeCode;
		}
		public void setFeeCode(List<String> feeCode) {
			this.feeCode = feeCode;
		}
		public String getType() {
			return type;
		}
		public void setType(String type) {
			this.type = type;
		}
    }

    public static class OptionTradingLevels {
    	@JsonProperty("Level")
        protected List<String> level;

		public List<String> getLevel() {
			return level;
		}

		public void setLevel(List<String> level) {
			this.level = level;
		}
    }

    public static class OutboundEftFrequencies {
        protected List<String> frequency;

		public List<String> getFrequency() {
			return frequency;
		}

		public void setFrequency(List<String> frequency) {
			this.frequency = frequency;
		}
    }
}