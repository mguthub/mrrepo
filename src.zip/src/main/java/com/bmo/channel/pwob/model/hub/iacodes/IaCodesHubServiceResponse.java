package com.bmo.channel.pwob.model.hub.iacodes;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class IaCodesHubServiceResponse {
	GetInvestmentAdvisorCodeResponseBody getInvestmentAdvisorCodeResponseBody;

	public GetInvestmentAdvisorCodeResponseBody getGetInvestmentAdvisorCodeResponseBody() {
		return getInvestmentAdvisorCodeResponseBody;
	}

	public void setGetInvestmentAdvisorCodeResponseBody(
			GetInvestmentAdvisorCodeResponseBody getInvestmentAdvisorCodeResponseBody) {
		this.getInvestmentAdvisorCodeResponseBody = getInvestmentAdvisorCodeResponseBody;
	}
	
}
