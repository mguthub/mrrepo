package com.bmo.channel.pwob.service.reference.model;


public class GetDataListForParameterRequest {
	private GetDataListForParameterRequestBody getDataListForParameterRequest;

	public GetDataListForParameterRequestBody getGetDataListForParameterRequest() {
		return getDataListForParameterRequest;
	}

	public void setGetDataListForParameterRequest(GetDataListForParameterRequestBody request) {
		this.getDataListForParameterRequest = request;
	}
}
