package com.bmo.channel.pwob.convert.migration;

import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;

public interface RelationshipSummaryMigrator {

	boolean isMigrationRequired(RelationshipSummary relationshipSummary, FeatureFlags systemFeatureFlags, Application application);

	void migrateRelationshipSummary(RelationshipSummary relationshipSummary, FeatureFlags systemFeatureFlags, Application application);

}
