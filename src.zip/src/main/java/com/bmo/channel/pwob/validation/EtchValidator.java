package com.bmo.channel.pwob.validation;

import java.util.List;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.Phone;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactoryImpl.ValidationRequestBuilder;

public class EtchValidator extends AbstractBaseValidator implements ConstraintValidator<ValidEtch, Application>
{
	public static final String COUNTRY_CODE_PATTERN =  "^\\d\\d?\\d?$";

	@Autowired
	private UsersService userService;

	@Autowired 
	private ValidationRequestFactory validationRequestFactory;

	@Override
	public void initialize(ValidEtch constraintAnnotation) {	}

	@Override
	public boolean isValid(Application application, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		boolean valid = true;

		List<Party> primaries = this.getPrimaryApplicantParties(application.getParties());
		List<Party> joints = this.getJointApplicantParties(application.getParties());
		if(CollectionUtils.isEmpty(primaries)) {
			this.createConstraintViolation(context, ErrorCodes.INVALID_EMPTY_PARTY, PARTIES_NODE);
			return false;
		}

		int index = 0;

		for(Party party : primaries) {
			valid = validatePrimaryParty(party, application, index, context) && valid;
			index++;
		}		
		
		for(Party jointParty : joints) {
			valid = validateJointParty(jointParty, application, application.getParties().indexOf(jointParty), context) && valid;
		}
		
		return valid;
	}

	private boolean validatePrimaryParty(Party party, Application application, int index, ConstraintValidatorContext context) {
		ApplicationLob lob = this.userService.currentUser().getLob();
		ValidationRequestBuilder builder = validationRequestFactory.createBuilder(context, lob).withParentFieldPath(PARTIES_NODE+"["+ index +"]");

		ValidationRequest request = builder.withParentPropertyNode(PARTIES_NODE+"["+ index +"]").build();
		request.setIndex(index);
		request.setPartyRole(PartyRole.PRIMARY_APPLICANT);
		boolean valid = true;

		valid = this.validatePartyCountryCode(party, request, context, index) && valid;
		

		return valid;
	}
	
	private boolean validateJointParty(Party party, Application application, int index, ConstraintValidatorContext context) {
		ApplicationLob lob = this.userService.currentUser().getLob();
		ValidationRequestBuilder builder = validationRequestFactory.createBuilder(context, lob).withParentFieldPath(PARTIES_NODE+"["+ index +"]");

		ValidationRequest request = builder.withParentPropertyNode(PARTIES_NODE+"["+ index +"]").build();
		request.setIndex(index);
		request.setPartyRole(PartyRole.JOINT_APPLICANT);
		boolean valid = true;

		valid = this.validatePartyCountryCode(party, request, context, index) && valid;
		
		return valid;
	}

	
	
	private boolean validatePartyCountryCode(Party party, ValidationRequest request, ConstraintValidatorContext context, int index) {
		boolean valid = true;
		ApplicationLob lob = this.userService.currentUser().getLob();

		if(party.getPersonal() != null && party.getPersonal().getResidence() != null && party.getPersonal().getResidence().getPrimaryPhone() != null) {
			ValidationRequest phoneValReq = validationRequestFactory.createBuilder(context, lob).
					withParentPropertyNode(PARTIES_NODE+"["+ index +"]").
					withParentFieldPath(PARTIES_NODE+"["+ index +"]").
					withChildPropertyNode(PERSONAL_RESIDENCE + "." + PRIMARY_PHONE_NODE).
					withChildFieldPath(PERSONAL_RESIDENCE + "." + PRIMARY_PHONE_PATH).build();
			phoneValReq.setFieldName("countryCode");
			phoneValReq.setErrorCode(ErrorCodes.INVALID_PHONE_COUNTRY_CODE);
			phoneValReq.setPartyRole(request.getPartyRole());
			valid = this.isValidCountryCode(party, party.getPersonal().getResidence().getPrimaryPhone(), phoneValReq) && valid;
		}

		return valid;
	}

	public boolean isValidCountryCode(Party party, Phone phoneNumber, ValidationRequest request) {
		if (isInternationalNumber(party) && (StringUtils.isBlank(phoneNumber.getCountryCode())
						|| !this.doesPatternMatch(phoneNumber.getCountryCode(), COUNTRY_CODE_PATTERN))){
			request.addConstraintViolation();
			return false;
		}	
		return true;
	}
	
	public boolean isInternationalNumber(Party party) {
		if(party.getPersonal() != null && party.getPersonal().getResidence() != null 
				&& Optional.ofNullable(party.getPersonal().getResidence().getPrimaryPhone().getIsInternationalNumber()).isPresent()
				&& party.getPersonal().getResidence().getPrimaryPhone().getIsInternationalNumber()){
			
			return true;
		}
		return false;
	}
	

	protected boolean doesPatternMatch(String value, String pattern) {
		return StringUtils.isNoneBlank(value) && value.matches(pattern);
	}
	
}
