package com.bmo.channel.pwob.validation;

import java.math.BigInteger;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.InvestmentObjectives;
import com.bmo.channel.pwob.model.onboarding.RiskTolerance;
import com.bmo.channel.pwob.model.onboarding.TargetAllocation;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

@Component
public class InvestmentObjectivesValidatorImpl extends AbstractBaseValidator implements InvestmentObjectivesValidator {

	@Autowired ValidationRequestFactory requestFactory;	
	@Override
	public boolean validateTargetAllocation(TargetAllocation targetAllocation, ValidationRequest request) {
		BigInteger cash = targetAllocation.getCash();
		BigInteger equities = targetAllocation.getEquities();
		BigInteger fixedIncome = targetAllocation.getFixedIncome();
		boolean valid = true;				
		if (this.isTargetAllocationInValid(cash)) {			
			request.setErrorCode(ErrorCodes.INVALID_TARGET_ALLOCATION_CASH);
			request.setFieldName(TARGET_ALLOCATION_CASH_FIELD_NAME);
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}
			valid = false;
		}			
		
		if (this.isTargetAllocationInValid(equities)) {			
			request.setErrorCode(ErrorCodes.INVALID_TARGET_ALLOCATION_EQUITIES);
			request.setFieldName(TARGET_ALLOCATION_EQUITIES_FIELD_NAME);
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}			
			valid = false;
		}
		
		if (this.isTargetAllocationInValid(fixedIncome)) {			
			request.setErrorCode(ErrorCodes.INVALID_TARGET_ALLOCATION_FIXED_INCOME);
			request.setFieldName(TARGET_ALLOCATION_FIXED_INCOME_FIELD_NAME);
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}			
			valid = false;
		}

		if (this.isTargetAllocationTotalInValid(targetAllocation)) {							
			request.setErrorCode(ErrorCodes.INVALID_TARGET_ALLOCATION_TOTAL_CASH_EQUITIES_FIXEDINCOME_100);
			request.setFieldName(TARGET_ALLOCATION_TOTAL_FIELD_NAME);
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}	
			valid = false;				
		}
		return valid;
	}

	@Override
	public boolean validateRiskTolerance(RiskTolerance riskTolerance, ValidationRequest request) {
		BigInteger  low = riskTolerance.getLow();
		BigInteger medium = riskTolerance.getMedium();
		BigInteger high = riskTolerance.getHigh();
		boolean valid = true;				
		if (this.isRiskToleranceInValid(low)) { 			
			request.setErrorCode(ErrorCodes.INVALID_RISK_TOLERANCE_LOW);
			request.setFieldName(RISK_TOLERANCE_LOW_FIELD_NAME);
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}
			valid = false;
		}

		if (this.isRiskToleranceInValid(medium)) {
			request.setErrorCode(ErrorCodes.INVALID_RISK_TOLERANCE_MEDIUM);
			request.setFieldName(RISK_TOLERANCE_MEDIUM_FIELD_NAME);
            if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}
			valid = false;
		}

		if (this.isRiskToleranceInValid(high)) {			
			request.setErrorCode(ErrorCodes.INVALID_RISK_TOLERANCE_HIGH);
			request.setFieldName(RISK_TOLERANCE_HIGH_FIELD_NAME);			
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}		
			valid = false;
		}

		if (this.isRiskToleranceTotalInValid(riskTolerance)) {
			request.setErrorCode(ErrorCodes.INVALID_RISK_TOLERANCE_NOT_EQUAL_100);
			request.setFieldName(RISK_TOLERANCE_TOTAL_FIELD_NAME);
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}		
			valid = false;
		}								
		return valid;
	}

	private boolean isRiskToleranceInValid(BigInteger value) {
		return (value == null || value.intValue() > 100 || value.intValue() < 0);
	}
	
	private boolean isRiskToleranceTotalInValid(RiskTolerance riskTolerance) {
		return (Optional.ofNullable(riskTolerance.getLow()).isPresent() && 
				Optional.ofNullable(riskTolerance.getMedium()).isPresent() && 
				Optional.ofNullable(riskTolerance.getHigh()).isPresent() &&
				riskTolerance.getLow().add(riskTolerance.getMedium()).add(riskTolerance.getHigh()).intValue() != 100);
	}

	private boolean isTargetAllocationInValid(BigInteger value) {
		return (value == null || value.intValue() > 100 || value.intValue() < 0);
	}

	private boolean isTargetAllocationTotalInValid(TargetAllocation targetAllocation) {
		return (Optional.ofNullable(targetAllocation.getCash()).isPresent() && 
				Optional.ofNullable(targetAllocation.getEquities()).isPresent() && 
				Optional.ofNullable(targetAllocation.getFixedIncome()).isPresent() &&
				targetAllocation.getCash().add(targetAllocation.getEquities()).add(targetAllocation.getFixedIncome()).intValue() != 100);
	}

	@Override
	public boolean validateInvestmentObjectives(InvestmentObjectives investmentObjectives, ValidationRequest request) {
		if(investmentObjectives == null || StringUtils.isEmpty(investmentObjectives.getObjective())) {			
			request.setErrorCode(ErrorCodes.INVALID_INVESTMENT_OBJECTIVES);
			request.setFieldName(OBJECTIVE_FIELD_NAME);						
			if(Optional.ofNullable(request.getIndex()).isPresent()) {
				request.addConstraintViolation(request.getIndex());
			} else {
				request.addConstraintViolation();
			}
			return false;								
		}
		return true;
	}				

	@Override
	public boolean validateAccountInvestmentObjectives(Account account, ValidationRequest request) {
		boolean valid = true;
		ValidationRequest accReq = requestFactory.createBuilder(request.getContext(), request.getLob()).withChildPropertyNode(INVESTMENT_OBJECTIVES_NODE).build();

		InvestmentObjectives investmentObjectives = account.getInvestmentObjectives();

		if (!this.validateInvestmentObjectives(investmentObjectives, accReq)) {
			valid = false;
		}
		
		if(investmentObjectives != null) {
			RiskTolerance riskTolerance = investmentObjectives.getRiskTolerance();

			if (riskTolerance == null) {
				accReq.setErrorCode(ErrorCodes.INVALID_RISK_TOLERANCE);
				accReq.setFieldName(RISK_TOLERANCE_FIELD_NAME);
				if(Optional.ofNullable(accReq.getIndex()).isPresent()) {
					accReq.addConstraintViolation(accReq.getIndex());
				} else {
					accReq.addConstraintViolation();
				}
				valid = false;
			} else if(!this.validateRiskTolerance(riskTolerance, accReq)) {
				valid = false;
			}

			TargetAllocation targetAllocation = investmentObjectives.getTargetAllocation();
			if(targetAllocation == null) {
				accReq.setErrorCode(ErrorCodes.INVALID_TARGET_ALLOCATION);
				accReq.setFieldName(RISK_TOLERANCE_FIELD_NAME);
				if(Optional.ofNullable(accReq.getIndex()).isPresent()) {
					accReq.addConstraintViolation(accReq.getIndex());
				} else {
					accReq.addConstraintViolation();
				}
				valid = false;
			} else if(!this.validateTargetAllocation(targetAllocation, accReq)) {
				valid = false;
			}
		}

		return valid;
	}
}
