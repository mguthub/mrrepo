package com.bmo.channel.pwob.model.onboarding;

import java.math.BigInteger;

import org.apache.commons.lang3.builder.ToStringBuilder;


public class NetWorth {
	private BigInteger liquidAssets;
	private BigInteger fixedAssets;

	public BigInteger getLiquidAssets() {
		return liquidAssets;
	}
	public void setLiquidAssets(BigInteger liquidAssets) {
		this.liquidAssets = liquidAssets;
	}
	public BigInteger getFixedAssets() {
		return fixedAssets;
	}
	public void setFixedAssets(BigInteger fixedAssets) {
		this.fixedAssets = fixedAssets;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
