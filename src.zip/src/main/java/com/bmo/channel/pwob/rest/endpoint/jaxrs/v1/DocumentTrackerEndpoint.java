package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.SecurityContext;

import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.bmo.channel.core.exception.UnauthorizedSecurityException;
import com.bmo.channel.pwob.model.onboarding.EsignPackageInfo;
import com.bmo.channel.pwob.service.document.DocumentTrackerService;
import com.bmo.channel.pwob.service.documentpackages.DocumentPackagesService;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentDto;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentPackageDto;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentUploadDto;
import com.bmo.channel.pwob.service.documentpackages.dto.GetDocumentResponseDto;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.util.Constants;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.ValidationManager.IdType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(DocumentTrackerEndpoint.V1_SUB_PATH)
@Path(WorkflowsEndpoint.V1_PATH)
public class DocumentTrackerEndpoint {

	public static final String V1_SUB_PATH = "document_packages";
	public static final String DOCUMENT_COMPLETION = "document_completion";
	public static final String ACCOUNT_SETUP = "account_setup";
	public static final String DATA_COLLECTION = "/data_collection";
	private static final String WORKFLOW_ID = "workflow_id";
	
	private static Logger logger = LoggerFactory.getLogger(DocumentTrackerEndpoint.class);
	
	
	@Autowired
	private DocumentPackagesService documentPackagesService;
	
	@Autowired
	private DocumentTrackerService documentTrackerService;
	
	@Autowired
	protected ValidationManager validationManager;
	
	@Autowired 
	protected UsersService usersService;
	
	
	@POST
	@Path("/" + V1_SUB_PATH)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value="Generate and retrieve document list", notes="A successful response will return package id and signer id")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "workflow_id", value = "ISAM injected header to identify associated workflow id", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "am-eai-ext-user-id", value = "ISAM injected header for user id", dataType = "string",paramType = "header"),
		@ApiImplicitParam(name = "x_bmo_business_category", value = "ISAM injected header to identify LOB", dataType = "string",paramType = "header"),
		@ApiImplicitParam(name = "x_bmo_email_id", value = "ISAM injected header to identify LOB", dataType = "string",paramType = "header"),
		@ApiImplicitParam(name = "x_bmo_sso_id", value = "ISAM injected header for sso id", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response retrieveDocument(@Context HttpServletRequest httpRequest) {

		
		// validate headers
		if (Optional.ofNullable(httpRequest.getHeader(WORKFLOW_ID)).isPresent()) {
			String workflowId = httpRequest.getHeader(WORKFLOW_ID);
			this.validationManager.validateId(workflowId, IdType.Application);
			//generate document
			documentTrackerService.generateDocumentPackages(workflowId);
			//retrieve documents
			final List<DocumentPackageDto> documentPackages = documentPackagesService.retrieveDocumentPackages(workflowId, false);
			
			List<EsignPackageInfo> docs = new ArrayList<>();
			documentPackages.stream().forEach(docPackage -> 
				docs.add(new EsignPackageInfo(docPackage.getId(), docPackage.getSigners().stream().findFirst().get().getId()))
			);

			return Response.ok().entity(docs).build();

		} else
			throw new UnauthorizedSecurityException("invalid workflow_id " + httpRequest.getHeader(WORKFLOW_ID));
				
	}
		


	@POST
	@Path("/{id}/" + V1_SUB_PATH)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value="Generate Documents for an application", notes="A successful response will be empty")
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response generateDocument(@NotEmpty @ApiParam(value = "Application ID") @PathParam("id") String workflowId) {

		this.validationManager.validateId(workflowId, IdType.Application);
		documentTrackerService.generateDocumentPackages(workflowId);
		
			try {
				documentPackagesService.assignUsersToeSignDocs(workflowId);
			} catch (Exception e) {
				logger.error("Assigning Users to eSign docs is failed, but user can continue with paper sign", e);
			}
		
		return Response.ok().build();
	}
	
	/**
	 * This is to get a list of document packages by ids.
	 */
	@GET
	@Path("/{id}/" + V1_SUB_PATH)
	@ApiOperation(value="Retrieve a document package for an application", response=DocumentPackageDto.class, responseContainer = "list")
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Package or Application not found")})
	public Response retrieveDocumentPackage(@NotEmpty @ApiParam(value = "Application ID") @PathParam("id") String workflowId) {

		this.validationManager.validateId(workflowId, IdType.Application);
		final List<DocumentPackageDto> documentPackages = documentPackagesService.retrieveDocumentPackages(workflowId, false);

			final DocumentPackagesResponse documentPackagesResponse = new DocumentPackagesResponse();
			documentPackagesResponse.setDocumentPackages(documentPackages);
			return Response.ok().entity(documentPackagesResponse).build();
	}

	@GET
	@Path("/{id}/" + V1_SUB_PATH + "/{documentPackageId}")
	@ApiOperation(value="View a sepcific document", response=GetDocumentResponseDto.class)
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Document, Package or Application not found")})
	public Response viewDocument(@NotEmpty  @ApiParam(value = "Application ID") @PathParam("id") String workflowId, 
			@NotEmpty @ApiParam(value = "Document Package ID") @PathParam("documentPackageId") String documentPackageId,
			@ApiParam(value = "Document ID", required=true) @QueryParam("documentId") List<String> documentIds, 
			@ApiParam(value = "Repositorty ID", required=true) @QueryParam("repositoryId") String repositoryId) {
		
		this.validationManager.validateId(workflowId, IdType.Application);
		final DocumentDto documentDto = documentPackagesService.viewDocument(workflowId, repositoryId, documentPackageId, documentIds);
		return Response.ok().entity(new GetDocumentResponseDto(documentDto)).build();
	}

	@GET
	@Path("/{id}/" + V1_SUB_PATH + "/{documentPackageId}/content")
	@ApiOperation(value="View a document pdf", notes="PDF is returned as a byte array", response = byte[].class)
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Document, Package, or Application Not found")})
	public Response viewDocumentPdf(@NotEmpty @ApiParam(value = "Application ID") @PathParam("id") String workflowId, 
			@NotEmpty @ApiParam(value = "Document Package ID") @PathParam("documentPackageId") String documentPackageId,
			@ApiParam(value = "Document ID", required=true) @QueryParam("documentId") List<String> documentIds, 
			@ApiParam(value = "Repositorty ID", required=true) @QueryParam("repositoryId") String repositoryId) {
		
		this.validationManager.validateId(workflowId, IdType.Application);
		final byte[] pdfBytes = documentPackagesService.retrieveDocumentContent(workflowId, repositoryId, documentPackageId, documentIds, false, null);
		final Response.ResponseBuilder rBuild = Response.ok(pdfBytes, Constants.APPLICATION_PDF);
	    return rBuild.build();
	}
	
	@POST
	@Path("/{id}/" + V1_SUB_PATH + "/esign")
	@ApiOperation(value="Document esigning", notes="A successful response will be empty")
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="ESign failed"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Package or Application not found")})
	public Response eSigning(@Context SecurityContext context, @NotEmpty @ApiParam(value = "Application ID") @PathParam("id") String workflowId) {

		this.validationManager.validateId(workflowId, IdType.Application);
		documentPackagesService.activateESigning(workflowId);
		return Response.status(Status.OK).build();
	}
	
	@POST
	@Path("/{id}/" + V1_SUB_PATH + "/{documentPackageId}/papersign")
	@ApiOperation(value="Paper signing", notes="A successful response will be empty")
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Paper sign failed"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Package or Application not found")})
	public Response paperSigning(@Context SecurityContext context, @NotEmpty @ApiParam(value = "Application ID") @PathParam("id") String workflowId, 
			@NotEmpty @ApiParam(value = "Document Package ID") @PathParam("documentPackageId") String documentPackageId) {
		
		this.validationManager.validateId(workflowId, IdType.Application);
		documentPackagesService.paperSigning(workflowId, documentPackageId);
		return Response.status(Status.OK).build();
	}
	
	@POST
	@Path("/{id}/" + V1_SUB_PATH + "/{documentPackageId}/content")
	@ApiOperation(value="Update the content of a document", notes="A successful response will be empty")
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Package or Application not found")})
	public Response updateDocumentContent(@NotEmpty @ApiParam(value = "Application ID") @PathParam("id") String workflowId, 
			@NotEmpty @ApiParam(value = "DocumentPackage ID") @PathParam("documentPackageId") String documentPackageId,
			@Context HttpHeaders headers, @RequestBody DocumentUploadDto request) {
		
		this.validationManager.validateId(workflowId, IdType.Application);
		String contentType = headers.getHeaderString(Constants.HEADER_DOCUMENT_EXTENSION);
		if (contentType == null) {
			contentType = Constants.PDF_EXTENSION;
		}
		documentPackagesService.updateDocument(workflowId, documentPackageId, contentType, request);
		return Response.status(Status.OK).build();
	}
	
	@POST
	@Path("/{id}/" + V1_SUB_PATH + "/{documentPackageId}/print")
	@ApiOperation(value="Print a Document", notes="Response is a PDF returned as a byte array", response = byte[].class)
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Package or Application not found")})
	public Response print(@NotEmpty @ApiParam(value = "Application ID") @PathParam("id") String workflowId, 
			@NotEmpty @ApiParam(value = "DocumentPackage ID") @PathParam("documentPackageId") String documentPackageId, 
			@ApiParam(value = "Repositorty ID", required=true) @QueryParam("repositoryId") String repositoryId) {

		this.validationManager.validateId(workflowId, IdType.Application);

		final byte[] pdfBytes = documentPackagesService.print(workflowId, repositoryId, documentPackageId);
		return Response.ok(pdfBytes, Constants.APPLICATION_PDF).build();			
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}" + DATA_COLLECTION)
	@ApiOperation(value="Return to data collection step in workflow", notes="Unlocks the application and removes any generated documents")
	@ApiImplicitParams({@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
        @ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response unlock(@ApiParam(value = "Application ID") @PathParam("id") String workflowId) {
		this.validationManager.validateId(workflowId, IdType.Application);
		documentTrackerService.unlock(workflowId);
		return Response.ok().build();
	}
}
