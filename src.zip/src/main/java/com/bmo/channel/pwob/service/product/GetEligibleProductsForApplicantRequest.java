package com.bmo.channel.pwob.service.product;

public class GetEligibleProductsForApplicantRequest {
	private Request getEligibleProductsForApplicantRequest;
	
	public Request getGetEligibleProductsForApplicantRequest() {
		return getEligibleProductsForApplicantRequest;
	}
	public void setGetEligibleProductsForApplicantRequest(Request getEligibleProductsForApplicantRequest) {
		this.getEligibleProductsForApplicantRequest = getEligibleProductsForApplicantRequest;
	}

	public static class Request {
		private GetEligibleProductsForApplicantRequestBody getEligibleProductsForApplicantRequestBody;

		public GetEligibleProductsForApplicantRequestBody getGetEligibleProductsForApplicantRequestBody() {
			return getEligibleProductsForApplicantRequestBody;
		}
		public void setGetEligibleProductsForApplicantRequestBody(
				GetEligibleProductsForApplicantRequestBody getEligibleProductsForApplicantRequestBody) {
			this.getEligibleProductsForApplicantRequestBody = getEligibleProductsForApplicantRequestBody;
		}
	}

}
