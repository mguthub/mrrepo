package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang.builder.ToStringBuilder;

import io.swagger.annotations.ApiModelProperty;

public class FeatureFlag {
	@ApiModelProperty(required=true, value="name of feature flag. eg. BILLC31_ETCH")
    protected String name;
	@ApiModelProperty(value="state of feature flag. eg. ACTIVE")
    protected String state;

    public FeatureFlag(String name, String state) {
		this.name = name;
		this.state = state;
	}

    public FeatureFlag(String name) {
		this.name = name;
	}
    
    public FeatureFlag() {
    }

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
