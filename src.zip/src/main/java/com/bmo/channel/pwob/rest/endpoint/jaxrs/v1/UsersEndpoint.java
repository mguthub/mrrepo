package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.service.user.UsersService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(UsersEndpoint.V1_PATH)
@Path(UsersEndpoint.V1_PATH)
public class UsersEndpoint {
	public static final String V1_PATH = "v1/users";

	@Autowired
	private UsersService userService;

	@GET
	@Path("/current")
	@ApiOperation(value="Get current user's information", response=User.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified")})
	public Response currentUser() {
		return Response.ok(userService.currentUser()).build();
	}
	
	@GET
	@Path("/iaUsers/{iaCode}")
	@ApiOperation(value="Get current user's information", response=User.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified")})
	public Response getIaUsersWithjurisdictionProvinces(@ApiParam(value = "IA Code") @PathParam("iaCode") String iaCode) {
		return Response.ok(userService.getIAUsersByIACode(iaCode)).build();
	}
}
