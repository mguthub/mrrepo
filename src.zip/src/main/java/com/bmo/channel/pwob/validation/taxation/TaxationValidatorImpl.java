package com.bmo.channel.pwob.validation.taxation;

import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.AlternateAddress;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.RegulatoryDisclosures;
import com.bmo.channel.pwob.model.onboarding.Residence;
import com.bmo.channel.pwob.model.onboarding.Taxation;
import com.bmo.channel.pwob.model.onboarding.Verification;
import com.bmo.channel.pwob.util.W8FormHelper;
import com.bmo.channel.pwob.util.W9FormHelper;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

/**
 * Validate the Taxation details. 
 *
 */
@Component
public class TaxationValidatorImpl extends AbstractBaseValidator implements TaxationValidator {
		
	@Autowired
	private W8FormHelper w8FormHelper;
	@Autowired
	private W9FormHelper w9FormHelper;
		
	protected static final String [] USA_PHONE_COUNTRY_CODE= {"001","1"};
	public static final String TAXATION_NODE = "taxation";
	public static final String IS_IRS_W8_FORM_PROVIDED_FIELD_NAME = "isIrsW8FormProvided";
	public static final String IS_IRS_W9_FORM_PROVIDED_FIELD_NAME = "isIrsW9FormProvided";
	public static final String BENEFICIAL_OWNER_COUNTRY_FIELD_NAME = "beneficialOwnerCountry";
	public static final String TAX_IDENTIFICATION_NUM_FIELD_NAME = "taxIdentificationNumber";

	@Override
	public boolean validateW8W9Form(Party party, List<Account> accounts, ValidationRequest request) {		
		
		final ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		
        boolean valid = true;
               
        if(party != null){
             final Residence residence = party.getPersonal().getResidence();
             final PersonalInformation personal = party.getPersonal();
             final Identity identity = party.getPersonal().getIdentity();
             final Employment employmentInformation = party.getPersonal().getEmployment();
             final RegulatoryDisclosures regulatoryDisclosures = party.getRegulatoryDisclosures();
      	
      		 List<AlternateAddress> duplicateAddresses = null;
      		 if(party.getPreferences() != null)
      			 duplicateAddresses=party.getPreferences().getAlternateMailingAddresses();
      		
      		 if (isAccountEligible(accounts)) {   
      			if (w9FormHelper.isW9FormApplicable(residence, identity, regulatoryDisclosures, personal)) {
      				valid = checkW9(party, request) && valid;
      			} 
      			else{
  					//NOTE: Temporary fix to clean up w9 form details in case the validation to capture the taxation was failed
  					Taxation taxation = party.getTaxation();
					final String idVerificationMethod = Optional.ofNullable(party).map(Party::getRegulatoryDisclosures)
							.map(RegulatoryDisclosures::getVerification).map(Verification::getIdVerificationMethod)
							.isPresent() ? party.getRegulatoryDisclosures().getVerification().getIdVerificationMethod()
									: null;
														
  					if(taxation != null) {
  						taxation.setIsIrsW9FormProvided(null);
  						taxation.setTaxIdentificationNumber(null);
  						if (w8FormHelper.isW8FormApplicable(residence, employmentInformation, duplicateAddresses, party.getRoles(), idVerificationMethod)) {
  							valid = checkW8(party, request) && valid;
  						}
  						else{
  							//NOTE: Temporary fix to clean up w8 form details in case the validation to capture the taxation was failed
  							taxation.setIsIrsW8FormProvided(null);
  							taxation.setBeneficialOwnerCountry(null);
  						}
  					}
      			}
      		}
        }
        
        if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting but always sanitize if necessary
			return true;
		}
      
		return valid;
	}

	private boolean isAccountEligible(List<Account> accounts) {
		for (Account account : accounts) {			
			if(account.isIndividual() || account.isTfsa() || account.isJoint())  {
				return true;
    		}			
    	}
		return false;
	}

	private boolean checkW8(final Party party, ValidationRequest request) {
		final Taxation taxation = party.getTaxation();
		if (!Optional.ofNullable(taxation.getIsIrsW8FormProvided()).isPresent()) {
			request.setFieldName(IS_IRS_W8_FORM_PROVIDED_FIELD_NAME);
			request.setErrorCode(ErrorCodes.INVALID_IS_IRS_W8_FORM_PROVIDED);
			request.addConstraintViolation();
			return false;
		} else if (taxation.getIsIrsW8FormProvided() && StringUtils.isBlank(taxation.getBeneficialOwnerCountry())) {
			request.setFieldName(BENEFICIAL_OWNER_COUNTRY_FIELD_NAME);
			request.setErrorCode(ErrorCodes.INVALID_BENEFICIAL_OWNER_COUNTRY);
			request.addConstraintViolation();
			return false;
		}
		return true;
	}
	
	private boolean checkW9(final Party party, ValidationRequest request) {
		final Taxation taxation = party.getTaxation();
		if (!Optional.ofNullable(taxation.getIsIrsW9FormProvided()).isPresent()) {
			request.setFieldName(IS_IRS_W9_FORM_PROVIDED_FIELD_NAME);
			request.setErrorCode(ErrorCodes.INVALID_IS_IRS_W9_FORM_PROVIDED);
			request.addConstraintViolation();
			return false;
		} else if (taxation.getIsIrsW9FormProvided() && StringUtils.isBlank(taxation.getTaxIdentificationNumber())) {
			request.setFieldName(TAX_IDENTIFICATION_NUM_FIELD_NAME);
			request.setErrorCode(ErrorCodes.INVALID_TAX_IDENTIFICATION_NUMBER);
			request.addConstraintViolation();
			return false;
		}
		return true;
	}	

}