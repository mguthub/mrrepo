/**
 * @author akhales
 */
package com.bmo.channel.pwob.model.onboarding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.validator.constraints.NotEmpty;

import com.bmo.channel.pwob.exception.ValidationError;
import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidEtch;
import com.bmo.channel.pwob.validation.ValidIaCode;
import com.bmo.channel.pwob.validation.applicant.ValidApplication;
import com.bmo.channel.pwob.validation.otherparties.ValidOtherParties;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@ValidApplication
@ValidOtherParties
@ValidEtch
/**
 * Represents an application/workflow to open new accounts.
 */
public class Application  {
	// until release version is stored on application itself, it will be stored in metadata
	public static final String RELEASE_METADATA_KEY = "release";
	public static final String RELEASE_VERSION_5 = "5";
	public static final String RELEASE_VERSION_6 = "6";
	public static final String RELEASE_VERSION_7 = "7";
	public static final String RELEASE_VERSION_8 = "8";
	public static final String RELEASE_VERSION_9 = "9";
	public static final String RELEASE_VERSION_10 = "10";
	public static final String RELEASE_VERSION_11 = "11";
	public static final String RELEASE_VERSION_12 = "12";
	/**
	 * This fields needs to be updated with every release
	 */
	public static final String CURRENT_RELEASE = RELEASE_VERSION_12;

	@NotNull(message=ErrorCodes.INVALID_LOB)
	@ApiModelProperty(example="il", value="Line of business. nb or il")
	private ApplicationLob applicationLob;		

	@NotEmpty(message=ErrorCodes.INVALID_APPLICATION_ID)
	@ApiModelProperty(example="c547ab0e-a645-4307-ad61-e30f8157f699", value="Unique id for application")
	private String applicationId;

	@ValidIaCode
	@ApiModelProperty(example="ABC", value="IA code")
	private String iaCode;

	@ApiModelProperty(example="AccountSetup", value="Step the application is in.")
	private String status;

	@ApiModelProperty(example="405", value="Branch code")
	private String branchCode;
	
	@Valid
	private List<MultiApplicantsInvestmentExperience> multiApplicantsInvestmentExperiences = new ArrayList<>();
	
	@Valid
	private List<Guarantor> guarantors = new ArrayList<>();

	@Valid
	private List<Guarantee> guarantees = new ArrayList<>();

	@Valid
	private List<Beneficiary> beneficiaries = new ArrayList<>();

	@Valid
	private List<Party> parties = new ArrayList<>();

	@ApiModelProperty(example="en-ca", value="Locale. en-ca or fr-ca")
	private String locale = UILocale.EN_CA.getLang();

	@ApiModelProperty(value="Client-defined key-value pairs")
	private Map<String,String> clientMetadata = new HashMap<>();

	@ApiModelProperty(example="2017-04-20T17:02:22.119-04:00", value="Last time the application was updated")
	private String lastUpdated;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<ValidationError> validationErrors;

	//IA Validations are taken care during IA service .Hence removed the constraint validations from here (Note:To avoid the validation errors during Save/update workflow) 
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private RelationshipSummary relationshipSummary;

	@Valid
	private ClientAccessId clientAccessId = new ClientAccessId();

	@Valid
	private List<Account> accounts = new ArrayList<>();

	@ApiModelProperty(value="list of feature flags")
	private List<FeatureFlag> featureFlags = new ArrayList<>();

	@ApiModelProperty(value="Current release")
	private String release;
	
	public ClientAccessId getClientAccessId() {
		return clientAccessId;
	}

	public void setClientAccessId(ClientAccessId clientAccessId) {
		this.clientAccessId = clientAccessId;
	}

	public List<ValidationError> getValidationErrors() {
		return validationErrors;
	}

	public void setValidationErrors(List<ValidationError> validationErrors) {
		this.validationErrors = validationErrors;
	}
	
	public Map<String, String> getClientMetadata() {
		return clientMetadata;
	}

	public void setClientMetadata(Map<String, String> clientMetadata) {
		this.clientMetadata = clientMetadata;
	}

	public String getApplicationId() {
		return applicationId;
	}
		
	public void setApplicationId(String applicationId) {
		if (StringUtils.isNotEmpty(applicationId)) {
			this.applicationId = applicationId.trim();	
		}
	}	
	
	public ApplicationLob getApplicationLob() {
		return applicationLob;
	}
	public void setApplicationLob(ApplicationLob applicationLob) {
		this.applicationLob = applicationLob;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getIaCode() {
		return iaCode;
	}
	
	public void setIaCode(String iaCode) {
		this.iaCode = iaCode;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public RelationshipSummary getRelationshipSummary() {
		return relationshipSummary;
	}

	public void setRelationshipSummary(RelationshipSummary relationshipSummary) {
		this.relationshipSummary = relationshipSummary;
	}
	
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	
	public List<Guarantor> getGuarantors() {
		return guarantors;
	}

	public void setGuarantors(List<Guarantor> guarantors) {
		this.guarantors = guarantors;
	}

	public List<Guarantee> getGuarantees() {
		return guarantees;
	}

	public void setGuarantees(List<Guarantee> guarantees) {
		this.guarantees = guarantees;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public List<Party> getParties() {
		return parties;
	}

	public void setParties(List<Party> parties) {
		this.parties = parties;
	}

	public List<Beneficiary> getBeneficiaries() {
		return beneficiaries;
	}

	public void setBeneficiaries(List<Beneficiary> beneficiaries) {
		this.beneficiaries = beneficiaries;
	}

	/**
	 * @return the branchCode
	 */
	public String getBranchCode() {
		return branchCode;
	}

	/**
	 * @param branchCode the branchCode to set
	 */
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated(String lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	public List<FeatureFlag> getFeatureFlags() {
		return featureFlags;
	}
	public void setFeatureFlags(List<FeatureFlag> featureFlags) {
		this.featureFlags = featureFlags;
	}

	public String getRelease() {
		return release;
	}
	public void setRelease(String release) {
		this.release = release;
	}
	
	public List<MultiApplicantsInvestmentExperience> getMultiApplicantsInvestmentExperiences() {
		return multiApplicantsInvestmentExperiences;
	}

	public void setMultiApplicantsInvestmentExperiences(
			List<MultiApplicantsInvestmentExperience> multiApplicantsInvestmentExperiences) {
		this.multiApplicantsInvestmentExperiences = multiApplicantsInvestmentExperiences;
	}

	@JsonIgnore
	public Party getPrimaryApplicant() {
		Optional<Party> primary = parties.stream().filter(p -> p.getRoles().contains(PartyRole.PRIMARY_APPLICANT)).findFirst();
		if(primary.isPresent()) {
			return primary.get();
		} else {
			return null;
		}
	}

	@JsonIgnore
	public List<Party> getJointApplicants(List<String> jointPartyRefIds) {
		if(CollectionUtils.isEmpty(jointPartyRefIds)) {
			return Collections.emptyList();
		}
		List<Party> jointParties = parties.stream()
				  				.filter(p -> p.getRoles().contains(PartyRole.JOINT_APPLICANT))				  				
				  				.filter(p -> jointPartyRefIds.contains(p.getPartyRefId()))
				  				 .collect(Collectors.toList());
				  				
		if(CollectionUtils.isNotEmpty(jointParties)) {
			return jointParties;
		} else {
			return Collections.emptyList();
		}
	}

	@JsonIgnore
	public List<Party> getTradingAuthorityParties() {		
		List<Party> tradingAuths = parties.stream()
					  .filter(p -> CollectionUtils.isNotEmpty(p.getRoles()))
					  .filter(p -> p.getRoles().contains(PartyRole.TRADING_AUTHORITY))
					  .collect(Collectors.toList());						
		if(CollectionUtils.isNotEmpty(tradingAuths)) {
			return tradingAuths;
		} else {
			return Collections.emptyList();
		}
	}

	@JsonIgnore
	public Party getSpouseParty() {
		Optional<Party> spouse = parties.stream().filter(p -> StringUtils.isNotBlank(p.getSpousePartyRefId()) && !p.getRoles().contains(PartyRole.PRIMARY_APPLICANT)).findFirst();
		return spouse.isPresent() ? spouse.get() : null;
	}

	@JsonIgnore
	public FeatureFlag getFeatureFlag(String name) {
		return featureFlags.stream().filter(f -> f.getName().equals(name)).findFirst().orElse(null);
	}

	@JsonIgnore
	public Party getPartyById(String partyRefId) {
		return parties.stream().filter(p -> partyRefId != null && partyRefId.equals(p.getPartyRefId())).findFirst().orElse(null);
	}

	@JsonIgnore
	public List<Account> getAccountsForJointApplicant(String jointApplicantRefId) {
		if (StringUtils.isNotEmpty(jointApplicantRefId)) {
			return accounts.stream()
					.filter(a -> Optional.ofNullable(a.getJointApplicantPartyRefIds()).isPresent()
							&& a.getJointApplicantPartyRefIds().contains(jointApplicantRefId))
					.collect(Collectors.toList());

		} else {
			return new ArrayList<Account>();
		}
	}
	@JsonIgnore
    public List<Party> getJointApplicants() {
           
           List<Party> jointParties = parties.stream()
                                                   .filter(p -> p.getRoles().contains(PartyRole.JOINT_APPLICANT))                                                     
                                                   .collect(Collectors.toList());
                                                   
           if(CollectionUtils.isNotEmpty(jointParties)) {
                  return jointParties;
           } else {
                  return Collections.emptyList();
           }
    }
	
	@JsonIgnore
	public List<Account> getJointAccounts() {
		if(CollectionUtils.isEmpty(accounts)) {
			return Collections.emptyList();
		}
		List<Account> jointAccounts = accounts.stream()
				  				.filter(p -> p.getType().contains(Account.JOINT_TYPE))
				  				.collect(Collectors.toList());
				  				
		if(CollectionUtils.isNotEmpty(jointAccounts)) {
			return jointAccounts;
		} else {
			return Collections.emptyList();
		}
	}

}
