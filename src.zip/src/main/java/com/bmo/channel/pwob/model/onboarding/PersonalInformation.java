/**
 * @author akhales
 */
package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.validation.residence.ValidTaxResidency;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@ValidTaxResidency
public class PersonalInformation {
	
	@Valid	
	private Identity identity;
	
	@Valid
	private Residence residence = new Residence();

	@Valid	
	private Employment employment;
	
	private Boolean hasTaxResidency;
	
	@Valid		
	private List<TaxResidency> residencyForTax;

	public Identity getIdentity() {
		return identity;
	}
	public void setIdentity(Identity identity) {
		this.identity = identity;
	}

	public Employment getEmployment() {
		return employment;
	}

	public void setEmployment(Employment employmentInformation) {
		this.employment = employmentInformation;
	}	
	public Residence getResidence() {
		return residence;
	}
	public void setResidence(Residence residence) {
		this.residence = residence;
	}
	public List<TaxResidency> getResidencyForTax() {
		return residencyForTax;
	}
	public void setResidencyForTax(List<TaxResidency> residencyForTax) {
		this.residencyForTax = residencyForTax;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	public Boolean getHasTaxResidency() {
		return hasTaxResidency;
	}
	public void setHasTaxResidency(Boolean hasTaxResidency) {
		this.hasTaxResidency = hasTaxResidency;
	}
	
}
