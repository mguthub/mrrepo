package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;

public class FinancialStatus {

	@Valid
	private Income income = new Income();
	@Valid
	private NetWorth netWorth = new NetWorth();

	public Income getIncome() {
		return income;
	}
	public void setIncome(Income income) {
		this.income = income;
	}

	public NetWorth getNetWorth() {
		return netWorth;
	}
	public void setNetWorth(NetWorth netWorth) {
		this.netWorth = netWorth;
	}
}
