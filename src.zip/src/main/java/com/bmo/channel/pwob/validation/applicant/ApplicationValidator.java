package com.bmo.channel.pwob.validation.applicant;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactoryImpl.ValidationRequestBuilder;

public class ApplicationValidator extends AbstractBaseValidator implements ConstraintValidator<ValidApplication, Application> {

	@Autowired
	UsersService userService;
	
	@Autowired 
	ValidationRequestFactory validationRequestFactory;
	
	@Override
	public void initialize(ValidApplication constraintAnnotation) {	}

	@Override
	public boolean isValid(Application application, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		ApplicationLob lob = userService.currentUser().getLob();
		ValidationRequestBuilder builder = validationRequestFactory.createBuilder(context, lob);
        ValidationRequest request = builder.build();
        boolean valid = true;

		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}		
		
		valid = this.enforceUniqueAccountRefIds(application.getAccounts(), request) && valid;

        valid = this.validateLocale(application, request) && valid;
        
        valid = this.isEmptyParties(application, request) && valid;

		valid  = this.isValidAccountArraySize(application, context) && valid;

		valid = this.isValidTradingAuthPartyRefId(application, context, lob) && valid;
		
		valid = this.validateCoApplicantTitle(application, request) && valid;

		valid = this.validateElectronicDeliveryForCoApplicants(application, request) && valid;
		
		request = builder.withParentPropertyNode(PARTIES_NODE).build();
		valid = this.isValidSpousePartyRefId(application, request) && valid;

		valid = this.isSinglePrimaryApplicant(application, request) && valid;				

		request = builder.withParentPropertyNode(CLIENT_METADATA_FIELD_NAME).build();
	    valid = this.validateClientMetadata(application, request) && valid;	    		
	        
	    return valid;
	}
	
	private boolean isEmptyParties(Application application, ValidationRequest request) {
		if(CollectionUtils.isEmpty(application.getParties())) {
			request.addConstraintViolation(PARTIES_NODE, ErrorCodes.INVALID_EMPTY_PARTY);
			return false;
		}	
		return true;
	}
	

	private boolean enforceUniqueAccountRefIds(List<Account> accounts, ValidationRequest request) {
		Set<String> refIds = accounts.stream().map(Account::getRefId).collect(Collectors.toSet());
		if(refIds.size() < accounts.size()){			
			request.addConstraintViolation("accounts", ErrorCodes.INVALID_ACCOUNT_REF_IDS);
			return false;
		}
		return true;
	}
	
	private boolean validateClientMetadata(Application application, ValidationRequest request) {
		request.setErrorCode(ErrorCodes.INVALID_CLIENT_METADATA);
		boolean flag = true;
		Map<String,String> mapInfo = application.getClientMetadata();
		if(!mapInfo.isEmpty()){
			for(Map.Entry<String, String> entry: mapInfo.entrySet()) {
				request.setFieldName(entry.getKey());
				request.setFieldValue(entry.getValue());
				flag = this.validateField(request) && flag;
			}
		}
		return flag;	
	}	
	
	@Override
	protected boolean validateField(ValidationRequest request) {		

		String regex = this.retrievePatternForFieldAndLob(request.getLob(), CLIENT_METADATA_FIELD_NAME);		
		if(StringUtils.isBlank(request.getFieldValue()) || 
				(StringUtils.isNoneBlank(regex) && !request.getFieldValue().matches(regex))) {	
			request.addConstraintViolation();
			return false;
		}
		return true;
	}
	
	/**
	 * Must have one account submitted
	 * @param application
	 * @param context
	 * @param validationContext
	 * @return
	 */
	private boolean isValidAccountArraySize(Application application, ConstraintValidatorContext context) {
		if (application.getAccounts() == null || CollectionUtils.isEmpty(application.getAccounts())) {
			this.createConstraintViolation(context, ErrorCodes.INVALID_ACCOUNT, "accounts");
			return false;
		}
		return true;
	}

	/**
	 * Validate the trading authority reference Ids from account against the party reference Ids.
	 * @param application
	 * @param context 
	 * @param context
	 * @param lob 
	 * @return
	 */
	private boolean isValidTradingAuthPartyRefId(Application application, ConstraintValidatorContext context, ApplicationLob lob) {
		ValidationRequest request = validationRequestFactory.createBuilder(context, lob).withParentPropertyNode(ACCOUNTS_NODE).build();
		List<Party> tradingAuthParties = application.getTradingAuthorityParties();
		List<String> tradingAuthRefIds = this.getPartyRefIds(tradingAuthParties);
		List<Account> accounts = application.getAccounts();
		boolean valid = true;

		if(CollectionUtils.isNotEmpty(tradingAuthRefIds)) {
			for(int index = 0; index < accounts.size(); index++) {
				Account account = accounts.get(index);
				request.setIndex(index);
				if(Optional.ofNullable(account.getAreOtherPartiesSpecified()).isPresent() && account.getAreOtherPartiesSpecified())	{
					valid = validateAccountTradingAuthorityRefId(request, tradingAuthRefIds, account) && valid;
				}
			}	
		}

		return valid;
	}

	boolean validateAccountTradingAuthorityRefId(ValidationRequest request, List<String> tradingAuthorityPartyRefIds, Account account) {

		boolean valid = true;
		
		if(CollectionUtils.isNotEmpty(tradingAuthorityPartyRefIds) && CollectionUtils.isNotEmpty(account.getTradingAuthorityPartyRefIds())) {
			int refIndex = 0;
			for (String refId : account.getTradingAuthorityPartyRefIds()) {				
				if (CollectionUtils.isNotEmpty(account.getTradingAuthorityPartyRefIds()) && !tradingAuthorityPartyRefIds.contains(refId)){
					request.setErrorCode(ErrorCodes.INVALID_TRADING_AUTHORITY_PARTY_REF_ID);
					request.setFieldName("tradingAuthorityPartyRefIds["+ refIndex + "]");
					request.addConstraintViolation(request.getIndex());
					valid = false;
				}
				refIndex++;
			}
		}
		return valid;
	}

	/**
	 * Validate the spouse party reference Id within the primary party against the party reference Ids.
	 * @param application
	 * @param context
	 * @return
	 */
	private boolean isValidSpousePartyRefId(Application application, ValidationRequest request) {
		
		request.setFieldName(SPOUSE_PARTY_REF_ID_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_SPOUSE_PARTY_REF_ID);
		
		Party primaryAppParty = application.getPrimaryApplicant();											
		
		if(Optional.ofNullable(primaryAppParty).isPresent() && StringUtils.isNotBlank(primaryAppParty.getSpousePartyRefId())
				&& (primaryAppParty.getPersonal().getIdentity().getMaritalStatus()!= null &&
				!primaryAppParty.getPersonal().getIdentity().getMaritalStatus().equalsIgnoreCase(RefDataValues.MARITAL_STATUS_SINGLE))) {
			Optional<Party> spouseParty = this.getSpouseParty(application.getParties());	
			
			if(!spouseParty.isPresent() || (spouseParty.isPresent() && StringUtils.isNotBlank(spouseParty.get().getPartyRefId()) &&
					!primaryAppParty.getSpousePartyRefId().equals(spouseParty.get().getPartyRefId())) ){
				request.addConstraintViolation(0);	
				return false;
			}			
		}				
		return true;
	}	
	
	/**
	 * Validate for only one Primary Applicant per application
	 * @param application
	 * @param context
	 * @return
	 */
	private boolean isSinglePrimaryApplicant(Application application, ValidationRequest request) {
		request.setFieldName(PARTY_REF_ID_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_PRIMARY_APPLICANT_PARTY_REF_ID);
		
		List<Party> parties = getPrimaryApplicantParties(application.getParties());		
		
		if(CollectionUtils.isNotEmpty(parties) && parties.size() > 1) {			
			request.addConstraintViolation(0);	
			return false;					
		}				
		return true;
	}	

	private boolean validateLocale(Application application, ValidationRequest request) {
		request.setFieldName(LOCALE_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_LOCALE);

		if(StringUtils.isNoneBlank(application.getLocale()) &&
				!Arrays.asList(UILocale.EN_CA.getLang(), UILocale.FR_CA.getLang()).contains(application.getLocale().toLowerCase())){			
			request.addConstraintViolation();	
			return false;					
		}				
		return true;
	}	
	
	/**
	 * Validate CoApplicant Title with Primary applicant Title
	 * @param application
	 * @param context
	 * @return
	 */
	
	private boolean validateCoApplicantTitle(Application application, ValidationRequest request) {
        boolean valid = true;
        Party primaryApplicant = application.getPrimaryApplicant();   
        List<Party> coApplicantList=application.getJointApplicants(); 
        
        if(CollectionUtils.isNotEmpty(coApplicantList) && Optional.ofNullable(primaryApplicant).isPresent()) {                 
               String primaryApplicantTitle = primaryApplicant.getPersonal().getIdentity().getLegalName().getTitle(); // null
               
               for (Party coApplicant : coApplicantList) {
                     String coApplicantTitle = coApplicant.getPersonal().getIdentity().getLegalName().getTitle(); // null, 10000
                     if ((!Optional.ofNullable(primaryApplicantTitle).isPresent() && Optional.ofNullable(coApplicantTitle).isPresent()) 
                                   || Optional.ofNullable(primaryApplicantTitle).isPresent() && !Optional.ofNullable(coApplicantTitle).isPresent()){
                            int refIndex=application.getParties().indexOf(coApplicant);
                            request.setErrorCode(ErrorCodes.INVALID_COAPPLICANT_TITLE);
                            request.setFieldName("parties[" + refIndex + "].personal.identity.legalName.title");
                            request.addConstraintViolation();
                            valid = false;
                     }
               }
        }             
        return valid;
 }

	
	private boolean validateElectronicDeliveryForCoApplicants(Application application, ValidationRequest request) {
		boolean valid = true;
		Set<Party> coApplicantSet = new HashSet<Party>();
		for (Account account : application.getAccounts()) {
			if (account.isJoint() && Optional.ofNullable(account.getJointAccountDetails()).isPresent()
					&& Optional.ofNullable(account.getJointAccountDetails().getPreferences()).isPresent()
					&& Optional
							.ofNullable(
									account.getJointAccountDetails().getPreferences().getReceiveElectronicDelivery())
							.isPresent()
					&& account.getJointAccountDetails().getPreferences().getReceiveElectronicDelivery()) {
				List<Party> jointApplicantList = application.getJointApplicants(account.getJointApplicantPartyRefIds());
				coApplicantSet.addAll(jointApplicantList.stream().collect(Collectors.toSet()));
			}
		}
		for (Party coApplicant : coApplicantSet) {			
			valid=validatePrimaryEmailForElectronicDelivery(application, coApplicant, request);
		}
		return valid;
	}
	
	private boolean validatePrimaryEmailForElectronicDelivery(Application application, Party applicant, ValidationRequest request) {
		boolean valid = true;		
		if (Optional.ofNullable(applicant.getPersonal()).isPresent()
				&& Optional.ofNullable(applicant.getPersonal().getIdentity()).isPresent()
				&& StringUtils.isBlank(applicant.getPersonal().getIdentity().getPrimaryEmailAddress())) {
            int refIndex=application.getParties().indexOf(applicant);
            request.setErrorCode(ErrorCodes.INVALID_PRIMARY_EMAIL);
            request.setFieldName("parties[" + refIndex + "].personal.identity.primaryEmailAddress");	            
			request.setFieldValue(applicant.getPersonal().getIdentity().getPrimaryEmailAddress());
			request.addConstraintViolation();
			valid = false;
		}
		return valid;
	}
}
