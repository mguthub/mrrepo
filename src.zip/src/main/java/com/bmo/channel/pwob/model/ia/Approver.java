package com.bmo.channel.pwob.model.ia;

import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

public class Approver {
	@ApiModelProperty(value = "Approver's network id")
	private String userid;

	@ApiModelProperty(value = "Approver's first name")
	private String firstName;
	@ApiModelProperty(value = "Approver's last name")
	private String lastName;
	@ApiModelProperty(value = "possible approval status")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String actionType;
	@ApiModelProperty(value = "approval time")
	private String timeOfApproval;
	@ApiModelProperty(value = "true or false")
	private Boolean approved;
	@ApiModelProperty(value = "IA or BM")
	private String approverType;
	@ApiModelProperty(value = "First name of bypassed by user")
	private String byPassedBy;
	@ApiModelProperty(value = "BM approval date")
	private String bmApprovalDateTime;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTimeOfApproval() {
		return timeOfApproval;
	}

	public void setTimeOfApproval(String timeOfApproval) {
		this.timeOfApproval = timeOfApproval;
	}

	public String getActionType() {
		return actionType;
	}

	public void setActionType(String actionType) {
		this.actionType = actionType;
	}

	public Boolean getApproved() {
		return approved;
	}

	public void setApproved(Boolean approved) {
		this.approved = approved;
	}

	public String getApproverType() {
		return approverType;
	}

	public void setApproverType(String approverType) {
		this.approverType = approverType;
	}

	public String getByPassedBy() {
		return byPassedBy;
	}

	public void setByPassedBy(String byPassedBy) {
		this.byPassedBy = byPassedBy;
	}

	public String getBmApprovalDateTime() {
		return bmApprovalDateTime;
	}

	public void setBmApprovalDateTime(String bmApprovalDateTime) {
		this.bmApprovalDateTime = bmApprovalDateTime;
	}
}
