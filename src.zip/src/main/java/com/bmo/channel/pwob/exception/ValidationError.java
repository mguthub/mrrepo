package com.bmo.channel.pwob.exception;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ValidationError {
	private String code;
	private String field;
	private Map<String, Object> meta;

	public ValidationError() {
	}

	public ValidationError(String message, String field) {
		this.code = message;
		this.field = field;
	}

	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getField() {
		return field;
	}

	public Map<String, Object> getMeta() {
		return meta;
	}
	public void setMeta(Map<String, Object> meta) {
		this.meta = meta;
	}
}
