package com.bmo.channel.pwob.validation.newworkflowrequest;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.user.AuthenticatedUser;
import com.bmo.channel.pwob.user.UserContext;

public class NewWorkflowRequestValidator implements ConstraintValidator<ValidNewWorkflowRequest, NewWorkflowRequest> {
	@Autowired
	UserContext userContext;

	@Override
	public void initialize(ValidNewWorkflowRequest constraintAnnotation) {	
	}

	@Override
	public boolean isValid(NewWorkflowRequest request, ConstraintValidatorContext context) {
		if(StringUtils.isEmpty(request.getRisToken()) && (StringUtils.isEmpty(request.getFirstName()) || StringUtils.isEmpty(request.getLastName()))) {
			return false;
		}
		AuthenticatedUser authenticatedUser = userContext.getAuthenticatedUser();
		if(ApplicationLob.nb == authenticatedUser.getLob() && StringUtils.isEmpty(request.getIaCode())) {
			return false;
		}
		return true;
	}
}
