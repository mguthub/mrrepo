package com.bmo.channel.pwob.service.workflow;

import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.bmo.channel.pwob.service.documentpackages.dto.DocumentPackageDto;

import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveApplicationRequest;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveRelationshipRequest;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

/**
 * Repository to create, save and delete OnboardApplication records.
 * @author Ryan Chambers (rcham02)
 */
public interface OnboardApplicationRepository {

	String FUNCTION_SAVE = "SaveApplication";
	String FUNCTION_RETRIEVE = "RetrieveApplication";
	String FUNCTION_CANCEL = "CancelApplication";
	String RESOURCE = "OnboardApplication";
	String FUNCTION_RELATIONSHIP_SAVE = "SaveRelationship";
	SaveApplicationResponse save(SaveApplicationRequest saveApplicationRequest, String ecifId);
	SaveApplicationResponse save(SaveApplicationRequest saveApplicationRequest, HUBHeaderRequest requestHeader);

	RetrieveApplicationResponse retrieve(String applicationID, String ecifId);
	RetrieveApplicationResponse retrieve(String applicationID, HUBHeaderRequest requestHeader);

	void cancel(String applicationId, 
			String ecifId, 
			XMLGregorianCalendar lastUpdatedDateTime, 
			List<String> accountNumbers,
			List<DocumentPackageDto> pckgs);

	SaveApplicationRequest.Body defaultSaveApplicationRequestBody();

	void saveRelationship(SaveRelationshipRequest saveRequest);
	void saveRelationship(SaveRelationshipRequest saveRequest, HUBHeaderRequest requestHeader);
}
