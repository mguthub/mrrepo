package com.bmo.channel.pwob.service.reference.mapping;

import java.util.List;

import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.model.DataAndMapping;

public interface ReferenceMapper {
	public List<Reference> mapToReferenceListEN(DataAndMapping dataAndMapping);
	public List<Reference> mapToReferenceListFR(DataAndMapping dataAndMapping);
}
