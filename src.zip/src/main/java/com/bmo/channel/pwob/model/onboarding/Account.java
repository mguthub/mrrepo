
/**
 * @author akhales
 */
package com.bmo.channel.pwob.model.onboarding;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidIaCode;
import com.bmo.channel.pwob.validation.account.ValidAccount;
import com.bmo.channel.pwob.validation.account.ValidAccountBeneficiary;
import com.bmo.channel.pwob.validation.account.ValidRifAccount;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.bmo.channel.pwob.validation.reference.ReferenceData;
import com.bmo.channel.pwob.validation.reference.ReferenceListData;
import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModelProperty;

@ValidAccount
@ValidRifAccount
@ValidAccountBeneficiary
public class Account {
	public static final String INDIVIDUAL_TYPE = "100544";
	public static final String RSP_TYPE = "100391";	
	public static final String SPOUSAL_RSP_TYPE = RSP_TYPE.concat("-").concat("SPOUSAL");
	public static final String TFSA_TYPE = "100562";
	public static final String RIF_TYPE = "100555";
	public static final String JOINT_TYPE = "100545";
	public static final String LIRA_TYPE = "100560";
	public static final String LIF_TYPE = "100215";

	@ApiModelProperty(example="100544", value="Valid values can be found in the reference service", allowableValues="100544,100545,100562,100391,10391-SPOUSAL")
	@ReferenceData(code=ErrorCodes.INVALID_ACCOUNT_TYPES, type=ReferenceType.ACCOUNT_TYPES)
	private String type;

	@ApiModelProperty(example="1", value="Valid values can be found in the reference service", allowableValues="1,2,3")
	@ReferenceData(code=ErrorCodes.INVALID_ACCOUNT_LINK_TYPE, type=ReferenceType.LINK_ACCOUNT_TYPES)
	private String accountLinkType;

	@ApiModelProperty(example="GXS", value="Must be a valid iaCode for your supplied iv-user, use the users endpoint to find this information")
	@ValidIaCode
	private String iaCode;

	@ApiModelProperty(value="Refers to party ref id of primary applicant party")
	private String primaryApplicantPartyRefId;

	private Boolean linkDebitCard;	

	private Boolean isSpousal;

	private String debitCardNumber;

	@ApiModelProperty(example="11211220")
	private String accountNumber;

	private Boolean bankUsFunds;

	private Boolean hasOptionsTrading;
	 
	@ApiModelProperty(value="Only populate if hasOptionsTrading is true")
	private OptionsTrading optionsTrading; 

	@ApiModelProperty(example="[*]")
	private List<String> currencies = new ArrayList<>();
	
	@ApiModelProperty(value="Only populate for Joint Account")
	private JointAccountDetails jointAccountDetails;	
	
	@ApiModelProperty(value="Only populate for Lira Account")
	private LiraAccountDetails liraAccountDetails;	

	@ApiModelProperty(example="['1','7']", value="Accepts values from 1-8, valid values can be found in the reference service")
	@ReferenceListData(code=ErrorCodes.INVALID_SUB_TYPE, type=ReferenceType.ACCOUNT_SUBTYPES)
	private List<String> subTypes = new ArrayList<>();

	
	@ApiModelProperty(example="04", value="Valid values can be found in the reference service")
	@ReferenceData(code=ErrorCodes.INVALID_ACCOUNT_INTENDED_USE, type=ReferenceType.ACCOUNT_USES)
	private String intendedUse;

	private String otherDescription;

	@ApiModelProperty(example="04", value="Valid values can be found in the reference service", allowableValues="M,Q,I,D,A,W")
	@ReferenceData(code=ErrorCodes.INVALID_ACCOUNT_INVESTMENT_TIME_HORIZON, type=ReferenceType.INVESTMENT_TIME_HORIZONS)
	private String investmentTimeHorizon;

	@Valid	
	private InvestmentObjectives investmentObjectives = new InvestmentObjectives();

	@ApiModelProperty(value="id used for referential integrity within the workflow")
	private String refId;

	@DataValidationPattern(code = ErrorCodes.INVALID_ACCOUNT_NAME)
	@ApiModelProperty(value="account nick name")
	private String name;

	@ApiModelProperty(value="true if this account has beneficiaries")
	private Boolean hasBeneficiaries;

	@ApiModelProperty(value="Only populate if hasBeneficiaries is true")
	private List<AccountBeneficiary> beneficiaries = new ArrayList<>();

	@ApiModelProperty(value="trading authority, guarantee or guarantor specified")
	private Boolean areOtherPartiesSpecified;

	@ApiModelProperty(value="Reference Id from tradingAuthorities")
	private List<String> tradingAuthorityPartyRefIds = new ArrayList<>();

	@ApiModelProperty(value="Reference Id from guarantors")
	private List<String> guarantorRefIds = new ArrayList<>();

	@ApiModelProperty(value="Reference Id from guarantees")
	private List<String> guaranteeRefIds = new ArrayList<>();

	@ApiModelProperty(value="is successor the applicant's spouse. For TFSA only.")
	private Boolean hasSuccessorAnnuitant;
	
	private Contributor contributor; 
	
	private Boolean hasEftSetup;
	
	private EftDetails inboundEftDetails;
	
	private EftDetails outboundEftDetails;
	
	@ApiModelProperty(value="RIF Account related details captured")
	private RifPaymentDetails rifPayment;
	
	private Boolean hasThirdPartyInterest;

	@ApiModelProperty(value="Joint application party ref ids")
	private List<String> jointApplicantPartyRefIds;
	
	@ApiModelProperty(value="will be provided by CG")
	private Boolean isProAccount;
	
	public Boolean getHasThirdPartyInterest() {
		return hasThirdPartyInterest;
	}

	public void setHasThirdPartyInterest(Boolean hasThirdPartyInterest) {
		this.hasThirdPartyInterest = hasThirdPartyInterest;
	}

	public String getAccountLinkType() {
		return accountLinkType;
	}

	public void setAccountLinkType(String accountLinkType) {
		this.accountLinkType = accountLinkType;
	}

	public String getDebitCardNumber(){
		return debitCardNumber;
	}
	
	public void setDebitCardNumber(String debitCardNumber){
		this.debitCardNumber=debitCardNumber;
	}
	
	public Boolean getBankUsFunds(){
		return bankUsFunds;
	}
	
	public void setBankUsFunds(Boolean bankUsFunds){
		this.bankUsFunds = bankUsFunds;
	}
	
	public Boolean getHasOptionsTrading(){
		return hasOptionsTrading;
	}
	
	public void setHasOptionsTrading(Boolean hasOptionsTrading){
		this.hasOptionsTrading=hasOptionsTrading;
	}

	public OptionsTrading getOptionsTrading(){
		return optionsTrading;
	}
	
	public void setOptionsTrading(OptionsTrading optionsTrading){
		this.optionsTrading=optionsTrading;
	}
	
	public List<String> getCurrencies(){
		return currencies;
	}
	
	public void setCurrencies(List<String> currencies){
		this.currencies=currencies;
	}
	
	public List<String> getSubTypes(){
		return subTypes;
	}
	
	public void setSubTypes(List<String> subTypes){
		this.subTypes=subTypes;
	}
	
	public String getRefId(){
		return refId;
	}
	
	public void setRefId(String refId){
		this.refId = refId;
	}
	
	public String getName(){
		return name;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public String getIaCode() {
		return iaCode;
	}

	public void setIaCode(String iaCode) {
		this.iaCode = iaCode;
	}

	public Boolean getLinkDebitCard() {
		return linkDebitCard;
	}

	public void setLinkDebitCard(Boolean linkDebitCard) {
		this.linkDebitCard = linkDebitCard;
	}

	public String getIntendedUse() {
		return intendedUse;
	}

	public void setIntendedUse(String intendedUse) {
		this.intendedUse = intendedUse;
	}

	public String getOtherDescription() {
		return otherDescription;
	}

	public void setOtherDescription(String otherDescription) {
		this.otherDescription = otherDescription;
	}

	public String getInvestmentTimeHorizon() {
		return investmentTimeHorizon;
	}

	public void setInvestmentTimeHorizon(String investmentTimeHorizon) {
		this.investmentTimeHorizon = investmentTimeHorizon;
	}

	public InvestmentObjectives getInvestmentObjectives() {
		return investmentObjectives;
	}

	public void setInvestmentObjectives(InvestmentObjectives investmentObjectives) {
		this.investmentObjectives = investmentObjectives;
	}

	public Boolean getHasBeneficiaries() {
		return hasBeneficiaries;
	}
	public void setHasBeneficiaries(Boolean hasBeneficiaries) {
		this.hasBeneficiaries = hasBeneficiaries;
	}

	public List<AccountBeneficiary> getBeneficiaries() {
		return beneficiaries;
	}
	public void setBeneficiaries(List<AccountBeneficiary> beneficiaries) {
		this.beneficiaries = beneficiaries;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Boolean getAreOtherPartiesSpecified() {
		return areOtherPartiesSpecified;
	}

	public void setAreOtherPartiesSpecified(Boolean areOtherPartiesSpecified) {
		this.areOtherPartiesSpecified = areOtherPartiesSpecified;
	}

	public List<String> getTradingAuthorityPartyRefIds() {
		return tradingAuthorityPartyRefIds;
	}

	public void setTradingAuthorityPartyRefIds(List<String> tradingAuthorityPartyRefIds) {
		this.tradingAuthorityPartyRefIds = tradingAuthorityPartyRefIds;
	}

	public List<String> getGuarantorRefIds() {
		return guarantorRefIds;
	}

	public void setGuarantorRefIds(List<String> guarantorRefIds) {
		this.guarantorRefIds = guarantorRefIds;
	}

	public List<String> getGuaranteeRefIds() {
		return guaranteeRefIds;
	}

	public void setGuaranteeRefIds(List<String> guaranteeRefIds) {
		this.guaranteeRefIds = guaranteeRefIds;
	}

	public String getPrimaryApplicantPartyRefId() {
		return primaryApplicantPartyRefId;
	}

	public void setPrimaryApplicantPartyRefId(String primaryApplicantPartyRefId) {
		this.primaryApplicantPartyRefId = primaryApplicantPartyRefId;
	}

	public Boolean getHasSuccessorAnnuitant() {
		return hasSuccessorAnnuitant;
	}
	public void setHasSuccessorAnnuitant(Boolean hasSuccessorAnnuitant) {
		this.hasSuccessorAnnuitant = hasSuccessorAnnuitant;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	public Contributor getContributor() {
		return contributor;
	}

	public void setContributor(Contributor contributor) {
		this.contributor = contributor;
	}

	@JsonIgnore
	public boolean hasBeneficiaryRefId(String beneficiaryRefId) {
		if(CollectionUtils.isEmpty(beneficiaries)) {
			return false;
		} else {
			return beneficiaries.stream().anyMatch(b -> beneficiaryRefId.equals(b.getBeneficiaryRefId()));
		}
	}

	@JsonIgnore
	public boolean hasTradingAuthorityPartyRefId(String tradingAuthorityPartyRefId) {
		if(CollectionUtils.isEmpty(tradingAuthorityPartyRefIds)) {
			return false;
		} else {
			return tradingAuthorityPartyRefId.contains(tradingAuthorityPartyRefId);
		}
	}

	public Boolean getHasEftSetup() {
		return hasEftSetup;
	}

	public void setHasEftSetup(Boolean hasEftSetup) {
		this.hasEftSetup = hasEftSetup;
	}

	public EftDetails getInboundEftDetails() {
		return inboundEftDetails;
	}

	public void setInboundEftDetails(EftDetails inboundEftDetails) {
		this.inboundEftDetails = inboundEftDetails;
	}

	public EftDetails getOutboundEftDetails() {
		return outboundEftDetails;
	}

	public void setOutboundEftDetails(EftDetails outboundEftDetails) {
		this.outboundEftDetails = outboundEftDetails;
	}

	public RifPaymentDetails getRifPayment() {
		return rifPayment;
	}
	public void setRifPayment(RifPaymentDetails rifPayment) {
		this.rifPayment = rifPayment;
	}

	public List<String> getJointApplicantPartyRefIds() {
		return jointApplicantPartyRefIds;
	}
	public void setJointApplicantPartyRefIds(List<String> jointApplicantPartyRefIds) {
		this.jointApplicantPartyRefIds = jointApplicantPartyRefIds;
	}

	public JointAccountDetails getJointAccountDetails() {
		return jointAccountDetails;
	}
	public void setJointAccountDetails(JointAccountDetails jointAccountDetails) {
		this.jointAccountDetails = jointAccountDetails;
	}
	
	public LiraAccountDetails getLiraAccountDetails() {
		return liraAccountDetails;
	}

	public void setLiraAccountDetails(LiraAccountDetails liraAccountDetails) {
		this.liraAccountDetails = liraAccountDetails;
	}

	@JsonIgnore
	public boolean isIndividual() {
		return INDIVIDUAL_TYPE.equalsIgnoreCase(getType());		
	}
	@JsonIgnore
	public boolean isRsp() {
		return RSP_TYPE.equalsIgnoreCase(getType());		
	}
	@JsonIgnore
	public boolean isRif() {
		return RIF_TYPE.equalsIgnoreCase(getType());		
	}
	@JsonIgnore
	public boolean isTfsa() {
		return TFSA_TYPE.equals(getType());
	}
	@JsonIgnore
	public boolean isSpousalRsp() {
		return RSP_TYPE.equals(getType()) && Optional.ofNullable(getIsSpousal()).isPresent() && getIsSpousal();
	}
	
	@JsonIgnore
	public boolean isJoint() {
		return JOINT_TYPE.equalsIgnoreCase(getType());		
	}
	
	@JsonIgnore
	public boolean isLira() {
		return LIRA_TYPE.equalsIgnoreCase(getType());		
	}
	
	@JsonIgnore
	public boolean isLif() {
		return LIF_TYPE.equalsIgnoreCase(getType());		
	}
	
	public Boolean getIsSpousal() {
		return isSpousal;
	}

	public void setIsSpousal(Boolean isSpousal) {
		this.isSpousal = isSpousal;
	}

	public Boolean getIsProAccount() {
		return isProAccount;
	}

	public void setIsProAccount(Boolean isProAccount) {
		this.isProAccount = isProAccount;
	}

}
