package com.bmo.channel.pwob.service.document;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.DocumentUpdateUploadRequest;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.DocumentUpdateUploadResponse;

@Produces(MediaType.APPLICATION_JSON)
public interface DocumentUpdateUploadEndpointInterface {
	@POST
	public DocumentUpdateUploadResponse captureDocument(@RequestBody final DocumentUpdateUploadRequest request, @HeaderParam("hubHeader") String hubHeader);
}
