package com.bmo.channel.pwob.validation.employment;

import com.bmo.channel.pwob.model.onboarding.Phone;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface EmploymentValidator {
	
	public static final String EMPLOYER_BUSINESS_NAME_PATTERN = "^[\\p{IsLatin}\\s-'0-9_.,&]{0,30}$";
	
	boolean validateEmployment(Employment employment,Phone primaryPhone,boolean isPrimaryApplicantSpouse, ValidationRequest request);
	boolean validateEmploymentStatus(ValidationRequest request);
	boolean validateEmployerBusinessName(ValidationRequest request, String businessName);
	boolean validateBMOGroup(ValidationRequest request);
	boolean validateNatureOfBusiness(ValidationRequest request);
	boolean validateOccupation(ValidationRequest request);
	boolean validateLineOfBusiness(ValidationRequest request);
	boolean shouldValidateNatureOfBusiness(Employment employment);
}
