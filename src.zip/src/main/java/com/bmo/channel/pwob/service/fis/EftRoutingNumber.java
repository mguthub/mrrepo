package com.bmo.channel.pwob.service.fis;

public class EftRoutingNumber {
  private static final int STANDARD_LENGTH = 9;
  
  private static final int FIID_LENGTH = 3;
  @SuppressWarnings("unused")
  private static final int TRANSITID_LENGTH = 5;
  
  private char lead = '0';
  private String fiId = "000";
  private String transitId = "00000";
  
  public EftRoutingNumber() {}
  
  public EftRoutingNumber(final String eftRoutingNumber) {
    buildFromRoutingNumber(eftRoutingNumber);
  }
  
  public EftRoutingNumber(char lead, String fiId, String transitId) {
    this.lead = lead;
    this.fiId = fiId;
    this.transitId = transitId;
  }
  
  public static EftRoutingNumber buildFromRoutingNumber(String eftRoutingNumber) {
    if (eftRoutingNumber.length() < STANDARD_LENGTH) return new EftRoutingNumber();
    
    return new EftRoutingNumber(eftRoutingNumber.charAt(0),
                  eftRoutingNumber.substring(1, FIID_LENGTH + 1),
                  eftRoutingNumber.substring(1 + FIID_LENGTH, STANDARD_LENGTH));
  }

  public char getLead() {
    return lead;
  }

  public void setLead(char lead) {
    this.lead = lead;
  }

  public String getFiId() {
    return fiId;
  }

  public void setFiId(String fiId) {
    this.fiId = fiId;
  }

  public String getTransitId() {
    return transitId;
  }

  public void setTransitId(String transitId) {
    this.transitId = transitId;
  }
}
