package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;


public class GetCountResponseRootWrapper {

    public GetCountResponseWrapper getGetCountResponse() {
        return getCountResponse;
    }

    public void setGetCountResponse(GetCountResponseWrapper getCountResponse) {
        this.getCountResponse = getCountResponse;
    }

    @JsonProperty("root")
    @JsonDeserialize(using = GetCountResponseDeserializer.class)
    GetCountResponseWrapper getCountResponse;

}
