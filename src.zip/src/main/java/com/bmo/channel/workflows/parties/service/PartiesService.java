package com.bmo.channel.workflows.parties.service;

import com.bmo.channel.pwob.model.onboarding.Party;

public interface PartiesService {
	String createParty(String firstName, String lastName);
	
	Party getParty(String ecifId);
}
