package com.bmo.channel.pwob.model.onboarding;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ClientAccessIdResponse {
	
	private Credential credential;                               
	private String temporaryPassword;                            
	private Application application;                            
	                                
	
	public Application getApplication() {
		return application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

	public Credential getCredential() {                          
		return credential;                                   
	}                                                            
	                                                             
	public void setCredential(Credential credential) {           
		this.credential = credential;                        
	}                                                            
	                                                             
	public String getTemporaryPassword() {                       
		return temporaryPassword;                            
	}                                                            
	                                                             
	public void setTemporaryPassword(String temporaryPassword) { 
		this.temporaryPassword = temporaryPassword;          
	}		                                             

}
