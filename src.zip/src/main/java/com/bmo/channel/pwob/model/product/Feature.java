/**
 * 
 */
package com.bmo.channel.pwob.model.product;

/**
 * @author vvallia
 *
 */
public class Feature {
    protected String code;
    protected String featureNameEN;
    protected String featureNameFR;
    protected String eligible;

    /**
     * Gets the value of the code property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCode() {
        return code;
    }

    /**
     * Sets the value of the code property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCode(String value) {
        this.code = value;
    }

    /**
     * Gets the value of the featureNameEN property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeatureNameEN() {
        return featureNameEN;
    }

    /**
     * Sets the value of the featureNameEN property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeatureNameEN(String value) {
        this.featureNameEN = value;
    }

    /**
     * Gets the value of the featureNameFR property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFeatureNameFR() {
        return featureNameFR;
    }

    /**
     * Sets the value of the featureNameFR property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFeatureNameFR(String value) {
        this.featureNameFR = value;
    }

    /**
     * Gets the value of the eligible property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEligible() {
        return eligible;
    }

    /**
     * Sets the value of the eligible property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEligible(String value) {
        this.eligible = value;
    }
}
