package com.bmo.channel.pwob.service.accounts;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.CreateAccountRequest;

public interface AccountsService {
	Account createAccount(CreateAccountRequest request);
}
