package com.bmo.channel.pwob.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;

/**
 * Validates using Luhn checksum validator.
 * @see <a href="http://id-check.artega.biz/info-ca.php">reference</a>
 * @author Ryan Chambers (rcham02)
 */
public class LuhnCheckValidator  extends AbstractBaseValidator implements ConstraintValidator<LuhnCheck, CharSequence> {
	@Override
	public void initialize(LuhnCheck constraintAnnotation) {
	}

	@Override
	public boolean isValid(CharSequence value, ConstraintValidatorContext context) {
		if(StringUtils.isBlank(value)) {
			return true;
		}
		
		return verifySinPattern(value.toString());
	}

}
