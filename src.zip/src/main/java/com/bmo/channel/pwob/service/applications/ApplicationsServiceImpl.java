package com.bmo.channel.pwob.service.applications;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.BadRequestException;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.AccountBeneficiary;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Beneficiary;
import com.bmo.channel.pwob.model.onboarding.Guarantor;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.RifPaymentDetails;
import com.bmo.channel.pwob.model.onboarding.Taxation;

/**
 * For creating/updating an Application
 * @author Ryan Chambers rcham02
 */
@Service
public class ApplicationsServiceImpl implements ApplicationsService {

	@Override
	public Application removeSpousePartyFromApplication(Application application, String spousePartRefId) {
		Party spouseParty = application.getSpouseParty();
		if(spouseParty == null || !spousePartRefId.equals(spouseParty.getPartyRefId())) {
			throw new BadRequestException("is not a spouse party ref id");
		}

		// remove party
		List<Party> updatedParties = application.getParties().stream().filter(p -> !spousePartRefId.equals(p.getPartyRefId())).collect(Collectors.toList());

		application.setParties(updatedParties);

		Party primaryApplicant = application.getPrimaryApplicant();

		// clear spouse ref
		if(spousePartRefId.equals(primaryApplicant.getSpousePartyRefId())) {
			primaryApplicant.setSpousePartyRefId(null);
		}

		// remove spouse beneficiary
		List<Beneficiary> existingBeneficiaries = application.getBeneficiaries();
		List<Beneficiary> beneficiariesSpouseRemoved = existingBeneficiaries.stream()
				.filter(b -> b.getHasPrimaryApplicantSpouse() == null || !b.getHasPrimaryApplicantSpouse()).collect(Collectors.toList());
		application.setBeneficiaries(beneficiariesSpouseRemoved);

		// Remove spouse guarantors from application
		removeSpouseGuarantors(application);

		List<String> removedBeneficiaryIds = removedBeneficiaryIds(existingBeneficiaries);
		for (Account account : application.getAccounts()) {
			// remove references in accounts to spouse beneficiaries
			removeBeneficiariesWithIds(account, removedBeneficiaryIds);
			// remove references in accounts to spouse TAs
			removeTradingAuthority(account, spousePartRefId);
			// for TFSA & RIF accounts hasSuccessorAnnuitant = false
			successorAnnuitantFalse(account);
			// for Rif payment details, isSpouseAgeUsed = false
			isSpouseAgeUsedFalseForRifPaymentDetails(account);
		}

		return application;
	}
	
	@Override
	public Application addJointApplicantToApplication(Application application, Party jointParty) {		
			application.getParties().add(jointParty);			
		return application;
	}

	private void removeSpouseGuarantors(Application application) {
		// Collect ref IDs of spouse guarantors(s)
		Set<String> spouseGuarantorIds = new HashSet<String>();
		application.getGuarantors().forEach(g -> {
			if (Optional.ofNullable(g.getIsClientSpouseGuarantor()).orElse(false)) {
				spouseGuarantorIds.add(g.getGuarantorRefId());
			}
		});

		// Filter out spouse guarantors from application
		List<Guarantor> guarantors = application.getGuarantors().stream()
				                                    .filter(g -> !Optional.ofNullable(g.getIsClientSpouseGuarantor()).orElse(false))
				                                    .collect(Collectors.toList());
		application.setGuarantors(guarantors);

		// Remove spouse guarantor ref IDs from accounts
		for (Account account : application.getAccounts()) {
			if(account.getGuarantorRefIds() != null){
				List<String> guarantorRefIds = account.getGuarantorRefIds().stream()
						                              .filter(id -> !spouseGuarantorIds.contains(id))
						                              .collect(Collectors.toList());
				account.setGuarantorRefIds(guarantorRefIds);
			}
		}
	}

	private void successorAnnuitantFalse(Account account) {
		if(account.isTfsa()|| account.isRif()) {
			account.setHasSuccessorAnnuitant(false);
		}
	}

	private void isSpouseAgeUsedFalseForRifPaymentDetails(Account account) {
		if (account.isRif()) {
			RifPaymentDetails rifPaymentDetails = account.getRifPayment();
			if(rifPaymentDetails!=null)
				rifPaymentDetails.setIsSpouseAgeUsed(false);
		}
	}

	private void removeTradingAuthority(Account account, String spousePartyRefId) {
		if(account.getTradingAuthorityPartyRefIds() != null){
			List<String> updatedList = account.getTradingAuthorityPartyRefIds().stream().filter(p -> !p.equals(spousePartyRefId)).collect(Collectors.toList());
			account.setTradingAuthorityPartyRefIds(updatedList);
		}
	}

	private void removeBeneficiariesWithIds(Account account, List<String> removedBeneficiaryIds) {
		if(CollectionUtils.isNotEmpty(removedBeneficiaryIds)) {
			List<AccountBeneficiary> beneficiaries = account.getBeneficiaries();
			
			if(CollectionUtils.isNotEmpty(beneficiaries)) {
				List<AccountBeneficiary> newBeneficiaries = beneficiaries.stream().filter(ab -> !removedBeneficiaryIds.contains(ab.getBeneficiaryRefId())).collect(Collectors.toList());
				// remove contingent beneficiaries as well
				for (AccountBeneficiary accountBeneficiary : newBeneficiaries) {
					removeSpouseFromContingentBeneficiaries(accountBeneficiary, removedBeneficiaryIds);
				}
				account.setBeneficiaries(newBeneficiaries);
				//clear hasBeneficiaries flag and setting it to null
				account.setHasBeneficiaries(null);
			}
		}
	}

	private void removeSpouseFromContingentBeneficiaries(AccountBeneficiary accountBeneficiary, List<String> removedBeneficiaryIds) {
		List<String> contingentBeneficiaryRefIds = accountBeneficiary.getContingentBeneficiaryRefIds();
		if(CollectionUtils.isNotEmpty(contingentBeneficiaryRefIds)) {
			accountBeneficiary.setContingentBeneficiaryRefIds(contingentBeneficiaryRefIds.stream().filter(cId -> !removedBeneficiaryIds.contains(cId)).collect(Collectors.toList()));
		}
	}

	private List<String> removedBeneficiaryIds(List<Beneficiary> existingBeneficiaries) {
		return existingBeneficiaries.stream()
				.filter(b -> b.getHasPrimaryApplicantSpouse() != null && b.getHasPrimaryApplicantSpouse())
				.collect(Collectors.toList())
					.stream()
					.map(b -> b.getBeneficiaryRefId()).collect(Collectors.toList());
	}

	@Override
	public Application removeAccountFromApplication(Application existingApp, String accountRefId) {
		Optional<Account> oAcc = existingApp.getAccounts().stream().filter(a -> accountRefId.equals(a.getRefId())).findFirst();
		if(!oAcc.isPresent()) {
			throw new NotFoundException("There is no account with ref id " + accountRefId);
		} else {
			Account jointAccount = oAcc.get();
			if(jointAccount.isJoint()) {
				jointAccountCleanup(existingApp, jointAccount);
			}
		}

		List<Account> remainingAccounts = existingApp.getAccounts().
				stream().
				filter(a -> !accountRefId.equals(a.getRefId())).
				collect(Collectors.toList());
		existingApp.setAccounts(remainingAccounts);

		return existingApp;
	}

	/**
	 * @param existingApp
	 * @param jointAccountToBeRemoved  If joint applicant for the account to be
	 * removed is not a joint applicant for any other accounts then.
	 * 	if they are primary applicant's spouse, remove JOINT_APPLICANT role
	 *  if not, remove applicant
	 */
	void jointAccountCleanup(Application existingApp, Account jointAccountToBeRemoved) {
		List<String> jointApplicantPartyRefIds = jointAccountToBeRemoved.getJointApplicantPartyRefIds();
		if(CollectionUtils.isEmpty(jointApplicantPartyRefIds)) {
			return;
		}

		jointApplicantPartyRefIds.stream().forEach(s -> {
			if(!doesApplicantHaveAnyOtherJointAccounts(existingApp, jointAccountToBeRemoved, s)) {
				removeJointApplicantFromApplication(existingApp, s);
			}
		});
	}

	void removeJointApplicantFromApplication(Application existingApp, String partyRefId) {
		if(partyRefId.equals(existingApp.getPrimaryApplicant().getSpousePartyRefId())) {
			// don't remove spouse party
			Party spouseParty = existingApp.getPartyById(partyRefId);
			spouseParty.getRoles().removeIf(r -> PartyRole.JOINT_APPLICANT == r);
			spouseParty.setTaxation(new Taxation());
		} else {
			// remove party
			List<Party> partiesToKeep = existingApp.getParties().stream().filter(p -> !partyRefId.equals(p.getPartyRefId())).collect(Collectors.toList());
			existingApp.setParties(partiesToKeep);
		}
	}

	boolean doesApplicantHaveAnyOtherJointAccounts(Application existingApp, Account jointAccountToBeRemoved, String jointApplicantRefId) {
		return existingApp.getAccountsForJointApplicant(jointApplicantRefId).
			stream().
			anyMatch(a -> !jointAccountToBeRemoved.getRefId().equals(a.getRefId()) && a.isJoint());
	}
}
