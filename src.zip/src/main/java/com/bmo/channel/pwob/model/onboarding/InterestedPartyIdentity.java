package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;

import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;

public class InterestedPartyIdentity {

	@Valid
	private Name legalName = new Name();

	@DataValidationPattern(code = ErrorCodes.INVALID_DATE_OF_BIRTH)
	private String dateOfBirth;

	public Name getLegalName() {
		return legalName;
	}

	public void setLegalName(Name legalName) {
		this.legalName = legalName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	
}
