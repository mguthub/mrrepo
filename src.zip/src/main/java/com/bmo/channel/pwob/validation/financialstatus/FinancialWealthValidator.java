package com.bmo.channel.pwob.validation.financialstatus;

import com.bmo.channel.pwob.model.onboarding.FinancialWealth;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface FinancialWealthValidator {
	public boolean isValid(FinancialWealth value, ValidationRequest validationRequest);
}
