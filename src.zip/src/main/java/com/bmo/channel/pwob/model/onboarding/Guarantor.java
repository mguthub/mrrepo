/**
 * @author Sasi Nagamony (snagamo)
 */
package com.bmo.channel.pwob.model.onboarding;


import javax.validation.Valid;

import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;

import io.swagger.annotations.ApiModelProperty;

public class Guarantor {
	
	@ApiModelProperty(value="Reference Id from guarantors")
	@DataValidationPattern(code = ErrorCodes.INVALID_GUARANTOR_REF_MAPPING)
	private String guarantorRefId;

	@ApiModelProperty(example="11211220")
	@DataValidationPattern(code = ErrorCodes.INVALID_GUARANTOR_ACCOUNT_NUMBER)
	private String guarantorAccountNumber;
	
	private Boolean isSpouseLiveInSameAddress;
	
	private Boolean isClientSpouseGuarantor;
	
	@Valid
	private InterestedPartyPersonalInfo personalInfo = new InterestedPartyPersonalInfo();
	
	public String getGuarantorRefId() {
		return guarantorRefId;
	}

	public void setGuarantorRefId(String guarantorRefId) {
		this.guarantorRefId = guarantorRefId;
	}

	public String getGuarantorAccountNumber() {
		return guarantorAccountNumber;
	}

	public void setGuarantorAccountNumber(String guarantorAccountNumber) {
		this.guarantorAccountNumber = guarantorAccountNumber;
	}

	public Boolean getIsSpouseLiveInSameAddress() {
		return isSpouseLiveInSameAddress;
	}

	public void setIsSpouseLiveInSameAddress(Boolean isSpouseLiveInSameAddress) {
		this.isSpouseLiveInSameAddress = isSpouseLiveInSameAddress;
	}

	public Boolean getIsClientSpouseGuarantor() {
		return isClientSpouseGuarantor;
	}

	public void setIsClientSpouseGuarantor(Boolean isClientSpouseGuarantor) {
		this.isClientSpouseGuarantor = isClientSpouseGuarantor;
	}

	public InterestedPartyPersonalInfo getPersonalInfo() {
		return personalInfo;
	}
	public void setPersonalInfo(InterestedPartyPersonalInfo personalInfo) {
		this.personalInfo = personalInfo;
	}
}
