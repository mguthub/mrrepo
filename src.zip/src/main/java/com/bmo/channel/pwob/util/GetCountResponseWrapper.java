package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.annotation.JsonProperty;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Workflowcount;

import java.util.ArrayList;
import java.util.List;

public class GetCountResponseWrapper {

    @JsonProperty("Body")
    protected GetCountResponseWrapper.Body body;

    /**
     * Gets the value of the body property.
     *
     * @return
     *     possible object is
     *     {@link GetCountResponseWrapper.Body }
     *
     */
    public GetCountResponseWrapper.Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     *
     * @param value
     *     allowed object is
     *     {@link GetCountResponseWrapper.Body }
     *
     */
    public void setBody(GetCountResponseWrapper.Body value) {
        this.body = value;
    }


    public static class Body {

        protected Body.Counts counts;

        /**
         * Gets the value of the counts property.
         *
         * @return
         *     possible object is
         *     {@link Body.Counts }
         *
         */
        public Body.Counts getCounts() {
            return counts;
        }

        /**
         * Sets the value of the counts property.
         *
         * @param value
         *     allowed object is
         *     {@link Body.Counts }
         *
         */
        public void setCounts(Body.Counts value) {
            this.counts = value;
        }


        public static class Counts {

            protected List<Workflowcount> workflowcount;

            /**
             * Gets the value of the workflowcount property.
             *
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the workflowcount property.
             *
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getWorkflowcount().add(newItem);
             * </pre>
             *
             *
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link Workflowcount }
             *
             *
             */
            public List<Workflowcount> getWorkflowcount() {
                if (workflowcount == null) {
                    workflowcount = new ArrayList<Workflowcount>();
                }
                return this.workflowcount;
            }

        }

    }

}
