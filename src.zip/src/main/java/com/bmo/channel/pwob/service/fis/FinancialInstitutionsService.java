package com.bmo.channel.pwob.service.fis;

import java.util.List;

import com.bmo.channel.pwob.model.onboarding.Branch;
import com.bmo.channel.pwob.model.onboarding.FinancialInstitution;

public interface FinancialInstitutionsService {
	List<FinancialInstitution> retrieveFinancialInstitutionsByPartialId(String partialId, String lang);
	Branch retrieveBankBranchInformationByFiIdAndTransitId(String fiId, String transitId, String lang);
	List<Branch> retrieveBankBranchesInformationByFiIdAndPartialTransitId(String fiId, String partialId, String lang);
}
