package com.bmo.channel.pwob.service.reference.mapping;

import java.util.Date;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;

import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.util.DateUtils;
import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.TranslationType;
import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.ValueType;

public abstract class AbstractBaseReferenceMapper implements ReferenceMapper {
	public final String IS_PEP_FLAG = "Yes";
	public final String PEP_FLAG_PROPERTY = "PEP Flag";
	public final String EXPIRED_DATA_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
	public final String FR_LANG = "Français";

	public Reference toReference(ValueType v) {
		Reference reference = new Reference(v.getCode().getValue(), v.getName().getValue());
		if(isExpiredData(v)) {
			reference.setExpired(Boolean.TRUE);
		}
		return reference;
	}
	
	public Reference toReferenceFR(ValueType v) {
		Reference reference;
		String name = getFrenchName(v);		
		if(!StringUtils.isBlank(name)){
			reference = new Reference(v.getCode().getValue(), name);
		}else{
			reference = new Reference(v.getCode().getValue(), v.getName().getValue());
		}
			if (isExpiredData(v)) {
				reference.setExpired(Boolean.TRUE);
			}
		return reference;		
	}

	public Reference MapRisToEcif(ValueType v, Map<String,String> mappings) {
		if(mappings.containsKey(v.getCode().getValue())) {	
			Reference reference = new Reference(mappings.get(v.getCode().getValue()), v.getName().getValue());
			if(isExpiredData(v)) {
				reference.setExpired(Boolean.TRUE);
			}
			return reference;
		}
		return null;
	}
	
	
	public Reference MapRisToEcifFR(ValueType v, Map<String,String> mappings) {
		
		if(mappings.containsKey(v.getCode().getValue())) {
			return getTranslation(v, mappings);
		}
		return null;
	}

	private  Reference getTranslation(ValueType v, Map<String, String> mappings) {
		Reference ref;
		
		String name = getFrenchName(v);
		if(!StringUtils.isBlank(name)){
			ref = new Reference(mappings.get(v.getCode().getValue()), name);
			
		}else
		{	//if French translation is not present, set English name
			ref = new Reference(mappings.get(v.getCode().getValue()), v.getName().getValue());
		}
		
		if (isExpiredData(v)) {
			ref.setExpired(Boolean.TRUE);
		}
		return ref;
	}

	protected String getFrenchName(ValueType v){
		Optional<TranslationType> translation = v.getTranslations().getTranslation().stream().filter(t -> FR_LANG.equals(t.getLanguage())).findFirst();
		if (translation.isPresent() && Optional.ofNullable(translation.get().getName()).isPresent()	&& StringUtils.isNotEmpty(translation.get().getName())) {
			return translation.get().getName();
		}
		return null;
	}
	
	
	public boolean isExpiredData(ValueType v) {
		boolean expired = false;
		
		if (v.getEffectiveDate() != null && StringUtils.isNotBlank(v.getEffectiveDate().getValue())) {
			expired = new Date().before(DateUtils.convertStringToDateTime(v.getEffectiveDate().getValue(), EXPIRED_DATA_DATE_FORMAT)) || expired;
		}	
				
		if (v.getExpiryDate() != null && StringUtils.isNotBlank(v.getExpiryDate().getValue())) {
			expired = new Date().after(DateUtils.convertStringToDateTime(v.getExpiryDate().getValue(), EXPIRED_DATA_DATE_FORMAT)) || expired;	
		}
		
		return expired;
	}
}
