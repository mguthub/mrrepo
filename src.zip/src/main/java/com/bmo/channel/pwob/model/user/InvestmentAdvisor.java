package com.bmo.channel.pwob.model.user;

import java.util.ArrayList;
import java.util.List;

public class InvestmentAdvisor {

	private String firstName;
	private String lastName;
	
	
	private List<String> jurisdictionProvinces = new ArrayList<String>();	
	private String networkId;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public List<String> getJurisdictionProvinces() {
		return jurisdictionProvinces;
	}
	public void setJurisdictionProvinces(List<String> jurisdictionProvinces) {
		this.jurisdictionProvinces = jurisdictionProvinces;
	}
	public String getNetworkId() {
		return networkId;
	}
	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}
}
