package com.bmo.channel.pwob.model.ia;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

public class ClientRelationship {
	private Integer duration;
	
	@ReferenceData(code=ErrorCodes.INVALID_TIME_UNIT, type=ReferenceType.TIME_UNITS)
	private String timeUnits;


	public Integer getDuration() {
		return duration;
	}

	public void setDuration(Integer duration) {
		this.duration = duration;
	}

	public String getTimeUnits() {
		return timeUnits;
	}

	public void setTimeUnits(String timeUnits) {
		this.timeUnits = timeUnits;
	}
}
