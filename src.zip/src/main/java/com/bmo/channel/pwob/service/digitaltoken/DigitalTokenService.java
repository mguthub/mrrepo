/**
 * 
 */
package com.bmo.channel.pwob.service.digitaltoken;

/**
 * @author vvallia
 * To cache the OLAP customer connect data 
 *
 */
public interface DigitalTokenService {
	String generateToken(String payload);
	String validateToken(String cachedToken);
}
