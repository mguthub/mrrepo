package com.bmo.channel.pwob.validation.financialstatus;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.InvestmentExperience;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

@Component
public class InvestmentExperienceKnowledgeValidatorImpl extends AbstractBaseValidator implements InvestmentExperienceKnowledgeValidator{
	
	public static final String PAST_EXPERIENCE_FIELD_NAME = "pastExperience";
	public static final String INVESTMENT_KNOWLEDGE_FIELD_NAME = "investmentKnowledge";
	private static final String ALT_INVESTMENT_EXPERIENCE_FIELD_NAME = "altInvestmentExperience";
	public static final String ALT_INV_EXP_PATTERN = "^[" + GENERIC_ALLOWED_CHARACTERS_PATTERN + "]{0,100}$";	

	@Autowired ValidationRequestFactory validationRequestFactory;

	@Autowired private UsersService userService;	

	
	public boolean isInvestmentExperienceValid(InvestmentExperience value, ValidationRequest validationRequest) {
		ValidationContextHolder validationContextHolder = ValidationManager.validationContext.get();

		if(validationContextHolder.getAction() == Action.SAVE) {
			// only validate of submitting			
			return true;
		}

		boolean valid = true;
		if(this.userService.currentUser().getLob() == ApplicationLob.nb) {
			
			validationRequest.setFieldValueList(value.getPastExperience());
			valid = this.validatePastExperience(validationRequest);

			
			validationRequest.setFieldValue(value.getInvestmentKnowledge());
			valid = this.validateKnowledge(validationRequest) && valid;

			validationRequest.setFieldValue(value.getAltInvestmentExperience());
			valid = validateAltInvestmentExperience(value.getPastExperience(), value.getAltInvestmentExperience(), validationRequest) && valid;
		}
		return valid;
	}

	private boolean validateAltInvestmentExperience(List<String> pastExperience, String altInvestmentExperience, ValidationRequest validationRequest) {
		if(isValidAlternativeExperience(pastExperience, altInvestmentExperience)) {
			return true;
		} else {			
			validationRequest.addConstraintViolation(ALT_INVESTMENT_EXPERIENCE_FIELD_NAME,ErrorCodes.INVALID_ALT_INVESTMENT_EXPERIENCE);
			return false;
		}
	}

	boolean isValidAlternativeExperience(List<String> past, String alt) {
		if(CollectionUtils.isEmpty(past)) {
			return true;
		}
		if(past.contains(RefDataValues.PAST_EXPERIENCE_ALTERNATIVE_INVESTMENTS)) {
			return this.doesPatternMatch(alt, ALT_INV_EXP_PATTERN);
		}
		return true;
	}	

	private boolean validatePastExperience(ValidationRequest validationRequest) {		
		if(validationRequest.getFieldValueList() == null || validationRequest.getFieldValueList().isEmpty()) {			
			validationRequest.addConstraintViolation(PAST_EXPERIENCE_FIELD_NAME,ErrorCodes.INVALID_PAST_INVESTMENT_EXPERIENCE);
			return false; 
		} else return true;
	}

	private boolean validateKnowledge(ValidationRequest validationRequest) {				
		if(StringUtils.isBlank(validationRequest.getFieldValue())) {					
			validationRequest.addConstraintViolation(INVESTMENT_KNOWLEDGE_FIELD_NAME,ErrorCodes.INVALID_INVESTMENT_KNOWLEDGE);
			return false; 
		} else return true;		
	}
}
