package com.bmo.channel.pwob.model.applications;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Summary {
	
	@JsonProperty(value="DataCollection")
	private int dataCollection;
	
	@JsonProperty(value="DocumentCollection")
	private int documentCollection;
	
	@JsonProperty(value="AccountSetup")
	private int accountSetup;
	
	@JsonProperty(value="IAApproval")
	private int iaApproval;
	
	@JsonProperty(value="IARemediation")
	private int iaRemediation;
	
	@JsonProperty(value="BMApproval")
	private int bmApproval;
	
	@JsonProperty(value="Completed")
	private int approved;

	public int getDataCollection() {
		return dataCollection;
	}
	public void setDataCollection(int dataCollection) {
		this.dataCollection = dataCollection;
	}		
	public int getDocumentCollection() {
		return documentCollection;
	}
	public void setDocumentCollection(int documentCollection) {
		this.documentCollection = documentCollection;
	}
	public int getAccountSetup() {
		return accountSetup;
	}
	public void setAccountSetup(int accountSetup) {
		this.accountSetup = accountSetup;
	}
	public int getIaApproval() {
		return iaApproval;
	}
	public void setIaApproval(int iaApproval) {
		this.iaApproval = iaApproval;
	}
	public int getIaRemediation() {
		return iaRemediation;
	}
	public void setIaRemediation(int iaRemediation) {
		this.iaRemediation = iaRemediation;
	}
	public int getBmApproval() {
		return bmApproval;
	}
	public void setBmApproval(int bmApproval) {
		this.bmApproval = bmApproval;
	}
	public int getApproved() {
		return approved;
	}
	public void setApproved(int approved) {
		this.approved = approved;
	}	
}
