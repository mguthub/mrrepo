package com.bmo.channel.pwob.validation.risprefill;

import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.onboarding.IndividualParty;

public interface RisPrefillValidator {
	
	public abstract void titleValidator(Party party);
	public abstract void primaryApplicantNamesValidator(IndividualParty party);
	public abstract void primaryApplicantPrimaryAddressValidator(IndividualParty party,String accountNumber);	
	public abstract void spouseNameValidator(Party party);
	public abstract void primaryApplicantAddressValidator(Party party);
	public abstract void primaryApplicantPhoneValidator(Party party);
	public abstract void taxResidencyValidator(Party party);
	public abstract void employmentDetailsValidator(Party party);		
	public abstract void preferredLangValidator(Party party);
	public abstract void citizenshipValidator(Party party);
	public abstract void preferredNameValidator(Party party);
	public abstract void maritalStatusValidator(Party party);
	public abstract void dateOfBirthValidator(Party party);
}
