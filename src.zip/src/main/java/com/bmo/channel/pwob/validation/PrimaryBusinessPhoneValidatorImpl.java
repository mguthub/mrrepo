package com.bmo.channel.pwob.validation;

import java.util.Properties;

import javax.annotation.Resource;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class PrimaryBusinessPhoneValidatorImpl extends AbstractBaseValidator implements PrimaryBusinessPhoneValidator { 
	
	@Resource(name = "validationRules")
	private Properties validationRules;
	
	@Override
	public boolean validatePhoneNumber(ValidationRequest validationRequest) {		
		return this.validateAndAddConstraintViolation(validationRequest);
	}

		
	protected boolean validateAndAddConstraintViolation(ValidationRequest validationRequest) {		
		boolean valid = StringUtils.isNotBlank(validationRequest.getFieldValue()) && validateField(validationRequest);	
		if(!valid) {
			this.addConstraintViolation(validationRequest);
		}
		return valid;
	}
	
	
	protected boolean validateField(ValidationRequest validationRequest) {		
		String fullFieldPath = validationRequest.getFieldPath().concat(".")		
				.concat(validationRequest.getChildFieldPath()).concat(".")
				.concat(validationRequest.getFieldName());
		String regex = this.retrievePatternForFieldAndLob(validationRequest.getLob(), fullFieldPath);
		return (StringUtils.isNoneBlank(regex) && validationRequest.getFieldValue().matches(regex));
	}
	
	@Override
	public void addConstraintViolation(ValidationRequest validationRequest) {
		validationRequest.getContext().disableDefaultConstraintViolation();
		ConstraintViolationBuilder builder = validationRequest.getContext()
				.buildConstraintViolationWithTemplate(validationRequest.getErrorCode());					
		builder.addPropertyNode(validationRequest.getChildPropertyNode())
			   .addPropertyNode(validationRequest.getFieldName())
			   .addBeanNode()
			   .addConstraintViolation();		
	}
}
