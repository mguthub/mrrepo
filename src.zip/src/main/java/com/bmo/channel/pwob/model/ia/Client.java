package com.bmo.channel.pwob.model.ia;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ia.ValidInternalApprovalClient;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;
@ValidInternalApprovalClient
public class Client {
	private ClientRelationship relationship;
	
	private Boolean registeredInResidenceProvince;
	
	private Integer householdSize;
	
	@ApiModelProperty(example="1", value="Valid values can be found in the reference service", allowableValues="1,2")
	@ReferenceData(code=ErrorCodes.INVALID_REFERRAL_SOURCE, type=ReferenceType.REFERRAL_SOURCES)
	private String referralSource;
	
	private String referrerFirstName;
	
	private String referrerLastName;
	
	private String transitNumber;
	
	private String tismCode;

	public ClientRelationship getRelationship() {
		return relationship;
	}

	public void setRelationship(ClientRelationship relationship) {
		this.relationship = relationship;
	}

	public Boolean getRegisteredInResidenceProvince() {
		return registeredInResidenceProvince;
	}

	public void setRegisteredInResidenceProvince(Boolean registeredInResidenceProvince) {
		this.registeredInResidenceProvince = registeredInResidenceProvince;
	}

	public Integer getHouseholdSize() {
		return householdSize;
	}

	public void setHouseholdSize(Integer householdSize) {
		this.householdSize = householdSize;
	}

	public String getReferralSource() {
		return referralSource;
	}

	public void setReferralSource(String referralSource) {
		this.referralSource = referralSource;
	}
	public String getReferrerFirstName() {
		return referrerFirstName;
	}

	public void setReferrerFirstName(String referrerFirstName) {
		this.referrerFirstName = referrerFirstName;
	}

	public String getReferrerLastName() {
		return referrerLastName;
	}

	public void setReferrerLastName(String referrerLastName) {
		this.referrerLastName = referrerLastName;
	}

	public String getTransitNumber() {
		return transitNumber;
	}

	public void setTransitNumber(String transitNumber) {
		this.transitNumber = transitNumber;
	}

	public String getTismCode() {
		return tismCode;
	}

	public void setTismCode(String tismCode) {
		this.tismCode = tismCode;
	}
}
