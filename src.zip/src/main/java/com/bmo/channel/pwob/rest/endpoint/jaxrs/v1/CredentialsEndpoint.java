package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.ClientAccessIdRequest;
import com.bmo.channel.pwob.model.onboarding.ClientAccessIdResponse;
import com.bmo.channel.pwob.model.onboarding.Credential;
import com.bmo.channel.pwob.model.onboarding.SuggestedUserIds;
import com.bmo.channel.pwob.service.credential.CredentialService;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.ValidationManager.IdType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
/**
 * Sub-route for Credentials.
 * @author Tolga Ekmen
 */
@Api(WorkflowsEndpoint.V1_PATH + "/{id}" + CredentialsEndpoint.V1_SUBPATH)
@Path(WorkflowsEndpoint.V1_PATH + "/{id}" + CredentialsEndpoint.V1_SUBPATH)
public class CredentialsEndpoint {

	public static final String V1_SUBPATH = "/credentials";
	public static final String SUGGESTED_ID_SUBPATH = "/user_ids/suggested";
	
	@Autowired
	protected ValidationManager validationManager;
	
	
	@Autowired
	private CredentialService credentialService;

	@GET
	@Path("/{userId}")
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value="Validate the existence of Access Id", response = Credential.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code = 404, message = "User Id not found"),
			@ApiResponse(code = 400, message = "User Id pattern validation failed")})
	public CredentialResponse validateCredential(
			@ApiParam(value = "Application ID") @PathParam("id") String applicationId,
			@ApiParam(value = "pjtucker") @PathParam("userId") @NotEmpty String userId) {
		this.validationManager.validateId(userId, IdType.ExistingGatewayUserId);
		return new CredentialResponse(credentialService.validateExistingAccessId(applicationId, userId));
	}
	
	@GET
	@Path(SUGGESTED_ID_SUBPATH)
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value="Check and retrieve suggested user ids for the given user id", response = SuggestedUserIds.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "UserId or suggested user ids exist"),
			@ApiResponse(code = 400, message = "User Id pattern validation failed"),
			@ApiResponse(code = 404, message = "User id or application id is invalid")})			
	public SuggestedUserIds retrieveSuggestedUserIds(
			@ApiParam(value = "Application ID") @PathParam("id") String applicationId, 
			@ApiParam(value = "User ID") @QueryParam("userId") String userId) {
		this.validationManager.validateId(userId, IdType.PWOBGatewayUserId);
		return  credentialService.retrieveSuggestedUserIds(applicationId, userId);
	}
	
	@GET	
	@Produces(MediaType.APPLICATION_JSON)
	@ApiOperation(value="Retrieve application user id", response = Credential.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string", paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string", paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code = 200, message = "Returns application's userId"),
			@ApiResponse(code = 404, message = "Credential does not exist")})			
	public ClientAccessIdResponse retrieveApplicationUserId(@ApiParam(value = "Application ID") @PathParam("id") String applicationId) {
		return  credentialService.retrieveApplicationUserId(applicationId);
	}
	
	@PUT                                                                                                                                           	                                                                                                                               
	@Produces(MediaType.APPLICATION_JSON)                                                                                                          
	@ApiOperation(value="Create and Reserve new userId and temporary password", response = ClientAccessIdResponse.class)                                                               
	@ApiImplicitParams({                                                                                                                           
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,      
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})  
	@ApiResponses(value={                                                                                                                          
			@ApiResponse(code=404, message="Application Id not found"),                                                                    
			@ApiResponse(code=400, message="Workflow user id has already been reserved"),                                                  
			@ApiResponse(code=409, message="User id is already used by some other user/application")})                                     
	public ClientAccessIdResponse reserveCredential(@ApiParam(value = "Application ID") @PathParam("id") String applicationId, 
			ClientAccessIdRequest request) {                                                   
			return credentialService.reserveUserCredential(applicationId, request.getCredential());                
	}                                                                                                                                              

}

