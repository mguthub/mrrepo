package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.DateValidation;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.bmo.channel.pwob.validation.reference.ReferenceData;
import com.bmo.channel.pwob.validation.verification.ValidVerification;

import io.swagger.annotations.ApiModelProperty;

@ValidVerification
public class Verification {
	@ApiModelProperty(example="3", value="Valid values can be found in the reference service", allowableValues="1,2,3,4")
	@ReferenceData(type=ReferenceType.ID_VERIFICATION_METHODS, code=ErrorCodes.INVALID_ID_VERIFICATION_METHOD)
	private String idVerificationMethod;

	@ApiModelProperty(example="009", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.DOCUMENT_TYPES, code=ErrorCodes.INVALID_DOCUMENT_TYPE)
	private String documentType;

	@ApiModelProperty(example="1955-12-25", value="Format: YYYY-MM-DD")
	@DateValidation(code=ErrorCodes.INVALID_DATE)	
	private String expiryDate;

	@ApiModelProperty(value="Id number in identity document")
	private String idNumber;

	@ApiModelProperty(example="100000", value="ECIF code for issuing country")
	private String country; //will be used for place of issue, country of citizenship

	@ApiModelProperty(example="101", value="ECIF code for issuing province")
	private String province;

	@ApiModelProperty(value="Does the applicant birth place is USA?")
	private Boolean isPlaceOfBirthUS;
	
	@ApiModelProperty(example="100000", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.COUNTRIES, code=ErrorCodes.INVALID_COUNTRY)
	private String countryOfBirth;

	@ApiModelProperty(value="First name of employee who verified ID")
	private String employeeFirstName;

	@ApiModelProperty(value="Last name of employee who verified ID")
	private String employeeLastName;

	@ApiModelProperty(value="Does the ID provided by the client match the information collected?")
	@Valid
	private Boolean idProvidedMatchApplicantInformation;

	@ApiModelProperty(value="Reason for why ID provided does not match the information collected")
	private String reasonForDiscrepancy;

	@ApiModelProperty(value="When client id was captured, YYYY-MM-DD", example="2016-12-25")
	@DateValidation(code=ErrorCodes.INVALID_DATE)
	private String clientIdCaptureTime;

	public String getIdVerificationMethod() {
		return idVerificationMethod;
	}

	public void setIdVerificationMethod(String idVerificationMethod) {
		this.idVerificationMethod = idVerificationMethod;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getIdNumber() {
		return idNumber;
	}

	public void setIdNumber(String idNumber) {
		this.idNumber = idNumber;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}	

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCountryOfBirth() {
		return countryOfBirth;
	}

	public void setCountryOfBirth(String countryOfBirth) {
		this.countryOfBirth = countryOfBirth;
	}

	public String getEmployeeFirstName() {
		return employeeFirstName;
	}

	public void setEmployeeFirstName(String employeeFirstName) {
		this.employeeFirstName = employeeFirstName;
	}

	public String getEmployeeLastName() {
		return employeeLastName;
	}

	public void setEmployeeLastName(String employeeLastName) {
		this.employeeLastName = employeeLastName;
	}

	public Boolean getIdProvidedMatchApplicantInformation() {
		return idProvidedMatchApplicantInformation;
	}

	public void setIdProvidedMatchApplicantInformation(Boolean idProvidedMatchApplicantInformation) {
		this.idProvidedMatchApplicantInformation = idProvidedMatchApplicantInformation;
	}

	public String getReasonForDiscrepancy() {
		return reasonForDiscrepancy;
	}

	public void setReasonForDiscrepancy(String reasonForDiscrepancy) {
		this.reasonForDiscrepancy = reasonForDiscrepancy;
	}

	public String getClientIdCaptureTime() {
		return clientIdCaptureTime;
	}

	public void setClientIdCaptureTime(String clientIdCaptureTime) {
		this.clientIdCaptureTime = clientIdCaptureTime;
	}

	public Boolean getIsPlaceOfBirthUS() {
		return isPlaceOfBirthUS;
	}

	public void setIsPlaceOfBirthUS(Boolean isPlaceOfBirthUS) {
		this.isPlaceOfBirthUS = isPlaceOfBirthUS;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
