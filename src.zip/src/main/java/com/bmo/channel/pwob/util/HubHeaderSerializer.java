package com.bmo.channel.pwob.util;

import java.io.IOException;
import java.util.Optional;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

import net.bmogc.xmlns.hub.header.v1.Correlation;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;
import net.bmogc.xmlns.hub.header.v1.What;
import net.bmogc.xmlns.hub.header.v1.Where;
import net.bmogc.xmlns.hub.header.v1.Who;

public class HubHeaderSerializer extends StdSerializer<HUBHeaderRequest> {
	private static final long serialVersionUID = 1L;

	public HubHeaderSerializer() {
		this(null);
	}

	protected HubHeaderSerializer(Class<HUBHeaderRequest> t) {
		super(t);
	}

	@Override
	public void serialize(HUBHeaderRequest hubHeader, JsonGenerator jgen, SerializerProvider provider)
			throws IOException, JsonGenerationException {
		jgen.writeStartObject();

		Correlation correlation = hubHeader.getCorrelation();
		jgen.writeObjectFieldStart("correlation");
		jgen.writeStringField("callPath", correlation.getCallPath());
		jgen.writeStringField("myId", correlation.getMyId());
		jgen.writeStringField("myTimeStamp", correlation.getMyTimeStamp().toString());
		jgen.writeStringField("requestId", correlation.getRequestId());
		jgen.writeEndObject();

		jgen.writeStringField("digitalSignature", hubHeader.getDigitalSignature());
		jgen.writeStringField("headerVersion", hubHeader.getHeaderVersion());

		What what = hubHeader.getWhat();
		jgen.writeObjectFieldStart("what");
		jgen.writeStringField("API", what.getAPI());
		jgen.writeStringField("APIFunction", what.getAPIFunction());
		jgen.writeEndObject();

		Where where = hubHeader.getWhere();
		jgen.writeObjectFieldStart("where");
		jgen.writeStringField("originatorChannel", where.getOriginatorChannel());
		jgen.writeStringField("originatorApplicationCatalogueId", where.getOriginatorApplicationCatalogueId());
		jgen.writeStringField("originatorLocationId", where.getOriginatorLocationId());
		jgen.writeStringField("originatorLocationType", where.getOriginatorLocationType());
		jgen.writeStringField("originatorSessionId", where.getOriginatorSessionId());
		jgen.writeEndObject();

		if (Optional.ofNullable(hubHeader).map(HUBHeaderRequest::getWho).isPresent()) {
			Who who = hubHeader.getWho();
			jgen.writeObjectFieldStart("who");
			jgen.writeStringField("employeeUserId", who.getEmployeeUserId());
			jgen.writeStringField("employeeUserIdType", who.getEmployeeUserIdType());
			jgen.writeStringField("partyAccessId", who.getPartyAccessId());
			jgen.writeStringField("partyAccessIdType", who.getPartyAccessId());
			jgen.writeStringField("partyMultiFactorAuthenticationIndicator",
			who.getPartyMultiFactorAuthenticationIndicator());
			jgen.writeEndObject();
		}

		jgen.writeEndObject();
	}
}
