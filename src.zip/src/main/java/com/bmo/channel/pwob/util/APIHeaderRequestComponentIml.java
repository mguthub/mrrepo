package com.bmo.channel.pwob.util;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.core.util.RequestIdContext;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.user.UserContext;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.UUID;

@Component
public class APIHeaderRequestComponentIml  implements APIHeaderRequestComponent{
    private Logger logger = LoggerFactory.getLogger(APIHeaderRequestComponentIml.class);

    @Autowired
    private RequestIdContext requestIdContext;

    @Autowired
    private UserContext userContext;

    @Override
    public APIRequestHeaderBuilder.HeaderBuilder getHubBuilder() {
        String requestId = StringUtils.isNoneBlank(requestIdContext.getRequestId()) ? requestIdContext.getRequestId() : UUID.randomUUID().toString();
        APIRequestHeaderBuilder.HeaderBuilder headerBuilder = new APIRequestHeaderBuilder.HeaderBuilder();
        ApplicationLob lob = userContext.getAuthenticatedUser().getLob();
      
        headerBuilder.requestId(requestId);
        headerBuilder.lob(lob);
       
        if(ApplicationLob.nb == lob) {
        	String userId = userContext.getAuthenticatedUser().getUserId();
        	   headerBuilder.userId(userId).partyAccessId(userId).partyId(userId);
        }

        return headerBuilder;
    }

    @Override
    public <T> T requestBodyWithRequestorInfo(T t, String... strings) {

        Arrays.asList(strings).forEach(property -> {
            try {
                BeanUtils.setProperty(t, property, userContext.getAuthenticatedUser().getNetworkId());
            } catch (Exception ex) {
                logger.error("error set property in api header request xml object", ex);
                throw new WebServiceException(ex);
            }
        });


        return t;
    }

    @Override
    public String getMetaInfo(final String documentPackageId) {
        String lob = Constants.INVESTOR_LINE;
        if (userContext.getAuthenticatedUser().getLob() == ApplicationLob.nb) {
            lob = Constants.NESBITT;
        }
        return MetadataCreator.createMetadata(documentPackageId, userContext.getAuthenticatedUser().getUserId(), lob);
    }
}
