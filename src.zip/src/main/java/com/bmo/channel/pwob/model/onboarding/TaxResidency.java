package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

public class TaxResidency {
	
	@ApiModelProperty(example="101", value="Valid values can be found in the reference service")
	private String province;
	
	@ApiModelProperty(example="100000", value="Valid values can be found in the reference service")
	private String country;
	
	@ApiModelProperty(example="15676", value="Alphanumeric")
	private String taxIdentificationNumber;
	
	@ReferenceData(code=ErrorCodes.INVALID_TAX_ID_MISSING_REASON, type=ReferenceType.TAX_ID_MISSING_REASON)
	private String taxIdentificationNumberMissingReason;
	
	@ApiModelProperty(example="Applied but not recieved", value="String")
	private String taxIdentificationNumberMissingReasonDescription;
	
	@ApiModelProperty(example="No tax identification number", value="Boolean")
	private Boolean haveNoTaxIdentificationNumber;

	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	public TaxResidency(String country) {
		super();
		this.country = country;
	}
	
	public TaxResidency() {
		// TODO Auto-generated constructor stub
	}
	public String getTaxIdentificationNumber() {
		return taxIdentificationNumber;
	}
	public void setTaxIdentificationNumber(String taxIdentificationNumber) {
		this.taxIdentificationNumber = taxIdentificationNumber;
	}
	public String getTaxIdentificationNumberMissingReason() {
		return taxIdentificationNumberMissingReason;
	}
	public void setTaxIdentificationNumberMissingReason(String taxIdentificationNumberMissingReason) {
		this.taxIdentificationNumberMissingReason = taxIdentificationNumberMissingReason;
	}
	public String getTaxIdentificationNumberMissingReasonDescription() {
		return taxIdentificationNumberMissingReasonDescription;
	}
	public void setTaxIdentificationNumberMissingReasonDescription(String taxIdentificationNumberMissingReasonDescription) {
		this.taxIdentificationNumberMissingReasonDescription = taxIdentificationNumberMissingReasonDescription;
	}
	public Boolean getHaveNoTaxIdentificationNumber() {
		return haveNoTaxIdentificationNumber;
	}
	public void setHaveNoTaxIdentificationNumber(Boolean haveNoTaxIdentificationNumber) {
		this.haveNoTaxIdentificationNumber = haveNoTaxIdentificationNumber;
	}
}
