package com.bmo.channel.pwob.validation.holder;

import com.bmo.channel.pwob.model.onboarding.Application;

public class ValidationContextHolder {	
	private final String locale;
	private final Action action;
	private final Application application;
		
	
	public enum Action {
		SAVE,
		SUBMIT
	}

	public ValidationContextHolder(String locale, Action action) {
		this.locale = locale;
		this.action = action;
		this.application = null;
	}
	
	public ValidationContextHolder(String locale, Action action, Application application) {
		this.locale = locale;
		this.action = action;
		this.application = application;
	}
	
	public ValidationContextHolder(String locale, Application application) {
		this.locale = locale;
		this.action = null;
		this.application = application;
	}
	
	public ValidationContextHolder(String locale){
		this.locale = locale;
		this.action = null;
		this.application = null;
	}
	
	public Application getApplication() {
		return application;
	}

	public String getLocale() {
		return locale;
	}
	public Action getAction() {
		return action;
	}
}
