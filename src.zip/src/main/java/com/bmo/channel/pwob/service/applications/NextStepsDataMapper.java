package com.bmo.channel.pwob.service.applications;

import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.onboarding.NextStepsData;

import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationResponse;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.ApplicationData;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.BmoRelationship;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.PersonalInformation;

public class NextStepsDataMapper
		implements NextStepsFunction<SavedApplication, RetrieveApplicationResponse, NextStepsData> {

	@Override
	public NextStepsData apply(SavedApplication savedApp, RetrieveApplicationResponse response) {
		
		ApplicationData originalApplicationData = response.getBody().getPayload().getAPPLICATIONDATA().getAppData();	
		
		Party primaryParty = originalApplicationData.getParties().get(0);
		PersonalInformation personalInfo = primaryParty.getPersonalInformation();
		BmoRelationship bmoRelationship = primaryParty.getBmoRelationship();
		
		NextStepsData data = new NextStepsData();
		data.setFirstName(personalInfo.getLegalFirstName());
		data.setLastName(personalInfo.getLegalLastName());
		data.setMiddleName(personalInfo.getLegalMiddleName());
		data.setTitle(personalInfo.getTitle());
		data.setWorkflowStatus(savedApp.getAppStatus());
		data.setPreferredLanguage(personalInfo.getPreferredLanguage());
		data.setApplicationNumber(savedApp.getApplicationNumber());
		data.setAccountNumber(originalApplicationData.getAccounts().get(0).getAccountNumber());
		data.setIsProAccount(originalApplicationData.getAccounts().get(0).isIsProAccount());
		data.setBmoRelationship(new com.bmo.channel.pwob.model.onboarding.BmoRelationship(bmoRelationship.isIsApplicantExistingClient(), bmoRelationship.getBmoProduct(), bmoRelationship.getBmoAccountNumber()));
		data.setIirocMember(primaryParty.getRegulatoryDisclosures().isIirocMember());
		data.setIirocOrganization(primaryParty.getRegulatoryDisclosures().getIirocOrganization());
		data.setIsProAccount(originalApplicationData.getAccounts().get(0).isIsProAccount());
		data.setProvince(primaryParty.getContactInformation().getPrimaryAddress().getProvince());
		data.setAccountType(originalApplicationData.getAccounts().get(0).getAccountType());
				
		return data;
	}

}
