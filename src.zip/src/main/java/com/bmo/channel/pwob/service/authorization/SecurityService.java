package com.bmo.channel.pwob.service.authorization;

import java.util.Collection;

import com.bmo.channel.core.exception.ForbiddenSecurityException;
import com.bmo.channel.pwob.exception.PwobStatusException;

public interface SecurityService {
	/**
	 * Call to:
	 * <ul>
	 * <li>ensure that current user is authorized to perform action</li>
	 * <li>ensure that action to be performed is allowed</li>
	 * </ul>
	 * @param appStatus  application status of workflow, null if the action is one that is not workflow specific
	 * @param iaCode	 ia code of workflow, null if the action is one that is not iaCode specific
	 * @param action	 action to be performed
	 * @throws ForbiddenSecurityException if user is not authorized to perform action
	 * @throws PwobStatusException            if action is not allowed based on current appStatus
	 */
	void authorizeAction(String appStatus, String iaCode, PwobAction action);

	/**
	 * Call to ensure that current user is authorized to view workflows with the given SA.
	 * @throws ForbiddenSecurityException if user is not authorized to view IA code
	 * @param iaCode	 ia code of workflow
	 */
	void authorizeReadAccess(String iaCode);

	void authorizeReadAccessToAll(Collection<String> iaCodes);
}
