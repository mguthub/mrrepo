package com.bmo.channel.pwob.validation.taxation;

import java.util.List;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface TaxationValidator {

	boolean validateW8W9Form(Party party, List<Account> accounts, ValidationRequest request);
}