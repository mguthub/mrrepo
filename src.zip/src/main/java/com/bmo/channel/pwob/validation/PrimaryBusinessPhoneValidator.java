package com.bmo.channel.pwob.validation;

import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface PrimaryBusinessPhoneValidator {
	
	boolean validatePhoneNumber(ValidationRequest validationRequest);
	void addConstraintViolation(ValidationRequest validationRequest);
		

}
