package com.bmo.channel.pwob.model.onboarding;

import java.math.BigInteger;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author vvallia
 *
 */
public class RifPaymentDetails {
	public static final String METHOD_EFT = "EFT";
	public static final String METHOD_TRANSFER = "TFR";

	@ApiModelProperty(example="true", value="Whether to use spouse's age to calculate when payments should be made", dataType="boolean")
	private Boolean isSpouseAgeUsed;

	@ApiModelProperty(example="100", value="An integer amount for the payment", dataType="integer")
	private BigInteger amount;

	@ApiModelProperty(example="1", value="Amount type. 1: gross. 2: net", allowableValues="1,2")
	@ReferenceData(code=ErrorCodes.INVALID_AMOUNT_TYPE, type=ReferenceType.RIF_AMOUNT_TYPES)
	private String amountType;
	
	@ApiModelProperty(example="1", value="Valid values can be found in the reference service", allowableValues="1,2,3,4,5,6,7,8,9")
	@ReferenceData(code=ErrorCodes.INVALID_RIF_FREQUENCY, type=ReferenceType.RIF_PAYMENT_FREQUENCY_TYPES)
	private String frequency;
	
	@ApiModelProperty(example="1", dataType="int", value="Month of year to start payment", allowableValues="1-12")
	private BigInteger startMonth;
	
	@ApiModelProperty(example="1", value="Start year can be either Current Year or Following Year", allowableValues="1,2")
	private String startYear;
	
	@ApiModelProperty(example="1", value="When in month payment will be made", allowableValues="1,2")
	@ReferenceData(code=ErrorCodes.INVALID_WHEN_IN_MONTH, type=ReferenceType.RIF_MID_END_MONTH)
	private String whenInMonth;

	@ApiModelProperty(example="CHQ", value="Payment method", allowableValues="CHQ,TFR,EFT")
	@ReferenceData(code=ErrorCodes.INVALID_PAYMENT_METHOD, type=ReferenceType.RIF_PAYMENT_METHOD)
	private String method;

	private Boolean hasIncreasedWitholdingTax;

	@ApiModelProperty(example="1", value="Valid values can be found in the reference service", allowableValues="1,2,3")
	@ReferenceData(code=ErrorCodes.INVALID_WITH_HOLDING_TAX, type=ReferenceType.RIF_WITH_HOLDING_TAX)
	private String withHoldingTaxType;


	private BigInteger withHoldingTaxAmount;
	
	private BigInteger withHoldingQuebecTaxAmount;

	private BigInteger withHoldingTaxPercentage;
	
	private BigInteger withHoldingQuebecTaxPercentage;
	
	@ApiModelProperty(dataType = "String", example ="1",value="Whether to pay minimum or greater than minimum amount. Minimum: 1. Greater than minimum: 2", allowableValues="1,2") 
	private String greaterThanMinimumAmountType;

	private String transferAccountNumber;
	
	@ApiModelProperty(example="1", value="Valid values can be 1 or 2", allowableValues="1,2")
	private String nonRegisteredAccountSelectionType;


	@ApiModelProperty(dataType = "String", example ="John",value="Valid values are alphabetic(a-z, A-Z, space, hyphen, apostrophe), min size 2 and max size 20 ") 
	private String spouseElectionVerifiedByFirstName;
	@ApiModelProperty(dataType = "String", example ="Smith",value="Valid values are alphabetic(a-z, A-Z, space, hyphen, apostrophe), min size 2 and max size 20 ")
	private String spouseElectionVerifiedByLastName;
	@ApiModelProperty(example="1956-12-25", value="Format: YYYY-MM-DD")
	private String spouseElectionVerifiedDate;

	
	public String getNonRegisteredAccountSelectionType() {
		return nonRegisteredAccountSelectionType;
	}

	public void setNonRegisteredAccountSelectionType(String nonRegisteredAccountSelectionType) {
		this.nonRegisteredAccountSelectionType = nonRegisteredAccountSelectionType;
	}
	
	public Boolean getIsSpouseAgeUsed() {
		return isSpouseAgeUsed;
	}

	public void setIsSpouseAgeUsed(Boolean isSpouseAgeUsed) {
		this.isSpouseAgeUsed = isSpouseAgeUsed;
	}

	public BigInteger getAmount() {
		return amount;
	}

	public void setAmount(BigInteger amount) {
		this.amount = amount;
	}

	public String getAmountType() {
		return amountType;
	}

	public void setAmountType(String amountType) {
		this.amountType = amountType;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public BigInteger getStartMonth() {
		return startMonth;
	}

	public void setStartMonth(BigInteger startMonth) {
		this.startMonth = startMonth;
	}

	public String getStartYear() {
		return startYear;
	}

	public void setStartYear(String startYear) {
		this.startYear = startYear;
	}

	public String getWhenInMonth() {
		return whenInMonth;
	}

	public void setWhenInMonth(String whenInMonth) {
		this.whenInMonth = whenInMonth;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public Boolean getHasIncreasedWitholdingTax() {
		return hasIncreasedWitholdingTax;
	}

	public void setHasIncreasedWitholdingTax(Boolean hasIncreasedWitholdingTax) {
		this.hasIncreasedWitholdingTax = hasIncreasedWitholdingTax;
	}

	public String getWithHoldingTaxType() {
		return withHoldingTaxType;
	}

	public void setWithHoldingTaxType(String withHoldingTaxType) {
		this.withHoldingTaxType = withHoldingTaxType;
	}


	public BigInteger getWithHoldingTaxPercentage() {
		return withHoldingTaxPercentage;
	}

	public BigInteger getWithHoldingTaxAmount() {
		return withHoldingTaxAmount;
	}

	public void setWithHoldingTaxAmount(BigInteger withHoldingTaxAmount) {
		this.withHoldingTaxAmount = withHoldingTaxAmount;
	}

	public BigInteger getWithHoldingQuebecTaxAmount() {
		return withHoldingQuebecTaxAmount;
	}

	public void setWithHoldingQuebecTaxAmount(BigInteger withHoldingQuebecTaxAmount) {
		this.withHoldingQuebecTaxAmount = withHoldingQuebecTaxAmount;
	}

	public void setWithHoldingTaxPercentage(BigInteger withHoldingTaxPercentage) {
		this.withHoldingTaxPercentage = withHoldingTaxPercentage;
	}

	public BigInteger getWithHoldingQuebecTaxPercentage() {
		return withHoldingQuebecTaxPercentage;
	}

	public void setWithHoldingQuebecTaxPercentage(BigInteger withHoldingQuebecTaxPercentage) {
		this.withHoldingQuebecTaxPercentage = withHoldingQuebecTaxPercentage;
	}

	public String getGreaterThanMinimumAmountType() {
		return greaterThanMinimumAmountType;
	}

	public void setGreaterThanMinimumAmountType(String greaterThanMinimumAmountType) {
		this.greaterThanMinimumAmountType = greaterThanMinimumAmountType;
	}

	public String getTransferAccountNumber() {
		return transferAccountNumber;
	}

	public void setTransferAccountNumber(String transferAccountNumber) {
		this.transferAccountNumber = transferAccountNumber;
	}

	public String getSpouseElectionVerifiedDate() {
		return spouseElectionVerifiedDate;
	}

	public void setSpouseElectionVerifiedDate(String spouseElectionVerifiedDate) {
		this.spouseElectionVerifiedDate = spouseElectionVerifiedDate;
	}

	public String getSpouseElectionVerifiedByFirstName() {
		return spouseElectionVerifiedByFirstName;
	}

	public void setSpouseElectionVerifiedByFirstName(String spouseElectionVerifiedByFirstName) {
		this.spouseElectionVerifiedByFirstName = spouseElectionVerifiedByFirstName;
	}

	public String getSpouseElectionVerifiedByLastName() {
		return spouseElectionVerifiedByLastName;
	}

	public void setSpouseElectionVerifiedByLastName(String spouseElectionVerifiedByLastName) {
		this.spouseElectionVerifiedByLastName = spouseElectionVerifiedByLastName;
	}
}
