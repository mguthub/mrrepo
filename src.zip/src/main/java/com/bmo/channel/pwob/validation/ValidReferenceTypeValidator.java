package com.bmo.channel.pwob.validation;

import java.util.Arrays;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.bmo.channel.pwob.service.reference.ReferenceType;

/**
 * Validate that each type matches real {@link com.bmo.channel.pwob.service.reference.ReferenceType}. 
 * @author Ryan Chambers rcham02
 */
public class ValidReferenceTypeValidator implements ConstraintValidator<ValidReferenceType, Iterable<String>> {

	@Override
	public void initialize(ValidReferenceType constraintAnnotation) {
	}

	@Override
	public boolean isValid(Iterable<String> types, ConstraintValidatorContext context) {
		boolean valid = true;
		for (String type : types) {
			if(!isValidReferenceType(type)) {
				valid = false;
			}
		}

		return valid;
	}

	boolean isValidReferenceType(String type) {
		Optional<ReferenceType> refTypeO = Arrays.asList(ReferenceType.values()).stream().filter(refType -> refType.toString().equals(type)).findFirst();
		return refTypeO.isPresent();
	}
}
