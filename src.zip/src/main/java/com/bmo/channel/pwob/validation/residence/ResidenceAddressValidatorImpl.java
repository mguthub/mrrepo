package com.bmo.channel.pwob.validation.residence;

import java.util.Optional;
import java.util.Properties;

import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.Residence;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.util.Constants;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.AddressValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.field.FieldPathExtractor;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

/**
 * Validator that takes into consideration that secondary address is required if 
 * current address has been lived at for less than two years.
 * @author Ryan Chambers (rcham02)
 */
@Component
public class ResidenceAddressValidatorImpl extends AbstractBaseValidator implements ResidenceAddressValidator  {
	private static final String STREET_ADDRESS_FIELD_NAME = "streetAddress";
	private static final String PREVIOUS_RESIDENTIAL_ADDRESS_FIELD_NAME = "personal.residence.previousAddress";	
	private static final String LIVED_IN_LESS_THAN_2_YEARS = "livedInLessThanTwoYears";
	private static final String PRIMARY_ADDRESS_SOURCE = "primaryAddressSourceOption";
	private static final String UNIT_NUMBER_FIELD_NAME = "unitNumber";
	private static final String CITY_FIELD_NAME = "city";
	private static final String COUNTRY_FIELD_NAME = "country";
	private static final String POSTAL_CODE_FIELD_NAME = "postalCode";	

	@Autowired
	private FieldPathExtractor fieldPathExtractor;

	@Autowired private AddressValidator addressValidator;

	@Autowired private UsersService userService;

	@Autowired private PrimaryAddressValidator primaryAddressValidator;

	@Override
	public boolean validateResidenceAddress(Residence value, ValidationRequest request) {
		ApplicationLob lob = this.userService.currentUser().getLob();

		boolean valid = true;		

		if(PartyRole.JOINT_APPLICANT.equals(request.getPartyRole())){
			if(StringUtils.isEmpty(value.getPrimaryAddressSourceOption())){
				ValidationRequest primeValReq = request.createChildValidationRequest("personal.residence", "personal.residence");
				primeValReq.setErrorCode(ErrorCodes.INVALID_PRIMARY_ADDRESS_SOURCE);
				primeValReq.setFieldName(PRIMARY_ADDRESS_SOURCE);
				primeValReq.addConstraintViolation();				
				valid = false;
			}else if(Constants.OTHER_ADDR.equals(value.getPrimaryAddressSourceOption()) && !Optional.ofNullable(value.getPrimaryAddress()).isPresent()){
				Address primAddress = new Address();
				value.setPrimaryAddress(primAddress);
			}
			if(StringUtils.isNotEmpty(value.getAlternateAddressSourceOption())){
				valid = this.validateAlternateAddress(value, request) && valid;
			}
		}
		
		//validate Primary Address
		if(Optional.ofNullable(value.getPrimaryAddress()).isPresent()){		
			request.setIndex(null);
			valid = primaryAddressValidator.validatePrimaryAddress(value.getPrimaryAddress(), request) && valid;
		}

		if(PartyRole.PRIMARY_APPLICANT.equals(request.getPartyRole()) || PartyRole.TRADING_AUTHORITY.equals(request.getPartyRole())) {
			if(isPreviousAddressNotAllowedButSpecified(value, lob) || isPreviousAddressMandatoryAndNotSpecified(value, lob)) {
				ValidationRequest primValReq = request.createChildValidationRequest("personal.residence.primaryAddress", "personal.residence.primaryAddress");
				primValReq.setErrorCode(ErrorCodes.INVALID_FLAG_LIVED_IN_LESS_THAN_TWO_YEARS);
				primValReq.setFieldName(LIVED_IN_LESS_THAN_2_YEARS);
				primValReq.addConstraintViolation();				
				valid = false;
			}

			if(Optional.ofNullable(value.getPrimaryAddress()).isPresent() && 
					value.getPrimaryAddress().getLivedInLessThanTwoYears() != null && value.getPrimaryAddress().getLivedInLessThanTwoYears()) {
				Address previousResidentialAddress = value.getPreviousAddress();
				// if null, then by definition these fields are invalid
				if(previousResidentialAddress == null) {
					request.getContext().disableDefaultConstraintViolation();
					addPreviousAddressConstraintViolation(request.getContext(), STREET_ADDRESS_FIELD_NAME, ErrorCodes.INVALID_STREET_ADDR);
					addPreviousAddressConstraintViolation(request.getContext(), POSTAL_CODE_FIELD_NAME, ErrorCodes.INVALID_POSTAL_CODE);
					addPreviousAddressConstraintViolation(request.getContext(), CITY_FIELD_NAME, ErrorCodes.INVALID_CITY);
					addPreviousAddressConstraintViolation(request.getContext(), COUNTRY_FIELD_NAME, ErrorCodes.INVALID_COUNTRY);

					valid = false;
				} else {
					String fieldPath = fieldPathExtractor.determineFieldPath(request.getContext());
					if(StringUtils.isNoneBlank(previousResidentialAddress.getUnitNumber())) {
						valid = validateUnitNumber(request.getContext(), fieldPath, previousResidentialAddress) && valid;
					}
					valid = validateStreetAddress(request.getContext(), fieldPath, previousResidentialAddress) && valid;
					valid = validateCity(request.getContext(), fieldPath, previousResidentialAddress) && valid;
					valid = validateCountry(request.getContext(), fieldPath, previousResidentialAddress) && valid;

					if(previousResidentialAddress.getCountry().equals(RefDataValues.USA_COUNTRY_CODE)){
						request.setFieldValue(previousResidentialAddress.getPostalCode());
						valid = validatePostalCode(request.getContext(), fieldPath, previousResidentialAddress) && valid;
					}else if(previousResidentialAddress.getCountry().equals(RefDataValues.CANADA_COUNTRY_CODE)){
						valid = isValidCanadianPostalCode(previousResidentialAddress.getPostalCode())&& valid;
						if(!valid){
							addPreviousAddressConstraintViolation(request.getContext(), POSTAL_CODE_FIELD_NAME, ErrorCodes.INVALID_POSTAL_CODE);
							valid = false;
						}
					} 
				}
			}

			//Validate alternate address
			valid = this.validateAlternateAddress(value, request) && valid;
		}
		return valid;
	}

	private boolean validateAlternateAddress(Residence residence, ValidationRequest request) {
		boolean valid = true;
		ValidationRequest altAddrValReq = request.createChildValidationRequest("personal.residence.alternateAddress", "personal.residence.alternateAddress");
		
		boolean isAlternateAddressToBeValidated = false;
		if(PartyRole.PRIMARY_APPLICANT.equals(request.getPartyRole()) || PartyRole.TRADING_AUTHORITY.equals(request.getPartyRole())){
			if(Optional.ofNullable(residence.getHasAlternateAddress()).isPresent() && residence.getHasAlternateAddress()) {
				isAlternateAddressToBeValidated = true;
			}			
		}else if(PartyRole.JOINT_APPLICANT.equals(request.getPartyRole())){
				isAlternateAddressToBeValidated = true;
		}
		if(isAlternateAddressToBeValidated) {
			if(!Optional.ofNullable(residence.getAlternateAddress()).isPresent()) {
				addAlternateAddressConstraintViolation(altAddrValReq, "recipient", ErrorCodes.INVALID_RECIPIENT);
				addAlternateAddressConstraintViolation(altAddrValReq, STREET_ADDRESS_FIELD_NAME, ErrorCodes.INVALID_STREET_ADDR);				
				addAlternateAddressConstraintViolation(altAddrValReq, CITY_FIELD_NAME, ErrorCodes.INVALID_CITY);
				addAlternateAddressConstraintViolation(altAddrValReq, COUNTRY_FIELD_NAME, ErrorCodes.INVALID_COUNTRY);
				return false;
			}

			valid = addressValidator.validateUnitStreetCityPostalCountry(altAddrValReq, residence.getAlternateAddress());

			if(request.getLob().equals(ApplicationLob.nb)) {								
				altAddrValReq.setFieldValue(residence.getAlternateAddress().getRecipient());
				valid = addressValidator.validateRecipient(altAddrValReq) && valid;
			}
		}		
		return valid;
	}		

	boolean isPreviousAddressMandatoryAndNotSpecified(Residence residence, ApplicationLob lob) {
		return doesLobAllowPreviousAddressToBeSpecified(lob) && Optional.ofNullable(residence.getPrimaryAddress()).isPresent() && 
				residence.getPrimaryAddress().getLivedInLessThanTwoYears() == null;
	}

	boolean isPreviousAddressNotAllowedButSpecified(Residence residence, ApplicationLob lob) {
		boolean previousAddressAllowed = doesLobAllowPreviousAddressToBeSpecified(lob);
		if(!previousAddressAllowed && Optional.ofNullable(residence.getPrimaryAddress()).isPresent()) {
			// must not be specified			
			Boolean livedInLessThanTwoYears = residence.getPrimaryAddress().getLivedInLessThanTwoYears();
			return ! (livedInLessThanTwoYears == null || !livedInLessThanTwoYears);			
		}
		return false;
	}

	private boolean doesLobAllowPreviousAddressToBeSpecified(ApplicationLob lob) {		
		//return ApplicationLob.il == lob;
		//changed for BIL (assuming that it will work like PCD )
		return false;
	}

	private boolean validateCity(ConstraintValidatorContext context, String fieldPath, Address previousResidentialAddress) {
		return validateAndAddConstraintViolation(context, fieldPath, previousResidentialAddress.getCity(), CITY_FIELD_NAME, ErrorCodes.INVALID_CITY);
	}

	private boolean validateAndAddConstraintViolation(ConstraintValidatorContext context, String fieldPath, String value, String fieldName, String code) {
		boolean valid = StringUtils.isNotBlank(value) && validateField(context, fieldPath, fieldName, value, code);
		if(!valid) {
			addPreviousAddressConstraintViolation(context, fieldName, code);
		}
		return valid;
	}

	private boolean validatePostalCode(ConstraintValidatorContext context, String fieldPath, Address previousResidentialAddress) {
		return validateAndAddConstraintViolation(context, fieldPath, previousResidentialAddress.getPostalCode(), POSTAL_CODE_FIELD_NAME, ErrorCodes.INVALID_POSTAL_CODE);
	}

	private boolean validateStreetAddress(ConstraintValidatorContext context, String fieldPath, Address previousResidentialAddress) {
		return validateAndAddConstraintViolation(context, fieldPath, previousResidentialAddress.getStreetAddress(), STREET_ADDRESS_FIELD_NAME, ErrorCodes.INVALID_STREET_ADDR);
	}

	private boolean validateUnitNumber(ConstraintValidatorContext context, String fieldPath, Address previousResidentialAddress) {
		return validateField(context, fieldPath, UNIT_NUMBER_FIELD_NAME, previousResidentialAddress.getUnitNumber(), ErrorCodes.INVALID_UNIT_NUMBER);
	}
	
	private boolean validateCountry(ConstraintValidatorContext context, String fieldPath, Address previousResidentialAddress) {
		return validateAndAddConstraintViolation(context, fieldPath, previousResidentialAddress.getCountry(), COUNTRY_FIELD_NAME, ErrorCodes.INVALID_COUNTRY);
	}

	private boolean validateField(ConstraintValidatorContext context, String fieldPath, String fieldName,
			String fieldValue, String code) {
		String regex = validationRules.getProperty(fieldPath + "." + PREVIOUS_RESIDENTIAL_ADDRESS_FIELD_NAME + "." + fieldName);
		if(fieldValue != null && regex != null && !fieldValue.matches(regex)) {
			addPreviousAddressConstraintViolation(context, fieldName, code);
			return false;
		}
		return true;
	}

	private void addPreviousAddressConstraintViolation(ConstraintValidatorContext context, String fieldName, String code) {
		addConstraintViolation(context, fieldName, code, PREVIOUS_RESIDENTIAL_ADDRESS_FIELD_NAME);
	}

	private void addAlternateAddressConstraintViolation(ValidationRequest request, String fieldName, String code) {
		request.setErrorCode(code);
		request.setFieldName(fieldName);
		request.addConstraintViolation();		
	}

	private void addConstraintViolation(ConstraintValidatorContext context, String fieldName, String code,
			String parentPropertyNode) {
		ConstraintViolationBuilder builder = context.buildConstraintViolationWithTemplate(code);
		context.disableDefaultConstraintViolation();
		builder.addPropertyNode(parentPropertyNode).addPropertyNode(fieldName).addBeanNode();
		builder.addConstraintViolation();
	}

	@Override
	public void setValidationRules(Properties validationRules) {
		this.validationRules = validationRules;
	}	
}
