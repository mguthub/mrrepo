package com.bmo.channel.pwob.filter;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;

import com.bmo.channel.pwob.user.IvUserParser;
import com.bmo.channel.pwob.user.UserContextImpl;

/**
 * Put authenticated user's id into {@link org.slf4j.MDC} context for logging.
 * @author Ryan Chambers (rcham02)
 */
public class UserIdLoggerFilter implements Filter {

	private static final String NETWORK_ID = "networkId";

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
		throws IOException, ServletException {

		if(request instanceof HttpServletRequest) {
			HttpServletRequest servletRequest = (HttpServletRequest) request;
			String ivUser = servletRequest.getHeader(UserContextImpl.IV_USER_HEADER);
			
			//TO DO
			//In future we need to update parser for BIL
			
			if(!Optional.ofNullable(servletRequest.getHeader(UserContextImpl.X_BMO_BUSINESS_CATEGORY)).isPresent() && StringUtils.isNotBlank(ivUser)) {
				MDC.put(NETWORK_ID, new IvUserParser(ivUser).parse().getNetworkId());
			}
		}

		chain.doFilter(request, response);
	}

	@Override
	public void destroy() {
	}
}
