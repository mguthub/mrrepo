package com.bmo.channel.pwob.service.document;

import java.util.List;
import java.util.Optional;

import javax.ws.rs.BadRequestException;
import javax.xml.ws.Holder;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.exception.ExceptionUtils;
import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.product.Products;
import com.bmo.channel.pwob.service.applications.SavedApplicationsService;
import com.bmo.channel.pwob.service.authorization.PwobAction;
import com.bmo.channel.pwob.service.authorization.SecurityService;
import com.bmo.channel.pwob.service.documentpackages.DocumentPackagesService;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentPackageDto;
import com.bmo.channel.pwob.service.product.ProductService;
import com.bmo.channel.pwob.service.workflow.WorkflowService;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.channel.pwob.util.HubRequestHeaderBuilder.HeaderBuilder;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.swagger.client.model.APIError;
import io.swagger.client.model.GenerateFromApplicationRequest;
import net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.http.v1_0.OnboardApplicationPreparation;
import net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.types.v1_0.PrepareForDocGenRequest;
import net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.types.v1_0.PrepareForDocGenResponse;
import net.bmogc.xmlns.hub.cg.customerservice.prepfordocgen.types.v1_0.PrepareForDocGenRequestBody;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.ApplicationIntegrityException;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.InputViolationException;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.OnboardApplication;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.SystemException;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.AppStatus;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.CallerType;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.UnlockApplicationRequest;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.UnlockApplicationRequest.Body.PackageIds;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderResponse;


@Service
public class DocumentTrackerServiceImpl implements DocumentTrackerService {

	private static Logger logger = LoggerFactory.getLogger(DocumentTrackerServiceImpl.class);

	@Autowired
	private WorkflowService workflowService;
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private OnboardApplicationPreparation onboardApplicationPreparationService;
	
	@Autowired
	OnboardApplicationDocumentationEndpointInterface onboardApplicationDocumentationEndpointInterface;
	
	@Autowired
	private HubRequestComponent hubRequestComponent;
	
	@Autowired
	private UserContext userContext;
	
	@Autowired
	private DocumentPackagesService documentPackagesService; 

	@Autowired
	private OnboardApplication onboardApplicationHubClient;
	
	@Autowired
	protected ValidationManager validationManager;
	
	@Autowired
	protected SavedApplicationsService savedApplicationsService;
	
	@Autowired
	protected ProductService productService;
	
	protected static final String WIS_SERVICE_NAME = "WIS";
	protected static final String WIS_GET_WORKFLOW_FUNCTION = "GW";
	private static final String DEFAULT = "Default";

	@Override
	public Boolean generateDocumentPackages(final String workflowId) {
		Boolean documentTracker = Boolean.TRUE;
		SavedApplication savedApp = this.savedApplicationsService.retrieveSavedApplication(workflowId);
		
		if (savedApp.getAppStatus().equals(com.bmo.channel.pwob.model.onboarding.AppStatus.DOCUMENT_COLLECTION.toString())) {
			return documentTracker;
		} 
		
		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.GENERATE_DOCUMENTS);
		
		final RetrieveApplicationResponse response = workflowService.retrieveApplicationResponse(workflowId,savedApp.getCustomerId());
		
		if(!Optional.ofNullable(response.getBody().getPayload()).isPresent()) {
			logger.error("No workflow found for workflow id: "+workflowId);
			throw new NotFoundException("Workflow Not Found");
		}
			
		if (response.getBody().getAppStatus() != AppStatus.IN_PROGRESS) {
			logger.error("Action 'Generate documents' is not allowed with app status: "+response.getBody().getAppStatus()+
						"for worflow id: "+workflowId);
			throw ExceptionUtils.buildStatusExceptionForActionNotAllowedContext(PwobAction.GENERATE_DOCUMENTS.toString(), response.getBody().getAppStatus().toString());
		}
		
		final Application application = workflowService.deriveWorkflow(response, savedApp.getAppStatus());	
		Products products= productService.determineProductEligibilities(application);
		
		if(products == null){
			throw new WebServiceException("Eligible Product response is empty from server.");
		}
		
		validationManager.validateModel(application, Action.SUBMIT);
		
		try {
			validationManager.validateProduct(application.getAccounts(), products.getProductEligibilities());
	    	final PrepareForDocGenRequest req = new PrepareForDocGenRequest();
			final PrepareForDocGenRequestBody body = new PrepareForDocGenRequestBody();
			body.setApplicationId(workflowId);
			body.setApplicationDateTime(response.getBody().getLastUpdatedDateTime());
			req.setPrepareForDocGenRequestBody(body);

			HUBHeaderRequest requestHeader;
			final Holder<HUBHeaderResponse> responseHeader = new Holder<>();
    	
    		requestHeader = createRequestHeader("prepareForDocGen", workflowId,null,null,savedApp.getCustomerId());
    		final PrepareForDocGenResponse docGenResponse = onboardApplicationPreparationService.prepareForDocGen(req, requestHeader, responseHeader);
    		
    		onboardApplicationDocumentationEndpointInterface.generateFromApplication(createGenerateFromApplicationRequest(workflowId, docGenResponse), generateHeaderString(createHeader()));
    		
		} catch (BadRequestException ex) {
    		logger.error("Error generated for application id"+application.getApplicationId()+" ", ex);
    		throw new BadRequestException(ex.getMessage(), ex.getResponse());
		} catch (JsonProcessingException ex) {
			logger.error("Failure in JSON processing during Document Generation for workflow id: ",workflowId, ex);
			throw new WebServiceException(ex);
		} catch (javax.ws.rs.InternalServerErrorException ise) {
			ExceptionUtils.throwDocumentServiceException(ise);
		} catch (Exception ex) {
    		logger.error("Failed to generate document packages for workflow id: ",workflowId, ex);
    		ExceptionUtils.throwGenerateDocumentPackagesErrors(ex);
    	}
		
		return documentTracker;
	}	

	@Override
	public void unlock(String workflowId) {
		SavedApplication savedApp = this.savedApplicationsService.retrieveSavedApplication(workflowId);

		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.UNLOCK_DATA);
		PackageIds packageIds = new PackageIds();
		String packageId = null;

		try {
			List<DocumentPackageDto> packages = documentPackagesService.retrieveDocumentPackages(workflowId, true);
			if(CollectionUtils.isNotEmpty(packages)) {
				for(DocumentPackageDto docPackage: packages) {
					packageIds.getPackageId().add(docPackage.getId());
					if(packageId == null) {
						packageId = docPackage.getId().concat(",");
					}
					else {
						packageId = packageId.concat(",").concat(docPackage.getId());
					}
				}
			}
		} catch(NotFoundException e) {
			logger.warn("No document package ids found for workflow " + workflowId);
		}

		String requestorId = this.userContext.getAuthenticatedUser().getUserId();
		UnlockApplicationRequest unlockApplicationRequest = new UnlockApplicationRequest();		
		UnlockApplicationRequest.Body body = new UnlockApplicationRequest.Body();
		body.setApplicationID(workflowId);
		body.setRequestorId(requestorId);
		body.setPackageIds(packageIds);
		body.setCallerType(CallerType.OWM);
		unlockApplicationRequest.setBody(body);

		try {
			onboardApplicationHubClient.unlockApplication(unlockApplicationRequest, createHubHeader("UnlockApplication", 
					workflowId, packageId, null, savedApp.getCustomerId()),
					new Holder<>());
		} 		
		catch (SystemException e) {			
			logger.error("Failure in OnboardApplication HUB while processing unlock request",unlockApplicationRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnboardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}  catch (InputViolationException e) {
			logger.error("Failure in OnboardApplication HUB while processing unlock request",unlockApplicationRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnboardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}  catch (ApplicationIntegrityException e) {
			logger.error("Failure in OnboardApplication HUB while processing unlock request",unlockApplicationRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnboardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}
	}

    private HUBHeaderRequest createHubHeader(String function, String workflowId,String packageId,String documentId,String ecifId) {
        return hubRequestComponent.getHubBuilder()
                .originatorResource("OnboardApplication")
                .originatorResourceFunction(function)
                .partyId(ecifId)
                .packageId(packageId)
                .workflowId(workflowId)
                .build();
    }

	private HUBHeaderRequest createRequestHeader(final String resourceFunction, String workflowId,String packageId,String documentId,String ecifId) {
		HeaderBuilder headerBuilder = hubRequestComponent.getHubBuilder()
			.originatorResource("documentTrackingService")
			.originatorResourceFunction(resourceFunction)
			.workflowId(workflowId)
			.packageId(packageId)
			.documentId(documentId)
			.partyId(ecifId);
		
		if ("prepareForDocGen".equals(resourceFunction)) { // For the preparation call domain part is not required.
			final String userId = userContext.getAuthenticatedUser().getNetworkId();
			headerBuilder.userId(userId);
		}
		
		return headerBuilder.build();
	}
	
	private GenerateFromApplicationRequest createGenerateFromApplicationRequest(String workflowId, PrepareForDocGenResponse prepareForDocGenResponse) {
		GenerateFromApplicationRequest request = new GenerateFromApplicationRequest();		
		request.setApplicationID(workflowId);
		request.setLanguage(DEFAULT);
		request.setApplDateTime(prepareForDocGenResponse.getPrepareForDocGenResponseBody().getPrepareForDocGenResponse().getLastUpdatedDateTime().toString());
		return request;
	}
	
	private HUBHeaderRequest createHeader() {
		return hubRequestComponent
				.getHubBuilder()
				.originatorResource("OnboardApplicationDocumentation")
				.originatorResourceFunction("generateForm")
				.build();
	}
	
	String generateHeaderString(final HUBHeaderRequest requestHeader) throws JsonProcessingException {
		return ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
	}	
}
