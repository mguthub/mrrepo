package com.bmo.channel.pwob.service.reference.mapping;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;

import com.bmo.channel.pwob.model.reference.OccupationReference;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.model.DataAndMapping;
import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.PropertyType;
import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.ValueType;

public class OccupationMapper extends AbstractBaseReferenceMapper {

	@Override
	public List<Reference> mapToReferenceListEN(DataAndMapping dataAndMapping) {
		List<Reference> list = dataAndMapping.getReferenceData().stream()
				.map(v -> {
					OccupationReference reference = new OccupationReference(toReference(v));
					if(isExpiredData(v)) {
						reference.setExpired(Boolean.TRUE);
					}
					reference.setPoliticallyExposedOccupation(isPoliticallyExposedOccupation(v));
					return reference;
				}
		).collect(Collectors.toList());
		return new DuplicatesFilter().filterOutDuplicates(list);
	}

	private boolean isPoliticallyExposedOccupation(ValueType value) {
		if (value.getProperties() != null && value.getProperties().getProperty() != null && CollectionUtils.isNotEmpty(value.getProperties().getProperty())) {
			for(PropertyType prop: value.getProperties().getProperty()) {
				if (PEP_FLAG_PROPERTY.equals(prop.getName())) {
					if (prop.getContent().contains(IS_PEP_FLAG)) {
						return true;
					}
					break;
				}
			}
		}
		return false;
	}

	@Override
	public List<Reference> mapToReferenceListFR(DataAndMapping dataAndMapping) {

		List<Reference> list = dataAndMapping.getReferenceData().stream()
				.map(v -> {
					OccupationReference reference = new OccupationReference(toReferenceFR(v));
					if(isExpiredData(v)) {
						reference.setExpired(Boolean.TRUE);
					}
					reference.setPoliticallyExposedOccupation(isPoliticallyExposedOccupation(v));
					return reference;
				}
		).collect(Collectors.toList());
		return new DuplicatesFilter().filterOutDuplicates(list);
	
	}
}
