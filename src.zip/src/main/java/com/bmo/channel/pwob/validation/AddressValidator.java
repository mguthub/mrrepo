package com.bmo.channel.pwob.validation;

import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface AddressValidator {
	static final String UNIT_NUMBER_FIELD_NAME = "unitNumber";
	static final String STREET_ADDRESS_FIELD_NAME = "streetAddress";
	static String CITY_FIELD_NAME = "city";	
	static final String POSTAL_CODE_FIELD_NAME = "postalCode";
	static final String RECIPIENT_FIELD_NAME = "recipient";
	
	boolean validatePostalCode(ValidationRequest validationRequest);
	boolean validateStreetAddress(ValidationRequest validationRequest);
	boolean validateUnitNumber(ValidationRequest validationRequest);
	boolean validateCity(ValidationRequest validationRequest);
	boolean validateCountry(ValidationRequest validationRequest);	
	boolean validateRecipient(ValidationRequest request);
	boolean validateUnitStreetCityPostalCountry(ValidationRequest request, Address address);
}
