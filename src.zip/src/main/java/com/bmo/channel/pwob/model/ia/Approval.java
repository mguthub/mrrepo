package com.bmo.channel.pwob.model.ia;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

public class Approval {
	
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<Comment> comments;
	
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private List<Approver> approvers;
	
	private String documentEdits;

	public List<Comment> getComments() {
		return comments;
	}

	public void setComments(List<Comment> comments) {
		this.comments = comments;
	}

	public List<Approver> getApprovers() {
		return approvers;
	}

	public void setApprovers(List<Approver> approvers) {
		this.approvers = approvers;
	}

	public String getDocumentEdits() {
		return documentEdits;
	}

	public void setDocumentEdits(String documentEdits) {
		this.documentEdits = documentEdits;
	}

}
