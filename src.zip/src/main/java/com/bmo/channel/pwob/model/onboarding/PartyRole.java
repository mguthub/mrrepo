package com.bmo.channel.pwob.model.onboarding;

/**
 * List of Party Roles
 */
public enum PartyRole {
	PRIMARY_APPLICANT, 
	JOINT_APPLICANT,
	TRADING_AUTHORITY;
	
}
