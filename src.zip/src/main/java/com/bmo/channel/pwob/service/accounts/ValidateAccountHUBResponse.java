/**
 * 
 */
package com.bmo.channel.pwob.service.accounts;

/**
 * @author vvallia
 *
 */
public class ValidateAccountHUBResponse {
	
	private ValidateAccountResponseBody validateAccountResponseBody;

	public ValidateAccountResponseBody getValidateAccountResponseBody() {
		return validateAccountResponseBody;
	}

	public void setValidateAccountResponseBody(ValidateAccountResponseBody validateAccountResponseBody) {
		this.validateAccountResponseBody = validateAccountResponseBody;
	}
	
}
