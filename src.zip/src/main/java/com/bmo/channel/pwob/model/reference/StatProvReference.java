package com.bmo.channel.pwob.model.reference;

public class StatProvReference extends Reference{
	String isoCode;

	public StatProvReference() {

	}

	public StatProvReference(String code, String label) {
		super(code, label);
	}
	
	public StatProvReference(String code, String label, String isoCode) {
		super(code, label);
		this.isoCode = isoCode;
	}
	
	public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((isoCode == null) ? 0 : isoCode.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		StatProvReference other = (StatProvReference) obj;
		if (isoCode == null) {
			if (other.isoCode != null)
				return false;
		} else if (!isoCode.equals(other.isoCode))
			return false;
		return true;
	}
}
