package com.bmo.channel.pwob.service.product.rsclient;

import java.util.List;

public class AccountList {

    protected List<AccountType> accountType;
    protected AccountList.AgeRejection ageRejection;

    public List<AccountType> getAccountType() {
		return accountType;
	}
	public void setAccountType(List<AccountType> accountType) {
		this.accountType = accountType;
	}

	public AccountList.AgeRejection getAgeRejection() {
		return ageRejection;
	}
	public void setAgeRejection(AccountList.AgeRejection ageRejection) {
		this.ageRejection = ageRejection;
	}

	public static class AgeRejection {
        protected String code;
        protected String message;
		public String getCode() {
			return code;
		}
		public void setCode(String code) {
			this.code = code;
		}
		public String getMessage() {
			return message;
		}
		public void setMessage(String message) {
			this.message = message;
		}
    }
}