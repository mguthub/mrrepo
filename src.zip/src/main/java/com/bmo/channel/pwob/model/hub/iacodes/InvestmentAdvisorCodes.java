package com.bmo.channel.pwob.model.hub.iacodes;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class InvestmentAdvisorCodes {

	private List<InvestmentAdvisorCode> investmentAdvisorCode;

	@JsonProperty("ns3:investmentAdvisorCode")
	public List<InvestmentAdvisorCode> getInvestmentAdvisorCode() {
		return investmentAdvisorCode;
	}

	public void setInvestmentAdvisorCode(
			List<InvestmentAdvisorCode> investmentAdvisorCode) {
		this.investmentAdvisorCode = investmentAdvisorCode;
	}

}
