package com.bmo.channel.pwob.service.reference;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.reference.OccupationReference;
import com.bmo.channel.pwob.model.reference.Reference;

public interface ReferencesService {
	Map<ReferenceType, List<Reference>> all(UILocale locale);
	List<Reference> ofType(ReferenceType type,UILocale locale);

	Map<ReferenceType, List<Reference>> ofTypes(Set<ReferenceType> referenceTypes,UILocale locale);
	OccupationReference getOccupationReferences(String code);
	boolean isValidCodeForType(String code, ReferenceType refType);
}
