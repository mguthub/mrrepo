package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

import javax.validation.Valid;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.HasPreferredName;
import com.bmo.channel.pwob.validation.LuhnCheck;
import com.bmo.channel.pwob.validation.reference.ReferenceData;
import com.bmo.channel.pwob.validation.reference.ReferenceListData;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@HasPreferredName
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Identity {	

	@ApiModelProperty(example="abc123@bmo.com")
	private String primaryEmailAddress;

	@ApiModelProperty(example="046454286", value="Must pass a LuhnCheck")
	@LuhnCheck(message=ErrorCodes.INVALID_SIN)
	private String socialInsuranceNumber;

	@ApiModelProperty(example="1955-12-25", value="Format: YYYY-MM-DD")
	private String dateOfBirth;
	
	/**
	 * {@link SpecifiesSpouse} enforces maritalStatus being populated
	 */
	@ApiModelProperty(example="100001", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.MARITAL_STATUSES, code=ErrorCodes.INVALID_MARITAL_STATUS)
	private String maritalStatus;
	
	@Valid
	private Boolean hasDependents;
	
	@ApiModelProperty(value="Only populate if the Joint applicant is Spouse")
	private Boolean areDependentsSameAsSpouse;
	
	
	@ApiModelProperty(value="Only populate if hasDependents is true")
	private Integer numOfDependents;
	
	/**
	 * {@link HasPreferredName} enforces preferredLanguage being populated
	 */
	@ReferenceData(type = ReferenceType.LANGUAGES, code = ErrorCodes.INVALID_PREFERRED_LANGUAGE)
	private String preferredLanguage;

	private Boolean hasPreferredName;	

	@ApiModelProperty(required=true)
	@Valid
	private Name legalName = new Name();

	@ApiModelProperty(value="Only populate if hasPreferredName is true")
	@Valid
	private Name preferredName;

	@ApiModelProperty(example="100000", value="Valid values can be found in the reference service")
	@ReferenceListData(type=ReferenceType.COUNTRIES, code=ErrorCodes.INVALID_COUNTRY)
	private List<String> citizenships;

	public String getPrimaryEmailAddress() {
		return primaryEmailAddress;
	}

	public void setPrimaryEmailAddress(String primaryEmailAddress) {
		this.primaryEmailAddress = primaryEmailAddress;
	}

	public String getSocialInsuranceNumber() {
		return socialInsuranceNumber;
	}

	public void setSocialInsuranceNumber(String socialInsuranceNumber) {
		this.socialInsuranceNumber = socialInsuranceNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public Boolean getHasDependents() {
		return hasDependents;
	}

	public void setHasDependents(Boolean hasDependents) {
		this.hasDependents = hasDependents;
	}

	public Integer getNumOfDependents() {
		return numOfDependents;
	}

	public void setNumOfDependents(Integer numOfDependents) {
		this.numOfDependents = numOfDependents;
	}

	public String getPreferredLanguage() {
		return preferredLanguage;
	}

	public void setPreferredLanguage(String preferredLanguage) {
		this.preferredLanguage = preferredLanguage;
	}

	public Boolean getHasPreferredName() {
		return hasPreferredName;
	}

	public void setHasPreferredName(Boolean hasPreferredName) {
		this.hasPreferredName = hasPreferredName;
	}

	public Name getLegalName() {
		return legalName;
	}

	public void setLegalName(Name legalName) {
		this.legalName = legalName;
	}

	public Name getPreferredName() {
		return preferredName;
	}

	public void setPreferredName(Name preferredName) {
		this.preferredName = preferredName;
	}

	public List<String> getCitizenships() {
		return citizenships;
	}
	public void setCitizenships(List<String> citizenships) {
		this.citizenships = citizenships;
	}
	
	public Boolean getAreDependentsSameAsSpouse() {
		return areDependentsSameAsSpouse;
	}

	public void setAreDependentsSameAsSpouse(Boolean areDependentsSameAsSpouse) {
		this.areDependentsSameAsSpouse = areDependentsSameAsSpouse;
	}
}
