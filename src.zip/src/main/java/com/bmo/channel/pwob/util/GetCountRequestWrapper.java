package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.ByAccess;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.ByStatus;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetCountRequestWrapper {

    @JsonProperty("Body")
    protected Body body;

    /**
     * Gets the value of the body property.
     *
     * @return
     *     possible object is
     *     {@link Body }
     *
     */
    public Body getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     *
     * @param value
     *     allowed object is
     *     {@link Body }
     *
     */
    public void setBody(Body value) {
        this.body = value;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class Body {

        protected ByAccess byAccess;
        protected ByStatus byStatus;

        /**
         * Gets the value of the byAccess property.
         *
         * @return
         *     possible object is
         *     {@link ByAccess }
         *
         */
        public ByAccess getByAccess() {
            return byAccess;
        }

        /**
         * Sets the value of the byAccess property.
         *
         * @param value
         *     allowed object is
         *     {@link ByAccess }
         *
         */
        public void setByAccess(ByAccess value) {
            this.byAccess = value;
        }

        /**
         * Gets the value of the byStatus property.
         *
         * @return
         *     possible object is
         *     {@link ByStatus }
         *
         */
        public ByStatus getByStatus() {
            return byStatus;
        }

        /**
         * Sets the value of the byStatus property.
         *
         * @param value
         *     allowed object is
         *     {@link ByStatus }
         *
         */
        public void setByStatus(ByStatus value) {
            this.byStatus = value;
        }

    }

}

