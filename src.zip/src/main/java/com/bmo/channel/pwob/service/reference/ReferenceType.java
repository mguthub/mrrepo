package com.bmo.channel.pwob.service.reference;

import com.bmo.channel.pwob.service.reference.mapping.CodeAndValueMapper;
import com.bmo.channel.pwob.service.reference.mapping.CodeAndValueMapperForEligibleProperty;
import com.bmo.channel.pwob.service.reference.mapping.OccupationMapper;
import com.bmo.channel.pwob.service.reference.mapping.ReferenceMapper;
import com.bmo.channel.pwob.service.reference.mapping.RisEcifMapper;
import com.bmo.channel.pwob.service.reference.mapping.RisEcifMapperForLIFProvince;
import com.bmo.channel.pwob.service.reference.mapping.RisEcifMapperForLIRAProvince;
import com.fasterxml.jackson.annotation.JsonValue;

public enum ReferenceType {
	TITLES("titles"),
	COUNTRIES("countries"),
	PROVINCE_CODES("provinces"),
	EMPLOYMENT_STATUSES("employmentStatuses", "RIS.TB_EMP_STAT", "ES.RIS.EMPLOYMENT_TP_CD.STANDARD", RisEcifMapper.class),
	MARITAL_STATUSES("maritalStatuses"),
	MARITAL_STATUS_CODES("maritalStatusCodes"),
	ACCOUNT_TYPES("accountTypes"),
	ACCOUNT_USES("accountUses", "RIS.TB_ACC_USE", CodeAndValueMapper.class),
	ACCOUNT_SUBTYPES("accountSubTypes","RIS.TB_ACCTYP",CodeAndValueMapper.class),	
	OPTION_TYPES("optionTypes"),
	OPTION_TYPE_EXPERIENCES("optionsTypeExperiences"),
	OPTIONS_KNOWLEDGE("optionsKnowledge"),
	WEALTH_SOURCES("wealthSources","RIS.TB_WEALTH_SOURCE",CodeAndValueMapper.class),
	INCOME_SOURCES("incomeSources", "RIS.TB_INCOME_SRC", "ES.RIS.INCOME_SOURCE_CD.STANDARD", RisEcifMapper.class),
	INVESTMENT_EXPERIENCE("investmentExperience","RIS.TB_PWOB_INVESTMENT_EXPERIENCE", CodeAndValueMapper.class),
	INVESTMENT_KNOWLEDGE("investmentKnowledge","RIS.TB_EXP", CodeAndValueMapper.class),
	INVESTMENT_OBJECTIVES("investmentObjectives", "RIS.TB_INVESTOR_PROFILE", CodeAndValueMapper.class),
	INVESTMENT_TIME_HORIZONS("investmentTimeHorizons", "RIS.TB_IIROC_TIME_HORIZON", CodeAndValueMapper.class),
	IIROC_ORGANIZATIONS("iirocOrganizations"),
	RECEIVE_SECURITY_HOLDER_OPTIONS("receiveSecurityHolderOptions"),
	OCCUPATIONS_TYPES("occupationTypes", "RIS.TB_EMP", OccupationMapper.class),
	BMO_COMPANY_CODES("bmoCompanyCodes","RIS.TB_BMOEMP","ES.RIS.EMPLOYEE_ROLE_CD.STANDARD",RisEcifMapper.class),
	BUSINESS_NATURES("businessNatures", "RIS.TB_AML_INDUSTRY", "ES.RIS.BUSINESS_NATURE_CATEGORY_CD.STANDARD", RisEcifMapper.class),
	LINK_ACCOUNT_TYPES("linkAccountTypes", "RIS.TB_PWOB_IL_LINK_ACCOUNT_TYPE", CodeAndValueMapper.class),
	ID_VERIFICATION_METHODS("idVerificationMethods","RIS.TB_IDENTIFICATION_METHOD",CodeAndValueMapper.class),
	LANGUAGES("languages"),
	DOCUMENT_TYPES("documentTypes","RIS.TB_PWOB_DOCUMENTTP","ES.RIS.PWOB_DOCUMENTTP.STANDARD", CodeAndValueMapper.class),
	TIME_UNITS("timeUnits"),
	REFERRAL_SOURCES("referralSources"),
	PAYMENT_TYPES("paymentTypes"),	
	JURISDICTION_TYPES("jurisdictionTypes","RIS.TB_PWOB_LIRA_JURISDICTION", CodeAndValueMapper.class),
	LIRA_PROVINCE_CODES("liraProvinces", "RIS.TB_PROVSTAT","ES.RIS.PROV_STATE_CD.STANDARD",RisEcifMapperForLIRAProvince.class),
	LIF_PROVINCE_CODES("lifProvinces","RIS.TB_PROVSTAT","ES.RIS.PROV_STATE_CD.STANDARD",RisEcifMapperForLIFProvince.class),
	DOCUMENT_PREFERENCE_OPTIONS("documentPreferenceOptions"),
	APPLICATION_STATUS("appStatus"),
	FEE_TYPES("feeType"),
	RIF_AMOUNT_TYPES("rifAmountType", "RIS.TB_PWOB_RIF_AMOUNT_TYPE", CodeAndValueMapper.class),
	RIF_PAYMENT_AMOUNT_TYPES("rifPaymentAmountType","RIS.TB_PWOB_RIF_PAYMENT_AMOUNT_TYP",CodeAndValueMapper.class),
	RIF_PAYMENT_METHOD("rifPaymentMethod", "RIS.TB_PWOB_RIF_PAYMENT_METHOD", CodeAndValueMapper.class),
	RIF_MID_END_MONTH("rifMidEndMonth", "RIS.TB_PWOB_RIF_PAYMENT_MONTH", CodeAndValueMapper.class),
	RIF_WITH_HOLDING_TAX("rifWithHoldingTax"),
	RIF_PAYMENT_FREQUENCY_TYPES("rifPaymentFrequencyTypes","RIS.TB_PWOB_PAYMENT_FREQUENCY", CodeAndValueMapper.class),
	EFT_PAYMENT_FREQUENCY_TYPES("eftPaymentFrequencyTypes"),
	RIF_START_MONTH("rifStartMonth", "RIS.TB_PWOB_MONTH", CodeAndValueMapper.class),
	LIF_START_YEAR("lifStartYear","RIS.TB_PWOB_PAYMENT_FREQUENCY_START_YEAR_TYP", CodeAndValueMapper.class),
	LIF_PAYMENT_AMOUNT_TYPES("lifPaymentAmountType","RIS.TB_PWOB_PAYMENT_AMOUNT_TYP", CodeAndValueMapperForEligibleProperty.class),
	TAX_ID_MISSING_REASON("taxIdentificationNumberMissingReason", "RIS.TB_MISSING_TAX_ID", CodeAndValueMapper.class),
	BENEFICIAL_OWNER_COUNTRY_REASON("beneficialOwnerCountryReason","RIS.TB_PWOB_COUNTRY_REASON",CodeAndValueMapper.class),
	POLITICALLY_EXPOSED_PERSON_TYPE("politicallyExposedPersonType", "RIS.TB_PWOB_PEP_TYPE", CodeAndValueMapper.class),
	SOURCE_OF_ADDRESS("sourceOfAddress", "RIS.TB_PWOB_ADDRESS_SOURCE", CodeAndValueMapper.class),
	BMO_CLIENT_RELATIONSHIP_TYPE("bmoClientRelationshipType", "RIS.TB_PWOB_BMO_CLIENT_REL_TP",CodeAndValueMapper.class);

	private String label;
	private String dataRefCode;
	private String mappingRefCode;
	private Class<? extends ReferenceMapper> mapperClass;

	ReferenceType(String label) {
		this.label = label;
	}

	ReferenceType(String label, String refCode, Class<? extends ReferenceMapper> mapperClass) {
		this.label = label;
		this.dataRefCode = refCode;
		this.mappingRefCode = null;
		this.mapperClass = mapperClass;
	}
	
	ReferenceType(String label, String dataRefCode, String mappingRefCode, Class<? extends ReferenceMapper> mapperClass) {
		this.label = label;
		this.dataRefCode = dataRefCode;
		this.mappingRefCode = mappingRefCode;
		this.mapperClass = mapperClass;
	}

	public String getLabel() {
		return label;
	}
	
	@JsonValue
	public String toString() {
		return label;
	}

	public String getDataRefCode() {
		return dataRefCode;
	}
	
	public String getMappingRefCode() {
		return mappingRefCode;
	}
	
	public Class<? extends ReferenceMapper> getReferenceMapper() {
		return mapperClass;
	}
}
