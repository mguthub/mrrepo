package com.bmo.channel.pwob.model.onboarding;

import java.util.ArrayList;
import java.util.List;

import javax.validation.constraints.Min;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.bmo.channel.pwob.validation.reference.ReferenceListData;

import io.swagger.annotations.ApiModelProperty;

public class OptionsTrading {
	
	@ApiModelProperty(example="['long_calls_puts','covered']", value="Valid values can be found in the reference service")
	@ReferenceListData(code=ErrorCodes.INVALID_ACCOUNT_OPTION_TYPE_EXPERIENCES, type=ReferenceType.OPTION_TYPE_EXPERIENCES)
	private List<String> optionTypeExperiences=new ArrayList<>();
	
	@ApiModelProperty(example="['expert','knowledgeable']", value="Valid values can be found in the reference service")
	@ReferenceListData(code=ErrorCodes.INVALID_ACCOUNT_OPTION_TYPES, type=ReferenceType.OPTION_TYPES)
	private List<String> optionTypes=new ArrayList<>(); 
	
	@Min(0) 
	private Integer experienceInYears;
	
	@DataValidationPattern(code=ErrorCodes.INVALID_ACCOUNT_KNOWLEDGE)
	private String knowledge;
	

	public List<String> getOptionTypeExperiences(){
		return optionTypeExperiences;
	}
	public void setOptionTypeExperiences(List<String> optionTypeExperiences){
		this.optionTypeExperiences=optionTypeExperiences;
	}
	
	public List<String> getOptionTypes(){
		return optionTypes;
	}
	public void setOptionTypes(List<String> optionTypes){
		this.optionTypes=optionTypes;
	}
	
	public Integer getExperienceInYears(){
		return experienceInYears;
	}
	public void setExperienceInYears(Integer experienceInYears){
		this.experienceInYears=experienceInYears;
	}
	
	public String getKnowledge(){
		return knowledge;
	}
	public void setKnowledge(String knowledge){
		this.knowledge=knowledge;
	}
}
