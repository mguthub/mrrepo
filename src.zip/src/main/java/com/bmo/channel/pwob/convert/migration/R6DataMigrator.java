package com.bmo.channel.pwob.convert.migration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.pwob.config.HubServicesConfig;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;

@Component
@Order(value=3)
public class R6DataMigrator implements ApplicationMigrator {
	
	private static Logger logger = LoggerFactory.getLogger(R6DataMigrator.class);
	
	@Autowired
	private EventManager eventManager;

	@Override
	public void migrateApplication(Application application, FeatureFlags featureFlags) {
		// clear release from metadata
		application.getClientMetadata().remove(Application.RELEASE_METADATA_KEY);
		application.setRelease(Application.RELEASE_VERSION_6);
	}

	@Override
	public boolean isMigrationRequired(Application application, FeatureFlags featureFlags) {
		String release = application.getRelease();
		if(isReleaseDifferent(release)) {
			eventManager.publishWarn(String.format("Migrating application %s because release version is %s", application.getApplicationId(), release));
			return true;
		} else {
			return false;
		}
	}

	private boolean isReleaseDifferent(String release) {
		// this logic may need to change in the future, because
		// if application version is say, 6, then this will return true, even though the R5 migration should not be run
		try {
			Integer iRel = Integer.valueOf(release);
			return iRel <= 5;
		} catch(NumberFormatException ex) {
			return true;
		}
	}
}
