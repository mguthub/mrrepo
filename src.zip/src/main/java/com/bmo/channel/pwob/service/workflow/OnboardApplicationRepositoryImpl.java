package com.bmo.channel.pwob.service.workflow;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.exception.ExceptionUtils;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentPackageDto;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.channel.pwob.util.PwobHeaderInfo;

import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.ApplicationIntegrityException;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.InputViolationException;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.OnboardApplication;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication._interface.v1.SystemException;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.AppStatus;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.CallBPMLock;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.CallerType;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.CancelApplicationRequest;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.CancelApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationRequest;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveApplicationRequest;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveRelationshipRequest;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveRelationshipResponse;
import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

@Component
public class OnboardApplicationRepositoryImpl implements OnboardApplicationRepository {
	private static Logger logger = LoggerFactory.getLogger(OnboardApplicationRepositoryImpl.class);	

	private static final String SUCCESS_ACCOUNT_SETUP_CODE = "0";
	private static final String FAILURE_STRING = "Failure";

	@Autowired
	private OnboardApplication onboardApplicationHubClient;

	@Autowired
	private PwobHeaderInfo headerInfo;

	@Autowired
	private HubRequestComponent hubRequestComponent;

	@Autowired
	private UserContext userContext;

	@Override
	public SaveApplicationResponse save(SaveApplicationRequest saveApplicationRequest, String ecifId) {
		HUBHeaderRequest requestHeader = buildHUBHeaderRequest(OnboardApplicationRepository.FUNCTION_SAVE, 
				saveApplicationRequest.getBody().getApplicationID(),
				ecifId);
		return save(saveApplicationRequest, requestHeader);
	}

	@Override
	public SaveApplicationResponse save(SaveApplicationRequest saveApplicationRequest, HUBHeaderRequest requestHeader) {
		try {
			SaveApplicationResponse response = onboardApplicationHubClient.saveApplication(saveApplicationRequest, requestHeader, new Holder<>());

			if(!Optional.ofNullable(response).isPresent() || !Optional.ofNullable(response.getBody()).isPresent()) {
				logger.warn("HUB save application response: "+response.getBody().toString());
				throw new WebServiceException("HUB Save Application response is null.");
			}

			if (Optional.ofNullable(response.getBody()).isPresent() && !Optional.ofNullable(response.getBody().getSuccess()).isPresent()) {
				logger.warn("HUB save application success property: "+response.getBody().toString());
				throw new WebServiceException(response.getBody().toString());
			}
			
			return response;
		} 
		catch (SystemException  e) {
			logger.error("Failure in OnboardApplication HUB while processing save request",saveApplicationRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}
		catch (InputViolationException  e) {
			logger.error("Failure in OnboardApplication HUB while processing save request",saveApplicationRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		} catch (ApplicationIntegrityException  e) {
			logger.error("Failure in OnboardApplication HUB while processing save request",saveApplicationRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		} 
	}

	@Override
	public RetrieveApplicationResponse retrieve(String applicationID, HUBHeaderRequest requestHeader) {
		RetrieveApplicationRequest request = new RetrieveApplicationRequest();

		RetrieveApplicationRequest.Body body = new RetrieveApplicationRequest.Body();
		body.setApplicationID(applicationID);						
		request.setBody(body);
		try {
			RetrieveApplicationResponse response = onboardApplicationHubClient.retrieveApplication(request, requestHeader, new Holder<>());

			if(!Optional.ofNullable(response).isPresent() || !Optional.ofNullable(response.getBody()).isPresent()) {
				logger.error("HUB Retrieve Application response: "+response.getBody().toString());
				throw new WebServiceException("HUB Retrieve Application response is null.");
			}
			if(!Optional.ofNullable(response.getBody().getPayload()).isPresent()) {
				logger.error("HUB Retrieve Application response: "+response.getBody().toString());
				throw new NotFoundException("HUB Retrieve Application response empty.");
			}
			return response;
		} 
		
		catch (SystemException  e) {
			logger.error("Failure in OnboardApplication HUB while processing retrieve request",request.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		} catch (InputViolationException  e) {
			logger.error("Failure in OnboardApplication HUB while processing retrieve request",request.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		} catch (ApplicationIntegrityException  e) {
			logger.error("Failure in OnboardApplication HUB while processing retrieve request",request.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		} 
	}

	@Override
	public RetrieveApplicationResponse retrieve(String applicationID, String ecifId) {
		HUBHeaderRequest requestHeader = this.buildHUBHeaderRequest(OnboardApplicationRepository.FUNCTION_RETRIEVE, 
				applicationID, 
				ecifId);
		return retrieve(applicationID, requestHeader);
	}

	@Override
	public void cancel(String applicationID, String ecifId, XMLGregorianCalendar lastUpdatedDateTime, List<String> accountNumbers,
			List<DocumentPackageDto> pckgs) {
		
		CancelApplicationRequest request = new CancelApplicationRequest();
		try {
	    	
			CancelApplicationRequest.Body.PackageIds pckIds = new CancelApplicationRequest.Body.PackageIds();
			populatePackageIds(pckgs, pckIds);			
			CancelApplicationRequest.Body.UnReserveAccountsList unReserveAccounts = new CancelApplicationRequest.Body.UnReserveAccountsList();
			unReserveAccounts.getUnReserveAccounts().addAll(accountNumbers);

			CancelApplicationRequest.Body body = new CancelApplicationRequest.Body();
			body.setApplicationID(applicationID);
			CancelApplicationRequest.Body.UserIdList userIds= new CancelApplicationRequest.Body.UserIdList();

			body.setUnReserveAccountsList(unReserveAccounts);
			body.setPackageIds(pckIds);
			body.setUserIdList(userIds);
			body.setCallerType(CallerType.OWM);
			body.setRequestorId(this.userContext.getAuthenticatedUser().getUserId());
			body.setLastUpdatedDateTime(lastUpdatedDateTime);

			request.setBody(body);
			HUBHeaderRequest requestHeader = buildHUBHeaderRequest("CancelApplication", applicationID, ecifId);
			CancelApplicationResponse response = onboardApplicationHubClient.cancelApplication(request,
					requestHeader, 
					new Holder<>());
			if (!Optional.ofNullable(response).isPresent()){
				logger.warn("HUB Cancel Application response: "+response.getBody().getMessage());
				throw new WebServiceException("HUB Cancel Application Response is null");
			} else if (Optional.ofNullable(response.getBody().getFailure()).isPresent() ) {
				logger.warn("HUB Cancel Application response..." + 
						response.getBody().getMessage() + " Workflow Id: "+ applicationID);
				throw new WebServiceException(response.getBody().getMessage());
			}
		} 		
		catch (SystemException  e) {			
			logger.error("Failure in OnboardApplication HUB while processing cancel request", request.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		} catch (InputViolationException  e) {
			logger.error("Failure in OnboardApplication HUB while processing cancel request", request.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		} catch (ApplicationIntegrityException  e) {
			logger.error("Failure in OnboardApplication HUB while processing cancel request", request.getBody().getApplicationID(),e);
			logger.error(String.format("OnBoardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		} 
	}

	void populatePackageIds(List<DocumentPackageDto> pckgs, CancelApplicationRequest.Body.PackageIds pckIds) {
		if(CollectionUtils.isNotEmpty(pckgs)){
			pckIds.getPackageId().addAll(pckgs.stream().map(a->a.getId()).collect(Collectors.toList()));
		}
	}

	private HUBHeaderRequest buildHUBHeaderRequest(String functionName, String workflowId, String ecifId) {
		return hubRequestComponent
				.getHubBuilder()
				.originatorResource("OnboardApplication")
				.originatorResourceFunction(functionName)
				.originatorLocationId(headerInfo.getRemoteAddress())
				.partyId(ecifId)
				.workflowId(workflowId)
				.build();
	}

	@Override
	public SaveApplicationRequest.Body defaultSaveApplicationRequestBody() {
		SaveApplicationRequest.Body body = new SaveApplicationRequest.Body();		
		body.setAppStatus(AppStatus.IN_PROGRESS);
		
		if(ApplicationLob.nb.equals(userContext.getAuthenticatedUser().getLob())){
			body.setCallerType(CallerType.OWM);
		}else if(ApplicationLob.il.equals(userContext.getAuthenticatedUser().getLob())){
			body.setCallerType(CallerType.BIL);
		}		
		
		body.setCallBPMLock(CallBPMLock.NO);
		return body;
	}

	@Override
	public void saveRelationship(SaveRelationshipRequest saveRequest) {
		HUBHeaderRequest requestHeader = hubRequestComponent.getHubBuilder().originatorResource("OnboardApplication").
				originatorResourceFunction(OnboardApplicationRepository.FUNCTION_RELATIONSHIP_SAVE).workflowId(saveRequest.getBody().getApplicationID()).build();

		saveRelationship(saveRequest, requestHeader);
	}

	@Override
	public void saveRelationship(SaveRelationshipRequest saveRequest, HUBHeaderRequest requestHeader) {
		try {
			SaveRelationshipResponse response = onboardApplicationHubClient.saveRelationship(saveRequest, requestHeader, new Holder<>());

			if(!Optional.ofNullable(response).isPresent()) {
				logger.warn("HUB Save Application response is null");
				throw new WebServiceException("HUB Save Application response is null.");
			}

			if (Optional.ofNullable(response.getBody()).isPresent() && !Optional.ofNullable(response.getBody().getSuccess()).isPresent()) {
				logger.warn("HUB Save Relationship success property: "+response.getBody().getSuccess());
				throw new WebServiceException(ToStringBuilder.reflectionToString(response.getBody()));
			}

			if((response.getBody().getResultcode() != null && !response.getBody().getResultcode().equals(SUCCESS_ACCOUNT_SETUP_CODE)) ||
					response.getBody().getSuccess() != null && response.getBody().getSuccess().equals(FAILURE_STRING)){
				logger.warn("HUB Save Relationship success property: "+response.getBody().getSuccess()
						+"and HUB Save Relationship Result code: "+response.getBody().getResultcode());
				throw new WebServiceException(ToStringBuilder.reflectionToString(response.getBody()));
			}
		} 
		catch (SystemException e) {
			logger.error("Failure in OnboardApplication HUB while processing saveRelationship request",saveRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnboardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}
		catch (InputViolationException e) {
			logger.error("Failure in OnboardApplication HUB while processing saveRelationship request",saveRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnboardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}  catch (ApplicationIntegrityException e) {
			logger.error("Failure in OnboardApplication HUB while processing saveRelationship request",saveRequest.getBody().getApplicationID(),e);
			logger.error(String.format("OnboardApplication error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("OnboardApplication service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}
	}
}
