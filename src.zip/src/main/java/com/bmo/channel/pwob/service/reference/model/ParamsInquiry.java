package com.bmo.channel.pwob.service.reference.model;

public class ParamsInquiry {
	private String source;
    private String code;
    
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
    
    
}
