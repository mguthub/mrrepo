package com.bmo.channel.pwob.service.user;

import java.util.Set;

import com.bmo.channel.pwob.model.user.InvestmentAdvisor;
import com.bmo.channel.pwob.model.user.User;

public interface UsersService {

	User currentUser();

	/**
	 * Returns user for network id. Always used LOB of authorized user.
	 * @param networkId
	 */
	User getUserByNetworkId(String networkId);
	
	Set<InvestmentAdvisor> getIAUsersByIACode(String iaCode);
}
