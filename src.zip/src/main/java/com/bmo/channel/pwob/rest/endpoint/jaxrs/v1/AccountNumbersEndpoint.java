/**
 * 
 */
package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;

import com.bmo.channel.pwob.service.accounts.AccountNumbersService;
import com.bmo.channel.pwob.service.accounts.ValidateAccountResponse;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * @author vvallia
 *
 */
@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(AccountNumbersEndpoint.V1_PATH)
@Path(AccountNumbersEndpoint.V1_PATH)
@Validated
public class AccountNumbersEndpoint {
	
	@SuppressWarnings("unused")
	private Logger logger = LoggerFactory.getLogger(AccountNumbersEndpoint.class);
	
	public static final String V1_PATH = "v1/account_numbers";
	
	@Autowired
	private AccountNumbersService accountNumbersService;
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	 @ApiOperation(value="Validate account number is in the current branch", response=ValidateAccountResponse.class)
		@ApiImplicitParams({
			@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
			@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	    @ApiResponses(value={
	    		@ApiResponse(code=200, message="Account number is valid"),
	    		@ApiResponse(code=400, message="Invalid IA code"),
	    		@ApiResponse(code=404, message="Account number Not found"),
	            @ApiResponse(code=500, message="Internal server error")})
	public Response validate(@ApiParam(value = "Account ID") @PathParam("id") String accountId,
			@NotNull @Size(min = 3, max = 3) @ApiParam(value = "IACode") @QueryParam("iaCode") String iaCode,
			@ApiParam(value = "Rule Name", allowableValues = "GUARANTEE, GUARANTOR, RIFOUTBOUNDTRANSFER", required = true) @NotNull @QueryParam("rule") String rule) {
	
		return Response.ok(accountNumbersService.validateAccount(accountId,iaCode,rule)).build();
	}

}
