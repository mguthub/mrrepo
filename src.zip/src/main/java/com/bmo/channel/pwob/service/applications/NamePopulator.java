package com.bmo.channel.pwob.service.applications;

import java.util.List;

import com.bmo.channel.pwob.model.applications.SavedApplication;

public interface NamePopulator {
	void populateLastUpdatedByNames(List<SavedApplication> savedApplications);
}
