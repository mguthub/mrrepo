package com.bmo.channel.pwob.validation.residence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.TaxResidency;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

public class TaxResidencyValidator extends AbstractBaseValidator implements ConstraintValidator<ValidTaxResidency, PersonalInformation> {
	@Autowired private UsersService userService;

	@Autowired private ValidationRequestFactory validationRequestFactory;

	public static final String TAX_ID_PATTERN =  "^\\d{9}$";
	public static final String TAX_ID_MISSING_DESC = "^[\\’\\'\\`\\d\\sA-Za-zÀ-Ÿà-ÿ]{1,120}$";
		
	@Override
	public void initialize(ValidTaxResidency constraintAnnotation) {}

	@Override
	public boolean isValid(PersonalInformation pInfo, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if (validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).build();
		return validateTaxResidency(pInfo, request);
	}

	private boolean validateTaxResidency(PersonalInformation pInfo, ValidationRequest request) {
		request.setIndex(0);
		request.setPartyRole(PartyRole.PRIMARY_APPLICANT);
		boolean valid = true;
		// check has declared any other country for tax declaration
		if(null!= pInfo && Optional.ofNullable(pInfo.getHasTaxResidency()).isPresent() && pInfo.getHasTaxResidency()){
			valid = this.validateTaxResidencyDetails(pInfo, request) && valid;

			valid = this.validateUniqueTaxId(pInfo, request) && valid;
		}
		return valid;
	}

	private boolean validateUniqueTaxId(PersonalInformation pInfo, ValidationRequest request) {
		if(Optional.ofNullable(pInfo.getResidencyForTax()).isPresent() &&  CollectionUtils.isNotEmpty(pInfo.getResidencyForTax())){
			List<TaxResidency> validTaxIds= pInfo.getResidencyForTax().stream().filter(t->t.getTaxIdentificationNumber() !=null || 
					(t.getHaveNoTaxIdentificationNumber()!= null && !t.getHaveNoTaxIdentificationNumber())).collect(Collectors.toList());
			Set<String> taxIds = validTaxIds.stream().map(t->t.getTaxIdentificationNumber()).collect(Collectors.toSet());
			if(CollectionUtils.isNotEmpty(taxIds) && taxIds.size() > 1 && taxIds.size() != validTaxIds.size()) {
				ValidationRequest valReq = request.createChildValidationRequest(PERSONAL_RESIDENCE_FOR_TAX_NODE, null);
				valReq.setErrorCode(ErrorCodes.INVALID_TAX_RESIDENCIES);		
				valReq.addConstraintViolation();
				return false;	
			}
		}
		return true;
	}

	private boolean validateTaxResidencyDetails(PersonalInformation pInfo, ValidationRequest request) {
		boolean valid = true;
		int index = 0;
		if(pInfo.getResidencyForTax() == null || (Optional.ofNullable(pInfo.getResidencyForTax()).isPresent() &&  CollectionUtils.isEmpty(pInfo.getResidencyForTax()))){
			// if declared any other country for tax and no information is provided
			ValidationRequest taxValReq = request.createChildValidationRequest(PERSONAL_RESIDENCE_FOR_TAX_NODE + "[" +index +"]", PERSONAL_RESIDENCE_FOR_TAX_PATH+ "[" +index +"]");
			taxValReq.setFieldName("country");
			taxValReq.setErrorCode(ErrorCodes.INVALID_COUNTRY);
			taxValReq.addConstraintViolation();
			valid = false;
		}
		if (pInfo.getHasTaxResidency() && Optional.ofNullable(pInfo.getResidencyForTax()).isPresent() && pInfo.getResidencyForTax().size() == 1) {
			// If only Canada but more specified 			
			ValidationRequest taxValReq = request.createChildValidationRequest(PERSONAL_RESIDENCE_FOR_TAX_NODE + "[" +index +"]", PERSONAL_RESIDENCE_FOR_TAX_PATH+ "[" +index +"]");
			index++;
			taxValReq.setFieldName("country");
			taxValReq.setErrorCode(ErrorCodes.INVALID_COUNTRY);

			taxValReq.addConstraintViolation();
			valid = false;				
		}
		else {
			if(Optional.ofNullable(pInfo.getResidencyForTax()).isPresent())
			{		
				TaxResidency taxRes;
				valid = validateForDuplicateTaxResidencyCountry(pInfo.getResidencyForTax(), request);
				for(int pos = 0; pos < pInfo.getResidencyForTax().size() ; pos++){
					taxRes = pInfo.getResidencyForTax().get(pos);
					ValidationRequest taxValReq = request.createChildValidationRequest(PERSONAL_RESIDENCE_FOR_TAX_NODE + "[" +pos +"]", PERSONAL_RESIDENCE_FOR_TAX_PATH + "[" +pos +"]");

					// if null, skip validation
					if(StringUtils.isEmpty(taxRes.getCountry())) {
						continue;
					}

					// if Canada, skip validation
					if (RefDataValues.CANADA_COUNTRY_CODE.equals(taxRes.getCountry())) {
						validateForCanada(taxRes, taxValReq);
						continue;
					}

					if(!(Optional.ofNullable(taxRes.getHaveNoTaxIdentificationNumber()).isPresent() && taxRes.getHaveNoTaxIdentificationNumber())){
						// do Tax ID validation

						if( (taxRes.getCountry().equals(RefDataValues.USA_COUNTRY_CODE) 
								&& (StringUtils.isBlank(taxRes.getTaxIdentificationNumber()) || !this.doesPatternMatch(taxRes.getTaxIdentificationNumber(), TAX_ID_PATTERN)))){
							// For US Tax id pattern
							taxValReq.setFieldName("taxIdentificationNumber");
							taxValReq.setErrorCode(ErrorCodes.INVALID_SOCIAL_SECURITY_NUMBER);
							taxValReq.addConstraintViolation();
							valid = false;
						} else if(StringUtils.isBlank(taxRes.getTaxIdentificationNumber())){
							// for countries other then US
							taxValReq.setFieldName("taxIdentificationNumber");
							taxValReq.setErrorCode(ErrorCodes.INVALID_TAX_IDENTIFICATION_NUMBER);
							taxValReq.addConstraintViolation();
							valid = false;
						}						
					}
					else{
						//validation of missing reason						
						if(StringUtils.isBlank(taxRes.getTaxIdentificationNumberMissingReason())){
							taxValReq.setFieldName("taxIdentificationNumberMissingReason");
							taxValReq.setErrorCode(ErrorCodes.INVALID_TAX_ID_MISSING_REASON);
							taxValReq.addConstraintViolation();
							valid = false;
						} else if(taxRes.getTaxIdentificationNumberMissingReason().equals(RefDataValues.TAX_ID_MISSING_REASON_OTHER) 
								&& (StringUtils.isBlank(taxRes.getTaxIdentificationNumberMissingReasonDescription()) 
								|| !this.doesPatternMatch(taxRes.getTaxIdentificationNumberMissingReasonDescription(), TAX_ID_MISSING_DESC))){
							//validation of missing reason description

							taxValReq.setFieldName("taxIdentificationNumberMissingReasonDescription");
							taxValReq.setErrorCode(ErrorCodes.INVALID_TAX_ID_MISSING_REASON_DESC);
							taxValReq.addConstraintViolation();
							valid = false;
						}
					}
				}
			}
		}		
		return valid;
	}

	private boolean validateForCanada(TaxResidency taxRes, ValidationRequest request) {
		if(taxRes.getHaveNoTaxIdentificationNumber() != null || taxRes.getTaxIdentificationNumber() != null || taxRes.getTaxIdentificationNumberMissingReason() != null 
				|| taxRes.getTaxIdentificationNumberMissingReasonDescription() != null) {

			request.setFieldName("");
			request.setErrorCode(ErrorCodes.INVALID_CANADIAN_TAX_RESIDENCY);
			request.addConstraintViolation();
			return false;
		}
		return true;		
	}

	private boolean validateForDuplicateTaxResidencyCountry(List<TaxResidency> taxReslist, ValidationRequest request) {
		boolean valid = true;	
		List<String> taxResCountrylist=taxReslist.stream().map(p -> p.getCountry()).collect(Collectors.toList());		
		final Map<String,Integer> freqMap=new HashMap<String,Integer>();
		for (String country: taxResCountrylist) {
			if (!freqMap.containsKey(country)) {
				freqMap.put(country,1);
			} else {
				freqMap.put(country,freqMap.get(country)+1);
			}
		 }
		 for (Map.Entry<String, Integer> entry:freqMap.entrySet()) {
			 if (entry.getValue()>1) {
				 ValidationRequest taxValReq = request.createChildValidationRequest(PERSONAL_RESIDENCE_FOR_TAX_NODE + "[" + taxResCountrylist.lastIndexOf(entry.getKey()) +"]",
						 PERSONAL_RESIDENCE_FOR_TAX_PATH+ "[" +taxResCountrylist.lastIndexOf(entry.getKey()) +"]");
				 taxValReq.setFieldName("country");
				 taxValReq.setErrorCode(ErrorCodes.INVALID_TAX_RESIDENCY_DUPLICATE_COUNTRY);
				 taxValReq.addConstraintViolation();
				 valid=false;
			 }			 
		 }
		return valid;
	}
}
