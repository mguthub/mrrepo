package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import java.util.List;

import javax.validation.constraints.Pattern;
import javax.ws.rs.QueryParam;

public class SavedApplicationsFilter {
	@QueryParam("appStatus")
	private String appStatus;

	@QueryParam("firstName")
	@Pattern(regexp = "^[a-zA-ZÀ-Ÿà-ÿ\\s\\-'’ ]{2,50}$")
	private String firstName;

	@QueryParam("lastName")
	@Pattern(regexp = "^[a-zA-ZÀ-Ÿà-ÿ\\s\\-'’ ]{2,50}$")
	private String lastName;

	@QueryParam("pageNum")
	// TODO WMPWO-1997 restore
//	@Range(min = 1, max = 100)
	private Integer pageNum;

	@QueryParam("numPerPage")
	// TODO WMPWO-1997 restore
//	@Range(min = 0, max = 50)
	private Integer numPerPage;
	
	@QueryParam("iaCode")
	private List<String> iaCodes;

	@QueryParam("customerId")
	private List<String> customerIds;
	
	public String getAppStatus() {
		return appStatus;
	}
	public void setAppStatus(String appStatus) {
		this.appStatus = appStatus;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Integer getPageNum() {
		return pageNum;
	}
	public void setPageNum(Integer pageNum) {
		this.pageNum = pageNum;
	}
	public Integer getNumPerPage() {
		return numPerPage;
	}
	public void setNumPerPage(Integer numPerPage) {
		this.numPerPage = numPerPage;
	}
	public List<String> getIaCodes() {
		return iaCodes;
	}
	public void setIaCodes(List<String> iaCodes) {
		this.iaCodes = iaCodes;
	}
	public List<String> getCustomerIds() {
		return customerIds;
	}
	public void setCustomerIds(List<String> customerIds) {
		this.customerIds = customerIds;
	}
	
}
