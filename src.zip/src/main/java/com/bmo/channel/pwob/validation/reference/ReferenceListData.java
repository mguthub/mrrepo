package com.bmo.channel.pwob.validation.reference;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.bmo.channel.pwob.service.reference.ReferenceType;

@Documented
@Constraint(validatedBy = ReferenceListDataValidator.class)
@Target({ FIELD })
@Retention(RUNTIME)
public @interface ReferenceListData {
	String message() default "{generic}";
	String code();
	Class<?>[] groups() default {};
	Class<? extends Payload>[] payload() default {};
	ReferenceType type();
}
