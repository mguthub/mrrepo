package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import com.bmo.channel.pwob.service.documentpackages.dto.Error;

@JsonIgnoreProperties(ignoreUnknown = true)
public class DocumentUpdateUploadResponse {
	private String status;
	private List<Error> errors;

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	public List<Error> getErrors() {
		return errors;
	}
	public void setErrors(List<Error> errors) {
		this.errors = errors;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
