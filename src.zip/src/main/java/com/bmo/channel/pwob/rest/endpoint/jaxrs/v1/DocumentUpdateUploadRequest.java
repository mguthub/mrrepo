package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import com.bmo.channel.pwob.service.documentpackages.dto.Image;
import com.bmo.channel.pwob.service.documentpackages.dto.MetaInfo;

public class DocumentUpdateUploadRequest {	
	
	private String destination = "OutputImage";
	private String processFlow = "WMT_Personal_Wealth_Onboarding";
	private MetaInfo metaInfo;
	private Image image;

	public String getDestination() {
		return destination;
	}
	public void setDestination(final String destination) {
		this.destination = destination;
	}	
	public String getProcessFlow() {
		return processFlow;
	}
	public void setProcessFlow(final String processFlow) {
		this.processFlow = processFlow;
	}
	public MetaInfo getMetaInfo() {
		return metaInfo;
	}
	public void setMetaInfo(final MetaInfo metaInfo) {
		this.metaInfo = metaInfo;
	}	
	public Image getImage() {
		return image;
	}
	public void setImage(final Image image) {
		this.image = image;
	}	
	
}
