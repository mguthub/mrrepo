package com.bmo.channel.pwob.validation.party;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.service.product.ProductService;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

@Component
public class JointApplicantValidatorImpl implements JointApplicantValidator {
	@Autowired
	private ProductService productService;

	/**
	 * If date of birth and province are provided, check product eligibility.
	 * If not provided, don't check eligibility.
	 */
	@Override
	public boolean validateJointProductEligibility(String applicationId, Party party, ValidationRequest partyValidationRequest) {
		if(areDobAndProvinceProvided(party)) {
			boolean eligibleForProduct = productService.isEligibleForProduct(applicationId, 
					party.getPersonal().getIdentity().getDateOfBirth(), 
					party.getPersonal().getResidence().getPrimaryAddress().getProvince(), 
					Account.JOINT_TYPE);
			if(eligibleForProduct) {
				return true;
			} else {
				ValidationRequest provinceValRequest = partyValidationRequest.createChildValidationRequest("personal.residence.primaryAddress", "personal.residence.primaryAddress");
				provinceValRequest.addConstraintViolation("province", ErrorCodes.INVALID_JOINT_PRODUCT_ELIGIBILITY_PROVINCE);

				ValidationRequest dateOfBirthValRequest = partyValidationRequest.createChildValidationRequest("personal.identity", "personal.identity");
				dateOfBirthValRequest.addConstraintViolation("dateOfBirth", ErrorCodes.INVALID_JOINT_PRODUCT_ELIGIBILITY_DOB);

				return false;
			}
		} else {
			return true;
		}
	}

	private boolean areDobAndProvinceProvided(Party party) {
		if(party != null && party.getPersonal() != null) {
			PersonalInformation personal = party.getPersonal();
			return hasDateOfBirth(personal) && hasProvince(personal);
		} else {
			return true;
		}
	}

	private boolean hasProvince(PersonalInformation personal) {
		return personal.getResidence() != null 
				&& personal.getResidence().getPrimaryAddress() != null
				&& personal.getResidence().getPrimaryAddress().getProvince() != null;
	}

	private boolean hasDateOfBirth(PersonalInformation personal) {
		return personal.getIdentity() != null && personal.getIdentity().getDateOfBirth() != null;
	}
}
