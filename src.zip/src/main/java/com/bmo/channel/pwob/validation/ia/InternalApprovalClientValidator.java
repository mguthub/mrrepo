package com.bmo.channel.pwob.validation.ia;


import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.ia.Client;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

/**
 * Validate the Taxation details. 
 *
 */
public class InternalApprovalClientValidator extends AbstractBaseValidator implements ConstraintValidator<ValidInternalApprovalClient, Client> {

	
	@Autowired
	private UsersService userService;
	
	@Autowired 
	private ValidationRequestFactory validationRequestFactory;
	

	@Override
	public void initialize(ValidInternalApprovalClient constraintAnnotation) {
	}

	@Override
	public boolean isValid(Client client, ConstraintValidatorContext context) {
		
        ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).build();
        return validateReferrerInfo(client,request);
	}
	
	private boolean validateReferrerInfo(Client client,ValidationRequest request)
	{
		boolean valid = true;
		
		if(client.getReferralSource().equals(RefDataValues.REFERRAL_SOURCE_BMO_REFERRER)){
			
			request.setFieldName("referrerFirstName");
			request.setErrorCode(ErrorCodes.INVALID_REFERRER_FIRST_NAME);
			request.setFieldValue(client.getReferrerFirstName());
			valid = validateAndAddConstraintViolation(request) && valid;
			
			request.setFieldName("referrerLastName");
			request.setErrorCode(ErrorCodes.INVALID_REFERRER_LAST_NAME);
			request.setFieldValue(client.getReferrerLastName());
			valid = validateAndAddConstraintViolation(request) && valid;
			
			request.setFieldName("transitNumber");
			request.setErrorCode(ErrorCodes.INVALID_TRANSIT_NUMBER);
			request.setFieldValue(client.getTransitNumber());
			valid = validateAndAddConstraintViolation(request) && valid;
			// TISM code is optional hence validation is not required
			
			/*request.setFieldName("tismCode");
			request.setErrorCode(ErrorCodes.INVALID_TISM_CODE);
			request.setFieldValue(client.getTismCode());
			valid = validateAndAddConstraintViolation(request) && valid;*/
			
			}
		return valid;
	}


}
