package com.bmo.channel.pwob.service.party;

import com.bmo.channel.pwob.model.onboarding.Party;

public interface PartyFactory {

	Party createPrimaryApplicantParty(Party party);
	
	Party createJointApplicantParty(Party party);
	
	Party createSpouseParty(Party spouse, Party party);
}
