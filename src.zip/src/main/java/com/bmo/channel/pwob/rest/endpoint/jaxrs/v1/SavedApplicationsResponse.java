package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import java.util.List;

import com.bmo.channel.pwob.model.applications.SavedApplication;

public class SavedApplicationsResponse {

	private List<SavedApplication> savedApplications;
	
	private boolean moreRecordsExist;

	public SavedApplicationsResponse(List<SavedApplication> savedApplications) {
		this.savedApplications = savedApplications;
	}

	public List<SavedApplication> getSavedApplications() {
		return savedApplications;
	}
	public void setSavedApplications(List<SavedApplication> savedApplications) {
		this.savedApplications = savedApplications;
	}

	public boolean isMoreRecordsExist() {
		return moreRecordsExist;
	}

	public void setMoreRecordsExist(boolean moreRecordsExist) {
		this.moreRecordsExist = moreRecordsExist;
	}
}
