/**
 * @author akhales
 */
package com.bmo.channel.pwob.model.onboarding;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;
import com.bmo.channel.pwob.validation.reference.ReferenceListData;

import io.swagger.annotations.ApiModelProperty;
//Commented for sprint 34 only
//@InvestmentExperienceKnowledge
public class InvestmentExperience {
	@ApiModelProperty(example="['1', '2']", value="Accepts values from 1-8, see reference service for more information")
	@ReferenceListData(type = ReferenceType.INVESTMENT_EXPERIENCE, code = ErrorCodes.INVALID_PAST_INVESTMENT_EXPERIENCE)
	private List<String> pastExperience = new ArrayList<>();

	@ApiModelProperty(example="B", value="Accepts values from A-D, see reference service for more information")
	@ReferenceData(type = ReferenceType.INVESTMENT_KNOWLEDGE, code = ErrorCodes.INVALID_INVESTMENT_KNOWLEDGE)
	private String investmentKnowledge;

	@ApiModelProperty(example="fine art", value="If past experience includes alternate investments, describe here.")
	private String altInvestmentExperience;

	public String getInvestmentKnowledge() {
		return investmentKnowledge;
	}
	public void setInvestmentKnowledge(String investmentKnowledge) {
		this.investmentKnowledge = investmentKnowledge;
	}

	public List<String> getPastExperience() {
		return pastExperience;
	}
	public void setPastExperience(List<String> pastInvestmentExp) {
		this.pastExperience = pastInvestmentExp;
	}

	public String getAltInvestmentExperience() {
		return altInvestmentExperience;
	}
	public void setAltInvestmentExperience(String altInvestmentExperience) {
		this.altInvestmentExperience = altInvestmentExperience;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
