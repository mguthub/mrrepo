package com.bmo.channel.pwob.service.ia;

import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.model.ia.Approval;
import com.bmo.channel.pwob.model.ia.BMApproval;
import com.bmo.channel.pwob.model.ia.IAApproval;

public interface InternalApprovalsService {
	static final String FUNCTION_RELATIONSHIP_SAVE = "SaveRelationshipSummary";
	
	RelationshipSummary updateRelationshipSummary(RelationshipSummary accountSetup, String workflowId);
	RelationshipSummary getInitialRelationshipSummary(String workflowId);
	
	IAApproval addNewIAApproval(IAApproval iaApproval, String workflowId);
	Approval getIAApprovals(String workflowId);
	
	BMApproval addNewBMApproval(BMApproval bmApproval, String workflowId);
	Approval getBMApprovals(String workflowId);
}
