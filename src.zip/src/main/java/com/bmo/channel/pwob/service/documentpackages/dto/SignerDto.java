package com.bmo.channel.pwob.service.documentpackages.dto;

public class SignerDto {
	private String id;
	private String role;
	private String signedPackage;
	private String firstName;
	private String lastName;

	public String getId() {
		return id;
	}
	public void setId(final String signerId) {
		this.id = signerId;
	}
	public String getName() {
		return firstName + " " + lastName;
	}
	public String getRole() {
		return role;
	}
	public void setRole(final String role) {
		this.role = role;
	}	
	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}
	public String getLastName() {
		return lastName;
	}
	/**
	 * @return the signedPackage
	 */
	public String getSignedPackage() {
		return signedPackage;
	}
	/**
	 * @param signedPackage the signedPackage to set
	 */
	public void setSignedPackage(final String signedPackage) {
		this.signedPackage = signedPackage;
	}
}
