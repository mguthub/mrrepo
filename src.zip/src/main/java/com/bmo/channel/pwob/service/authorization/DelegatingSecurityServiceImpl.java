package com.bmo.channel.pwob.service.authorization;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.service.ia.InternalApprovalsServiceImpl;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.ErrorCodes;

@Service
public class DelegatingSecurityServiceImpl implements SecurityService {
	
	private static Logger logger = LoggerFactory.getLogger(DelegatingSecurityServiceImpl.class);
	
	@Autowired
	private EventManager eventManager;

	@Autowired
	private UsersService usersService;

	@Autowired
	private LobSecurityService nbSecurityService;

	@Autowired
	private LobSecurityService ilSecurityService;

	@Override
	public void authorizeAction(String appStatus, String userAccessCode, PwobAction action) {
		if(action == null){
			logger.error("The action is null");
			throw new WebServiceException(ErrorCodes.EMPTY_SECURITY_FIELDS);
		}

		User user = usersService.currentUser();

		eventManager.publishInfo(
			String.format("User %s in LOB %s trying to execute %s on app with status %s and ia code %s", 
				user.getUserId(),
				user.getLob().name(),
				action.name(),
				appStatus,
				userAccessCode)
		);

		getLobSecurityService(user.getLob()).authorizeAction(user, userAccessCode, appStatus, action);
	}

	private LobSecurityService getLobSecurityService(ApplicationLob lob) {
		return ApplicationLob.nb == lob ? nbSecurityService : ilSecurityService;
	}

	@Override
	public void authorizeReadAccessToAll(Collection<String> userAccessCodes) {
		userAccessCodes.stream().forEach(i -> authorizeReadAccess(i));
	}

	@Override
	public void authorizeReadAccess(String userAccessCode) {
		User user = usersService.currentUser();

		eventManager.publishInfo(
			String.format("User %s in LOB %s trying to retrieve app with ia code %s", 
				user.getUserId(),
				user.getLob().name(),
				userAccessCode)
		);

		getLobSecurityService(user.getLob()).authorizeReadAccess(user, userAccessCode);
	}
}
