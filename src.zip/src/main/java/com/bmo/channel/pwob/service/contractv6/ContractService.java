package com.bmo.channel.pwob.service.contractv6;

import com.bmo.accounts.AccountDetailsResponse;

public interface ContractService {
	String retrieveEcifId(AccountDetailsResponse risModel);
}
