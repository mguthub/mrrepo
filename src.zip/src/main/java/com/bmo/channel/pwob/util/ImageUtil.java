package com.bmo.channel.pwob.util;

import java.io.ByteArrayOutputStream;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.itextpdf.text.Document;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.PdfWriter;

/**
 * Provides the utilities to process image (jpeg and png) files.
 */
public class ImageUtil implements DocumentImage {
	
	private static Logger logger = LoggerFactory.getLogger(ImageUtil.class);
	/**
	 * This is to concatenate several images files and get a single pdf.
	 * 
	 * @param contents List of byte[] of image contents.
	 * @return Concatenated pdf file.
	 * @throws Exception In case of error.
	 */
	public byte[] merge(final List<StringBuilder> contents) {
		Document pdfDoc = null;
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
		PdfWriter writer = null;
		try {
			Image img = null;
			final Rectangle size = new Rectangle(PageSize.LETTER.getWidth(), PageSize.LETTER.getHeight());
			// Create the doc with no margins.
			pdfDoc = new Document(size, Constants.ZERO, Constants.ZERO, Constants.ZERO, Constants.ZERO);
			writer = PdfWriter.getInstance(pdfDoc, out);
			writer.open();
			pdfDoc.open();
			for (StringBuilder content : contents) {
				img = Image.getInstance(Base64.decodeBase64(content.toString()));
				img.scaleToFit(PageSize.LETTER.getWidth(), PageSize.LETTER.getHeight());
				pdfDoc.add(img);
			}
		} catch (Exception ex) {
			logger.error("Failed to merge image files : ", ex);
			throw new WebServiceException(ex);
		} finally {
			if (pdfDoc != null && pdfDoc.isOpen()) {
				pdfDoc.close();
			}
			if (writer != null) {
				writer.close();
			}
			IOUtils.closeQuietly(out);
		}
		
		return out.toByteArray();
	}
}
