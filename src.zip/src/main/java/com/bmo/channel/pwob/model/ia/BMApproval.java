package com.bmo.channel.pwob.model.ia;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.Pattern;

import com.bmo.channel.pwob.validation.ErrorCodes;

import io.swagger.annotations.ApiModelProperty;

public class BMApproval {
	
	@Pattern(regexp="^[\\p{IsLatin}\\s-'0-9_ ~`+@!#$%*()=,<.>?;:{}|&^\\[\\]/  ]{0,4000}$", message=ErrorCodes.INVALID_APPROVAL_COMMENT)
	private String comments;
	
	@AssertTrue(message=ErrorCodes.INVALID_CONFIRMED_IA_ARE_LICENSED_IN_CLIENT_JURISDICTION)
	private Boolean confirmedIaAreLicensedInClientJurisdiction;
	
	@AssertTrue(message=ErrorCodes.INVALID_REVIEWED_ACCOUNT_SUITABLITY)
	private Boolean reviewedAccountSuitability;
	
	@ApiModelProperty(value="BM's decision to approve or reject the application", allowableValues="reject,approve")
	private String status;
	
	@Pattern(regexp="^[\\p{IsLatin}\\s-'0-9_ ~`+@!#$%*()=,<.>?;:{}|&^\\[\\]/  ]{0,4000}$", message=ErrorCodes.INVALID_APPROVAL_DOCEDITCOMMENT)
	private String documentEdits;
	
	@ApiModelProperty(value="Self attestation checkbox for IA Licence confirmation")
	private Boolean isIALicenceConfirmed;
	
	public Boolean getIsIALicenceConfirmed() {
		return isIALicenceConfirmed;
	}

	public void setIsIALicenceConfirmed(Boolean isIALicenceConfirmed) {
		this.isIALicenceConfirmed = isIALicenceConfirmed;
	}
	
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Boolean getConfirmedIaAreLicensedInClientJurisdiction() {
		return confirmedIaAreLicensedInClientJurisdiction;
	}

	public void setConfirmedIaAreLicensedInClientJurisdiction(Boolean confirmedIaAreLicensedInClientJurisdiction) {
		this.confirmedIaAreLicensedInClientJurisdiction = confirmedIaAreLicensedInClientJurisdiction;
	}

	public Boolean getReviewedAccountSuitability() {
		return reviewedAccountSuitability;
	}

	public void setReviewedAccountSuitability(Boolean reviewedAccountSuitability) {
		this.reviewedAccountSuitability = reviewedAccountSuitability;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDocumentEdits() {
		return documentEdits;
	}

	public void setDocumentEdits(String documentEdits) {
		this.documentEdits = documentEdits;
	}

}
