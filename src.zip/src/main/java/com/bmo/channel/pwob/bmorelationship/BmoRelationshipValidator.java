package com.bmo.channel.pwob.bmorelationship;

import com.bmo.channel.pwob.model.onboarding.BmoRelationship;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface BmoRelationshipValidator {

	public abstract Boolean validateBmoRelationship(BmoRelationship bmoRealtionship, ValidationRequest request);
}
