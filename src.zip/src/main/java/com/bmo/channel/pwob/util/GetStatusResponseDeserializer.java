package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

import java.io.IOException;


public class GetStatusResponseDeserializer extends StdDeserializer<GetStatusResponseWrapper> {

    public GetStatusResponseDeserializer() {
        this(null);
    }

    public GetStatusResponseDeserializer(Class<GetStatusResponseWrapper> t) {
        super(t);
    }

    @Override
    public GetStatusResponseWrapper deserialize(JsonParser jp, DeserializationContext dc)
            throws IOException {

        JsonNode node = jp.getCodec().readTree(jp);
        JsonNode response = node.get("GetStatusResponse");
        ObjectMapper jsonObjectMapper = new ObjectMapper();
        GetStatusResponseWrapper newJsonNode = jsonObjectMapper.treeToValue(response, GetStatusResponseWrapper.class);
        return newJsonNode;
    }

}

