package com.bmo.channel.common.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.Response.Status;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BuildNumberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Logger logger = LoggerFactory.getLogger(BuildNumberServlet.class);	

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ServletContext application = getServletConfig().getServletContext();
		InputStream inputStream = application.getResourceAsStream("/META-INF/MANIFEST.MF");
		Manifest manifest = new Manifest(inputStream);
        Attributes mainAttribs = manifest.getMainAttributes();
        resp.setStatus(Status.OK.getStatusCode());
        try (PrintWriter writer = resp.getWriter()) {
        	writer.write(mainAttribs.getValue("Implementation-Build"));
        	resp.flushBuffer();
        }
        catch (Exception ex) {
        	logger.error("Failure in writing main attributes for the Manifest. ", ex);        
        }
	}
}
