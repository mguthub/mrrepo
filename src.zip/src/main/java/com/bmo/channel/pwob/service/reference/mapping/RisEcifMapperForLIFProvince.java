package com.bmo.channel.pwob.service.reference.mapping;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.model.reference.StatProvReference;
import com.bmo.channel.pwob.service.reference.model.DataAndMapping;
import com.ibm.xmlns.prod.infosphere.referencedatamanagement.referenceset.ValueType;

public class RisEcifMapperForLIFProvince extends AbstractBaseReferenceMapper {

	public final String LIF_ELIGIBLE = "YES";
	
	@Override
	public List<Reference> mapToReferenceListEN(DataAndMapping dataAndMapping) {
		List<Reference> collect = dataAndMapping.getReferenceData().stream().map(v -> {
			return mapRisToEcifEnForStatProv(v, dataAndMapping.getMappingData());
		}).collect(Collectors.toList());
		return new DuplicatesFilter().filterOutDuplicates(collect);
	}

	@Override
	public List<Reference> mapToReferenceListFR(DataAndMapping dataAndMapping) {
		List<Reference> collect = dataAndMapping.getReferenceData().stream().map(v -> {			
			return mapRisToEcifFRForStatProv(v, dataAndMapping.getMappingData());
		}).collect(Collectors.toList());
		return new DuplicatesFilter().filterOutDuplicates(collect);
	}

	public Reference mapRisToEcifEnForStatProv(ValueType v, Map<String,String> mappings) {
		if(LIF_ELIGIBLE.equalsIgnoreCase(getLifEligibleProperty(v)) && mappings.containsKey(v.getCode().getValue())) {
			Reference reference = new StatProvReference(mappings.get(v.getCode().getValue()), v.getName().getValue());
			if(isExpiredData(v)) {
				reference.setExpired(Boolean.TRUE);
			}
			return reference;
		}
		return null;
	}
	
	public Reference mapRisToEcifFRForStatProv(ValueType v, Map<String,String> mappings) {		
		if(LIF_ELIGIBLE.equalsIgnoreCase(getLifEligibleProperty(v)) && mappings.containsKey(v.getCode().getValue())) {
			return getTranslationForStatProv(v, mappings);
		}
		return null;
	}
	
	private  Reference getTranslationForStatProv(ValueType v, Map<String, String> mappings) {
		Reference ref;
		
		String name = getFrenchName(v);
		if (!StringUtils.isBlank(name)){
			ref = new StatProvReference(mappings.get(v.getCode().getValue()), name);
			
		} else {	//if French translation is not present, set English name
			ref = new StatProvReference(mappings.get(v.getCode().getValue()), v.getName().getValue());
		}
		
		if (isExpiredData(v)) {
			ref.setExpired(Boolean.TRUE);
		}
		return ref;
	}
	
	private String getLifEligibleProperty(ValueType v){
		if (Optional.ofNullable(v.getProperties()).isPresent()
				&& CollectionUtils.isNotEmpty(v.getProperties().getProperty())
				&& CollectionUtils.isNotEmpty(v.getProperties().getProperty().get(2).getContent())) {
			return v.getProperties().getProperty().get(2).getContent().get(0).toString();
		}
		return null;
	}
}
