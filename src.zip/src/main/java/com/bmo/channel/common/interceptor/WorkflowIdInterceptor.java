package com.bmo.channel.common.interceptor;

import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.jaxrs.impl.UriInfoImpl;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.WorkflowsEndpoint;

@Component
public class WorkflowIdInterceptor extends AbstractPhaseInterceptor<Message> {

	private static Logger logger = LoggerFactory.getLogger(WorkflowIdInterceptor.class);
	
	public WorkflowIdInterceptor() {
		this(Phase.RECEIVE);
	}
	
	public WorkflowIdInterceptor(String phase, boolean uniqueId) {
		super(Phase.RECEIVE, uniqueId);
	}

	public WorkflowIdInterceptor(String i, String p, boolean uniqueId) {
		super(i, p, uniqueId);

	}

	public WorkflowIdInterceptor(String i, String p) {
		super(i, p);
	
	}

	public WorkflowIdInterceptor(String phase) {
		super(Phase.RECEIVE);

	}

	@Override
	public void handleMessage(Message message) throws Fault {
		UriInfo uriInfo = new UriInfoImpl(message);
		
		String workflowId ="";
		
		MultivaluedMap<String, String> metadataMap = uriInfo.getPathParameters();
		if(!metadataMap.isEmpty())
			workflowId=metadataMap.getFirst("id");
		else 
			workflowId=extractWorkflowId(uriInfo.getPath());
		
		MDC.put("workflowID", StringUtils.trimToEmpty(workflowId));
		
		logger.debug("workflowID = {}", StringUtils.trimToEmpty(workflowId));
		
	}
	
	String extractWorkflowId(String workflowId){
		if(workflowId.contains(WorkflowsEndpoint.V1_PATH) && 
				workflowId.length() != workflowId.indexOf(WorkflowsEndpoint.V1_PATH)+WorkflowsEndpoint.V1_PATH.length())
		{
			int workflow_index=WorkflowsEndpoint.V1_PATH.length()+1;
			int beginIndex=workflowId.indexOf(WorkflowsEndpoint.V1_PATH)+workflow_index;
				
			String splitChar="/";
				
			int endIndex=workflowId.indexOf(splitChar,beginIndex);
			if (endIndex==-1)
				endIndex=workflowId.length();
			
			return workflowId.substring(beginIndex,endIndex);
		}
		else{
			return "";
		}
	}
}
