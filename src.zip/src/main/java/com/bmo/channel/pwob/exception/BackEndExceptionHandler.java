package com.bmo.channel.pwob.exception;

import java.util.Optional;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.commons.lang3.StringUtils;

import com.bmo.channel.core.event.MessageEvent;
import com.bmo.channel.core.exception.AbstractExceptionHandler;
import com.bmo.channel.core.exception.ErrorResponse;
import com.bmo.channel.core.mapping.DataMapper;
import com.bmo.channel.core.util.JsonUtil;

public class BackEndExceptionHandler extends AbstractExceptionHandler implements ExceptionMapper<BackEndException> {
	
	public BackEndExceptionHandler(DataMapper dataMapper) {
		super(dataMapper);
	}

	@Override
	public Response toResponse(BackEndException exception) {
		MessageEvent messageEvent = getEventManager().publishError(exception);

		String message = exception.getMessage();

		ErrorResponse errorResponse = getDataMapper().map(messageEvent, ErrorResponse.class);
		
		if (Optional.ofNullable(exception).map(BackEndException::getErrorType).isPresent()){
			errorResponse.setErrorCode(exception.getErrorType());
		}		
		errorResponse.setMessage(
			message + (
				(exception.getCause() != null && StringUtils.isNoneEmpty(exception.getCause().getMessage()))
					? (": " + exception.getCause().getMessage()) : ""
			)
		);

		Status status = getStatusCode(exception);
		String entity = JsonUtil.getJsonString(errorResponse);

		return Response.status(status).entity(entity).build();
	}
}
