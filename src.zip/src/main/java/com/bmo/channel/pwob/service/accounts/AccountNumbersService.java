/**
 * 
 */
package com.bmo.channel.pwob.service.accounts;

import java.util.List;

/**
 * @author vvallia
 *
 */
public interface AccountNumbersService {

	ValidateAccountResponse validateAccount(String accountNumber,String iaCode, String rule);
}
