package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class FinancialInformation {

	@Valid
	private FinancialStatus status = new FinancialStatus();

	@Valid
	private FinancialWealth other = new FinancialWealth();

	@Valid
	private InvestmentExperience investment = new InvestmentExperience();

	public FinancialStatus getStatus() {
		return status;
	}
	public void setStatus(FinancialStatus status) {
		this.status = status;
	}

	public FinancialWealth getOther() {
		return other;
	}
	public void setOther(FinancialWealth other) {
		this.other = other;
	}

	public InvestmentExperience getInvestment() {
		return investment;
	}
	public void setInvestment(InvestmentExperience investmentExperience) {
		this.investment = investmentExperience;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
