#!/bin/bash
# different for each user
export USER=YOURUSERNAME
ENV=$1
SERVER="api-workflows"

if [ "$1" == "dev" ]
then
	ENV="bwa-bccldv"
	
elif [ "$1" == "dit1" ]
then
	ENV="bwa-bccld1"

elif [ "$1" == "dit2" ]
then
	ENV="bwa-bccld2"
	
elif [ "$1" == "sit3" ]
then
	ENV="bwa-bcclq3"
fi

if [ "$3" != "" ]
then
	SERVER=$3
fi
	
echo $USER@${ENV}app01.paas.bmogc.net
ssh  -t $USER@${ENV}app01.paas.bmogc.net sudo /home/$USER/search.sh $2 $SERVER

echo "************************************************************************"

echo $USER@${ENV}app02.paas.bmogc.net
ssh  -t $USER@${ENV}app02.paas.bmogc.net sudo /home/$USER/search.sh $2 $SERVER