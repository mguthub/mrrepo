package com.bmo.channel.pwob.validation.field;

import java.util.List;

import javax.validation.ConstraintValidatorContext;

import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintValidatorContextImpl;
import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintViolationCreationContext;
import org.springframework.stereotype.Component;

/**
 * A hack which to retrieve the field path, which the context does not provide.
 * Necessary because certain fields (eg. Name.firstName) have different validation
 * rules depending on context (saving, submitting) as well as who the 
 * data is for (applicant, spouse, etc)
 * @author Ryan Chambers (rcham02)
 */
@Component
public class FieldPathExtractorImpl implements FieldPathExtractor {

	@Override
	public String determineFieldPath(ConstraintValidatorContext context) {
		ConstraintValidatorContextImpl hibernateValidatorContext = (ConstraintValidatorContextImpl)context;
		List<ConstraintViolationCreationContext> constraintViolationCreationContexts = hibernateValidatorContext.getConstraintViolationCreationContexts();
		return stripOutIndexes(constraintViolationCreationContexts.get(0).getPath().toString());
	}

	/**
 	* strip out indexes in order to avoid having to specify every combination of applicants[0].accounts[1].beneficiaries[2] etc
	 * @param path original field path
	 * @return path with [0] replaced with []
	 */
	String stripOutIndexes(String path) {
		return path.replaceAll("\\d+", "");
	}
}
