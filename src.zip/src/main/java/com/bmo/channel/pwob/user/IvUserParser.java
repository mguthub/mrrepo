package com.bmo.channel.pwob.user;

public class IvUserParser {

	final private String ivUser;

	public IvUserParser(String ivUser) {
		this.ivUser = ivUser;
	}

	public ParseResult parse() {
		String[] split = ivUser.split("@");
		String fullyResolvedDomain = split[1];
		return new ParseResult(split[0], fullyResolvedDomain.substring(0, fullyResolvedDomain.indexOf(".")));
	}

	public static class ParseResult {
		final private String networkId;
		final private String domain;

		public ParseResult(String networkId, String domain) {
			this.networkId = networkId;
			this.domain = domain;
		}

		public String getNetworkId() {
			return networkId;
		}
		public String getDomain() {
			return domain;
		}
	}
}
