/**
 * @author akhales
 */
package com.bmo.channel.pwob.validation;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import javax.ws.rs.BadRequestException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.model.ia.BMApproval;
import com.bmo.channel.pwob.model.ia.IAApproval;
import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.product.ProductEligibility;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;

@Component
public class ValidationManager {
	public static final ThreadLocal<ValidationContextHolder> validationContext = new ThreadLocal<>();

	@Autowired
	private Validator validator;
	@Autowired
	private UsersService usersService;
	@Autowired
	private EventManager eventManager;

	private final static String APPLICATION_ID_PATTERN = "^[\\:\\.\\-\\d\\sA-Za-z]{1,36}$";
	private final static String PARTY_ID_PATTERN = "^[\\-\\d\\sA-Za-z]{1,36}$";
	private final static String ACCOUNT_ID_PATTERN = "^[\\-\\d\\sA-Za-z]{1,80}$";
	private final static String ACCOUNT_NUMBER_PATTERN = "^\\d{8}$";
	private final static String GATEWAY_USER_ID_PATTERN = "^[\\dA-Za-z]{9,30}$";
	private final static String EXISTING_GATEWAY_USER_ID_PATTERN = "^[\\dA-Za-z]{1,}$";

	private final static String LOCALE = "en-ca";

	/**
	 * Set up validation context so that LOB and action can be taken into consideration.
	 * @param model
	 */
	public <T> void validateModel(T model, ValidationContextHolder.Action action) {
		try {

			if(model.getClass().isAssignableFrom(Application.class)) {
				if(action == null) {
					throw new WebServiceException("action cannot be null");
				}
				setUpApplicationValidationContext((Application) model, action);		
			}
			if (model.getClass().isAssignableFrom(IAApproval.class)) {
				setUpGenericValidationContext();
			}
			if (model.getClass().isAssignableFrom(BMApproval.class)) {
				setUpGenericValidationContext();
			}

			Set<ConstraintViolation<T>> violations = this.validator.validate(model);
			if(!violations.isEmpty()) {
				if(action.equals(ValidationContextHolder.Action.SAVE)){
					StringBuilder sb = new StringBuilder("BadRequest: ");
					violations.stream().forEach(c->sb.append(c.getMessage() + " " + c.getPropertyPath() + " "));
					eventManager.publishWarn(sb.toString());
				}
				
				throw new ConstraintViolationException(violations);
			}
		} finally {
			validationContext.remove();
		}
	}
	
	public <T> void validateRelationshipSummaryModel(RelationshipSummary relationshipSummary, Application applicationContext) {
		if(!Optional.ofNullable(this.usersService.currentUser().getLob()).isPresent()) {
			throw new BadRequestException("bad workflow: application lob, ivuser, and locale must not be null");
		}
		ValidationContextHolder v = new ValidationContextHolder(applicationContext.getLocale(), applicationContext);
		validationContext.set(v);
		
		validateModel(relationshipSummary, ValidationContextHolder.Action.SAVE);
	}

	private void setUpGenericValidationContext() {
		if(!Optional.ofNullable(this.usersService.currentUser().getLob()).isPresent()) {
			throw new BadRequestException("bad workflow: application lob, ivuser, and locale must not be null");
		}
		ValidationContextHolder v = new ValidationContextHolder(LOCALE);
		validationContext.set(v);
	}

	private void setUpApplicationValidationContext(Application application, Action action) {
		if(!Optional.ofNullable(this.usersService.currentUser().getLob()).isPresent() || !Optional.ofNullable(application.getLocale()).isPresent()) {
			throw new ConstraintViolationException("bad workflow: application lob, ivuser, and locale must not be null", new HashSet<>());
		}
		ValidationContextHolder v = new ValidationContextHolder(application.getLocale(), action, application);
		validationContext.set(v);
	}

	public void validateProduct(List<Account> accounts, List<ProductEligibility> products) {
		Set<String> accountTypes = null;
		Set<String> eligibleProducts = null;

		if(CollectionUtils.isNotEmpty(accounts)) {
			accountTypes = accounts.stream().map(a -> a.getType()).collect(Collectors.toSet());
		}
		if(CollectionUtils.isNotEmpty(products)){
			eligibleProducts = products.stream().filter(p -> "true".equals(p.getEligible())).map(p -> p.getType()).collect(Collectors.toSet());
		}
		if(CollectionUtils.isNotEmpty(eligibleProducts) && CollectionUtils.isNotEmpty(accountTypes)) {
			for(String accountType : accountTypes) {
				if(!eligibleProducts.contains(accountType)) {
					throw new BadRequestException("Applicant is not eligible for " + accountType); 
				}
			}
		} else {
			throw new BadRequestException("No eligible Products"); 
		}
	}

	public void validateId(String id, IdType idType) {			
		if(!isValidField(id, idType)) {			
			throw new BadRequestException("Invalid Id");
		}
	}

	public enum IdType {
		Application(APPLICATION_ID_PATTERN),
		Party(PARTY_ID_PATTERN),
		PWOBGatewayUserId(GATEWAY_USER_ID_PATTERN),
		ExistingGatewayUserId(EXISTING_GATEWAY_USER_ID_PATTERN), 
		Account(ACCOUNT_ID_PATTERN),
		AccountNumber(ACCOUNT_NUMBER_PATTERN);

		private String pattern;

		private IdType(String pattern) {
			this.pattern = pattern;
		}

		public String getPattern() {
			return pattern;
		}
	}

	boolean isValidField(String id, IdType idType) {
		if(StringUtils.isBlank(id)) {
			return false;
		}

		return id.matches(idType.getPattern());
	}

	/**
	 * Validate model without specifying an action
	 * Is there a better way to do this?
	 * @param model
	 */
	public <T> void validateModel(T model) {
		validateModel(model, null);
	}	
}