package com.bmo.channel.pwob.service.authorization.nb;

public class RoleRequirement {
	private final UserRole roleLevelRequired;

	public RoleRequirement(UserRole roleLevelRequired) {
		this.roleLevelRequired = roleLevelRequired;
	}
	public UserRole getRoleLevelRequired() {
		return roleLevelRequired;
	}
}
