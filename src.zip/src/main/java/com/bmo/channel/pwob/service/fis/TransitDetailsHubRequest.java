package com.bmo.channel.pwob.service.fis;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TransitDetailsHubRequest {	
	private String InstitutionNumber;
	private String transitnumber;

	public TransitDetailsHubRequest(String InstitutionNumber, String transitnumber) {
		this.InstitutionNumber = InstitutionNumber;
		this.transitnumber = transitnumber;
	}

	@JsonProperty("InstitutionNumber")
	public String getInstitutionNumber() {
		return InstitutionNumber;
	}
	public void setInstitutionNumber(String InstitutionNumber) {
		this.InstitutionNumber = InstitutionNumber;
	}

	@JsonProperty("transitnumber")
	public String getTransitNumber() {
		return transitnumber;
	}
	public void setTransitNumber(String transitnumber) {
		this.transitnumber = transitnumber;
	}
}
