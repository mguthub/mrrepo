package com.bmo.channel.pwob.config;

import java.util.Arrays;

import org.dozer.DozerBeanMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.bmo.channel.core.mapping.dozer.DozerDataMapper;

@Configuration
public class DataMappingConfig {

	@Bean
	public DozerBeanMapper dozerMapper() {
		DozerBeanMapper dozerMapper = new DozerBeanMapper();
		dozerMapper.setMappingFiles(Arrays.asList(
				"META-INF/config/dozer/onboardApplication-to-applicationData-mapping.xml",
				"META-INF/config/dozer/risPrefill-to-onboardApplication.xml",
				"META-INF/config/dozer/person-to-party-mapping.xml",
				"META-INF/config/dozer/hubProduct-to-pwobProduct-mapping.xml"
				));
		return dozerMapper;
	}

	@Bean
	public DozerDataMapper dozerDataMapper(){
		return new DozerDataMapper(dozerMapper());
	}
}
