package com.bmo.channel.pwob.validation.region;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.reference.CountryReference;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.model.reference.StatProvReference;
import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.service.reference.ReferencesService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.verification.VerificationValidator;

public class CountryAndProvinceValidator extends AbstractBaseValidator implements ConstraintValidator<CountryAndProvince, Object> {
	
	private static Logger logger = LoggerFactory.getLogger(CountryAndProvinceValidator.class);
	
	@Autowired
	private ReferencesService referencesService;

	private String countryFieldName;
	private String provinceFieldName;

	@Override
	public void initialize(CountryAndProvince constraintAnnotation) {
		countryFieldName = constraintAnnotation.countryFieldName();
		provinceFieldName = constraintAnnotation.provinceFieldName();
	}

	@Override
	public boolean isValid(Object objectToValidate, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		String country;
		String province;
		try {
			country = BeanUtils.getProperty(objectToValidate, countryFieldName);
			province = BeanUtils.getProperty(objectToValidate, provinceFieldName);
			
		} catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
			logger.error("Failed to validate country: "+countryFieldName+" or province : "+provinceFieldName, ex);
			throw new WebServiceException(ex);
		}

		if(StringUtils.isBlank(country) && StringUtils.isBlank(province)) {
			return true;
		}

		boolean valid = true;
		if(!isValidCountry(country)) {
			this.createConstraintViolation(context, ErrorCodes.INVALID_COUNTRY, countryFieldName);	
			valid = false;
		}

		if(!isValidProvinceForCountry(country, province)) {
			this.createConstraintViolation(context, ErrorCodes.INVALID_PROVINCE, provinceFieldName);
			valid = false;
		}

		return valid;
	}

	boolean isValidProvinceForCountry(String country, String province) {
		Optional<Reference> countryReferenceOption = referencesService.ofType(ReferenceType.COUNTRIES, UILocale.EN_CA).stream().
			filter(c -> c.getCode().equalsIgnoreCase(country)).
			findFirst();
		if(countryReferenceOption.isPresent()) {
			CountryReference countryReference = (CountryReference)countryReferenceOption.get();
			if(!countryReference.getStateProvinces().isEmpty()) {
				List<StatProvReference> provinces =  countryReference.getStateProvinces();
				return provinces.stream().anyMatch(c -> c.getCode().equals(province));
			} else {
				return StringUtils.isBlank(province);
			}
		} else {
			return true;
		}
	}

	boolean isValidCountry(String country) {
		List<Reference> list = referencesService.ofType(ReferenceType.COUNTRIES,UILocale.EN_CA);
		return list.stream().anyMatch(c -> c.getCode().equals(country));
	}
}
