/**
 * @author vvallia
 * Validate the captured guarantee information
 */
package com.bmo.channel.pwob.validation.otherparties;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Guarantee;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;

/**
 * @author vvallia
 *
 */
@Component
public class GuaranteeValidator extends AbstractBaseValidator {
	public static final String GUARANTEE_ACCOUNT_NUMBER_FIELD_NAME = "guaranteeAccountNumber";
	public static final String GUARANTEE_RELATIONSHIP_FIELD_NAME = "guaranteeRelationship";

	public boolean isValid(Application application, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();	

		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		boolean valid = true;

		List<Guarantee> guarantees = application.getGuarantees();	

		List<String> validGuarantees = application.getGuarantees().stream().map(t -> t.getGuaranteeRefId()).collect(Collectors.toList());

		List<String> guaranteeClntRefIds;
		int guaranteeIndex;

		if(CollectionUtils.isNotEmpty(guarantees)){
			guaranteeIndex = 0;
			for (Guarantee guarantee : guarantees) {
				if(StringUtils.isNoneBlank(guarantee.getGuaranteeAccountNumber()) && 
					StringUtils.isBlank(guarantee.getRelationship())){
					this.createConstraintViolation(context, ErrorCodes.INVALID_GUARANTEE_RELATIONSHIP, "guarantees[" + guaranteeIndex + "].guaranteeRelationship");
					valid = false;
				}
				else if(StringUtils.isBlank(guarantee.getGuaranteeAccountNumber()) && 
					StringUtils.isNoneBlank(guarantee.getRelationship())){
					this.createConstraintViolation(context, ErrorCodes.INVALID_GUARANTEE_ACCOUNT_NUMBER, "guarantees[" + guaranteeIndex + "].guaranteeAccountNumber");
					valid = false;
				}
				else if(StringUtils.isBlank(guarantee.getGuaranteeAccountNumber()) && 
					StringUtils.isBlank(guarantee.getRelationship())){
					this.createConstraintViolation(context, ErrorCodes.INVALID_GUARANTEE_RELATIONSHIP, "guarantees[" + guaranteeIndex + "].guaranteeRelationship");
					this.createConstraintViolation(context, ErrorCodes.INVALID_GUARANTEE_ACCOUNT_NUMBER, "guarantees[" + guaranteeIndex + "].guaranteeAccountNumber");
					valid = false;
				}		
				guaranteeIndex++;
			}
		}

		List<Account> accounts = application.getAccounts();
		int accIndex = 0;
		for(Account account : accounts) {
			if(Optional.ofNullable(account.getAreOtherPartiesSpecified()).isPresent()) {
				if(account.getAreOtherPartiesSpecified() && account.isIndividual()){
					if(this.isMarginSubTypeSelected(account) && CollectionUtils.isNotEmpty(account.getGuaranteeRefIds()) && 
							accIndex < account.getGuaranteeRefIds().size()){
						
						guaranteeClntRefIds = account.getGuaranteeRefIds();

						String guaranteeClntRefId = guaranteeClntRefIds.get(accIndex);

						if (CollectionUtils.isNotEmpty(validGuarantees) && !validGuarantees.contains(guaranteeClntRefId)){
							createConstraintViolation(context,	ErrorCodes.INVALID_GUARANTEE_REF_MAPPING, 
									"accounts["	+ accIndex + "].guaranteeRefId");
							valid = false;
						}
					}
				}
			} 
			accIndex++;
		}

		return valid;
	}		
}