package com.bmo.channel.pwob.service.ia;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.BadRequestException;
import javax.xml.ws.Holder;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.convert.ConvertorService;
import com.bmo.channel.pwob.convert.WSBuilder;
import com.bmo.channel.pwob.exception.ExceptionUtils;
import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.ia.Approval;
import com.bmo.channel.pwob.model.ia.Approver;
import com.bmo.channel.pwob.model.ia.BMApproval;
import com.bmo.channel.pwob.model.ia.Client;
import com.bmo.channel.pwob.model.ia.ClientRelationship;
import com.bmo.channel.pwob.model.ia.Comment;
import com.bmo.channel.pwob.model.ia.IAApproval;
import com.bmo.channel.pwob.model.ia.IaAccount;
import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.AppStatus;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.RegulatoryDisclosures;
import com.bmo.channel.pwob.model.onboarding.Verification;
import com.bmo.channel.pwob.model.product.IaProduct;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.provider.ApplicationProperties;
import com.bmo.channel.pwob.service.GetWorkflowRequestBuilder;
import com.bmo.channel.pwob.service.applications.SavedApplicationsService;
import com.bmo.channel.pwob.service.authorization.PwobAction;
import com.bmo.channel.pwob.service.authorization.SecurityService;
import com.bmo.channel.pwob.service.product.ProductService;
import com.bmo.channel.pwob.service.product.rsclient.AccountType.FeeCodeList;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.service.workflow.OnboardApplicationRepository;
import com.bmo.channel.pwob.service.workflow.WorkflowService;
import com.bmo.channel.pwob.util.DateUtils;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;

import net.bmogc.xmlns.bmo._2002.header.BMOHdrRs;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.ApprovalResponse;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.BMApproveDetails;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.Event;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.EventDetails;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.GetResponse;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.IAApproveDetails;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.IABypassList;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.CallerType;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveRelationshipRequest;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveRelationshipRequest.Body;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveRelationshipRequest.Body.PayloadRelationship;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.ApplicationIntegrityException;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.InputViolationException;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.SystemException;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.WorkflowInitiationService;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice.types.v1.GetWorkflowDataRequest;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice.types.v1.GetWorkflowDataResponse;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice.types.v1.NotifyWorkflowRequest;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice.types.v1.NotifyWorkflowResponse;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RelationshipSummaryComment;

@Service
public class InternalApprovalsServiceImpl implements InternalApprovalsService {
	
	private static Logger logger = LoggerFactory.getLogger(InternalApprovalsServiceImpl.class);
	private static final String  WIS_LOG_EVENT_MESSAGE= "Failure in workflow HUB while processing event notification request for event:";
	
	public static final String SUBMITTED_STATUS = "submitted";
	public static final String REJECTED_STATUS = "reject";
	public static final String APPROVED_STATUS = "approve";	
	
	public static final String ERROR_CONFLICT = "409";	
	public static final String ERROR_BAD_REQUEST = "400";	
	
	
	
	@Autowired
	private ApplicationProperties applicationProperties;

	@Autowired
	private WorkflowInitiationService workflowHubClient;	
	
	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private UsersService usersService;

	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private SavedApplicationsService savedApplicationsService;
	
	@Autowired
	private OnboardApplicationRepository onboardApplicationRepository;	

	@Autowired
	private ConvertorService convertorService;
	
	@Autowired
	private ProductService productService;
	
	@Autowired
	private ValidationManager validationManager;

	protected static final String WIS_SERVICE_NAME = "WIS";
	protected static final String WIS_FUNCTION = "GetWorkflowData";
	private static final String WIS_NOTIFY_WORKFLOW_FUNCTION = "NW";

	private static final String COMMISSION = "commission";
	private static final String FEE_BASED = "fee-based";

	@Override
	public RelationshipSummary updateRelationshipSummary(RelationshipSummary relationshipSummary, String applicationId) {		
		
		SavedApplication savedApp =	savedApplicationsService.retrieveSavedApplication(applicationId);
		   
    	securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.UPDATE_RELATIONSHIP_SUMMARY);
    	
    	final RetrieveApplicationResponse appResponse = workflowService.retrieveApplicationResponse(applicationId, savedApp.getCustomerId());
    	
    	net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RelationshipSummary hubRelationshipSummary = convertorService.convertRelationshipSummary(relationshipSummary);
    	User user = usersService.currentUser();
    	if (StringUtils.isNotBlank(relationshipSummary.getComments()) && StringUtils.isNotBlank(hubRelationshipSummary.getComments().getComments())) {
    		hubRelationshipSummary.getComments().setFirstName(user.getFirstName());
    		hubRelationshipSummary.getComments().setLastName(user.getLastName());
    		hubRelationshipSummary.getComments().setNetworkId(user.getNetworkId());
    		hubRelationshipSummary.getComments().setRole(user.getJobFunction());
			hubRelationshipSummary.getComments().setDateTime(DateUtils.getTimestamp());
    	}else{
    		if(hubRelationshipSummary.getComments() == null){
    			hubRelationshipSummary.setComments(new RelationshipSummaryComment());
    		}
    		hubRelationshipSummary.getComments().setFirstName(user.getFirstName());
    		hubRelationshipSummary.getComments().setLastName(user.getLastName());
    		hubRelationshipSummary.getComments().setNetworkId(user.getNetworkId());
    		hubRelationshipSummary.getComments().setRole(user.getJobFunction());
			hubRelationshipSummary.getComments().setDateTime(DateUtils.getTimestamp());
    	}
    	
    	List<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> partyList=appResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData().getParties();
    	List<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> relSummPartyList = new ArrayList<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party>();
    	for (net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party party:partyList) {
    		net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party relSumParty = new net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party();
    		net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.PersonalInformation personalInformation = new net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.PersonalInformation();
    		net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RegulatoryDisclosures regulatoryDisclosures = new net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RegulatoryDisclosures();
    		Optional<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> affiliateParty = hubRelationshipSummary.getParties().stream().filter(p -> p.getPartyRefId().equals(party.getPartyRefId())).findFirst();
    		if(affiliateParty.isPresent()) {
    			relSumParty.setPartyRefId((affiliateParty.get().getPartyRefId()));
    			relSumParty.getRoles().addAll(affiliateParty.get().getRoles());    			
    			personalInformation.setLegalFirstName(affiliateParty.get().getPersonalInformation().getLegalFirstName());
				personalInformation.setLegalLastName(affiliateParty.get().getPersonalInformation().getLegalLastName());
				relSumParty.setPersonalInformation(personalInformation);
				if (Optional.ofNullable(affiliateParty.get())
						.map(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party::getRegulatoryDisclosures)
						.map(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RegulatoryDisclosures::getVerification)
						.isPresent()) {
					regulatoryDisclosures.setVerification(affiliateParty.get().getRegulatoryDisclosures().getVerification());
					relSumParty.setRegulatoryDisclosures(regulatoryDisclosures);
				}								
    		} else {
				relSumParty.setPartyRefId(party.getPartyRefId());
				relSumParty.getRoles().addAll(party.getRoles());				
				personalInformation.setLegalFirstName(party.getPersonalInformation().getLegalFirstName());
				personalInformation.setLegalLastName(party.getPersonalInformation().getLegalLastName());
				relSumParty.setPersonalInformation(personalInformation);
				if (Optional.ofNullable(party)
						.map(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party::getRegulatoryDisclosures)
						.map(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RegulatoryDisclosures::getVerification)
						.isPresent()) {
					regulatoryDisclosures.setVerification(party.getRegulatoryDisclosures().getVerification());
					relSumParty.setRegulatoryDisclosures(regulatoryDisclosures);
				}								
    		}
    		relSummPartyList.add(relSumParty);
    	}
    	hubRelationshipSummary.getParties().clear();
    	hubRelationshipSummary.getParties().addAll(relSummPartyList);

    	Application applicationContext = convertorService.getOnboardApplicationData(applicationId, appResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData(), savedApp.getAppStatus());

    	if(Optional.ofNullable(applicationContext).map(Application::getApplicationId).isPresent()) {
    		applicationContext.setStatus(savedApp.getAppStatus());	
		}
    	this.validationManager.validateRelationshipSummaryModel(relationshipSummary, applicationContext);
    	
    	SaveRelationshipRequest saveRequest = new SaveRelationshipRequest();
    	saveRequest.setBody(new Body());
		saveRequest.getBody().setApplicationID(applicationId);
		saveRequest.getBody().setEmployeeUserID(user.getUserId());
		saveRequest.getBody().setPayloadRelationship(new PayloadRelationship());
		
		saveRequest.getBody().getPayloadRelationship().setRelationshipData(hubRelationshipSummary);

		saveRequest.getBody().setLastUpdatedDateTime(appResponse.getBody().getLastUpdatedDateTime());
    	saveRequest.getBody().setAppStatus(appResponse.getBody().getAppStatus());
    	saveRequest.getBody().setCallerType(CallerType.OWM);

    	onboardApplicationRepository.saveRelationship(saveRequest);
    	return relationshipSummary;
	}

	@Override
	public IAApproval addNewIAApproval(IAApproval iaApproval, String workflowId) {		
		
		SavedApplication savedApp = this.savedApplicationsService.retrieveSavedApplication(workflowId);
		
		
		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.IA_APPROVAL);

		User user = getUser();
		
		Event iaApprovalEvent = new Event();
		EventDetails eventDetails = new EventDetails();
		IABypassList iaBypassList = new IABypassList();
		
		eventDetails.setUserId(user.getUserId());
		eventDetails.setComment(iaApproval.getComments());

		eventDetails.setDocumentEdits(iaApproval.getDocumentEdits());

		iaBypassList.getUserid().addAll(iaApproval.getIaBypassList());
		
		IAApproveDetails iaDetails = new IAApproveDetails();
		iaDetails.setApproveEvent(eventDetails);
		iaDetails.setIaBypassList(iaBypassList);
		iaDetails.setIsIALicenceConfirmed(iaApproval.getIsIALicenceConfirmed());
		iaApprovalEvent.setIaApprove(iaDetails);
		eventNotify(iaApprovalEvent, workflowId,savedApp.getAppStatus(),PwobAction.IA_APPROVAL);

		return iaApproval;
	}

	@Override
	public BMApproval addNewBMApproval(BMApproval bmApproval, String workflowId) {	
		
		SavedApplication savedApp = this.savedApplicationsService.retrieveSavedApplication(workflowId);
		
		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.BM_APPROVAL);		

		User user = getUser();

		Event bmApprovalEvent = new Event();
		EventDetails eventDetails = new EventDetails();
		BMApproveDetails bmApproveDetails = new BMApproveDetails();
		eventDetails.setUserId(user.getUserId());
		eventDetails.setComment(bmApproval.getComments());
		eventDetails.setDocumentEdits(bmApproval.getDocumentEdits());
		
		bmApproveDetails.setApproveEvent(eventDetails);
		bmApproveDetails.setIsIALicenceConfirmed(bmApproval.getIsIALicenceConfirmed());
		if(bmApproval.getStatus().equals(APPROVED_STATUS)){
			bmApprovalEvent.setBmApprove(bmApproveDetails);
		}
		else if(bmApproval.getStatus().equals(REJECTED_STATUS)){
			bmApprovalEvent.setReject(eventDetails);
		}
		else{
			throw new BadRequestException("Bad Action");
		}

		eventNotify(bmApprovalEvent, workflowId,savedApp.getAppStatus(),PwobAction.BM_APPROVAL);

		return bmApproval;
	}

	@Override
	public RelationshipSummary getInitialRelationshipSummary(String workflowId) {		
		SavedApplication savedApp = this.savedApplicationsService.retrieveSavedApplication(workflowId);
		
		//securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.RETRIEVE_RELATIONSHIP_SUMMARY);
		
		securityService.authorizeReadAccess(savedApp.getIaCode());
		
		RetrieveApplicationResponse retResponse= workflowService.retrieveApplicationResponse(workflowId, savedApp.getCustomerId());
		
		Application workflow = workflowService.deriveWorkflow(retResponse,savedApp.getAppStatus());
		Approval approval= getIAApprovals(workflowId); 
		RelationshipSummary summary = deriveRelationshipSummary(retResponse, workflow, approval);
		
		return summary;
	}

	private RelationshipSummary deriveRelationshipSummary(RetrieveApplicationResponse response, Application workflow, Approval approval) {
		RelationshipSummary summary;
		
		List<IaProduct> iaProducts= productService.populateFeeCodeList(workflow);
		
		Set<String> eligibleProductTypes=null;
		
		if(Optional.ofNullable(response.getBody().getPayloadRelationship()).isPresent() && response.getBody().getPayloadRelationship().getRELATIONSHIPDATA().getRelationshipData() != null && !AppStatus.ACCOUNT_SETUP.toString().equals(workflow.getStatus())) {
			summary = convertorService.convertHubRelationshipSummary(response.getBody().getPayloadRelationship().getRELATIONSHIPDATA().getRelationshipData(), workflow);
		}
		else{
			summary = new RelationshipSummary();
			Client client = new Client();
			ClientRelationship relationship = new ClientRelationship();
			List<IaAccount> accounts = new ArrayList<>();

			client.setRelationship(relationship);
			summary.setClient(client);
			
			List<Party> relSumParties = workflow.getParties().stream()
					.filter(p -> (p.getRoles().contains(PartyRole.PRIMARY_APPLICANT)
							|| p.getRoles().contains(PartyRole.JOINT_APPLICANT)
							|| p.getRoles().contains(PartyRole.TRADING_AUTHORITY))
							&& Optional.ofNullable(p).map(Party::getRegulatoryDisclosures)
									.map(RegulatoryDisclosures::getVerification)
									.map(Verification::getIdVerificationMethod).isPresent()
							&& RefDataValues.ID_VERIFICATION_METHOD_AFFILIATE
									.equals(p.getRegulatoryDisclosures().getVerification().getIdVerificationMethod()))
					.collect(Collectors.toList());			

			summary.setParties(relSumParties);
			for(Account account: workflow.getAccounts()){
				IaAccount iaAccount = new IaAccount();
				iaAccount.setAccountNumber(account.getAccountNumber());				
				
				if(!account.isIndividual())
				{
					if(CollectionUtils.isNotEmpty(iaProducts)){
						eligibleProductTypes=iaProducts.stream().map(a->a.getType()).collect(Collectors.toSet());
					}
					if(CollectionUtils.isNotEmpty(eligibleProductTypes) && eligibleProductTypes.contains(account.getType())){
						Optional<IaProduct> iaProduct= iaProducts.stream().filter(a->a.getType().equalsIgnoreCase(account.getType())).findFirst();
						if(iaProduct.isPresent()){
							Optional<FeeCodeList> commissionFeeCodes= iaProduct.get().getFeeCodes().stream().filter(f->f.getType().equalsIgnoreCase(COMMISSION)).findFirst();
							if(commissionFeeCodes.isPresent())
								iaAccount.setCommissionFeeCodes(commissionFeeCodes.get().getFeeCode());
							Optional<FeeCodeList> feeBasedCodes=iaProduct.get().getFeeCodes().stream().filter(f->f.getType().equalsIgnoreCase(FEE_BASED)).findFirst();
							if(feeBasedCodes.isPresent())
								iaAccount.setFeeBasedCodes(feeBasedCodes.get().getFeeCode());
						}
					}
				} 
				iaAccount.setRef(account);			
				accounts.add(iaAccount);
			}
			summary.setAccounts(accounts);
		}				
		summary.setDocumentEdits(approval.getDocumentEdits());

		return summary;
	}

	@Override
	public Approval getIAApprovals(String workflowId) {
		GetWorkflowDataRequest req = 
				GetWorkflowRequestBuilder.builder(workflowId, applicationProperties.getWorkflowTemplateId(), applicationProperties.getWorkflowVersion())
				.getIaApprovals().build();
		GetResponse getResponse = getWorkflowData(req);
		ApprovalResponse approvalResponse = getResponse.getApproval();
		return convertApprovalResponse(approvalResponse);
	}

	private GetResponse getWorkflowData(GetWorkflowDataRequest req) {
		try {
			GetWorkflowDataResponse resp = workflowHubClient.getWorkflowData(req, WSBuilder.build(WIS_SERVICE_NAME, WIS_FUNCTION), new Holder<BMOHdrRs>());
			return resp.getBody().getPayload().getGetResponse();
		} catch (InputViolationException e) {
			logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(),e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
    	}
    	catch (ApplicationIntegrityException e) {
    		logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
    		throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}
		catch (SystemException e) {
    		logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
    		throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}
	}

	@Override
	public Approval getBMApprovals(String workflowId) {
		GetWorkflowDataRequest req = 
				GetWorkflowRequestBuilder.builder(workflowId, applicationProperties.getWorkflowTemplateId(), applicationProperties.getWorkflowVersion())
				.getBmApprovals().build();
		GetResponse getResponse = getWorkflowData(req);

		ApprovalResponse approvalResponse = getResponse.getApproval();
		return convertApprovalResponse(approvalResponse);
	}
	
	private User getUser() {
		return usersService.currentUser();
	}
	
	private Approval convertApprovalResponse(ApprovalResponse response){
		Approval approval = new Approval();
		List<Comment> comments = new ArrayList<>();
		List<Approver> approvers = new ArrayList<>();
		
		if(response.getComments() != null){
			for(net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.Comment comment: response.getComments().getComment()){
				Comment approvalComment = new Comment();
				approvalComment.setAction(comment.getAction());
				approvalComment.setComment(comment.getComment());
				approvalComment.setDateTime(comment.getDateTime().toString());
				approvalComment.setFirstName(comment.getFirstName());
				approvalComment.setLastName(comment.getLastName());
				approvalComment.setUserid(comment.getUserid());
				comments.add(approvalComment);
			}
		}
		if(response.getApprovers() != null){
			for(net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.Approver approver: response.getApprovers().getApprover()){
				Approver approvalApprover = new Approver();
				approvalApprover.setApproved(approver.isApproved());
				approvalApprover.setFirstName(approver.getFirstName());
				approvalApprover.setLastName(approver.getLastName());
				approvalApprover.setUserid(approver.getUserid().toUpperCase());
				
				approvalApprover.setActionType(approver.getAction().getActionType().value());
				approvalApprover.setByPassedBy(approver.getAction().getBypassedBy());

				if (Optional.ofNullable(approver.getAction().getBmApprovalDateTime()).isPresent()) {
					approvalApprover.setBmApprovalDateTime(approver.getAction().getBmApprovalDateTime().toString());
				}
				if (Optional.ofNullable(approver.getAction().getDateTime()).isPresent()) {
					approvalApprover.setTimeOfApproval(approver.getAction().getDateTime().toString());
				}
				approvers.add(approvalApprover);
			}
		}
		
		approval.setApprovers(approvers);
		approval.setComments(comments);
		approval.setDocumentEdits(response.getDocumentEdits());
		return approval;
	}

	private void eventNotify(Event event, String workflowId,String applicationStatus, PwobAction action) {
		try {
			NotifyWorkflowRequest.Body body = new NotifyWorkflowRequest.Body();

			body.setWorkflowId(workflowId);
			if (applicationProperties !=null) {
				body.setWorkflowTemplateId(applicationProperties.getWorkflowTemplateId());
				body.setVersion(applicationProperties.getWorkflowVersion());
			}

			body.setPayload(this.getNotifyPayLoad(event));
			NotifyWorkflowRequest notifyWorkflowRequest = new NotifyWorkflowRequest();
			notifyWorkflowRequest.setBody(body);

			NotifyWorkflowResponse response = workflowHubClient.notifyWorkflow(notifyWorkflowRequest, WSBuilder.build(WIS_SERVICE_NAME, WIS_NOTIFY_WORKFLOW_FUNCTION), new Holder<BMOHdrRs>());

			if (response == null) {
				logger.warn("HUB response is null.");
				throw new WebServiceException("HUB response is null");
			}

			if (response.getBody() !=null && response.getBody().getFailure() !=null) { 

				logger.warn("HUB response failure , Message:"+response.getBody().getFailure().getMessage());
				logger.error("HUB response failure , Message::"+response.getBody().getFailure().getMessage());
				logger.error("HUB response failure , Message::"+response.getBody().getFailure().getCode());

				if(response.getBody().getFailure().getCode() != null && (ERROR_CONFLICT.equals(response.getBody().getFailure().getCode()) || ERROR_BAD_REQUEST.equals(response.getBody().getFailure().getCode()))){
					throw ExceptionUtils.buildStatusExceptionForActionNotAllowedContext(action.toString(),applicationStatus);					
				}
				throw new WebServiceException(response.getBody().getFailure().getMessage());
			}
		}  catch (SystemException e) {
			logger.error(WIS_LOG_EVENT_MESSAGE+event,workflowId,e);
			logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}  catch (InputViolationException e) {
			logger.error(WIS_LOG_EVENT_MESSAGE+event,workflowId,e);
			logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}  catch (ApplicationIntegrityException e) {
			logger.error(WIS_LOG_EVENT_MESSAGE+event,workflowId,e);
			logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
	}
		return;
	}
	
	private NotifyWorkflowRequest.Body.Payload getNotifyPayLoad(Event event) {
		NotifyWorkflowRequest.Body.Payload payload = new NotifyWorkflowRequest.Body.Payload();
		payload.setEvent(event);

		return payload;
    }
}