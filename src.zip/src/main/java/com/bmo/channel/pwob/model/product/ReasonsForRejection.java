package com.bmo.channel.pwob.model.product;

import java.util.ArrayList;
import java.util.List;

/**
 * @author vvallia
 *
 */
public class ReasonsForRejection {

	 protected List<Message> msg;
	 
	 public List<Message> getMsg() {
         if (msg == null) {
             msg = new ArrayList<>();
         }
         return this.msg;
     }
	 public void setMsg(List<Message> msg) {
         if (msg == null) {
             this.msg = new ArrayList<>();
         }
         else{
        	 this.msg = msg;
         }
     }

}
