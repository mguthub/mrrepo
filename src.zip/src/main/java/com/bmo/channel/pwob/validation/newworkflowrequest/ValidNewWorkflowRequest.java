package com.bmo.channel.pwob.validation.newworkflowrequest;

import static java.lang.annotation.ElementType.TYPE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.bmo.channel.pwob.validation.ErrorCodes;

@Documented
@Constraint(validatedBy = NewWorkflowRequestValidator.class)
@Target({ TYPE })
@Retention(RUNTIME)
public @interface ValidNewWorkflowRequest{
	String message() default ErrorCodes.INVALID_NEW_WORKFLOW_REQUEST;
	Class<?>[] groups() default {};
	Class<? extends Payload>[] payload() default {};
}
