package com.bmo.channel.pwob.service.applications;

@FunctionalInterface
public interface NextStepsFunction<SavedApplication, RetrieveApplicationResponse, NextStepsData> {

	public NextStepsData apply(SavedApplication savedApp, RetrieveApplicationResponse response);

}
