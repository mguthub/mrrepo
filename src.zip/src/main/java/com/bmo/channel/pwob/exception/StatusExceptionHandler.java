package com.bmo.channel.pwob.exception;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.commons.lang3.StringUtils;

import com.bmo.channel.core.event.MessageEvent;
import com.bmo.channel.core.exception.AbstractExceptionHandler;
import com.bmo.channel.core.exception.ErrorResponse;
import com.bmo.channel.core.mapping.DataMapper;
import com.bmo.channel.core.util.JsonUtil;

public class StatusExceptionHandler extends AbstractExceptionHandler implements ExceptionMapper<PwobStatusException> {
	public StatusExceptionHandler(DataMapper dataMapper) {
		super(dataMapper);
	}

	@Override
	public Response toResponse(PwobStatusException exception) {
		MessageEvent messageEvent = getEventManager().publishError(exception);

		String message = exception.getMessage();

		ErrorResponse errorResponse = getDataMapper().map(messageEvent, ErrorResponse.class);
		if(PwobStatusException.ErrorType.staleData == exception.getErrorType()) {
			errorResponse.setErrorCode("10006");
		} else if(PwobStatusException.ErrorType.actionNotAllowed == exception.getErrorType()) {
			errorResponse.setErrorCode("10005");
		}
		errorResponse.setMessage(
			message + (
				(exception.getCause() != null && StringUtils.isNoneEmpty(exception.getCause().getMessage()))
					? (": " + exception.getCause().getMessage()) : ""
			)
		);

		Status status = getStatusCode(exception);
		String entity = JsonUtil.getJsonString(errorResponse);

		return Response.status(status).entity(entity).build();
	}
}
