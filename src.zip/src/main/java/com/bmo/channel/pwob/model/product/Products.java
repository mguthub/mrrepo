package com.bmo.channel.pwob.model.product;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Products {
    protected List<ProductEligibility> productEligibilities;
    protected ApplicationEligibility applicationEligibility;

    public List<ProductEligibility> getProductEligibilities() {
        if (productEligibilities == null) {
        	productEligibilities = new ArrayList<>();
        }
        return this.productEligibilities;
    }

    public void setProductEligibilities(List<ProductEligibility> productEligibilities) {
       	this.productEligibilities = productEligibilities;
    }

    public ApplicationEligibility getApplicationEligibility() {
        return applicationEligibility;
    }
    public void setApplicationEligibility(ApplicationEligibility value) {
        this.applicationEligibility= value;
    }

    @Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
