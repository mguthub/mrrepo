package com.bmo.channel.common.ehcache;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.springframework.cache.ehcache.EhCacheCacheManager;

public abstract class AbstractEhCache {
	private Map<String,String> cacheNames;
	private EhCacheCacheManager ehCacheManager;
	
	public void initializeEhCache(EhCacheCacheManager ehCacheManager) {
		 if (this.ehCacheManager == null)
			  this.init(ehCacheManager);
		 
	}

	private void init (EhCacheCacheManager ehCacheManager) {
		if (ehCacheManager==null)
			return;
		
		if (MapUtils.isNotEmpty(cacheNames))
			return;

		Collection<String> cacheCollection = ehCacheManager.getCacheNames();
		if (CollectionUtils.isNotEmpty(cacheCollection)) {
			cacheNames = new HashMap<>();
			 for (String item:cacheCollection) {
				 cacheNames.put(item, item);
			 }
		}

		this.ehCacheManager = ehCacheManager;
	}

	/**
	 *  Creates a composite key to be used when element is added or retrieved. Enum WFCacheKey + "your Id" 
	 * @param id
	 * @param key
	 * @return WFCachekey + id 
	 */

	String initialKey(String id,final String key) {
		StringBuilder sbk = new StringBuilder();
		sbk.append(key).append(id);

		return sbk.toString();
	}

	public EhCacheCacheManager getEhCacheManager() {
		return ehCacheManager;
	}

	public Map<String,String> getCachNames() {
		return cacheNames;
	}
}
