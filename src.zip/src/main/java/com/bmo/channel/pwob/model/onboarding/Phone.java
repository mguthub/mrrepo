/**
 * Model for Angular UI onboardingFormData
 * @author akhales
 */

package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.fasterxml.jackson.annotation.JsonInclude;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Phone {

	@ApiModelProperty(example="1234567890", value="10 digits only")
	@DataValidationPattern(code=ErrorCodes.INVALID_PHONE)
	private String  phoneNumber;
	
	@ApiModelProperty(example="1234", value="0-4 digits only")
	@DataValidationPattern(code=ErrorCodes.INVALID_PHONE_EXT)
	private String phoneExtension;
	
	@ApiModelProperty(example="1", value="TBD")
	@DataValidationPattern(code=ErrorCodes.INVALID_PHONE_EXT)
	private String countryCode;
	
	private Boolean isInternationalNumber;
	
	private Boolean mobile;

	public Boolean getMobile() {
		return mobile;
	}
	public void setMobile(Boolean mobile) {
		this.mobile = mobile;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getPhoneExtension() {
		return phoneExtension;
	}
	public void setPhoneExtension(String phoneExtension) {
		this.phoneExtension = phoneExtension;
	}

	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public Boolean getIsInternationalNumber() {
		return isInternationalNumber;
	}
	public void setIsInternationalNumber(Boolean isInternationalNumber) {
		this.isInternationalNumber = isInternationalNumber;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
