package com.bmo.channel.pwob.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.ByAccess;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.GetStatusRequest;
import net.bmogc.xmlns.hub.cg.ds.workflowstatusservice.types.v1.Visibility;


@JsonInclude(JsonInclude.Include.NON_NULL)
public class GetStatusRequestWrapper {

    @JsonProperty("Body")
    protected BodyWrapper body;

    /**
     * Gets the value of the body property.
     *
     * @return
     *     possible object is
     *     {@link BodyWrapper }
     *
     */
    public BodyWrapper getBody() {
        return body;
    }

    /**
     * Sets the value of the body property.
     *
     * @param value
     *     allowed object is
     *     {@link GetStatusRequest.Body }
     *
     */
    public void setBody(BodyWrapper value) {
        this.body = value;
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class BodyWrapper {

        protected BodyWrapper.ByCustomer byCustomer;
        protected BodyWrapper.ByWorkflow byWorkflow;
        protected ByAccess byAccess;
        protected String detailsLevel;
        protected String firstName;
        protected String lastName;
        protected String workflowType;
        protected String workflowStatus;
        protected String attribute1;
        protected String attribute2;
        protected String attribute3;
        protected String attribute4;
        protected String pageSize;
        protected String pageNumber;

        /**
         * Gets the value of the byCustomer property.
         *
         * @return
         *     possible object is
         *     {@link BodyWrapper.ByCustomer }
         *
         */
        public BodyWrapper.ByCustomer getByCustomer() {
            return byCustomer;
        }

        /**
         * Sets the value of the byCustomer property.
         *
         * @param value
         *     allowed object is
         *     {@link BodyWrapper.ByCustomer }
         *
         */
        public void setByCustomer(BodyWrapper.ByCustomer value) {
            this.byCustomer = value;
        }

        /**
         * Gets the value of the byWorkflow property.
         *
         * @return
         *     possible object is
         *     {@link BodyWrapper.ByWorkflow }
         *
         */
        public BodyWrapper.ByWorkflow getByWorkflow() {
            return byWorkflow;
        }

        /**
         * Sets the value of the byWorkflow property.
         *
         * @param value
         *     allowed object is
         *     {@link BodyWrapper.ByWorkflow }
         *
         */
        public void setByWorkflow(BodyWrapper.ByWorkflow value) {
            this.byWorkflow = value;
        }

        /**
         * Gets the value of the byAccess property.
         *
         * @return
         *     possible object is
         *     {@link ByAccess }
         *
         */
        public ByAccess getByAccess() {
            return byAccess;
        }

        /**
         * Sets the value of the byAccess property.
         *
         * @param value
         *     allowed object is
         *     {@link ByAccess }
         *
         */
        public void setByAccess(ByAccess value) {
            this.byAccess = value;
        }

        /**
         * Gets the value of the detailsLevel property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getDetailsLevel() {
            return detailsLevel;
        }

        /**
         * Sets the value of the detailsLevel property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setDetailsLevel(String value) {
            this.detailsLevel = value;
        }

        /**
         * Gets the value of the firstName property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getFirstName() {
            return firstName;
        }

        /**
         * Sets the value of the firstName property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setFirstName(String value) {
            this.firstName = value;
        }

        /**
         * Gets the value of the lastName property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getLastName() {
            return lastName;
        }

        /**
         * Sets the value of the lastName property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setLastName(String value) {
            this.lastName = value;
        }

        /**
         * Gets the value of the workflowType property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getWorkflowType() {
            return workflowType;
        }

        /**
         * Sets the value of the workflowType property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setWorkflowType(String value) {
            this.workflowType = value;
        }

        /**
         * Gets the value of the workflowStatus property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getWorkflowStatus() {
            return workflowStatus;
        }

        /**
         * Sets the value of the workflowStatus property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setWorkflowStatus(String value) {
            this.workflowStatus = value;
        }

        /**
         * Gets the value of the attribute1 property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getAttribute1() {
            return attribute1;
        }

        /**
         * Sets the value of the attribute1 property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setAttribute1(String value) {
            this.attribute1 = value;
        }

        /**
         * Gets the value of the attribute2 property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getAttribute2() {
            return attribute2;
        }

        /**
         * Sets the value of the attribute2 property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setAttribute2(String value) {
            this.attribute2 = value;
        }

        /**
         * Gets the value of the attribute3 property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getAttribute3() {
            return attribute3;
        }

        /**
         * Sets the value of the attribute3 property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setAttribute3(String value) {
            this.attribute3 = value;
        }

        /**
         * Gets the value of the attribute4 property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getAttribute4() {
            return attribute4;
        }

        /**
         * Sets the value of the attribute4 property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setAttribute4(String value) {
            this.attribute4 = value;
        }

        /**
         * Gets the value of the pageSize property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getPageSize() {
            return pageSize;
        }

        /**
         * Sets the value of the pageSize property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setPageSize(String value) {
            this.pageSize = value;
        }

        /**
         * Gets the value of the pageNumber property.
         *
         * @return
         *     possible object is
         *     {@link String }
         *
         */
        public String getPageNumber() {
            return pageNumber;
        }

        /**
         * Sets the value of the pageNumber property.
         *
         * @param value
         *     allowed object is
         *     {@link String }
         *
         */
        public void setPageNumber(String value) {
            this.pageNumber = value;
        }

        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class ByCustomer {

            protected String customerId;
            protected Visibility visibility;

            /**
             * Gets the value of the customerId property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getCustomerId() {
                return customerId;
            }

            /**
             * Sets the value of the customerId property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setCustomerId(String value) {
                this.customerId = value;
            }

            /**
             * Gets the value of the visibility property.
             *
             * @return
             *     possible object is
             *     {@link Visibility }
             *
             */
            public Visibility getVisibility() {
                return visibility;
            }

            /**
             * Sets the value of the visibility property.
             *
             * @param value
             *     allowed object is
             *     {@link Visibility }
             *
             */
            public void setVisibility(Visibility value) {
                this.visibility = value;
            }

        }

        @JsonInclude(JsonInclude.Include.NON_NULL)
        public static class ByWorkflow {

            protected String workflowTemplateId;
            protected String workflowId;

            /**
             * Gets the value of the workflowTemplateId property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getWorkflowTemplateId() {
                return workflowTemplateId;
            }

            /**
             * Sets the value of the workflowTemplateId property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setWorkflowTemplateId(String value) {
                this.workflowTemplateId = value;
            }

            /**
             * Gets the value of the workflowId property.
             *
             * @return
             *     possible object is
             *     {@link String }
             *
             */
            public String getWorkflowId() {
                return workflowId;
            }

            /**
             * Sets the value of the workflowId property.
             *
             * @param value
             *     allowed object is
             *     {@link String }
             *
             */
            public void setWorkflowId(String value) {
                this.workflowId = value;
            }

        }

    }

}

