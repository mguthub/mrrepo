/**
dup * @author nagamo
 */
package com.bmo.channel.pwob.validation.account.beneficiary;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Beneficiary;
import com.bmo.channel.pwob.model.onboarding.Name;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.NameValidator;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

public class BeneficiaryValidator extends AbstractBaseValidator implements ConstraintValidator<ValidBeneficiary, Beneficiary> {
	public static final String RELATIONSHIP_PATTERN = "[a-zA-Z-'àâäçéèêëîïôöûùüÿœÀÂÄÉÈÊËÎÏÔÖÙÛÜŸÇ’\\s]*{2,50}$";

	@Autowired
	private ValidationRequestFactory validationRequestFactory;

	@Autowired
	private UsersService userService;		

	@Autowired
	private NameValidator nameValidator;

	@Override
	public void initialize(ValidBeneficiary constraintAnnotation) {	
		// none requird
	}

	@Override
	public boolean isValid(Beneficiary beneficiary, ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();		

		ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).build();
				
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		Application app = validationContext.getApplication();
		List<Beneficiary> beneficiaries = app.getBeneficiaries();
		
		boolean valid = true;		
		
		valid = validateSin(beneficiary.getSocialInsuranceNumber(), request) && valid;
		valid = validateRelationshipToPlanHolder(beneficiary.getRelationshipToPlanHolder(),request) && valid;
		valid = validateBeneficiaryRefId(beneficiary.getBeneficiaryRefId(),request) && valid;
		valid = checkDuplicateRefId(beneficiary.getBeneficiaryRefId(), beneficiaries, request) && valid;
		
		if(this.isValidSpouse(app.getPrimaryApplicant().getPersonal().getIdentity().getMaritalStatus())){
			valid = validateHasPrimaryApplicantSpouse(beneficiary.getHasPrimaryApplicantSpouse(), request) && valid;
		}					
		
		valid = validateName(beneficiary.getName(), request) && valid;
		return valid;
	}

	private boolean validateName(Name name, ValidationRequest request) {
		boolean valid = true;
		ValidationRequest nameValReq = request.createChildValidationRequest(NAME_PATH, null);

		if(name == null ) {
			nameValReq.addConstraintViolation(FIRST_NAME_FIELD_NAME, ErrorCodes.INVALID_FIRST_NAME);
			nameValReq.addConstraintViolation(LAST_NAME_FIELD_NAME, ErrorCodes.INVALID_LAST_NAME);
	
			valid = false;
		} else {			
			valid = nameValidator.validateFirstName(name, nameValReq) && valid;
			valid = nameValidator.validateLastName(name, nameValReq) && valid;
		}
		return valid;
	}

	private boolean validateSin(String sin, ValidationRequest request) {
		
		if(StringUtils.isNoneBlank(sin) && !this.verifySinPattern(sin)){			
			request.addConstraintViolation(SIN_FIELD_NAME, ErrorCodes.INVALID_SIN);
			return false;
		} 
		return true;		
	}

	private boolean validateRelationshipToPlanHolder(String relationshipToPlanHolder, ValidationRequest request) {
		if(StringUtils.isBlank(relationshipToPlanHolder) || !this.doesPatternMatch(relationshipToPlanHolder, RELATIONSHIP_PATTERN)) {			
			request.addConstraintViolation("relationshipToPlanHolder", ErrorCodes.INVALID_RELATIONSHIP_TO_PLAN_HOLDER);
			return false;
		} 
		return true;		
	}		
	
	private boolean validateHasPrimaryApplicantSpouse(Boolean hasPrimaryApplicantSpouse,ValidationRequest validationRequest) {
		if(!Optional.ofNullable(hasPrimaryApplicantSpouse).isPresent()) {			
			validationRequest.addConstraintViolation("hasPrimaryApplicantSpouse", ErrorCodes.INVALID_HAS_PRIMARY_APPLICANT_SPOUSE);
			return false;
		} 
		return true;		
	}
	
	private boolean validateBeneficiaryRefId(String beneficiaryRefId,ValidationRequest validationRequest) {
		if(StringUtils.isBlank(beneficiaryRefId)) {			
			validationRequest.addConstraintViolation("beneficiaryRefId", ErrorCodes.INVALID_BENEFICIARY_REF_ID);
			return false;
		} 
		return true;		
	}
	private boolean checkDuplicateRefId(String beneficiaryRefId, List<Beneficiary> beneficiaries,ValidationRequest request) {
		if(CollectionUtils.isNotEmpty(beneficiaries) && 
				beneficiaries.stream().filter(t->t.getBeneficiaryRefId()!=null && t.getBeneficiaryRefId().equals(beneficiaryRefId)).collect(Collectors.toList()).size() > 1){			
			request.addConstraintViolation("", ErrorCodes.INVALID_BENEFICIARY_REF_ID);
			return false;
		}
		return true;
	}		
}
