package com.bmo.channel.pwob.convert;

import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.dozer.DozerConverter;

import com.bmo.channel.pwob.model.onboarding.Phone;

import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.PhoneNumber;

public class PhoneNumberCustomConverter extends DozerConverter<Phone, PhoneNumber>{
	public PhoneNumberCustomConverter() {
		super(Phone.class, PhoneNumber.class);
	}

	@Override
	public PhoneNumber convertTo(Phone source, PhoneNumber destination) {
		destination = new PhoneNumber();
		if(source != null) {
			if(StringUtils.isNotBlank(source.getPhoneNumber())){
				destination.setAreaCode(source.getPhoneNumber().substring(0,3));
				destination.setPhoneNumber(source.getPhoneNumber().substring(3));
			}

			if(StringUtils.isNotBlank(source.getPhoneExtension())){
				destination.setExtension(source.getPhoneExtension());
			}
			if(StringUtils.isNotBlank(source.getCountryCode())){
				destination.setCountryCode(source.getCountryCode());
			}
			if(Optional.ofNullable(source.getIsInternationalNumber()).isPresent()){
				destination.setIsInternationalNumber(source.getIsInternationalNumber());
			}					
		}
		return destination;
	}

	@Override
	public Phone convertFrom(PhoneNumber source, Phone destination) {
		destination = new Phone();
		if(source != null){
			if(StringUtils.isNotBlank(source.getAreaCode()) && StringUtils.isNotBlank(source.getPhoneNumber())){
				destination.setPhoneNumber(source.getAreaCode()+source.getPhoneNumber());
			}

			if(StringUtils.isNotBlank(source.getExtension())){
				destination.setPhoneExtension(source.getExtension());
			}
			if(StringUtils.isNotBlank(source.getCountryCode())){
				destination.setCountryCode(source.getCountryCode());
			}
			if(Optional.ofNullable(source.isIsInternationalNumber()).isPresent()){
				destination.setIsInternationalNumber(source.isIsInternationalNumber());
			}	
		}
		return destination;
	}
}
