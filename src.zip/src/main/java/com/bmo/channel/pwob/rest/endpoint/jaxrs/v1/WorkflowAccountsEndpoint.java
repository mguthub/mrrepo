package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.service.accounts.AccountsService;
import com.bmo.channel.pwob.service.workflow.WorkflowService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/**
 * Workflows sub-route for accounts
 * @author Ryan Chambers (rcham02)
 */
@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Path(WorkflowsEndpoint.V1_PATH + "/{id}/accounts")
@Api(WorkflowsEndpoint.V1_PATH + "/{id}/accounts")
public class WorkflowAccountsEndpoint {
	@SuppressWarnings("unused")
	private Logger logger = LoggerFactory.getLogger(WorkflowAccountsEndpoint.class);

	@Autowired
	private AccountsService accountsService;

	@Autowired
	private WorkflowService workflowService;

    @ApiOperation(value="Create a new account of specified type", response=Account.class, nickname="createAccount")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
    @ApiResponses(value={
            @ApiResponse(code=500, message="Internal server error"), 
            @ApiResponse(code=401, message="User cannot be identified"),
            @ApiResponse(code=400, message="Bad request")})
	@POST
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	public Response create(
			@ApiParam(value = "Application ID") @PathParam("id") String applicationId,
			@NotNull CreateAccountRequest request) {
		Account account = accountsService.createAccount(request);
		return Response.ok(account).build();
	}

    @ApiOperation(value="Remove an account (and possibly applicant) from the application", response=Application.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
    @ApiResponses(value={
            @ApiResponse(code=500, message="Internal server error"), 
            @ApiResponse(code=401, message="User cannot be identified"),
            @ApiResponse(code=400, message="Bad request"),
            @ApiResponse(code=404, message="Application or Account Not found")})
	@DELETE
	@Path("/{accountRefId}")
	public Response remove(
			@ApiParam(value = "Application ID") @PathParam("id") String applicationId,
			@ApiParam(value = "Account ref ID to be deleted") @PathParam("accountRefId") String accountRefId) {
        Application updated = workflowService.removeAccountFromApplication(applicationId, accountRefId);
        return Response.ok(updated).build();
	}
}
