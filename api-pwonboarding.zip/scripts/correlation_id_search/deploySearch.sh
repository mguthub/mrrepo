#!/bin/bash
# different for each user
export USER=YOURUSERNAME
echo $USER@$1

#optional rsa-key copy (You will need to point to your own)
ssh-copy-id -i PATH/TO/YOUR/id_rsa $1

scp ./serverSearch.sh $USER@$1:/home/$USER/search.sh
ssh $USER@$1 chmod a+x /home/$USER/search.sh