package com.bmo.channel.pwob.config;

import java.util.HashMap;
import java.util.Map;

import javax.validation.ConstraintViolationException;
import javax.ws.rs.BadRequestException;
import javax.ws.rs.NotAcceptableException;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;

import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;

import com.bmo.channel.core.aop.AroundLoggingAspect;
import com.bmo.channel.core.aop.ServiceNameAspect;
import com.bmo.channel.core.exception.DefaultExceptionHandler;
import com.bmo.channel.core.exception.EnterpriseServiceException;
import com.bmo.channel.core.exception.ExceptionInfo;
import com.bmo.channel.core.exception.ExceptionUtil;
import com.bmo.channel.core.exception.ForbiddenSecurityException;
import com.bmo.channel.core.exception.JsonParseExceptionHandler;
import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.NotFoundExceptionHandler;
import com.bmo.channel.core.exception.UnauthorizedSecurityException;
import com.bmo.channel.core.exception.WebApplicationExceptionHandler;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.core.exception.WebServiceExceptionHandler;
import com.bmo.channel.core.mapping.DataMapper;
import com.bmo.channel.core.util.ResourceUtil;
import com.bmo.channel.pwob.aop.PwobAroundLoggingAspect;
import com.bmo.channel.pwob.exception.ConstraintViolationExceptionHandler;
import com.bmo.channel.pwob.exception.PwobStatusException;
import com.bmo.channel.pwob.exception.StatusExceptionHandler;
import com.bmo.channel.pwob.exception.UnrecognizedPropertyExceptionHandler;
import com.bmo.channel.pwob.exception.BackEndException;
import com.bmo.channel.pwob.exception.BackEndExceptionHandler;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;

@Configuration
public class CoreConfig {

	/**********************************************************
	******************  Spring Component scan  ****************
	***********************************************************/

	@Bean
	public PropertyPlaceholderConfigurer propertyPlaceholderConfigurer(){
		PropertyPlaceholderConfigurer propertyPlaceholderConfigurer = new PropertyPlaceholderConfigurer();

		propertyPlaceholderConfigurer.setIgnoreResourceNotFound(false);
		propertyPlaceholderConfigurer.setLocation( new FileSystemResource(System.getProperty("api-workflows.channel.services.env.config.file")));
		propertyPlaceholderConfigurer.setIgnoreUnresolvablePlaceholders(true);

		return propertyPlaceholderConfigurer;
	}

	@Bean
	public PropertiesFactoryBean validationRules(){
		PropertiesFactoryBean validationRules =  new PropertiesFactoryBean();
		validationRules.setLocation(new ClassPathResource("validationRules.properties"));
		validationRules.setFileEncoding("UTF-8");
		return validationRules;
	}
	

	/**********************************************************
	********************  Localization  ***********************
	***********************************************************/

	@Bean
	public ResourceBundleMessageSource messageSource(){
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
		messageSource.setDefaultEncoding("UTF-8");
		messageSource.setBasenames("com.bmo.web.resource.bundle.errorMessages", "com.bmo.web.resource.bundle.validationMessages");
		ResourceUtil.setMessageSource(messageSource);
		return messageSource;
	}

	@Bean
	public LocalValidatorFactoryBean validator(){
		LocalValidatorFactoryBean validator = new LocalValidatorFactoryBean();
		validator.setValidationMessageSource(messageSource());
		return validator;
	}

	@Bean
	public MethodValidationPostProcessor methodValidationPostProcessor(){
		MethodValidationPostProcessor methodValidationPostProcessor = new MethodValidationPostProcessor();
		methodValidationPostProcessor.setValidator(validator());
		return methodValidationPostProcessor;
	}

	/****************************************************************
	********************  Exception Handling  ***********************
	*****************************************************************/

	@Bean
	public DefaultExceptionHandler defaultExceptionHandler(DataMapper dataMapper){
		return new DefaultExceptionHandler(dataMapper);
	}

	@Bean
	public WebApplicationExceptionHandler webApplicationExceptionHandler(DataMapper dataMapper){
		return new WebApplicationExceptionHandler(dataMapper);
	}

	@Bean
	public WebServiceExceptionHandler webServiceExceptionHandler(DataMapper dataMapper){
		return new WebServiceExceptionHandler(dataMapper);
	}

	@Bean
	public UnrecognizedPropertyExceptionHandler unrecognizedPropertyExceptionHandler(DataMapper dataMapper){
		return new UnrecognizedPropertyExceptionHandler(dataMapper);
	}

	@Bean
	public NotFoundExceptionHandler notFoundExceptionHandler(DataMapper dataMapper){
		return new NotFoundExceptionHandler(dataMapper);
	}

	@Bean
	public JsonParseExceptionHandler jsonParseExceptionHandler(DataMapper dataMapper){
		return new JsonParseExceptionHandler(dataMapper);
	}

	@Bean
	public ConstraintViolationExceptionHandler constraintViolationExceptionHandler(DataMapper dataMapper){
		ConstraintViolationExceptionHandler constraintViolationExceptionHandler = new ConstraintViolationExceptionHandler();
		constraintViolationExceptionHandler.setDataMapper(dataMapper);
		return constraintViolationExceptionHandler;
	}

	@Bean
	public StatusExceptionHandler statusExceptionHandler(DataMapper dataMapper) {
		return new StatusExceptionHandler(dataMapper);
	}
	
	@Bean
	public BackEndExceptionHandler wisExceptionHandler(DataMapper dataMapper) {
		return new BackEndExceptionHandler(dataMapper);
	}

	@Bean
	public Map<Class<? extends Exception>, ExceptionInfo> exceptionUtil(){
		HashMap<Class<? extends Exception>, ExceptionInfo> exceptionInfoMap = new HashMap<>();
		exceptionInfoMap.put(WebServiceException.class, new ExceptionInfo(WebServiceException.class, "10000", Status.INTERNAL_SERVER_ERROR));
		exceptionInfoMap.put(PwobStatusException.class, new ExceptionInfo(PwobStatusException.class, "10005", Status.CONFLICT));
		exceptionInfoMap.put(UnauthorizedSecurityException.class, new ExceptionInfo(UnauthorizedSecurityException.class, "10003", Status.UNAUTHORIZED));
		exceptionInfoMap.put(ForbiddenSecurityException.class, new ExceptionInfo(ForbiddenSecurityException.class, "10003", Status.FORBIDDEN));
		exceptionInfoMap.put(UnrecognizedPropertyException.class, new ExceptionInfo(UnrecognizedPropertyException.class, "10002", Status.BAD_REQUEST));
		exceptionInfoMap.put(BadRequestException.class, new ExceptionInfo(BadRequestException.class, "10007", Status.BAD_REQUEST));
		exceptionInfoMap.put(EnterpriseServiceException.class, new ExceptionInfo(EnterpriseServiceException.class, "10001", Status.INTERNAL_SERVER_ERROR));
		exceptionInfoMap.put(ConstraintViolationException.class, new ExceptionInfo(ConstraintViolationException.class, "10002", Status.BAD_REQUEST));
		exceptionInfoMap.put(WebApplicationException.class, new ExceptionInfo(WebApplicationException.class, "10000", Status.METHOD_NOT_ALLOWED));
		exceptionInfoMap.put(JsonMappingException.class, new ExceptionInfo(JsonMappingException.class, "10000", Status.BAD_REQUEST));
		exceptionInfoMap.put(NotFoundException.class, new ExceptionInfo(NotFoundException.class, "10000", Status.NOT_FOUND));
		exceptionInfoMap.put(JsonParseException.class, new ExceptionInfo(JsonParseException.class, "10002", Status.BAD_REQUEST));
		exceptionInfoMap.put(NotAcceptableException.class, new ExceptionInfo(NotAcceptableException.class, "10008", Status.NOT_ACCEPTABLE));
		exceptionInfoMap.put(BackEndException.class, new ExceptionInfo(BackEndException.class, "10009", Status.INTERNAL_SERVER_ERROR));

		ExceptionUtil.setExceptionInfoMap(exceptionInfoMap);
		return exceptionInfoMap;
	}

	/********************************************************
	********************  Spring Aop  ***********************
	*********************************************************/
	@Bean
	public AroundLoggingAspect loggingAspect(){
		return new AroundLoggingAspect();
	}

	@Bean
	public ServiceNameAspect srvcNameAspect(){
		return new ServiceNameAspect();
	}
	
	@Bean
	public PwobAroundLoggingAspect pwobLoggingAspect(){
		return new PwobAroundLoggingAspect();
	}

}
