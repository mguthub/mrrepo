package com.bmo.channel.pwob.service.workflow;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Holder;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.jetspeed.services.security.ldap.UnixCrypt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.convert.ConvertorService;
import com.bmo.channel.pwob.convert.WSBuilder;
import com.bmo.channel.pwob.exception.ConstraintViolationExceptionHandler;
import com.bmo.channel.pwob.exception.ExceptionUtils;
import com.bmo.channel.pwob.exception.ValidationErrorResponse;
import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Address;
import com.bmo.channel.pwob.model.onboarding.AppStatus;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.FeatureFlag;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;
import com.bmo.channel.pwob.model.onboarding.InvestmentObjectives;
import com.bmo.channel.pwob.model.onboarding.MultiApplicantsInvestmentExperience;
import com.bmo.channel.pwob.model.onboarding.Name;
import com.bmo.channel.pwob.model.onboarding.NextStepsData;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.Taxation;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.provider.ApplicationProperties;
import com.bmo.channel.pwob.service.applications.ApplicationsService;
import com.bmo.channel.pwob.service.applications.NextStepsDataMapper;
import com.bmo.channel.pwob.service.applications.SavedApplicationsService;
import com.bmo.channel.pwob.service.authorization.PwobAction;
import com.bmo.channel.pwob.service.authorization.SecurityService;
import com.bmo.channel.pwob.service.documentpackages.DocumentPackagesService;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentPackageDto;
import com.bmo.channel.pwob.service.party.PartyFactory;
import com.bmo.channel.pwob.service.risprefill.RisPrefillService;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.util.Constants;
import com.bmo.channel.pwob.util.DateUtils;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.ValidationManager.IdType;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.workflows.parties.service.PartiesService;

import net.bmogc.xmlns.bmo._2002.header.BMOHdrRs;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.Event;
import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.UpdateCriticalElements;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.Metadata;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.Metadata.KeyValuePair;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.RetrieveApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveApplicationRequest;
import net.bmogc.xmlns.hub.cg.ds.onboardapplication.types.v1.SaveApplicationResponse;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.ApplicationIntegrityException;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.InputViolationException;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.SystemException;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice._interface.v1.WorkflowInitiationService;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice.types.v1.NotifyWorkflowRequest;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice.types.v1.NotifyWorkflowResponse;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.ApplicationData;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.PartyRole;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.PersonalInformation;

@Service
public class WorkflowServiceImpl implements WorkflowService {
	static Logger logger = LoggerFactory.getLogger(WorkflowServiceImpl.class);	
	private static final String  WIS_LOG_EVENT_MESSAGE= "Failure in workflow HUB while processing event notification request for event:";
	private static final String PWOB_XSD_VERSION = "9";	
	private static final String DECLINED_ONLINE_ACCESS="declineAccess";	
	
	protected static final String WIS_SERVICE_NAME = "WIS";
	protected static final String WIS_FUNCTION = "GetWorkflowData";
	private static final String WIS_NOTIFY_WORKFLOW_FUNCTION = "NW";
	private static final String XATTRS = "am-eai-xattrs";
	private static final String AMEAI_FLAG = "am-eai-flags";
	private static final String EMAIL_ID = "x_bmo_email_id";
	private static final String USER_ID = "am-eai-ext-user-id";
	
	@Autowired
	private ApplicationProperties applicationProperties;
	
	@Autowired
	private WorkflowInitiationService workflowHubClient;

	@Autowired
	private PartiesService partiesService;
	
	@Autowired
	private RisPrefillService risPrefillService;

	@Autowired
	private ConvertorService convertorService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private ConstraintViolationExceptionHandler constraintViolationExceptionHandler;

	@Autowired
	private ValidationManager validationManager;

	@Autowired
	private SavedApplicationsService savedApplicationsService;

	@Autowired
	private UsersService usersService;

	@Autowired
	private PartyFactory partyFactory;

	@Autowired
	private DocumentPackagesService documentPackagesService;

	@Autowired
	private ApplicationsService applicationsService; 

	@Autowired
	private OnboardApplicationRepository onboardApplicationRepository;
	
	@Autowired
	private javax.servlet.http.HttpServletResponse httpServletResponse;
	
	@Autowired
	private HttpServletRequest httpServletRequest;

	private class RetrieveForUpdateResponse {
		String workflowStatus;
		RetrieveApplicationResponse retrieveApplicationResponse;
		String lastUpdatedBy;
	}

	@Override
	public Application saveApplication(NewWorkflowRequest request) {
		validationManager.validateModel(request, Action.SAVE);

		securityService.authorizeAction(null, request.getIaCode(), PwobAction.CREATE_APPLICATION);

		Application application = initalizeApplication(request);

		SaveApplicationRequest saveApplicationRequest = prepareSaveApplicationRequest(application, request.getEcifId());
		SaveApplicationResponse response = onboardApplicationRepository.save(saveApplicationRequest, request.getEcifId());

		application.setApplicationId(response.getBody().getWorkflowId());
		application.setLastUpdated(response.getBody().getLastUpdatedDateTime());

		validationErrorsCheck(application, Action.SUBMIT);

		return application;	
	}

	String getEcifId(List<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> parties) {
		String ecifId=null;

		Optional<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> party = 
				this.getPrimaryApplicant(parties);

		if(party.isPresent()) {
			ecifId = party.get().getPersonalInformation().getEcifId();
		}
		return ecifId;
	}

	private SaveApplicationRequest prepareSaveApplicationRequest(Application application, String ecifId) {
		SaveApplicationRequest saveApplicationRequest = new SaveApplicationRequest();
		String requestorId = usersService.currentUser().getNetworkId();

		ApplicationDataUpdateRequest updateReq = new ApplicationDataUpdateRequest();
		updateReq.setRequestorId(requestorId);
		updateReq.setLastUpdatedDateTime(DateUtils.getTimestamp());

		SaveApplicationRequest.Body body = this.populateBody(updateReq);
		ApplicationData applicationData = this.convertorService.getApplicationData(application);	
		applicationData.setVersion(PWOB_XSD_VERSION);
		
		String password=null;
		if(ApplicationLob.il == usersService.currentUser().getLob()){
			if(application.getPrimaryApplicant().getPassword()!=null)
				password=UnixCrypt.crypt("EZ", application.getPrimaryApplicant().getPassword());
			
			Optional<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> primaryAppData = applicationData.getParties().stream().filter(p -> p.getRoles().contains(PartyRole.PRIMARY_APPLICANT)).findFirst();
			if(primaryAppData.isPresent()) {
				primaryAppData.get().setPassword(password);
			} 
		}
		//populateBranchCode(applicationData);
		Metadata metadata = this.prepareMetaData(application, requestorId);
		body.setMetadata(metadata);

		populateEcifId(applicationData, ecifId,body);

		body.setPayload(this.populateSavePayload(applicationData));
		saveApplicationRequest.setBody(body);

		return saveApplicationRequest;
	}

	String setMetadataAcctType(String acctType) {
		if(Account.SPOUSAL_RSP_TYPE.equalsIgnoreCase(acctType))
			return SavedApplication.ACCOUNT_TYPE.concat(".").concat(acctType).concat(".").concat("spousal").concat(".").concat("true");
		else
			return SavedApplication.ACCOUNT_TYPE.concat(".").concat(acctType);
	}

	/**
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-PrepareWSSmetadata">Workflow Service Confluence Documentation</a>
	 */
	@Override
	public Metadata prepareMetaData(Application application, String requestorId) {
		Metadata metadata = new Metadata();
		List<KeyValuePair> keyValuePairList = new ArrayList<>();
		if(application!=null)
		{
			if(application.getIaCode() != null) {
				populateKeyValuePair(SavedApplication.IA_CODE, application.getIaCode(), keyValuePairList);
			} else if (ApplicationLob.il.equals(application.getApplicationLob())) {
				populateKeyValuePair(SavedApplication.IA_CODE, Constants.BIL_IA_CODE_PREFIX + UUID.randomUUID().toString(), keyValuePairList);
			}

			populateKeyValuePair(SavedApplication.UPDATE_TIMESTAMP, lastUpdated(application), keyValuePairList);

			if (ApplicationLob.nb.equals(application.getApplicationLob())) {
				populateKeyValuePair(SavedApplication.UPDATE_BY, requestorId, keyValuePairList);
			}

			if (CollectionUtils.isNotEmpty(application.getAccounts())) {
				populateKeyValuePair(setMetadataAcctType(Account.RSP_TYPE),	String.valueOf(application.getAccounts().stream().filter(a -> a.isSpousalRsp()).count()), keyValuePairList);
				
				populateKeyValuePair(setMetadataAcctType(Account.INDIVIDUAL_TYPE), 
						String.valueOf(application.getAccounts().stream().filter(a->a.isIndividual()).count()),keyValuePairList);
				populateKeyValuePair(setMetadataAcctType(Account.TFSA_TYPE), 
						String.valueOf(application.getAccounts().stream().filter(a->a.isTfsa()).count()),keyValuePairList);
				
				populateKeyValuePair(setMetadataAcctType(Account.RSP_TYPE), 
						String.valueOf(application.getAccounts().stream().filter(a->a.isRsp()).count()),keyValuePairList);				
				
				populateKeyValuePair(setMetadataAcctType(Account.RIF_TYPE), 
						String.valueOf(application.getAccounts().stream().filter(a->a.isRif()).count()),keyValuePairList);
				
				populateKeyValuePair(setMetadataAcctType(Account.JOINT_TYPE), 
						String.valueOf(application.getAccounts().stream().filter(a->a.isJoint()).count()),keyValuePairList);
				
				populateKeyValuePair(setMetadataAcctType(Account.LIRA_TYPE), 
						String.valueOf(application.getAccounts().stream().filter(a->a.isLira()).count()),keyValuePairList);
			}
			metadata.getKeyValuePair().addAll(keyValuePairList);
		}
		return metadata;
	}

	private String lastUpdated(Application application) {
		String determineLastUpdated = application.getLastUpdated();
		if(StringUtils.isBlank(determineLastUpdated)) {
			return DateUtils.getXmlGregorianCalendarAsString();
		} else {
			return determineLastUpdated;
		}
	}

	void populateKeyValuePair(String key,String value, List<KeyValuePair> keyValuePairList) {
		KeyValuePair keyValuePair=new KeyValuePair();
		List<String> values=new ArrayList<>();

		values.add(value);
		keyValuePair.setKey(key);
		keyValuePair.getValue().addAll(values);
		keyValuePairList.add(keyValuePair);
	}

	private void populateEcifId(ApplicationData applicationData, String ecifId, SaveApplicationRequest.Body body) {
		Optional<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> party = 
				this.getPrimaryApplicant(applicationData.getParties());

		if(party.isPresent()) {
			party.get().getPersonalInformation().setEcifId(ecifId);
			
			SaveApplicationRequest.Body.Parties parties = new SaveApplicationRequest.Body.Parties();
			List<SaveApplicationRequest.Body.Parties.Party> parties1 = new ArrayList<SaveApplicationRequest.Body.Parties.Party>();
			SaveApplicationRequest.Body.Parties.Party primaryApplicant = new SaveApplicationRequest.Body.Parties.Party();
			primaryApplicant.setECIFID(ecifId);
			primaryApplicant.setPartyRefID(party.get().getPartyRefId());
			parties1.add(primaryApplicant);
			parties.getParty().add(primaryApplicant);
			body.setParties(parties);
		}
	}

	private Optional<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> getPrimaryApplicant(List<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> parties) {
		return parties.stream().filter(c -> c.getRoles().contains(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.PartyRole.PRIMARY_APPLICANT)).findFirst();
	}

	/**
	 * @param application An {@link Application} to be updated.
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service">Workflow Service Confluence Documentation</a>
	 */
	@Override
	public Application updateApplication(Application application) {
		String applicationId = application.getApplicationId();

		checkAndSetDocumentPreference(application);
		checkAndSetJointApplicantsResidenceAddress(application);
		validateApplicationModel(application);

		updateMultiApplicantsInvestmentExperience(application);
		
		RetrieveForUpdateResponse retrieveForUpdateResponse = retrieveForUpdate(applicationId);
		RetrieveApplicationResponse retrieveAppResponse = retrieveForUpdateResponse.retrieveApplicationResponse;
		XMLGregorianCalendar lastUpdatedDateTime = retrieveAppResponse.getBody().getLastUpdatedDateTime();

		checkForStaleData(application.getLastUpdated(), lastUpdatedDateTime.toString(), retrieveForUpdateResponse.lastUpdatedBy);

		ApplicationData originalApplicationData = retrieveAppResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData();		

		storeUpdatedApplication(application, originalApplicationData, applicationId, retrieveAppResponse.getBody());

		return application;
	}
	
	/**
	 * @param application An {@link Application} to be updated.
	 * Update MultiApplicants Investment Exp record for UI to add details
	 */	
	private void updateMultiApplicantsInvestmentExperience(Application application) {
		List<Account> jointAccounts = application.getJointAccounts();
		List<MultiApplicantsInvestmentExperience> multiApplicantsInvestmentExperiences = application
				.getMultiApplicantsInvestmentExperiences();
		Map<List<String>, List<String>> map = new HashMap<List<String>, List<String>>();
		for (Account account : jointAccounts) {
			boolean found = false;
			for (Map.Entry<List<String>, List<String>> entry : map.entrySet()) {
				if (Optional.ofNullable(account.getJointApplicantPartyRefIds()).isPresent()
						&& CollectionUtils.isEqualCollection(entry.getKey(), account.getJointApplicantPartyRefIds())) {
					List<String> list = new ArrayList<String>();
					list.add(account.getPrimaryApplicantPartyRefId());
					list.addAll(account.getJointApplicantPartyRefIds());
					map.put(entry.getKey(), list);
					found = true;
					break;
				}
			}
			if (!found && Optional.ofNullable(account.getJointApplicantPartyRefIds()).isPresent()
                    && Optional.ofNullable(account.getJointAccountDetails()).isPresent()
                    && CollectionUtils.isNotEmpty(account.getJointAccountDetails().getAccountNameOrder())
                    && !(account.getJointAccountDetails().getAccountNameOrder().contains("")||account.getJointAccountDetails().getAccountNameOrder().contains(null))) {
                map.put(account.getJointApplicantPartyRefIds(), account.getJointAccountDetails().getAccountNameOrder());
			} else if (CollectionUtils.isNotEmpty(account.getJointApplicantPartyRefIds())) {
				List<String> list = new ArrayList<String>();
				list.add(account.getPrimaryApplicantPartyRefId());
				list.addAll(account.getJointApplicantPartyRefIds());
				map.put(account.getJointApplicantPartyRefIds(), list);
			}
		}
		for (Map.Entry<List<String>, List<String>> entry : map.entrySet()) {
			boolean found = false;
			for (MultiApplicantsInvestmentExperience exp : multiApplicantsInvestmentExperiences){
				List<String> expPartyRefIds = exp.getPartyRefIds();
				if(CollectionUtils.isEqualCollection(entry.getValue(), expPartyRefIds)) {
					exp.setPartyRefIds(entry.getValue());
					found = true;
					break;
				}
			}
			if(!found){
				MultiApplicantsInvestmentExperience multiAppExp = new  MultiApplicantsInvestmentExperience();
				multiAppExp.setPartyRefIds(entry.getValue());
				multiApplicantsInvestmentExperiences.add(multiAppExp);					
			}	
		}
		cleanUpMultiApplicantsInvestmentExperiences(application);
	}
	
	private void cleanUpMultiApplicantsInvestmentExperiences(Application application){
		List<Account> jointAccounts = application.getJointAccounts();
		List<MultiApplicantsInvestmentExperience> multiApplicantsInvestmentExperiences = application.getMultiApplicantsInvestmentExperiences();
				
		List<MultiApplicantsInvestmentExperience> unUsedExperiences = new ArrayList<MultiApplicantsInvestmentExperience>();
		
		for(MultiApplicantsInvestmentExperience exp : multiApplicantsInvestmentExperiences){			
			List<String> jointApplicantsRefIds = exp.getPartyRefIds();
			if(jointApplicantsRefIds != null && CollectionUtils.isNotEmpty(jointApplicantsRefIds)){				
				boolean found = false;
				for(Account account : jointAccounts){
						if(account.getJointApplicantPartyRefIds() != null && CollectionUtils.isNotEmpty(account.getJointApplicantPartyRefIds())){
							List<String> jointAccountApplicantsRefIds = new ArrayList<String>(account.getJointApplicantPartyRefIds());
							jointAccountApplicantsRefIds.add(account.getPrimaryApplicantPartyRefId());
							if(CollectionUtils.isEqualCollection(jointAccountApplicantsRefIds, jointApplicantsRefIds)) {
								found =true;
								break;
							}
						}
				}
				if(!found){
					unUsedExperiences.add(exp);
				}
			}else{
					unUsedExperiences.add(exp);
			}
		}
		if(unUsedExperiences.size() > 0){
			multiApplicantsInvestmentExperiences.removeAll(unUsedExperiences);
		}
	}
		
	/**
	 * Applies "SAVE" level validation to an application.
	 * This allows empty/incomplete data, but does not allow invalid data (values that aren't real ref data values or 
	 * data that does not match the allowed characters from the Critical Data Inventory (CDI)).
	 * @param application
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-Validateapplication">Workflow Service Confluence Documentation</a>
	 */
	private void validateApplicationModel(Application application) {
		validationManager.validateModel(application, Action.SAVE);
	}
	
	
	private void checkForLegalNameChanges(ApplicationData originalApplicationData, Application updatedApplication, String workflowId) {
		if(!originalApplicationData.getParties().get(0).getPersonalInformation().getLegalFirstName().equals(updatedApplication.getParties().get(0).getPersonal().getIdentity().getLegalName().getFirstName())
				|| !originalApplicationData.getParties().get(0).getPersonalInformation().getLegalLastName().equals(updatedApplication.getParties().get(0).getPersonal().getIdentity().getLegalName().getLastName())){

			Event legelNameUpdateEvent = new Event();
			
			UpdateCriticalElements UpdateCriticalElements = new UpdateCriticalElements();
			UpdateCriticalElements.setFirstName(updatedApplication.getParties().get(0).getPersonal().getIdentity().getLegalName().getFirstName());
			UpdateCriticalElements.setLastName(updatedApplication.getParties().get(0).getPersonal().getIdentity().getLegalName().getLastName());
			
			legelNameUpdateEvent.setUpdateCriticalElements(UpdateCriticalElements);
			
			try{
				
			NotifyWorkflowRequest.Body body = new NotifyWorkflowRequest.Body();
			body.setWorkflowId(workflowId);
				if (applicationProperties !=null) {
					body.setWorkflowTemplateId(applicationProperties.getWorkflowTemplateId());
					body.setVersion(applicationProperties.getWorkflowVersion());
				}
				
				NotifyWorkflowRequest.Body.Payload payload = new NotifyWorkflowRequest.Body.Payload();
				payload.setEvent(legelNameUpdateEvent);
				body.setPayload(payload);
				
				NotifyWorkflowRequest notifyWorkflowRequest = new NotifyWorkflowRequest();
				notifyWorkflowRequest.setBody(body);

				NotifyWorkflowResponse response = workflowHubClient.notifyWorkflow(notifyWorkflowRequest, WSBuilder.build(WIS_SERVICE_NAME, WIS_NOTIFY_WORKFLOW_FUNCTION), new Holder<BMOHdrRs>());

				if (response == null) {
					logger.warn("HUB response is null.");
					throw new WebServiceException("HUB response is null");
				}

				if (response.getBody() !=null && response.getBody().getFailure() !=null) { 
					logger.warn("HUB response is not null."+response.getBody().getFailure().getMessage());					
					throw new WebServiceException(response.getBody().getFailure().getMessage());
				}
						
		}  catch (SystemException e) {
			logger.error(WIS_LOG_EVENT_MESSAGE+legelNameUpdateEvent,workflowId,e);
			logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}  catch (InputViolationException e) {
			logger.error(WIS_LOG_EVENT_MESSAGE+legelNameUpdateEvent,workflowId,e);
			logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
		}  catch (ApplicationIntegrityException e) {
			logger.error(WIS_LOG_EVENT_MESSAGE+legelNameUpdateEvent,workflowId,e);
			logger.error(String.format("WIS error : %s,  %s", e.getFaultInfo().getServiceExceptionId(), e.getFaultInfo().getExceptionName(), e.getFaultInfo().getDetailedMessageText()));
			throw ExceptionUtils.buildBackEndException("WIS service exception - "+e.getClass().getName(), e.getFaultInfo().getExceptionName());
	}
		
	    }		
	}
	

	/**
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-PopulateDeclineOnlineAccess">Workflow Service Confluence Documentation</a>
	 */
	void populateSavedDeclineAccess(ApplicationData originalApplicationData, Application application) {
		if(originalApplicationData.getClientAccessId().isHasDeclinedOnlineAccess() != null &&
				!originalApplicationData.getClientAccessId().isHasDeclinedOnlineAccess()) {
			application.getClientAccessId().setHasDeclinedOnlineAccess(Boolean.FALSE);
		}
	}

	@Override
	public void storeUpdatedApplication(Application updatedApplication, ApplicationData originalApplicationData, String applicationId,RetrieveApplicationResponse.Body body){
			
		User currentUser = usersService.currentUser();
		String userId = currentUser.getNetworkId();
		
		XMLGregorianCalendar lastUpdatedDateTime = body.getLastUpdatedDateTime();

		checkForLegalNameChanges(originalApplicationData,updatedApplication,applicationId);
		
		ApplicationData newApplicationData = mergeApplicationWithExistingApplicationData(updatedApplication, originalApplicationData);

		ApplicationDataUpdateRequest updateReq = new ApplicationDataUpdateRequest();
		updateReq.setRequestorId(userId);
		updateReq.setApplicationId(applicationId);
		updateReq.setLastUpdatedDateTime(lastUpdatedDateTime);		

		Metadata metadata = prepareMetaData(updatedApplication, userId);

		SaveApplicationResponse response = sendApplicationUpdate(newApplicationData, updateReq, metadata, body);

		validationErrorsCheck(updatedApplication, Action.SUBMIT);
		updatedApplication.setLastUpdated(response.getBody().getLastUpdatedDateTime());
	}
	
public void mergeEcifId(RetrieveApplicationResponse.Body responeBody, ApplicationData newApplicationData, SaveApplicationRequest.Body body){		
		
		SaveApplicationRequest.Body.Parties saveParties = null;
		List<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> applicationParties = newApplicationData.getParties();
		if(body.getParties() != null){		
			 saveParties = body.getParties();
		}else{
			saveParties = new SaveApplicationRequest.Body.Parties();
			body.setParties(saveParties);
		}
		
		List<SaveApplicationRequest.Body.Parties.Party> savedParty =saveParties.getParty();
		
		RetrieveApplicationResponse.Body.Parties retrievedParties = responeBody.getParties();
		
		List<RetrieveApplicationResponse.Body.Parties.Party> retrievedParty = null;
		
		if(retrievedParties != null){		
			 retrievedParty = retrievedParties.getParty();	
		}else{
			 retrievedParties = new RetrieveApplicationResponse.Body.Parties();
			 retrievedParty = retrievedParties.getParty();	
			 
			 for(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party appParty  : applicationParties){				 
				 if(Optional.ofNullable(appParty.getPersonalInformation().getEcifId()).isPresent()){
					 RetrieveApplicationResponse.Body.Parties.Party newParty = new RetrieveApplicationResponse.Body.Parties.Party();
					 newParty.setECIFID(appParty.getPersonalInformation().getEcifId());
					 newParty.setPartyRefID(appParty.getPartyRefId());
					 retrievedParty.add(newParty);
				 }
			}
		}		
		
		for(RetrieveApplicationResponse.Body.Parties.Party party : retrievedParty){
			SaveApplicationRequest.Body.Parties.Party saveParty = new SaveApplicationRequest.Body.Parties.Party();
			saveParty.setECIFID(party.getECIFID());
			saveParty.setPartyRefID(party.getPartyRefID());			
			savedParty.add(saveParty);
		}
		
		for(SaveApplicationRequest.Body.Parties.Party party: savedParty){
			for(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party appParty  : applicationParties){
				if(appParty.getPartyRefId().equals(party.getPartyRefID())){
					appParty.getPersonalInformation().setEcifId(party.getECIFID());					
				}
			}
		}
		
		for(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party appParty  : applicationParties){
			boolean exist = false;
			for(SaveApplicationRequest.Body.Parties.Party party: savedParty){
				if(appParty.getPartyRefId().equals(party.getPartyRefID())){
					exist = true;
					break;
				}
			}
			if(!exist && Optional.ofNullable(appParty.getPersonalInformation().getEcifId()).isPresent()){
				SaveApplicationRequest.Body.Parties.Party saveNewParty = new SaveApplicationRequest.Body.Parties.Party(); 
				saveNewParty.setECIFID(appParty.getPersonalInformation().getEcifId());
				saveNewParty.setPartyRefID(appParty.getPartyRefId());
				savedParty.add(saveNewParty);  
			}
		}		
		
	}

	@Override
	public ApplicationData mergeApplicationWithExistingApplicationData(Application updatedApplication, ApplicationData originalApplicationData) {
		updateRequestObject(updatedApplication, originalApplicationData);

		ApplicationData newApplicationData = convertApplicationModelToOnboardModel(updatedApplication);
		newApplicationData.setVersion(PWOB_XSD_VERSION);

		populateOriginalData(originalApplicationData, newApplicationData); // to populate branch code, ecifid, proxyid, documentation and IndiciaCheckResults

		return newApplicationData;
	}

	/**
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-ConvertJSONtoXML">Workflow Service Confluence Documentation</a>
	 */
	private ApplicationData convertApplicationModelToOnboardModel(Application updatedApplication) {
		return convertorService.getApplicationData(updatedApplication);
	}

	/**
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-PopulateJSONModelData">Workflow Service Confluence Documentation</a>
	 */
	private void updateRequestObject(Application updatedApplication, ApplicationData originalApplicationData) {
		populateAccountInvestmentObjectives(updatedApplication);
    	populateAccountCurrencies(updatedApplication);
		populateSavedDeclineAccess(originalApplicationData, updatedApplication);
	}

	private RetrieveForUpdateResponse retrieveForUpdate(String applicationId) {
		SavedApplication savedApp = retrieveWorkflowSummary(applicationId);

		securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.UPDATE_APPLICATION);

		return retrieveApplication(applicationId, savedApp);
	}

	/**
	 * @param applicationId
	 * @param savedApp
	 * @return Application 
	 */
	private RetrieveForUpdateResponse retrieveApplication(String applicationId, SavedApplication savedApp) {
		RetrieveForUpdateResponse response = new RetrieveForUpdateResponse();
		response.workflowStatus = savedApp.getAppStatus();
		response.retrieveApplicationResponse = retrieveApplicationResponse(applicationId,savedApp.getCustomerId());
		response.lastUpdatedBy = savedApp.getLastUpdatedBy();
		return response;
	}

	/**
	 * @param applicationId
	 * @return workflow summary retrieved from WSS
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-RetrieveWorkflowfromWSS">Workflow Service Confluence Documentation</a>
	 */
	private SavedApplication retrieveWorkflowSummary(String applicationId) {
		return savedApplicationsService.retrieveSavedApplication(applicationId);
	}

	/**
	 * @param appLastUpdatedRequest  last updated time from request
	 * @param savedLastUpdatedOnboardService last updated time from onboard service
	 * @param lastUpdatedBy  user name of person who last updated in onboard service
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-StaleDataCheck">Workflow Service Confluence Documentation</a>
	 */
	private void checkForStaleData(String appLastUpdatedRequest, String savedLastUpdatedOnboardService, String lastUpdatedBy) {
		if(StringUtils.isBlank(appLastUpdatedRequest) || StringUtils.isBlank(savedLastUpdatedOnboardService)){
			return;
		}

		if(!appLastUpdatedRequest.equals(savedLastUpdatedOnboardService)){
			logger.error("Stale data","Date=" + appLastUpdatedRequest +", SavedDate=" + savedLastUpdatedOnboardService + ", LastUpdatedBy=" + lastUpdatedBy);
			throw ExceptionUtils.buildStatusExceptionForStaleApplicationDataContext(appLastUpdatedRequest, savedLastUpdatedOnboardService, lastUpdatedBy);
		}
	}

	void populateBranchCode(ApplicationData applicationData) {
		User currentUser = usersService.currentUser();
		applicationData.setBranchCode(currentUser.getBranchCode());
	}

	@Override
    public Application retrieveApplication(String applicationID) {
		SavedApplication savedApp = retrieveWorkflowSummary(applicationID);
		securityService.authorizeReadAccess(savedApp.getIaCode());

    	final RetrieveApplicationResponse response = retrieveApplicationResponse(applicationID,savedApp.getCustomerId());
    	return deriveWorkflow(response,savedApp.getAppStatus());
	}

	@Override
	public Application deriveWorkflow(final RetrieveApplicationResponse response, String appStatus) {
		Application application = null;
		if(Optional.ofNullable(response.getBody().getPayload()).isPresent()) {
			application = convertorService.getOnboardApplicationData(response.getBody().getApplicationID(), response.getBody().getPayload().getAPPLICATIONDATA().getAppData(), appStatus);
			application.setApplicationLob(usersService.currentUser().getLob());
			application.setLastUpdated(response.getBody().getLastUpdatedDateTime().toString());
		}

		if (application != null) {
			if(StringUtils.isNoneBlank(application.getApplicationId())) {
				application.setStatus(appStatus);	
			}	
		} else {
			logger.error("Failed to derive workflow details");
			throw new WebServiceException("Application Id does not have any workflow details");
		}

		this.validationErrorsCheck(application, Action.SUBMIT);
		return application;
	}

	/**
	 * When the Payload is replaced with new Payload data, the ecif id, proxy id and documentation and IndiciaCheckResults should not be 
	 * overridden. It should be retrieved from HUB for the workflow id and reset before replacing the Payload
	 * Copy the client Access Id on update.
	 * @param originalApplicationData
	 * @param newApplicationData
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-CopiesanyvaluesnotinJSONmodelfromoriginalXMLtonewXML(Merge)">Workflow Service Confluence Documentation</a>
	 */
	void populateOriginalData(ApplicationData originalApplicationData, ApplicationData newApplicationData) {
		for(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party newParty: newApplicationData.getParties()){
			for(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party oldParty: originalApplicationData.getParties()){
				if(newParty != null && newParty.getPartyRefId().equals(oldParty.getPartyRefId())){
					newParty.getPersonalInformation().setEcifId(oldParty.getPersonalInformation().getEcifId());
					newParty.getPersonalInformation().setProxyId(oldParty.getPersonalInformation().getProxyId());
					
					break;
				}
				if(newParty != null && newParty.getPartyRefId().equals(oldParty.getPartyRefId())){
				
						if(oldParty.getPersonalInformation().isIsLegalNameRisPrefilled()){
							newParty.getPersonalInformation().setLegalFirstName(oldParty.getPersonalInformation().getLegalLastName());
							newParty.getPersonalInformation().setLegalLastName(oldParty.getPersonalInformation().getLegalFirstName());
							newParty.getPersonalInformation().setLegalMiddleName(oldParty.getPersonalInformation().getLegalMiddleName());
						}
						
						if(oldParty.getPersonalInformation().isIsPreferredNameRisPrefilled()){
							newParty.getPersonalInformation().setPreferredLastName(oldParty.getPersonalInformation().getPreferredLastName());
							newParty.getPersonalInformation().setPreferredFirstName(oldParty.getPersonalInformation().getPreferredFirstName());
							newParty.getPersonalInformation().setPreferredMiddleName(oldParty.getPersonalInformation().getPreferredMiddleName());
						}
				}					
				
			}
		}

		List<net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party> parties = newApplicationData.getParties();			
		if(parties != null){
			for(net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party party: parties){
				if(party.getRoles().contains(PartyRole.JOINT_APPLICANT) && (!StringUtils.isNotBlank(party.getPersonalInformation().getEcifId()))){					
					if(StringUtils.isNotBlank(party.getPersonalInformation().getLegalFirstName()) && StringUtils.isNotBlank(party.getPersonalInformation().getLegalLastName())){	
						String ecifId = partiesService.createParty(party.getPersonalInformation().getLegalFirstName(),party.getPersonalInformation().getLegalLastName());
				        party.getPersonalInformation().setEcifId(ecifId);
					}
				}
			}
		}

		if(Optional.ofNullable(originalApplicationData.getIndiciaCheckResults()).isPresent()) {
			newApplicationData.getIndiciaCheckResults().addAll(originalApplicationData.getIndiciaCheckResults());
		}

		newApplicationData.setBranchCode(originalApplicationData.getBranchCode());
		newApplicationData.setLob(originalApplicationData.getLob());

		if(Optional.ofNullable(originalApplicationData.getClientAccessId()).isPresent())
		{
			if(Optional.ofNullable(originalApplicationData.getClientAccessId().getUserId()).isPresent()) 
				newApplicationData.getClientAccessId().setUserId(originalApplicationData.getClientAccessId().getUserId());
			if(Optional.ofNullable(originalApplicationData.getClientAccessId().getPrimaryAccountNumber()).isPresent())
				newApplicationData.getClientAccessId().setPrimaryAccountNumber(originalApplicationData.getClientAccessId().getPrimaryAccountNumber());
		}
	}

	/**
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-UpdateapplicationusingOnboardApplicationservice">Workflow Service Confluence Documentation</a>
	 */
	SaveApplicationResponse sendApplicationUpdate(ApplicationData applicationData, ApplicationDataUpdateRequest updateReq, Metadata metadata, RetrieveApplicationResponse.Body responseBody) {
		SaveApplicationRequest saveApplicationRequest = new SaveApplicationRequest();

		SaveApplicationRequest.Body body = this.populateBody(updateReq);	
		body.setMetadata(metadata);
		body.setPayload(this.populateSavePayload(applicationData));
		if(responseBody.getParties() != null){
			mergeEcifId(responseBody,applicationData, body);
	    }
		saveApplicationRequest.setBody(body);

		saveApplicationRequest.getBody().setApplicationID(updateReq.getApplicationId());				

		return onboardApplicationRepository.save(saveApplicationRequest, getEcifId(body.getPayload().getAppData().getParties()));
	}

	/**
	 * Retrieves an application from Onboard Application service.
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-RetrieveExistingApplication">Workflow Service Confluence Documentation</a>
	 */
	@Override
	public RetrieveApplicationResponse retrieveApplicationResponse(String applicationID,String ecifId) {
		return onboardApplicationRepository.retrieve(applicationID, ecifId);
	}

	private SaveApplicationRequest.Body populateBody(ApplicationDataUpdateRequest request) {
		SaveApplicationRequest.Body body = onboardApplicationRepository.defaultSaveApplicationRequestBody();
		body.setLastUpdatedDateTime(request.getLastUpdatedDateTime());
		body.setEmployeeUserID(request.getRequestorId());

		return body;
	}

	private SaveApplicationRequest.Body.Payload populateSavePayload(ApplicationData appData) {
		SaveApplicationRequest.Body.Payload payload = new SaveApplicationRequest.Body.Payload();
		payload.setAppData(appData);
		return payload;
	}

	@Override
	public void validate(Application application) {
		application.setApplicationLob(usersService.currentUser().getLob());
		this.validationManager.validateModel(application, Action.SUBMIT);
	}

    @Override
	public void delete(String applicationId) {    
    	SavedApplication savedApp = retrieveWorkflowSummary(applicationId);
    	securityService.authorizeAction(savedApp.getAppStatus(), savedApp.getIaCode(), PwobAction.DELETE_WORKFLOW);

		RetrieveApplicationResponse retResponse = retrieveApplicationResponse(applicationId,savedApp.getCustomerId());

		List<String> unReserveAccNumList = retResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData().getAccounts().
				stream().filter(a -> a.getAccountNumber() != null).map(a -> a.getAccountNumber()).collect(Collectors.toList());

		List<DocumentPackageDto> pckgs = new ArrayList<>();
		if(!AppStatus.DATA_COLLECTION.toString().equalsIgnoreCase(savedApp.getAppStatus())) {
			pckgs = documentPackagesService.retrieveDocumentPackages(applicationId, true);
		}

		onboardApplicationRepository.cancel(applicationId, savedApp.getCustomerId(), retResponse.getBody().getLastUpdatedDateTime(), unReserveAccNumList, pckgs);
	}

    /**
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-PopulateAccountInvestmentObjectives">Workflow Service Confluence Documentation</a>
     */
    void populateAccountInvestmentObjectives(final Application application) {
		if(application != null && application.getPrimaryApplicant() != null) {
			Party applicant = application.getPrimaryApplicant();
			if(applicant.getApplyInvestmentObjectivesToAccounts() != null && applicant.getApplyInvestmentObjectivesToAccounts()) {
				InvestmentObjectives investmentObjectives = applicant.getInvestmentObjectives();
				List<Account> accounts = application.getAccounts();
				for (Account account : accounts) {
					if(account.getInvestmentObjectives().getObjective() == null && (account.getInvestmentObjectives().getRiskTolerance().getHigh() == null && account.getInvestmentObjectives().getRiskTolerance().getMedium() == null && account.getInvestmentObjectives().getRiskTolerance().getLow() == null) && ( account.getInvestmentObjectives().getTargetAllocation().getCash() == null && account.getInvestmentObjectives().getTargetAllocation().getFixedIncome() ==null && account.getInvestmentObjectives().getTargetAllocation().getEquities() == null ) )
						account.setInvestmentObjectives(investmentObjectives);
				}
			}
    	}
	}

	private Application initalizeApplication(NewWorkflowRequest request) {
		Application application = new Application();
		application.setStatus(AppStatus.DATA_COLLECTION.toString());
		application.setApplicationLob(usersService.currentUser().getLob());
		application.setRelease(Application.CURRENT_RELEASE);
		// continue setting this feature flag until all R4 applications have been migrated
		application.getFeatureFlags().add(new FeatureFlag(FeatureFlags.BETCH, FeatureFlags.BETCH_ACTIVE));
		if (StringUtils.isNotBlank(request.getIaCode())) {
			application.setIaCode(request.getIaCode());
		}
		String firstName = request.getFirstName();
		application.setParties(new ArrayList<>());	

		populateAccountCurrencies(application);		
		application.setBranchCode(usersService.currentUser().getIaAndBranchCodes().get(request.getIaCode()));

		if(!Optional.ofNullable(request.getLocale()).isPresent()){
			application.setLocale(UILocale.EN_CA.getLang());
		} else {
			application.setLocale(request.getLocale());
		}

		String token = request.getRisToken();
		if(StringUtils.isNotBlank(token)) {
			application.setParties(this.risPrefillService.getParties(token, request));
			if(Optional.ofNullable(request).map(NewWorkflowRequest::getEcifId).isPresent() && request.getEcifId().isEmpty()){
				request.setEcifId(this.partiesService.createParty(firstName, request.getLastName()));
				logger.error(String.format(" ECIF ID not found for user: %s %s and New ECIF ID: %s is generated.", firstName, request.getLastName(), request.getEcifId()));				
			}
			
		} else {
			request.setEcifId(this.partiesService.createParty(firstName, request.getLastName()));
			populateLegalName(application, request);				
		}
		return application;
	}

    /**
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-PopulateAccountCurrencies">Workflow Service Confluence Documentation</a>
     */
	private void populateAccountCurrencies(Application application) {
		if(application != null && application.getAccounts() != null) {
			List<String> currencies = new ArrayList<>();
			currencies.add("*");

			for(Account account: application.getAccounts()){
				account.setCurrencies(currencies);
			}
		}
	}

	private void populateLegalName(Application application, NewWorkflowRequest request) {
		Name legalName = new Name();
		legalName.setFirstName(request.getFirstName());
		legalName.setLastName(request.getLastName());
		application.getParties().add(new Party());
		//Create Primary applicant Factory Party to create all required model objects
		application.getParties().set(0, partyFactory.createPrimaryApplicantParty(application.getParties().get(0)));
		application.getParties().get(0).getPersonal().getIdentity().setLegalName(legalName);
	}

	/**
	 * Update validation errors (what's missing) for application
	 * @see <a href="https://confluence.bmogc.net/display/PWO/Workflow+Service#WorkflowService-Updateswhat'smissing">Workflow Service Confluence Documentation</a>
	 */
	private void validationErrorsCheck(Application application, final Action action) {
		try{
			validationManager.validateModel(application, action);
			application.setValidationErrors(new ArrayList<>());
		} catch(ConstraintViolationException cvx) {
			logger.warn("Failed to check validation errors for application id: ",application.getApplicationId(),cvx);
			ValidationErrorResponse validationErrorResponse = constraintViolationExceptionHandler.createValidationErrorResponse(cvx);
			application.setValidationErrors(validationErrorResponse.getValidationErrors());
		}
	}

	@Override
	public Application removePartyFromApplication(String applicationId, String partyRefId) {
		RetrieveForUpdateResponse retrieveForUpdateResponse = retrieveForUpdate(applicationId);
		RetrieveApplicationResponse retrieveAppResponse = retrieveForUpdateResponse.retrieveApplicationResponse;

		ApplicationData existingApplicationData = retrieveAppResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData();
		Application existingApp = convertorService.getOnboardApplicationData(applicationId, existingApplicationData, retrieveForUpdateResponse.workflowStatus);

		Application updatedApp = applicationsService.removeSpousePartyFromApplication(existingApp, partyRefId);
		updatedApp.setStatus(retrieveForUpdateResponse.workflowStatus);

		storeUpdatedApplication(updatedApp, existingApplicationData, applicationId, retrieveAppResponse.getBody());

		return updatedApp;
	}
	
	@Override
	public Application addJointApplicantToApplication(String applicationId, Party party) {
		
		Name legalName = party.getPersonal().getIdentity().getLegalName();
		
        String ecifId = partiesService.createParty(legalName.getFirstName(),legalName.getLastName());
        
        Party jointApplicantParty =  partyFactory.createJointApplicantParty(party);
        jointApplicantParty.getPersonal().getIdentity().setLegalName(legalName);

		RetrieveForUpdateResponse retrieveForUpdateResponse = retrieveForUpdate(applicationId);
		RetrieveApplicationResponse retrieveAppResponse = retrieveForUpdateResponse.retrieveApplicationResponse;

		ApplicationData existingApplicationData = retrieveAppResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData();		
		Application existingApp = convertorService.getOnboardApplicationData(applicationId, existingApplicationData, AppStatus.DATA_COLLECTION.toString());

		net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party jointParty =  new net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Party();
		PersonalInformation info = new PersonalInformation();
		info.setEcifId(ecifId);
		jointParty.setPersonalInformation(info);
		jointParty.setPartyRefId(jointApplicantParty.getPartyRefId());
		
		existingApplicationData.getParties().add(jointParty);		
		
		Application updatedApp =  applicationsService.addJointApplicantToApplication(existingApp, jointApplicantParty);
		
		updatedApp.setStatus(retrieveForUpdateResponse.workflowStatus);

		storeUpdatedApplication(updatedApp, existingApplicationData, applicationId, retrieveAppResponse.getBody());

		return updatedApp;
	}

	@Override
	public Application removeAccountFromApplication(String applicationId, String accountRefId) {
        validationManager.validateId(applicationId, IdType.Application);
        validationManager.validateId(accountRefId, IdType.Account);
		RetrieveForUpdateResponse retrieveForUpdateResponse = retrieveForUpdate(applicationId);
		RetrieveApplicationResponse retrieveAppResponse = retrieveForUpdateResponse.retrieveApplicationResponse;

		ApplicationData existingApplicationData = retrieveAppResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData();
		Application existingApp = convertorService.getOnboardApplicationData(applicationId, existingApplicationData, retrieveForUpdateResponse.workflowStatus);

		Application updatedApp = applicationsService.removeAccountFromApplication(existingApp, accountRefId);
		
		cleanUpMultiApplicantsInvestmentExperiences(updatedApp);
		cleanUpW8W9Forms(updatedApp);	
		
		updatedApp.setStatus(retrieveForUpdateResponse.workflowStatus);

		storeUpdatedApplication(updatedApp, existingApplicationData, applicationId, retrieveAppResponse.getBody());

		return updatedApp;
	}
	
	private void cleanUpW8W9Forms(Application updatedApp) {
		
		if(updatedApp.getAccounts().stream().anyMatch(acc -> !acc.isJoint() && !acc.isIndividual() && !acc.isTfsa())){
			Party primaryParty = updatedApp.getPrimaryApplicant();
			primaryParty.setTaxation(new Taxation());
		}		
	}
	
	
	void checkAndSetDocumentPreference(Application application) {
		if (Optional.ofNullable(application.getClientAccessId()).isPresent()
				&& Optional.ofNullable(application.getClientAccessId().getHasDeclinedOnlineAccess()).isPresent()
				&& application.getClientAccessId().getHasDeclinedOnlineAccess()
				&& Optional.ofNullable(application.getClientMetadata()).isPresent()
				&& DECLINED_ONLINE_ACCESS.equalsIgnoreCase(application.getClientMetadata().get("isGatewayExisting"))
				&& Optional.ofNullable(application.getPrimaryApplicant().getPreferences()).isPresent()) {
			application.getPrimaryApplicant().getPreferences().setIsReceiveStatementByMail(true);
		}
	}
	
	private void checkAndSetJointApplicantsResidenceAddress(Application application) {
		if (Optional.ofNullable(application.getPrimaryApplicant()).isPresent()
				&& Optional.ofNullable(application.getPrimaryApplicant().getPersonal()).isPresent()
				&& Optional.ofNullable(application.getPrimaryApplicant().getPersonal().getResidence()).isPresent()) {
			
			if (Optional.ofNullable(application.getPrimaryApplicant().getPersonal().getResidence().getPrimaryAddress())
					.isPresent() && Optional.ofNullable(application.getJointApplicants()).isPresent()) {
				List<Party> coApplicantsPrimaryAddrSameAsPrimayApplicantPrimaryAddr = application.getJointApplicants()
						.stream()
						.filter(v -> Optional.ofNullable(v.getPersonal()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence().getPrimaryAddress()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence().getPrimaryAddressSourceOption())
										.isPresent()
								&& v.getPersonal().getResidence().getPrimaryAddressSourceOption()
										.equals(Constants.SAME_PRIMARY_APPLICANT_PRIMARY_ADDR))
						.collect(Collectors.toList());

				if (Optional.ofNullable(coApplicantsPrimaryAddrSameAsPrimayApplicantPrimaryAddr).isPresent()
						&& !CollectionUtils.isEmpty(coApplicantsPrimaryAddrSameAsPrimayApplicantPrimaryAddr)) {
					coApplicantsPrimaryAddrSameAsPrimayApplicantPrimaryAddr.stream()
							.forEach(p -> updateAddress(
									application.getPrimaryApplicant().getPersonal().getResidence().getPrimaryAddress(),
									p.getPersonal().getResidence().getPrimaryAddress()));
				}
			}
			
			if (Optional
					.ofNullable(application.getPrimaryApplicant().getPersonal().getResidence().getAlternateAddress())
					.isPresent() && Optional.ofNullable(application.getJointApplicants()).isPresent()) {
				List<Party> coApplicantsPrimaryAddrSameAsPrimayApplicantAlternateAddr = application.getJointApplicants()
						.stream()
						.filter(v -> Optional.ofNullable(v.getPersonal()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence().getPrimaryAddress()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence().getPrimaryAddressSourceOption())
										.isPresent()
								&& v.getPersonal().getResidence().getPrimaryAddressSourceOption()
										.equals(Constants.SAME_PRIMARY_APPLICANT_ALTERNATE_ADDR))
						.collect(Collectors.toList());

				List<Party> coApplicantsAlternateAddrSameAsPrimayApplicantAlternateAddr = application
						.getJointApplicants().stream()
						.filter(v -> Optional.ofNullable(v.getPersonal()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence().getAlternateAddress()).isPresent()
								&& Optional.ofNullable(v.getPersonal().getResidence().getAlternateAddressSourceOption())
										.isPresent()
								&& v.getPersonal().getResidence().getAlternateAddressSourceOption()
										.equals(Constants.SAME_PRIMARY_APPLICANT_ALTERNATE_ADDR))
						.collect(Collectors.toList());

				if (Optional.ofNullable(coApplicantsPrimaryAddrSameAsPrimayApplicantAlternateAddr).isPresent()
						&& !CollectionUtils.isEmpty(coApplicantsPrimaryAddrSameAsPrimayApplicantAlternateAddr)) {
					coApplicantsPrimaryAddrSameAsPrimayApplicantAlternateAddr.stream()
							.forEach(p -> updateAddress(
									application.getPrimaryApplicant().getPersonal().getResidence()
											.getAlternateAddress(),
									p.getPersonal().getResidence().getPrimaryAddress()));
				}

				if (Optional.ofNullable(coApplicantsAlternateAddrSameAsPrimayApplicantAlternateAddr).isPresent()
						&& !CollectionUtils.isEmpty(coApplicantsAlternateAddrSameAsPrimayApplicantAlternateAddr)) {
					coApplicantsAlternateAddrSameAsPrimayApplicantAlternateAddr.stream()
							.forEach(p -> updateAddress(
									application.getPrimaryApplicant().getPersonal().getResidence()
											.getAlternateAddress(),
									p.getPersonal().getResidence().getAlternateAddress()));
				}
			}		
		}
	
	}
	
	private void updateAddress(Address sourceAddress, Address targetAddress ) {
		targetAddress.setStreetAddress(sourceAddress.getStreetAddress());
		targetAddress.setProvince(sourceAddress.getProvince());
		targetAddress.setCity(sourceAddress.getCity());
		targetAddress.setCountry(sourceAddress.getCountry());
		targetAddress.setPostalCode(sourceAddress.getPostalCode());
		targetAddress.setUnitNumber(sourceAddress.getUnitNumber());
		targetAddress.setLivedInLessThanTwoYears(sourceAddress.getLivedInLessThanTwoYears());
	}

	@Override
	public Application createBilApplication(Application application) {
		
		validateApplicationModel(application);
		String ecifId = initalizeBilApplication(application);
		
		SaveApplicationRequest saveApplicationRequest = prepareSaveApplicationRequest(application, ecifId);
		SaveApplicationResponse response = onboardApplicationRepository.save(saveApplicationRequest, ecifId);
		application.setApplicationId(response.getBody().getWorkflowId());
		application.setLastUpdated(response.getBody().getLastUpdatedDateTime());		
	
		//reset the password
		resetPassword(application);			
		validationErrorsCheck(application, Action.SUBMIT);				
		
		httpServletResponse.setHeader(UserContext.WORKFLOW_ID, application.getApplicationId());
		httpServletResponse.setHeader(UserContext.SSO_ID, ecifId);
		httpServletResponse.setHeader(XATTRS, UserContext.SSO_ID +","+UserContext.X_BMO_BUSINESS_CATEGORY +","+EMAIL_ID +","+ UserContext.WORKFLOW_ID);
		httpServletResponse.setHeader(AMEAI_FLAG, "stream");
		httpServletResponse.setHeader(EMAIL_ID, application.getParties().get(0).getPersonal().getIdentity().getPrimaryEmailAddress());
		httpServletResponse.setHeader(USER_ID, httpServletRequest.getHeader(UserContext.IV_USER_HEADER));
		httpServletResponse.setHeader(UserContext.X_BMO_BUSINESS_CATEGORY, httpServletRequest.getHeader(UserContext.X_BMO_BUSINESS_CATEGORY));

		return application;
	}

	protected void resetPassword(Application application) {
		application.getParties().stream()
				.filter(f -> (f.getRoles().contains(com.bmo.channel.pwob.model.onboarding.PartyRole.PRIMARY_APPLICANT)
						|| f.getRoles().contains(com.bmo.channel.pwob.model.onboarding.PartyRole.JOINT_APPLICANT)))
				.forEach(p -> p.setPassword(null));
	}

	private String initalizeBilApplication(Application application) {
		
		application.setStatus(AppStatus.DATA_COLLECTION.toString());		
		//Set LOB
		application.setApplicationLob(usersService.currentUser().getLob());
		
		//set bil release (different constant)
		application.setRelease(Application.CURRENT_RELEASE);
		
		//application.setLocale(header.getLocale());				
		
		String firstName = application.getParties().get(0).getPersonal().getIdentity().getLegalName().getFirstName();
		String lastName = application.getParties().get(0).getPersonal().getIdentity().getLegalName().getLastName();
		String ecifId = partiesService.createParty(firstName, lastName);	
		return ecifId;
				
	}

	@Override
	public NextStepsData retrieveNextStepsData(String applicationID) {
		
		SavedApplication savedApp = retrieveWorkflowSummary(applicationID);
		securityService.authorizeReadAccess(savedApp.getIaCode());
    	final RetrieveApplicationResponse response = retrieveApplicationResponse(applicationID,savedApp.getCustomerId());
    	return new NextStepsDataMapper().apply(savedApp, response);
		
	}

	@Override
	public Application updateBilApplication(Application application, String user, String applicationId) {
		
		//UIhave to set below value after save operation 
		application.setApplicationId(applicationId);
		
		validateApplicationModel(application);

		RetrieveForUpdateResponse retrieveForUpdateResponse = retrieveForUpdate(applicationId);
		RetrieveApplicationResponse retrieveAppResponse = retrieveForUpdateResponse.retrieveApplicationResponse;
		ApplicationData originalApplicationData = retrieveAppResponse.getBody().getPayload().getAPPLICATIONDATA().getAppData();		
		storeUpdatedBilApplication(application, originalApplicationData, applicationId, retrieveAppResponse.getBody(), user);
		resetPassword(application);
		return application;
	}

	private void storeUpdatedBilApplication(Application updatedApplication, ApplicationData originalApplicationData,
			String applicationId, RetrieveApplicationResponse.Body body, String userId) {		
				
		XMLGregorianCalendar lastUpdatedDateTime = body.getLastUpdatedDateTime();		
		ApplicationData newApplicationData = mergeApplicationWithExistingApplicationData(updatedApplication, originalApplicationData);

		ApplicationDataUpdateRequest updateReq = new ApplicationDataUpdateRequest();
		updateReq.setRequestorId(userId);
		updateReq.setApplicationId(applicationId);
		updateReq.setLastUpdatedDateTime(lastUpdatedDateTime);		

		Metadata metadata = prepareMetaData(updatedApplication, userId);
		SaveApplicationResponse response = sendApplicationUpdate(newApplicationData, updateReq, metadata, body);

		validationErrorsCheck(updatedApplication, Action.SUBMIT);
		updatedApplication.setLastUpdated(response.getBody().getLastUpdatedDateTime());		
	}	

}
