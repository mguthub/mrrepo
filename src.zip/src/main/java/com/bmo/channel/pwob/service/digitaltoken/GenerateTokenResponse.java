/**
 * 
 */
package com.bmo.channel.pwob.service.digitaltoken;

/**
 * @author vvallia
 *
 */
public class GenerateTokenResponse {
	
	private String payLoad;

	private String cachedToken;
	
	private String status;
	
	private String detail;

	/**
	 * @return the payLoad
	 */
	public String getPayLoad() {
		return payLoad;
	}

	/**
	 * @param status the payLoad to set
	 */
	
	public void setPayLoad(String payLoad) {
		this.payLoad = payLoad;
	}

	/**
	 * @return the cachedToken
	 */
	public String getCachedToken() {
		return cachedToken;
	}
	
	/**
	 * @param status the cachedToken to set
	 */

	public void setCachedToken(String cachedToken) {
		this.cachedToken = cachedToken;
	}
	
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the detail
	 */
	public String getDetail() {
		return detail;
	}

	/**
	 * @param detail the detail to set
	 */
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
}
