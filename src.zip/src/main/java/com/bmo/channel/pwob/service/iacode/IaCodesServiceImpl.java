package com.bmo.channel.pwob.service.iacode;

import java.util.List;



import java.util.stream.Collectors;

import javax.xml.ws.Holder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.user.AuthenticatedUser;
import com.bmo.channel.pwob.util.APIHeaderRequestComponent;
import com.bmo.channel.pwob.validation.ErrorCodes;
//import com.bmo.investmentadvisor.GetUsersForInvestmentAdvisorCodeResponse;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetUsersForInvestmentAdvisorCodeResponseType.PcdUsers.PcdUser;

import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetApprovingBranchManagersRequestPayload;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetApprovingBranchManagersRequestType;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetApprovingBranchManagersResponsePayload;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetApprovingInvestmentAdvisorsRequestPayload;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetApprovingInvestmentAdvisorsRequestType;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetApprovingInvestmentAdvisorsResponsePayload;

import net.bmogc.xmlns.api.header.v1.APIHeaderRequest;
import net.bmogc.xmlns.api.header.v1.APIHeaderResponse;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetDetailedUserInformationRequestPayload;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetDetailedUserInformationRequestType;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetDetailedUserInformationResponsePayload;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetDetailedUserInformationResponseType;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetUsersForInvestmentAdvisorCodeRequestPayload;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetUsersForInvestmentAdvisorCodeRequestType;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetUsersForInvestmentAdvisorCodeResponsePayload;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetUsersForInvestmentAdvisorCodeResponseType;
import net.bmogc.xmlns.hub.cg.wealthmanagement.investmentadvisorunit.intf.v2_0.APIError;
import net.bmogc.xmlns.hub.cg.wealthmanagement.investmentadvisorunit.intf.v2_0.InvestmentAdvisorUnitV2;

@Service
public class IaCodesServiceImpl implements IaCodesService{
	
	private static Logger logger = LoggerFactory.getLogger(IaCodesServiceImpl.class);
	
	@Autowired
	InvestmentAdvisorUnitV2 investmentAdvisorUnit;
		
	@Autowired
	private APIHeaderRequestComponent apiHeaderRequestComponent;

	final String CHANNEL = "WEB.ASSIST";
	
	@Override
	public GetDetailedUserInformationResponseType  getUserInformation(AuthenticatedUser authenticatedUser) {
		
		APIHeaderResponse response = null;		
		final APIHeaderRequest requestHeader = createHeader("getDetailedUserInformation");		
		String networkId = authenticatedUser.getNetworkId();

		GetDetailedUserInformationRequestPayload iaPayload = new GetDetailedUserInformationRequestPayload();
		GetDetailedUserInformationRequestType iaRequest = new GetDetailedUserInformationRequestType();
		
		iaRequest.setNetworkId(networkId);	
		iaPayload.setGetDetailedUserInformationRequestBody(iaRequest);		
		GetDetailedUserInformationResponsePayload responsePayload;
		
		try {
				responsePayload = investmentAdvisorUnit.getDetailedUserInformation(iaPayload, requestHeader, new Holder<APIHeaderResponse>(response));				
				return responsePayload.getGetDetailedUserInformationResponseBody();			
				
			} catch (APIError ex) {
				logger.error("HUB error- Failed to get detailed user information with Network id:  ",authenticatedUser.getNetworkId(),ex);
				throw new WebServiceException(ex);
		}
	}	
	

	
	private APIHeaderRequest createHeader(String value) {
		return apiHeaderRequestComponent
				.getHubBuilder()
				.originatorResource("iaCodesService")
				.originatorResourceFunction(value)
				.build();
	}
		
	@Override
	public List<PcdUser> usersForIaCode(String iaCode, String branchCode) {
		GetUsersForInvestmentAdvisorCodeRequestPayload request = new GetUsersForInvestmentAdvisorCodeRequestPayload();		
		
		request.setGetUsersForInvestmentAdvisorCodeRequestBody(new GetUsersForInvestmentAdvisorCodeRequestType());
		request.getGetUsersForInvestmentAdvisorCodeRequestBody().setIaCode(iaCode);
		
		try {
			APIHeaderResponse response = null;
			GetUsersForInvestmentAdvisorCodeResponsePayload responsePayload = null;
			final APIHeaderRequest requestHeader = createHeader("getUsersForInvestmentAdvisorCode");
			
			responsePayload = investmentAdvisorUnit.getUsersForInvestmentAdvisorCode(request, requestHeader, new Holder<APIHeaderResponse>(response));
			
			if(responsePayload != null && responsePayload.getGetUsersForInvestmentAdvisorCodeResponseBody() != null && responsePayload.getGetUsersForInvestmentAdvisorCodeResponseBody().getPcdUsers() != null) {
				List<PcdUser> users = responsePayload.getGetUsersForInvestmentAdvisorCodeResponseBody().getPcdUsers().getPcdUser();
				if(users.size() > 0) {
					//return users.stream().map(f -> f.getNetworkId()).collect(Collectors.toList());
					return users;
				}
				
			}
		} catch (APIError ex) {
			logger.error("HUB error- Failed to get user information for investment advisor code: ",
					request.getGetUsersForInvestmentAdvisorCodeRequestBody().getIaCode(),ex);
			throw new WebServiceException(ex);
		}
		logger.error("No user found for IA code: "+ request.getGetUsersForInvestmentAdvisorCodeRequestBody().getIaCode());
		throw new NotFoundException(ErrorCodes.NO_USERS_FOUND_FOR_CODE);
	}
	
	
	@Override
	public List<net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser> iaUsersForIaCode(String iaCode, String branchCode) {
		
		List<net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser> users = null;
		GetApprovingInvestmentAdvisorsRequestPayload request = new GetApprovingInvestmentAdvisorsRequestPayload();		
		
		request.setGetApprovingInvestmentAdvisorsRequestBody(new GetApprovingInvestmentAdvisorsRequestType());
		request.getGetApprovingInvestmentAdvisorsRequestBody().setIaCode(iaCode);
		
		try {
			APIHeaderResponse response = null;
			GetApprovingInvestmentAdvisorsResponsePayload responsePayload = null;
			final APIHeaderRequest requestHeader = createHeader("getUsersForInvestmentAdvisorCode");
			
			responsePayload = investmentAdvisorUnit.getApprovingInvestmentAdvisors(request, requestHeader, new Holder<APIHeaderResponse>(response));
			
			if(responsePayload != null && responsePayload.getGetApprovingInvestmentAdvisorsResponseBody() != null && responsePayload.getGetApprovingInvestmentAdvisorsResponseBody().getPcdUsers() != null) {
				users = responsePayload.getGetApprovingInvestmentAdvisorsResponseBody().getPcdUsers().getPcdUser();
				if(users.size() > 0) {					
					return users;
				}				
			}
		} catch (APIError ex) {
			logger.error("HUB error- Failed to get user information for investment advisor code: ",	request.getGetApprovingInvestmentAdvisorsRequestBody().getIaCode(),ex);
			throw new WebServiceException(ex);
		}
		logger.error("No user found for IA code: "+ request.getGetApprovingInvestmentAdvisorsRequestBody().getIaCode());		
		return users;
	}
}
