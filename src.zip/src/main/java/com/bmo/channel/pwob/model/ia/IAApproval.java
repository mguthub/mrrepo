package com.bmo.channel.pwob.model.ia;

import java.util.List;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.Pattern;

import com.bmo.channel.pwob.validation.ErrorCodes;

import io.swagger.annotations.ApiModelProperty;

public class IAApproval {
	
	@Pattern(regexp="^[\\p{IsLatin}\\s-'0-9_ ~`+@!#$%*()=,<.>?;:{}|&^\\[\\]/  ]{0,4000}$", message=ErrorCodes.INVALID_APPROVAL_COMMENT)
	private String comments;
	
	@AssertTrue(message=ErrorCodes.INVALID_REGISTERED_IN_CLIENT_PROVINCE_OF_RESIDENCE)
	private Boolean registeredInClientProvinceOfResidence;
	
	@AssertTrue(message=ErrorCodes.INVALID_DISCUSSED_RISK_TOLERANCE_AND_OBJECTIVES)
	private Boolean discussedRiskToleranceAndObjectives;
	
	@AssertTrue(message=ErrorCodes.INVALID_REVIEWED_SUITABLITY)
	private Boolean reviewedSuitability;
	
	@ApiModelProperty(value="list of bypassed network ids")
	private List<String> iaBypassList;

	@Pattern(regexp="^[\\p{IsLatin}\\s-'0-9_ ~`+@!#$%*()=,<.>?;:{}|&^\\[\\]/  ]{0,4000}$", message=ErrorCodes.INVALID_APPROVAL_DOCEDITCOMMENT)
	private String documentEdits;
	
	@ApiModelProperty(value="Self attestation checkbox for IA Licence confirmation")
	private Boolean isIALicenceConfirmed;
	
	public Boolean getIsIALicenceConfirmed() {
		return isIALicenceConfirmed;
	}

	public void setIsIALicenceConfirmed(Boolean isIALicenceConfirmed) {
		this.isIALicenceConfirmed = isIALicenceConfirmed;
	}
		
	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Boolean getDiscussedRiskToleranceAndObjectives() {
		return discussedRiskToleranceAndObjectives;
	}

	public void setDiscussedRiskToleranceAndObjectives(Boolean discussedRiskToleranceAndObjectives) {
		this.discussedRiskToleranceAndObjectives = discussedRiskToleranceAndObjectives;
	}

	public Boolean getReviewedSuitability() {
		return reviewedSuitability;
	}

	public void setReviewedSuitability(Boolean reviewedSuitability) {
		this.reviewedSuitability = reviewedSuitability;
	}

	public Boolean getRegisteredInClientProvinceOfResidence() {
		return registeredInClientProvinceOfResidence;
	}

	public void setRegisteredInClientProvinceOfResidence(Boolean registeredInClientProvinceOfResidence) {
		this.registeredInClientProvinceOfResidence = registeredInClientProvinceOfResidence;
	}

	public List<String> getIaBypassList() {
		return iaBypassList;
	}

	public void setIaBypassList(List<String> iaBypassList) {
		this.iaBypassList = iaBypassList;
	}

	public String getDocumentEdits() {
		return documentEdits;
	}

	public void setDocumentEdits(String documentEdits) {
		this.documentEdits = documentEdits;
	}

	
}
