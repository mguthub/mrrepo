package com.bmo.channel.pwob.service.applications;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.core.exception.UnauthorizedSecurityException;
import com.bmo.channel.pwob.model.applications.SavedApplication;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.service.user.UsersService;

@Component
public class NamePopulatorImpl implements NamePopulator {
	
	private static Logger logger = LoggerFactory.getLogger(NamePopulatorImpl.class);
	
	@Autowired
	UsersService usersService;

	@Autowired
	EventManager eventManager;

	@Override
	public void populateLastUpdatedByNames(List<SavedApplication> savedApplications) {
		for (SavedApplication savedApplication : savedApplications) {
			String lastUpdatedBy = savedApplication.getLastUpdatedBy();
			if(StringUtils.isNotBlank(lastUpdatedBy)) {
				try {
					User user = usersService.getUserByNetworkId(lastUpdatedBy);
					savedApplication.setLastUpdatedBy(user.getFirstName() + " " + user.getLastName());
				} catch(UnauthorizedSecurityException ex) {
					// this can happen if last updated by network id is no longer returned by users service
					logger.error("Failure in retrieving user information for network id: ",lastUpdatedBy, ex);
					eventManager.publishInfo("Could not retrieve user info for network id " + lastUpdatedBy +ex.getMessage());
				}
			}
		}
	}
}
