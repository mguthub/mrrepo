package com.bmo.channel.pwob.model.reference;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class CountryReference extends Reference{
	private List<StatProvReference> stateProvinces = new ArrayList<>();
	private String isoCode;
	
	public String getIsoCode() {
		return isoCode;
	}

	public void setIsoCode(String isoCode) {
		this.isoCode = isoCode;
	}

	public List<StatProvReference> getStateProvinces() {
		return stateProvinces;
	}

	public void setStateProvinces(List<StatProvReference> stateProvinces) {
		this.stateProvinces = stateProvinces;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((stateProvinces == null) ? 0 : stateProvinces.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CountryReference other = (CountryReference) obj;
		if (stateProvinces == null) {
			if (other.stateProvinces != null)
				return false;
		} else if (!stateProvinces.equals(other.stateProvinces))
			return false;
		return true;
	}
}
