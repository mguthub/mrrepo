package com.bmo.channel.pwob.model.user;

import java.util.List;

public class BranchIa {
	private String firstName;
	private String lastName;
	private List<String> iaCodes;

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public List<String> getIaCodes() {
		return iaCodes;
	}
	public void setIaCodes(List<String> iaCodes) {
		this.iaCodes = iaCodes;
	}
}
