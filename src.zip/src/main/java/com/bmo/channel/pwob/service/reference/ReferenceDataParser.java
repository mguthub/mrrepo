package com.bmo.channel.pwob.service.reference;

import java.util.List;
import java.util.Map;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.model.GetDataListForParameterResponseBody;

public interface ReferenceDataParser {
	 Map<UILocale, List<Reference>>  extractReferenceList(ReferenceType referenceType, GetDataListForParameterResponseBody getDataListForParameterResponseBody, UILocale locale);
}
