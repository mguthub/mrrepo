package com.bmo.channel.pwob.service.accounts;

import org.springframework.stereotype.Service;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.JointAccountDetails;
import com.bmo.channel.pwob.model.onboarding.Preferences;
import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.CreateAccountRequest;

@Service
public class AccountsServiceImpl implements AccountsService {

	@Override
	public Account createAccount(CreateAccountRequest request) {
		Account account = new Account();
		String type = request.getType();

		account.setType(type);
		account.setRefId(type + "-" + System.currentTimeMillis());

		if(account.isJoint()) {
			JointAccountDetails jointAccountDetails = new JointAccountDetails();
			jointAccountDetails.setPreferences(new Preferences());
			account.setJointAccountDetails(jointAccountDetails);
		}

		return account;
	}
}
