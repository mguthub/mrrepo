package com.bmo.channel.pwob.service.authorization;

/**
 * Actions that can be performed with a workflow.
 */
public enum PwobAction {
	CREATE_APPLICATION,
	UPDATE_APPLICATION,
	UPDATE_RELATIONSHIP_SUMMARY,
	RETRIEVE_RELATIONSHIP_SUMMARY,
	IA_APPROVAL,
	BM_APPROVAL,
	DELETE_WORKFLOW,
	UNLOCK_DATA,	
	GENERATE_DOCUMENTS,
	UPLOAD_DOCUMENT,
	/**
	 * Such as:
	 * <ol>
	 *  <li>activate esign</li>
	 *  <li>convert to paper sign</li>
	 *  <li>print</li>
	 *  <li>retrieve content</li>
	 * </ol>
	 */
	DOCUMENT_ACTION
}
