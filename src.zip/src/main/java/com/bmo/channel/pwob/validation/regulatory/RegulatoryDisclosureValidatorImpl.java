/**
 * @author akhales
 */
package com.bmo.channel.pwob.validation.regulatory;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.config.EnvironmentConfig;
import com.bmo.channel.pwob.model.onboarding.RegulatoryDisclosures;
import com.bmo.channel.pwob.model.onboarding.Relationship;
import com.bmo.channel.pwob.model.reference.OccupationReference;
import com.bmo.channel.pwob.service.reference.ReferencesService;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

@Component
public class RegulatoryDisclosureValidatorImpl  extends AbstractBaseValidator implements RegulatoryDisclosureValidator {
		
	@Autowired ValidationRequestFactory requestFactory;
	@Autowired UsersService userService;	
	@Autowired EnvironmentConfig environmentConfig;
	@Autowired ReferencesService referencesService;
	
	private static final String FOREIGN_PEP_OCCUPATION_PATTERN = "^[\\p{IsLatin}\\s-;'0-9_.&,/]{1,40}$";

	@Override
	public boolean validateRegulatory(RegulatoryDisclosures disclosure, ValidationRequest request) {
	
		boolean valid = true;
		
		request.setFieldName("iirocMember");
		request.setErrorCode(ErrorCodes.INVALID_IIROC_MEMBER);
		valid = validateIirocOrg(request, disclosure.getIirocMember(), disclosure.getIirocOrganization()) && valid;  
					
		request.setFieldName("haveInsiderRelationship");
		request.setErrorCode(ErrorCodes.INVALID_FLAG_HAVE_INSIDER_RELATIONSHIP);
		valid = validateRelFlags(request, disclosure.getHaveInsiderRelationship(), disclosure.getInsiderRelationships(), "insiderRelationships", ErrorCodes.INVALID_INSIDER_RELATIONSHIPS) && valid;
		
		if(disclosure.getHaveInsiderRelationship() != null && disclosure.getHaveInsiderRelationship()) {
			request.setFieldName("isReportingInsider");
			request.setErrorCode(ErrorCodes.INVALID_FLAG_IS_REPORTING_INSIDER);	
			valid = validateRelFlags(request, disclosure.getIsReportingInsider(), disclosure.getReportingInsiderRelationships(), "reportingInsiderRelationships", ErrorCodes.INVALID_REPORTING_INSIDER_RELATIONSHIPS) && valid;
		}
		
		request.setFieldName("significantShareholder");
		request.setErrorCode(ErrorCodes.INVALID_FLAG_SIGNIFICANT_SHAREHOLDER);
		valid = validateRelFlags(request, disclosure.getSignificantShareholder(), disclosure.getSignificantShareholdings(), "significantShareholdings", ErrorCodes.INVALID_SIGNIFICANT_SHAREHOLDINGS) && valid;
		
		request.setFieldName("controlRelationship");
		request.setErrorCode(ErrorCodes.INVALID_FLAG_CONTROL_RELATIONSHIP);
		valid = validateRelFlags(request, disclosure.getControlRelationship(), disclosure.getControlRelationships(), "controlRelationships", ErrorCodes.INVALID_CONTROL_RELATIONSHIPS) && valid;
			
		return valid;
	}

	private boolean validateIirocOrg(ValidationRequest request, Boolean flag, String iirocOrg){
		boolean valid = true;
		valid = this.checkNull(request, flag) && valid;
		
		if(Optional.ofNullable(flag).isPresent() && flag && StringUtils.isBlank(iirocOrg)) {
			request.setFieldName("iirocOrganization");
			request.setErrorCode(ErrorCodes.INVALID_IIROC_ORGANIZATIONS);		
			request.addConstraintViolation();
			valid = false;
	
		}
		return valid;
	}
	
	private boolean validateRelFlags(ValidationRequest request, Boolean flag,List<Relationship> relList,String fieldName, String errorCode){
		boolean valid = true;
		valid = this.checkNull(request, flag) && valid;
		
		if(Optional.ofNullable(flag).isPresent() && flag) {
			request.setFieldName(fieldName);
			request.setErrorCode(errorCode);	
			valid = this.validateRelList(relList, request) && valid;
		}
		return valid;
	}
	
	private boolean validateRelList(List<Relationship> relList, ValidationRequest request) {
		if(CollectionUtils.isNotEmpty(relList) && relList.size() <= 10) {
			for(Relationship rel : relList){
				if(!this.isValidEntry(rel)) {
					request.addConstraintViolation();						
					return false;
				}
			}
		} else {		
			request.addConstraintViolation();
				return false;
		}
		return true;
	}
	
	private boolean isValidEntry(Relationship relationship) {
		return StringUtils.isNotBlank(relationship.getCompanyName()) && StringUtils.isNotBlank(relationship.getCompanyTradingSymbol());
	}
	
	@Override
	public boolean validatePoliticallyExposedPerson(RegulatoryDisclosures disclosure, ValidationRequest request) {
		boolean valid = true;
		boolean isPoliticalFlag = true;
			request.setFieldName("isPoliticallyExposedPerson");
			request.setErrorCode(ErrorCodes.INVALID_IS_POLITICALLY_EXPOSED_PERSON);
			isPoliticalFlag = this.checkNull(request, disclosure.getIsPoliticallyExposedPerson());

			if (isPoliticalFlag && disclosure.getIsPoliticallyExposedPerson()) {
				if (StringUtils.isBlank(disclosure.getPoliticallyExposedPersonType())) {
					request.addConstraintViolation("politicallyExposedPersonType",ErrorCodes.INVALID_POLITICALLY_EXPOSED_TYPE);
					valid = false;
				}
				else if (StringUtils.isBlank(disclosure.getPoliticallyExposedPersonPosition())) {
					request.addConstraintViolation("politicallyExposedPersonPosition",ErrorCodes.INVALID_POLITICALLY_EXPOSED_POSITION);
					valid = false;
				}
				
				if(StringUtils.isNoneBlank(disclosure.getPoliticallyExposedPersonType(), disclosure.getPoliticallyExposedPersonPosition())) {
					
					OccupationReference occupationReference =  referencesService.getOccupationReferences(disclosure.getPoliticallyExposedPersonPosition());
					if (disclosure.getPoliticallyExposedPersonType().equals(RefDataValues.PEP_TYPE_DOMESTIC) && 
							(occupationReference == null || !occupationReference.isPoliticallyExposedOccupation())) {
							request.addConstraintViolation("politicallyExposedPersonPosition",ErrorCodes.INVALID_POLITICALLY_EXPOSED_POSITION);
							valid = false;
					}
					
					else if (disclosure.getPoliticallyExposedPersonType().equals(RefDataValues.PEP_TYPE_FOREIGN) && 
							!doesPatternMatch(disclosure.getPoliticallyExposedPersonPosition(), FOREIGN_PEP_OCCUPATION_PATTERN)) {
						
						request.addConstraintViolation("politicallyExposedPersonPosition",ErrorCodes.INVALID_POLITICALLY_EXPOSED_POSITION);
						valid = false;
					}
					
				}
			}
			else {
				if (disclosure.getPoliticallyExposedPersonType() != null) {
					request.addConstraintViolation("politicallyExposedPersonType", ErrorCodes.INVALID_POLITICALLY_EXPOSED_TYPE);
					valid = false;
				}
				
				if (disclosure.getPoliticallyExposedPersonPosition() != null) {
					request.addConstraintViolation("politicallyExposedPersonPosition", ErrorCodes.INVALID_POLITICALLY_EXPOSED_POSITION);
					valid = false;
				}
			}		

		return valid && isPoliticalFlag;
	}
}
