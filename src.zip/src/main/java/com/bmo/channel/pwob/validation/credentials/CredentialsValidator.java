package com.bmo.channel.pwob.validation.credentials;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.ClientAccessId;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;


public class CredentialsValidator extends AbstractBaseValidator implements ConstraintValidator<ValidCredentials, ClientAccessId> {

	
	@Autowired ValidationRequestFactory validationRequestFactory;

	@Autowired
	private UsersService userService;
	
	private static final String DECLINED_ONLINE_ACCESS="declineAccess";
	
	@Override
	public void initialize(ValidCredentials constraintAnnotation) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isValid(ClientAccessId value, ConstraintValidatorContext context) {
		// TODO Auto-generated method stub
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();		

		ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).build();
				
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}

		boolean valid = true;
		request.setFieldName("hasDeclinedAccess");
		request.setErrorCode(ErrorCodes.INVALID_HAS_DECLINED_ACCESS);
		
		//valid = checkNull(request,value.getHasDeclinedOnlineAccess()) && valid;
		
		if(validationContext.getApplication().getClientMetadata().get("onlineAccountAccess")==null){
			request.addConstraintViolation();
			valid=false;
		}
			
	    else if(value.getHasDeclinedOnlineAccess()== null && !DECLINED_ONLINE_ACCESS.equalsIgnoreCase(validationContext.getApplication().getClientMetadata().get("isGatewayExisting")))
        {
            this.createConstraintViolation(context,  ErrorCodes.INVALID_GATEWAY_USER_ID, "credential.userId");
            valid=false;
        }
		return valid;
	}
}
