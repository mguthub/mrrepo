package com.bmo.channel.pwob.validation.residence;

import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface DependentValidator {
	boolean validateDependents(Identity identity, boolean isPrimaryApplicantSpose, ValidationRequest request);
}
