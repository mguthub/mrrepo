package com.bmo.channel.pwob.exception;

import java.util.List;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;

import org.apache.cxf.jaxrs.ext.MessageContext;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.core.event.MessageEvent;
import com.bmo.channel.core.exception.ExceptionUtil;
import com.bmo.channel.core.exception.ErrorResponse;
import com.bmo.channel.core.mapping.DataMapper;

public class UnrecognizedPropertyExceptionHandler implements ExceptionMapper<UnrecognizedPropertyException> {
	
	@Autowired
	private EventManager eventManager;
	@Autowired
	private DataMapper dataMapper;
	
	@Context
	private MessageContext messageContext;
	
	public UnrecognizedPropertyExceptionHandler(DataMapper dataMapper) {
		this.dataMapper = dataMapper;
	}
	
	public Response toResponse(UnrecognizedPropertyException exception) {
		MessageEvent messageEvent = eventManager.publishError(exception);
		ErrorResponse errorResponse = dataMapper.map(messageEvent, ErrorResponse.class);
		
		String message = "Unrecognized field '" + exception.getPropertyName() + "' " + "(" + exception.getReferringClass() + ")";
		errorResponse.setMessage(message);

		ResponseBuilder responseBuilder = Response.status(getStatusCode(exception)).entity(errorResponse);
		addContentType(responseBuilder);
		return responseBuilder.build();
	}

	/**
	 * If request is invalid JSON, for some reason the Accept request header is not respected and
	 * the Content-Type defaults to application/octet-stream. This is incorrect, since the 
	 * response is application/json.
	 * This method fixes that by specifying the correct Content-Type, but only if that was what
	 * was originally requested.
	 * @link https://issues.apache.org/jira/browse/CXF-6101
	 * @param responseBuilder
	 */
	private void addContentType(ResponseBuilder responseBuilder) {
		if(isAcceptApplicationJson()) {
			responseBuilder.header("Content-Type", MediaType.APPLICATION_JSON);
		}
	}

	boolean isAcceptApplicationJson() {
		List<String> requestHeaders = messageContext.getHttpHeaders().getRequestHeader("Accept");
		return requestHeaders != null && !requestHeaders.isEmpty() && MediaType.APPLICATION_JSON.equalsIgnoreCase(requestHeaders.get(0));
	}

	protected Status getStatusCode(Exception exception) {
		return ExceptionUtil.getExceptionInfo(exception).getHttpStatusCode();
	}

	protected EventManager getEventManager() {
		return eventManager;
	}
	protected void setEventManager(EventManager eventManager) {
		this.eventManager = eventManager;
	}

	protected DataMapper getDataMapper() {
		return dataMapper;
	}
	protected void setDataMapper(DataMapper dataMapper) {
		this.dataMapper = dataMapper;
	}

	protected void setMessageContext(MessageContext messageContext) {
		this.messageContext = messageContext;
	}
}
