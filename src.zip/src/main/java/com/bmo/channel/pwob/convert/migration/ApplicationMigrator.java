package com.bmo.channel.pwob.convert.migration;

import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;

/**
 * Defines an interface that for migration of application data.
 * Each migration is guaranteed to be run only one time.
 * @author Ryan Chambers (rcham02)
 */
public interface ApplicationMigrator {

	/**
	 * @param application   Application to be migrated. This class will be updated.
	 * @param featureFlags  A list of all feature flags.
	 */
	void migrateApplication(Application application, FeatureFlags systemFeatureFlags);

	boolean isMigrationRequired(Application application, FeatureFlags systemFeatureFlags);
}
