package com.bmo.channel.pwob.convert;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.dozer.DozerConverter;

import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.InvestmentExperience;

public class PwobInvestmentExperienceCustomConverter
	extends DozerConverter<com.bmo.channel.pwob.model.onboarding.InvestmentExperience, net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.InvestmentExperience>{
	
	//Must match reference data for InvestmentExperience in AbstractBaseReferenceService
	private static final String EXP_BONDS="1";
	private static final String EXP_OPTIONS="2";
	private static final String EXP_MUTUAL_FUNDS="3";
	private static final String EXP_COMMODITIES="4";
	private static final String EXP_STOCKS="5";
	private static final String EXP_SHORTS="6";
	private static final String EXP_ALTERNATIVES="7";
	private static final String EXP_NONE="8";	
	
	public PwobInvestmentExperienceCustomConverter(){
		super(com.bmo.channel.pwob.model.onboarding.InvestmentExperience.class, net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.InvestmentExperience.class);
	}

	@Override
	public InvestmentExperience convertTo(com.bmo.channel.pwob.model.onboarding.InvestmentExperience source, InvestmentExperience destination) {
		destination = new InvestmentExperience();

		if(Optional.ofNullable(source).isPresent() && CollectionUtils.isNotEmpty(source.getPastExperience())){						
			initFlags(destination);
			for(String exp: source.getPastExperience()){
				switch(exp){
					
					case EXP_BONDS:
						destination.setInvExpBonds(true);
						break;
					
					case EXP_MUTUAL_FUNDS:
						destination.setInvExpMutualFunds(true);
						break;

					case EXP_STOCKS:
						destination.setInvExpStocks(true);
						break;
					
					case EXP_SHORTS:
						destination.setInvExpShortSales(true);
						break;
						
					case EXP_OPTIONS:
						destination.setInvExpOptions(true);
						break;
						
					case EXP_COMMODITIES:
						destination.setInvExpCommodities(true);
						break;
						
					case EXP_NONE:
						destination.setInvExpNone(true);
						break;
						
					case EXP_ALTERNATIVES:
						destination.setInvExpAltInvestments(true);
						break;
						
					default:
						break;
				}
			}
			destination.setAltInvestmentExperience(source.getAltInvestmentExperience());
		}
		return destination;
	}

	@Override
	public com.bmo.channel.pwob.model.onboarding.InvestmentExperience convertFrom(InvestmentExperience source, com.bmo.channel.pwob.model.onboarding.InvestmentExperience destination) {
		destination = new com.bmo.channel.pwob.model.onboarding.InvestmentExperience();
		
		if(Optional.ofNullable(source).isPresent()){			
			List<String> investmentExperience = new ArrayList<>();
			
			if(Optional.ofNullable(source.isInvExpBonds()).isPresent() && source.isInvExpBonds())
				investmentExperience.add(EXP_BONDS);
			if(Optional.ofNullable(source.isInvExpMutualFunds()).isPresent() && source.isInvExpMutualFunds())
				investmentExperience.add(EXP_MUTUAL_FUNDS);
			if(Optional.ofNullable(source.isInvExpStocks()).isPresent() && source.isInvExpStocks())
				investmentExperience.add(EXP_STOCKS);
			if(Optional.ofNullable(source.isInvExpShortSales()).isPresent() && source.isInvExpShortSales())
				investmentExperience.add(EXP_SHORTS);
			if(Optional.ofNullable(source.isInvExpOptions()).isPresent() && source.isInvExpOptions())
				investmentExperience.add(EXP_OPTIONS);
			if(Optional.ofNullable(source.isInvExpCommodities()).isPresent() && source.isInvExpCommodities())
				investmentExperience.add(EXP_COMMODITIES);
			if(Optional.ofNullable(source.isInvExpNone()).isPresent() && source.isInvExpNone())
				investmentExperience.add(EXP_NONE);
			if(Optional.ofNullable(source.isInvExpAltInvestments()).isPresent() && source.isInvExpAltInvestments())
				investmentExperience.add(EXP_ALTERNATIVES);
			if(CollectionUtils.isNotEmpty(investmentExperience))
				destination.setPastExperience(investmentExperience);

			destination.setAltInvestmentExperience(source.getAltInvestmentExperience());
		}

		return destination;
	}

	private void initFlags(InvestmentExperience destination) {
		destination.setInvExpAltInvestments(false);
		destination.setInvExpBonds(false);
		destination.setInvExpCommodities(false);
		destination.setInvExpMutualFunds(false);
		destination.setInvExpNone(false);
		destination.setInvExpOptions(false);
		destination.setInvExpShortSales(false);
		destination.setInvExpStocks(false);
	}
}
