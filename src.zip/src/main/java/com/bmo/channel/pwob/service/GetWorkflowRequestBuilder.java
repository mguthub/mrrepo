package com.bmo.channel.pwob.service;

import net.bmogc.xmlns.hub.bpm.ds.pcdservice.types.v1.GetRequest;
import net.bmogc.xmlns.hub.cg.ds.workflowinitiationservice.types.v1.GetWorkflowDataRequest;

public class GetWorkflowRequestBuilder {

	private GetWorkflowDataRequest request;

	private GetWorkflowRequestBuilder(String workflowId, String workflowTemplateId, String workflowVersion) {
		this.request = new GetWorkflowDataRequest();
    	GetWorkflowDataRequest.Body body = new GetWorkflowDataRequest.Body();
		body.setWorkflowTemplateId(workflowTemplateId);
		body.setVersion(workflowVersion);
    	body.setWorkflowId(workflowId);

    	GetWorkflowDataRequest.Body.Payload payload = new GetWorkflowDataRequest.Body.Payload();
    	GetRequest getRequest = new GetRequest();

    	payload.setGetRequest(getRequest);
    	body.setPayload(payload);
    	request.setBody(body);
	}

	public static GetWorkflowRequestBuilder builder(String workflowId, String workflowTemplateId, String workflowVersion) {
		return new GetWorkflowRequestBuilder(workflowId, workflowTemplateId, workflowVersion);
	}

	public GetWorkflowDataRequest build() {
		return request;
	}
	
	public GetWorkflowRequestBuilder getIaApprovals(){
		request.getBody().getPayload().getGetRequest().setIaApproval(new Boolean(true));
		return this;
	}
	
	public GetWorkflowRequestBuilder getBmApprovals(){
		request.getBody().getPayload().getGetRequest().setBmApproval(new Boolean(true));
		return this;
	}
}
