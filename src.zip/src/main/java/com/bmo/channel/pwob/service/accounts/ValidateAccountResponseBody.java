/**
 * 
 */
package com.bmo.channel.pwob.service.accounts;

import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author vvallia
 *
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ValidateAccountResponseBody {
	
	@JsonIgnore
	private boolean isValidAccountNumber;
	
	private String accountId;
	
	private String rule;
	
	public boolean isIsValidAccountNumber() {
		return isValidAccountNumber;
	}	
	
	@JsonProperty("ruleResultMap")
    private void unpackRuleResultMap(Map<String,Object> ruleResultMap) {
        Map<String,Object> entriesMap = (Map<String,Object>)ruleResultMap.get("entries");
        List<Map<String,Object>> entryList = (List<Map<String,Object>>)entriesMap.get("ns2:entry");
        if (CollectionUtils.isNotEmpty(entryList) && entryList.size()==1) {
            this.rule = (String)entryList.get(0).get("key");
            this.isValidAccountNumber = (Boolean)entryList.get(0).get("ns2:value");
        }    
    }
	

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getRule() {
		return rule;
	}

}
