package com.bmo.channel.pwob.model.onboarding;

public enum AppStatus {
	DATA_COLLECTION("DataCollection"),
	DOCUMENT_COLLECTION("DocumentCollection"),
	ACCOUNT_SETUP("AccountSetup"),
	IA_APPROVAL("IAApproval"),
	IA_REMEDIATION("IARemediation"),
	BM_APPROVAL("BMApproval"),
	CANCELLED("Cancelled"),
	COMPLETE("Completed"),
	CONDITIONALLY_APPROVED("CondApproved");
	
	private String appStatus;
	private AppStatus(String app){
		this.appStatus = app;
	}
	
	@Override
	public String toString(){
		return appStatus;
	}
}
