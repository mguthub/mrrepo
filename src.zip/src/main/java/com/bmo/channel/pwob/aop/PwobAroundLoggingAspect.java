package com.bmo.channel.pwob.aop;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.core.event.EventManager;

public class PwobAroundLoggingAspect {
	@Autowired
	private EventManager eventManager; 		

	public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
		Signature signature = joinPoint.getSignature();
		String methodName = signature.getName();
		String className = signature.getDeclaringType().toString();		
		
		long start = System.currentTimeMillis();
		eventManager.publishWarn("Entering " + methodName + " method of  " + className);
		Object proceed = joinPoint.proceed();
		long elapsedTime = System.currentTimeMillis() - start;
		eventManager.publishWarn("Finished " + methodName + " method of " + className + " in " + elapsedTime + " milliseconds.");
		return proceed;
	}
}
