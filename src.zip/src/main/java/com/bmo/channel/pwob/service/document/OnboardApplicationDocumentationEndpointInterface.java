package com.bmo.channel.pwob.service.document;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import io.swagger.client.model.GenerateFromApplicationRequest;
import io.swagger.client.model.GenerateFromApplicationResponse;

@Produces(MediaType.APPLICATION_JSON)
public interface OnboardApplicationDocumentationEndpointInterface {

	@POST
	@Path("/form/generate")
	public GenerateFromApplicationResponse generateFromApplication(
			@RequestBody GenerateFromApplicationRequest generateFromApplicationRequest,
			@HeaderParam("APIHeaderRequest") String requestHeader);

}

