package com.bmo.channel.pwob.service.authorization;

import javax.ws.rs.ForbiddenException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.exception.ExceptionUtils;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.util.Constants;
import com.bmo.channel.pwob.validation.ErrorCodes;

@Component("ilSecurityService")
public class IlSecurityServiceImpl implements LobSecurityService {
	
	private static Logger logger = LoggerFactory.getLogger(IlSecurityServiceImpl.class);

	@Override
	public void authorizeAction(User user, String userAccessCode, String appStatus, PwobAction action) {
		// rules TBD. IL will likely not have any roles. But need to prevent IL users from updating a PCD application
		if(userAccessCode != null) {
			if(!userAccessCode.startsWith(Constants.BIL_IA_CODE_PREFIX)) {
			//	logger.error("IL users cannot update an application with a non IL ia code");
				logger.error("IL users cannot update an application without valid email id");
				//throw new ForbiddenException("IL users cannot update an application with a non IL ia code");
			}
		}
		
		//copy of Nb for now while IL enforcement is still TBD
		StatusChangeRequirement statusRequirements = StatusMap.getRequirements(action);
		enforceStatus(appStatus, statusRequirements, action);
	}

	@Override
	public void authorizeReadAccess(User user, String userAccessCode) {
		// rules TBD. IL will likely use an "IA Code" with format BIL\customer_ecif_id
	}

	private void enforceStatus(String appStatus, StatusChangeRequirement requirements, PwobAction action) {
		if(requirements.getAcceptableAppStatuses().contains(StatusMap.ANY_APP_STATUS)) {
			return;
		}
		else if(StringUtils.isBlank(appStatus)){
			logger.error("The application status is blank");
			throw new WebServiceException(ErrorCodes.EMPTY_SECURITY_FIELDS);
		}

		if(!requirements.getAcceptableAppStatuses().contains(appStatus)){
			logger.error("Action '"+action.name()+"' not allowed with app status: "+appStatus);
			throw ExceptionUtils.buildStatusExceptionForActionNotAllowedContext(action.name(), appStatus);
		}
	}
}
