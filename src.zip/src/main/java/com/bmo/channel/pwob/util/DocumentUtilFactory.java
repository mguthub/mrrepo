package com.bmo.channel.pwob.util;

import java.util.List;

public class DocumentUtilFactory {
	private static final String TIF = "tif";
	private static final String TIFF = "tiff";
	public static final String PDF = "pdf";

	public static byte[] mergeAll(final List<StringBuilder> contents, final String type) {
		DocumentImage documentImage;
		if (type.equalsIgnoreCase(PDF)) {
			documentImage = new PDFUtil();
		} else if (type.equalsIgnoreCase(TIFF) || type.equalsIgnoreCase(TIF)) {
			documentImage = new TiffUtil();
		} else {
			documentImage = new ImageUtil();
		}
		
		return documentImage.merge(contents);
	}
}
