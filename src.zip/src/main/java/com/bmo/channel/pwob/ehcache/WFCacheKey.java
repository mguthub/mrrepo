/**
 * Registered cacheKey being used in pwob. 
 * All the key used in cache must be defined here.  
 * @author akhales
 */
package com.bmo.channel.pwob.ehcache;

public enum WFCacheKey{
	// Please follow the format when you are creating a key for a single object.
	// Please make sure your name is meaningful and ends with "id." unless you put a list which you can pick any name as long as it is unique
	ONBOARDING_WORKFLOW_ID("onboarding.workflow.id."),
	APPLICANT_ID("applicant.id."),
	REFDATA("refata."),
	REFDATA_FR("refata.fr.")
	;

	private String code;
	
	private WFCacheKey (String code) {
		this.code = code;
	}
	
	public String getCode() {
		return this.code;
	}
	/**
	 * 
	 * @param code
	 * @return WFCache key it has been found.
	 */
	public static WFCacheKey parse (String code) {
		for (WFCacheKey key:WFCacheKey.values()) {
			if (key.getCode().equals(code)) {
				return key;
			}
		}		
		return null;
	}
	
	public static  <E> String initialKey(String id,final E key) {
		StringBuilder sbk = new StringBuilder();
		WFCacheKey nnn = (WFCacheKey) key;
		sbk.append(nnn.getCode()).append(id);

		return sbk.toString();
	}
	
}
