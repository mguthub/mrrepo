package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import java.util.List;

import com.bmo.channel.pwob.service.documentpackages.dto.DocumentPackageDto;

public class DocumentPackagesResponse {
	private List<DocumentPackageDto> documentPackages;

	public List<DocumentPackageDto> getDocumentPackages() {
		return documentPackages;
	}

	public void setDocumentPackages(final List<DocumentPackageDto> documentPackages) {
		this.documentPackages = documentPackages;
	}
	
}
