package com.bmo.channel.pwob.convert.migration;

import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.validation.RefDataValues;

@Component
@Order(value=7)
public class R11DataMigrator implements ApplicationMigrator {
	
	@Autowired
	private EventManager eventManager;
	
	@Override
	public void migrateApplication(Application application, FeatureFlags featureFlags) {
		application.setRelease(Application.RELEASE_VERSION_11);		
		migrateApplicationToRemoveExpiryDateWithHealthCardAndABProvinceSpecified(application);
		migrateApplicationForSpouseEmploymnetStatusRetired(application);
	}

	@Override
	public boolean isMigrationRequired(Application application, FeatureFlags featureFlags) {
		String release = application.getRelease();
		if(isReleaseDifferent(release)) {
			eventManager.publishWarn(String.format("Migrating application %s because release version is %s", application.getApplicationId(), release));
			return true;
		} else {
			return false;
		}
	}

	private boolean isReleaseDifferent(String release) {
		try {
			Integer iRel = Integer.valueOf(release);
			return iRel <= Integer.parseInt(Application.RELEASE_VERSION_10);
		} catch(NumberFormatException ex) {
			return true;
		}
	}
	
	private void migrateApplicationToRemoveExpiryDateWithHealthCardAndABProvinceSpecified(Application application) {
		if (CollectionUtils.isNotEmpty(application.getParties())) {
			application.getParties().stream()
					.filter(party -> ((party.getRoles().contains(PartyRole.PRIMARY_APPLICANT) || party.getRoles().contains(PartyRole.JOINT_APPLICANT) 
							|| party.getRoles().contains(PartyRole.TRADING_AUTHORITY))
							&& Optional.ofNullable(party.getRegulatoryDisclosures()).isPresent()
							&& Optional.ofNullable(party.getRegulatoryDisclosures().getVerification()).isPresent()
							&& Optional.ofNullable(party.getRegulatoryDisclosures().getVerification().getDocumentType()).isPresent()
							&& RefDataValues.DOCUMENT_TYPE_PROVINCIAL_HEALTH_INSURANCE_CARD.equalsIgnoreCase(party.getRegulatoryDisclosures().getVerification().getDocumentType())
							&& Optional.ofNullable(party.getRegulatoryDisclosures().getVerification().getProvince()).isPresent()
							&& RefDataValues.PROVINCE_AB.equalsIgnoreCase(party.getRegulatoryDisclosures().getVerification().getProvince())
							&& Optional.ofNullable(party.getRegulatoryDisclosures().getVerification().getExpiryDate()).isPresent()))
					.map(p -> {
						p.getRegulatoryDisclosures().getVerification().setExpiryDate(null);
						return p;
					}).collect(Collectors.toList());
		}
	}
	
	private void migrateApplicationForSpouseEmploymnetStatusRetired(Application application) {
		if (CollectionUtils.isNotEmpty(application.getParties())) {
			application.getParties().stream().filter(party -> ((CollectionUtils.isEmpty(party.getRoles())
					|| (Optional.ofNullable(party).map(Party::getRoles)).get().contains(PartyRole.JOINT_APPLICANT)
							&& Optional.ofNullable(party).map(Party::getIsPrimaryApplicantSpouse).isPresent()
							&& party.getIsPrimaryApplicantSpouse())
							&& Optional.ofNullable(party).map(Party::getPersonal).map(PersonalInformation::getEmployment).map(Employment::getEmploymentStatus).isPresent()
							&& RefDataValues.EMPLOYMENT_STATUS_RETIRED
									.equals(party.getPersonal().getEmployment().getEmploymentStatus())))
					.map(p -> {
						p.getPersonal().getEmployment().setJobTitle(null);
						p.getPersonal().getEmployment().setOccupation(null);
						p.getPersonal().getEmployment().setNatureOfBusiness(null);
						return p;
					}).collect(Collectors.toList());
		}
	}
}

