package com.bmo.channel.pwob.exception;

import com.bmo.channel.core.exception.WebServiceException;

public class BackEndException extends WebServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public BackEndException(String message, String errorType) {
		super(message);
		this.errorType = errorType;
	}

	public String getErrorType() {
		return errorType;
	}
	private final String errorType;

}
