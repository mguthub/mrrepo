/**
 * 
 */
package com.bmo.channel.pwob.service.digitaltoken;

import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.WebServiceException;

/**
 * @author vvallia
 *
 */
@Service
public class DigitalTokenServiceImpl implements DigitalTokenService{
	
	private static Logger logger = LoggerFactory.getLogger(DigitalTokenServiceImpl.class);

	@Autowired
	private DigitalTokenEndpointInterface digitalTokenEndpointInterface;
	
	static final String TOKEN_TIME_TO_LIVE="1800000";
	
	@Override
	public String generateToken(String payload) {
		try{
			GenerateTokenRequest generateTokenRequest = new GenerateTokenRequest();		
			generateTokenRequest.setPayload(Base64.getEncoder().encodeToString(payload.getBytes()));
			generateTokenRequest.setTokenTTL(TOKEN_TIME_TO_LIVE);
			GenerateTokenResponse generateTokenResponse=digitalTokenEndpointInterface.generate(generateTokenRequest);
			
			if(generateTokenResponse.getCachedToken()!=null){
				return generateTokenResponse.getCachedToken();
			}			
			else{ 
				logger.error("Receiving cached token as null "+generateTokenResponse.getCachedToken());
				throw new WebServiceException(generateTokenResponse.getStatus()+"  "+generateTokenResponse.getDetail());
			}
		} catch (Exception ex) {
			logger.error("Failed to generate token", ex);
			throw new WebServiceException(ex);
		}
		
	}
	
	@Override
	public String validateToken(String cachedToken) {
		ValidateTokenRequest validateTokenRequest = new ValidateTokenRequest();
		validateTokenRequest.setCachedToken(cachedToken);
		
		try
		{
			ValidateTokenResponse validateTokenResponse= digitalTokenEndpointInterface.validate(validateTokenRequest);
			
			if(validateTokenResponse.getIsValid())
			{
				return new String(Base64.getDecoder().decode(validateTokenResponse.getPayLoad()));
			}
			else if (validateTokenResponse.getStatus()!=null){
				logger.error("Token status during validate token : ", validateTokenResponse.getStatus());
				throw new WebServiceException(validateTokenResponse.getStatus()+"  "+validateTokenResponse.getDetail());
			}
			return null;
		} catch (Exception ex) {
			logger.error("Failed to validate token: ",cachedToken, ex);
			throw new WebServiceException(ex);
		}
	}

	
}
