package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

public class InvestmentObjectives {

	@ApiModelProperty(example="INC", value="See reference service for valid values", allowableValues="INC,BAL,GRW,AGRW")
	@ReferenceData(type = ReferenceType.INVESTMENT_OBJECTIVES, code = ErrorCodes.INVALID_INVESTMENT_OBJECTIVES)
	private String objective;
	
	@Valid
	@NotNull
	private RiskTolerance riskTolerance = new RiskTolerance();
	
	@Valid
	@NotNull
	private TargetAllocation targetAllocation = new TargetAllocation();

	public String getObjective() {
		return objective;
	}

	public void setObjective(String objective) {
		this.objective = objective;
	}

	public RiskTolerance getRiskTolerance() {
		return riskTolerance;
	}

	public void setRiskTolerance(RiskTolerance riskTolerance) {
		this.riskTolerance = riskTolerance;
	}
	
	public TargetAllocation getTargetAllocation() {
		return targetAllocation;
	}

	public void setTargetAllocation(TargetAllocation targetAllocation) {
		this.targetAllocation = targetAllocation;
	}

	@Override
	public String toString() {
			return ToStringBuilder.reflectionToString(this);
	}
}
