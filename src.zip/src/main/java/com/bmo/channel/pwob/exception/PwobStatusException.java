package com.bmo.channel.pwob.exception;

import com.bmo.channel.core.exception.StatusException;

public class PwobStatusException extends StatusException {
	private static final long serialVersionUID = 1L;

	enum ErrorType {
		staleData,
		actionNotAllowed
	}

	final private ErrorType errorType;

	public PwobStatusException(String message, ErrorType errorType) {
		super(message);
		this.errorType = errorType;
	}

	public ErrorType getErrorType() {
		return errorType;
	}
}
