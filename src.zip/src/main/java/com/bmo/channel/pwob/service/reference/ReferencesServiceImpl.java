package com.bmo.channel.pwob.service.reference;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.common.ehcache.CacheService;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.ehcache.WFCacheKey;
import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.AppStatus;
import com.bmo.channel.pwob.model.reference.CountryReference;
import com.bmo.channel.pwob.model.reference.OccupationReference;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.model.reference.StatProvReference;
import com.bmo.channel.pwob.service.reference.model.GetDataListForParameterRequest;
import com.bmo.channel.pwob.service.reference.model.GetDataListForParameterRequestBody;
import com.bmo.channel.pwob.service.reference.model.GetDataListForParameterResponse;
import com.bmo.channel.pwob.service.reference.model.ParamsInquiry;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.fasterxml.jackson.core.JsonProcessingException;

import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

/**
 * Service for managing reference data.
 * 
 * @author rcham02
 */
@Service
public class ReferencesServiceImpl implements ReferencesService {	
	private static Logger logger = LoggerFactory.getLogger(ReferencesServiceImpl.class);

	@Override
	public Map<ReferenceType, List<Reference>> all(UILocale locale) {
		if (locale == null) {
			locale = UILocale.EN_CA;
		}

		Map<ReferenceType, List<Reference>> references = new HashMap<>();

		references.put(ReferenceType.TITLES, 							this.getLabels(locale,ReferenceType.TITLES));
		references.put(ReferenceType.COUNTRIES, 						this.getLabels(locale,ReferenceType.COUNTRIES));
		references.put(ReferenceType.PROVINCE_CODES, 					this.getLabels(locale,ReferenceType.PROVINCE_CODES));
		references.put(ReferenceType.JURISDICTION_TYPES, 				this.getLabels(locale,ReferenceType.JURISDICTION_TYPES));
		references.put(ReferenceType.MARITAL_STATUSES, 					this.getLabels(locale,ReferenceType.MARITAL_STATUSES));
		references.put(ReferenceType.ACCOUNT_TYPES, 					this.getLabels(locale,ReferenceType.ACCOUNT_TYPES));		
		references.put(ReferenceType.IIROC_ORGANIZATIONS, 				this.getLabels(locale,ReferenceType.IIROC_ORGANIZATIONS));
		references.put(ReferenceType.OPTION_TYPE_EXPERIENCES, 			this.getLabels(locale,ReferenceType.OPTION_TYPE_EXPERIENCES));
		references.put(ReferenceType.OPTION_TYPES, 						this.getLabels(locale,ReferenceType.OPTION_TYPES));
		references.put(ReferenceType.OPTIONS_KNOWLEDGE, 				this.getLabels(locale,ReferenceType.OPTIONS_KNOWLEDGE));
		references.put(ReferenceType.RECEIVE_SECURITY_HOLDER_OPTIONS,	this.getLabels(locale,ReferenceType.RECEIVE_SECURITY_HOLDER_OPTIONS));
		references.put(ReferenceType.LANGUAGES,							this.getLabels(locale, ReferenceType.LANGUAGES));
		references.put(ReferenceType.TIME_UNITS,						this.getLabels(locale, ReferenceType.TIME_UNITS));
		references.put(ReferenceType.REFERRAL_SOURCES,					this.getLabels(locale, ReferenceType.REFERRAL_SOURCES));
		references.put(ReferenceType.PAYMENT_TYPES,						this.getLabels(locale, ReferenceType.PAYMENT_TYPES));
		references.put(ReferenceType.DOCUMENT_PREFERENCE_OPTIONS,		this.getLabels(locale, ReferenceType.DOCUMENT_PREFERENCE_OPTIONS));
		references.put(ReferenceType.APPLICATION_STATUS,				this.getLabels(locale, ReferenceType.APPLICATION_STATUS));
		references.put(ReferenceType.FEE_TYPES,							this.getLabels(locale, ReferenceType.FEE_TYPES));
		references.put(ReferenceType.RIF_WITH_HOLDING_TAX,				this.getLabels(locale, ReferenceType.RIF_WITH_HOLDING_TAX));
		references.put(ReferenceType.EFT_PAYMENT_FREQUENCY_TYPES,		this.getLabels(locale, ReferenceType.EFT_PAYMENT_FREQUENCY_TYPES));
		references.put(ReferenceType.TAX_ID_MISSING_REASON,				this.getLabels(locale, ReferenceType.TAX_ID_MISSING_REASON));
	
		List<ReferenceType> refDataTypes = new LinkedList<>();
		refDataTypes.add(ReferenceType.INCOME_SOURCES);

		refDataTypes.add(ReferenceType.POLITICALLY_EXPOSED_PERSON_TYPE);
		refDataTypes.add(ReferenceType.EMPLOYMENT_STATUSES);
		refDataTypes.add(ReferenceType.OCCUPATIONS_TYPES);
		refDataTypes.add(ReferenceType.BUSINESS_NATURES);
		refDataTypes.add(ReferenceType.SOURCE_OF_ADDRESS);
		refDataTypes.add(ReferenceType.INVESTMENT_OBJECTIVES);
		refDataTypes.add(ReferenceType.INVESTMENT_TIME_HORIZONS);
		refDataTypes.add(ReferenceType.ACCOUNT_USES);
		refDataTypes.add(ReferenceType.INVESTMENT_EXPERIENCE);
		refDataTypes.add(ReferenceType.INVESTMENT_KNOWLEDGE);
		refDataTypes.add(ReferenceType.DOCUMENT_TYPES); 		
		refDataTypes.add(ReferenceType.WEALTH_SOURCES);
		refDataTypes.add(ReferenceType.RIF_AMOUNT_TYPES);
		refDataTypes.add(ReferenceType.RIF_PAYMENT_FREQUENCY_TYPES);
		refDataTypes.add(ReferenceType.LINK_ACCOUNT_TYPES);
		refDataTypes.add(ReferenceType.RIF_PAYMENT_METHOD);
		refDataTypes.add(ReferenceType.TAX_ID_MISSING_REASON);
		refDataTypes.add(ReferenceType.BENEFICIAL_OWNER_COUNTRY_REASON);  
		refDataTypes.add(ReferenceType.RIF_MID_END_MONTH); 
		refDataTypes.add(ReferenceType.RIF_START_MONTH);
		refDataTypes.add(ReferenceType.ID_VERIFICATION_METHODS);
		refDataTypes.add(ReferenceType.ACCOUNT_SUBTYPES);
		refDataTypes.add(ReferenceType.RIF_PAYMENT_AMOUNT_TYPES);
		refDataTypes.add(ReferenceType.BMO_COMPANY_CODES);
		refDataTypes.add(ReferenceType.BMO_CLIENT_RELATIONSHIP_TYPE);
		refDataTypes.add(ReferenceType.LIRA_PROVINCE_CODES);
		refDataTypes.add(ReferenceType.LIF_PROVINCE_CODES);
		refDataTypes.add(ReferenceType.LIF_START_YEAR);
		refDataTypes.add(ReferenceType.LIF_PAYMENT_AMOUNT_TYPES);
		
		collectRefData(references, locale, refDataTypes);
		return references;
	}

	@Override
	public List<Reference> ofType(ReferenceType type, UILocale locale) {
		if (type == null) {
			logger.error("Reference type is null for type: "+type);
			throw new WebServiceException("Reference type is null.");
		}

		if (locale == null) {
			locale = UILocale.EN_CA;
		}

		return this.getLabels(locale, type);
	}

	@Override
	public Map<ReferenceType, List<Reference>> ofTypes(Set<ReferenceType> referenceTypes, UILocale locale) {
		return referenceTypes.stream().collect(Collectors.toMap(ref -> ref, ref -> ofType(ref, locale)));
	}

	static final String ECIF_COUNTRY_CODE_CANADA = "100000";
	static final String ECIF_COUNTRY_CODE_USA = "100001";
	static final String ISO_COUNTRY_CODE_CANADA ="CAN";
	static final String ISO_COUNTRY_CODE_USA ="USA";

	public static final String REFDATA_CACHE = "refDataCache";
	static final String COUNTRY_CODE = "ES.CDCOUNTRYTP";

	@Autowired
	private CacheService cacheService;

	@Autowired
	private ReferenceDataServiceEndpointInterface referenceData;

	@Autowired
	private HubRequestComponent hubRequestComponent;

	@Autowired
	private ReferenceDataParser dataListParser;

	@SuppressWarnings("unchecked")
	protected List<Reference> getLabels(UILocale locale, ReferenceType type) {
		String key = this.createLocaleCacheKey(locale);

		List<Reference> response = (List<Reference>) cacheService.get(key, type.getLabel(), REFDATA_CACHE);		

		if (CollectionUtils.isNotEmpty(response)) {
			return response;
		}

		switch (type) {
			case TITLES:
				response = this.createTitles(locale); 
				break;

			case COUNTRIES:
				response =this.createCountries(locale);
				break;

			case PROVINCE_CODES:
				response =this.createProvinceCodes(locale);
				break;

			case EMPLOYMENT_STATUSES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.EMPLOYMENT_STATUSES), locale).get(ReferenceType.EMPLOYMENT_STATUSES);
				break;
	
			case MARITAL_STATUSES:
				response = this.createMaritalStatuses(locale);
				break;
				
			case ACCOUNT_TYPES:
				response = this.createAccountTypes(locale);
				break;
	
			case ACCOUNT_USES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.ACCOUNT_USES), locale).get(ReferenceType.ACCOUNT_USES);
				break;
				
			case WEALTH_SOURCES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.WEALTH_SOURCES), locale).get(ReferenceType.WEALTH_SOURCES);
				break;

			case INCOME_SOURCES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.INCOME_SOURCES), locale).get(ReferenceType.INCOME_SOURCES);			
				break;
				
			case INVESTMENT_KNOWLEDGE:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.INVESTMENT_KNOWLEDGE), locale).get(ReferenceType.INVESTMENT_KNOWLEDGE);
				break;
	
			case INVESTMENT_EXPERIENCE:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.INVESTMENT_EXPERIENCE), locale).get(ReferenceType.INVESTMENT_EXPERIENCE);
				break;
	
			case INVESTMENT_TIME_HORIZONS:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.INVESTMENT_TIME_HORIZONS), locale).get(ReferenceType.INVESTMENT_TIME_HORIZONS);
				break;
	
			case INVESTMENT_OBJECTIVES:				
				response = this.loadReferenceData(Arrays.asList(ReferenceType.INVESTMENT_OBJECTIVES), locale).get(ReferenceType.INVESTMENT_OBJECTIVES);
				break;

			case IIROC_ORGANIZATIONS:
				response = this.createIirocOrganizations(locale);
				break;

			case RECEIVE_SECURITY_HOLDER_OPTIONS:
				response = this.createReceiveSecurityHolderOptionsList(locale);	
				break;

			case BMO_COMPANY_CODES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.BMO_COMPANY_CODES), locale).get(ReferenceType.BMO_COMPANY_CODES);
				break;

			case OCCUPATIONS_TYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.OCCUPATIONS_TYPES), locale).get(ReferenceType.OCCUPATIONS_TYPES);
				break;

			case BUSINESS_NATURES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.BUSINESS_NATURES), locale).get(ReferenceType.BUSINESS_NATURES);
				break;

			case ACCOUNT_SUBTYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.ACCOUNT_SUBTYPES), locale).get(ReferenceType.ACCOUNT_SUBTYPES);
				break;

			case LINK_ACCOUNT_TYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.LINK_ACCOUNT_TYPES), locale).get(ReferenceType.LINK_ACCOUNT_TYPES);
				break;

			case OPTION_TYPE_EXPERIENCES:
				response = this.createOptionTypeExperiences(locale);
				break;

			case OPTION_TYPES:
				response = this.createOptionTypes(locale);
				break;

			case OPTIONS_KNOWLEDGE:
				response = this.createOptionsKnowledge(locale);
				break;
							
			case ID_VERIFICATION_METHODS:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.ID_VERIFICATION_METHODS), locale).get(ReferenceType.ID_VERIFICATION_METHODS);
				break;
			case DOCUMENT_TYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.DOCUMENT_TYPES), locale).get(ReferenceType.DOCUMENT_TYPES);
				break;
			case LANGUAGES:
				response = this.createLanguages(locale);
				break;
			case TIME_UNITS:
				response = this.createTimeUnits(locale);
				break;
			case REFERRAL_SOURCES:
				response = this.createReferralSources(locale);
				break;
			case PAYMENT_TYPES:
				response = this.createPaymentTypes(locale);
				break;
			case JURISDICTION_TYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.JURISDICTION_TYPES), locale).get(ReferenceType.JURISDICTION_TYPES);
				break;
			case LIRA_PROVINCE_CODES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.LIRA_PROVINCE_CODES), locale).get(ReferenceType.LIRA_PROVINCE_CODES);
				break;
			case LIF_PROVINCE_CODES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.LIF_PROVINCE_CODES), locale).get(ReferenceType.LIF_PROVINCE_CODES);
				break;				
			case DOCUMENT_PREFERENCE_OPTIONS:
				response = this.createDocumentPreferenceOptions(locale);
				break;
			case APPLICATION_STATUS:
				response = this.createApplicationStatuses(locale);
				break;
			case FEE_TYPES:
				response=this.createFeeType(locale);
				break;
			case RIF_AMOUNT_TYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.RIF_AMOUNT_TYPES), locale).get(ReferenceType.RIF_AMOUNT_TYPES);
				break;
			case RIF_PAYMENT_AMOUNT_TYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.RIF_PAYMENT_AMOUNT_TYPES), locale).get(ReferenceType.RIF_PAYMENT_AMOUNT_TYPES);
				break;
			case RIF_PAYMENT_METHOD:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.RIF_PAYMENT_METHOD), locale).get(ReferenceType.RIF_PAYMENT_METHOD);
				break;
			case RIF_MID_END_MONTH:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.RIF_MID_END_MONTH), locale).get(ReferenceType.RIF_MID_END_MONTH);
				break;
			case RIF_WITH_HOLDING_TAX:
				response=this.createWithHoldingTax(locale);
				break;
			case RIF_PAYMENT_FREQUENCY_TYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.RIF_PAYMENT_FREQUENCY_TYPES), locale).get(ReferenceType.RIF_PAYMENT_FREQUENCY_TYPES);
				break;
			case EFT_PAYMENT_FREQUENCY_TYPES:
				response = this.createEftPaymentFrequencyTypes(locale);
				break;
			case RIF_START_MONTH:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.RIF_START_MONTH), locale).get(ReferenceType.RIF_START_MONTH);
				break;
			case LIF_START_YEAR:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.LIF_START_YEAR), locale).get(ReferenceType.LIF_START_YEAR);
				break;
			case LIF_PAYMENT_AMOUNT_TYPES:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.LIF_PAYMENT_AMOUNT_TYPES), locale).get(ReferenceType.LIF_PAYMENT_AMOUNT_TYPES);
				break;
			case TAX_ID_MISSING_REASON:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.TAX_ID_MISSING_REASON), locale).get(ReferenceType.TAX_ID_MISSING_REASON);
				break;
			case BENEFICIAL_OWNER_COUNTRY_REASON:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.BENEFICIAL_OWNER_COUNTRY_REASON), locale).get(ReferenceType.BENEFICIAL_OWNER_COUNTRY_REASON);
				break;
			
			case POLITICALLY_EXPOSED_PERSON_TYPE:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.POLITICALLY_EXPOSED_PERSON_TYPE), locale).get(ReferenceType.POLITICALLY_EXPOSED_PERSON_TYPE);
				break;
				
			case SOURCE_OF_ADDRESS:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.SOURCE_OF_ADDRESS), locale).get(ReferenceType.SOURCE_OF_ADDRESS);
                break;
                
			case BMO_CLIENT_RELATIONSHIP_TYPE:
				response = this.loadReferenceData(Arrays.asList(ReferenceType.BMO_CLIENT_RELATIONSHIP_TYPE), locale).get(ReferenceType.BMO_CLIENT_RELATIONSHIP_TYPE);
				break;
				
			default:
				break;
		}
		return response;
	}

	private List<Reference> createWithHoldingTax(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		// French Titles
		refMap.get(UILocale.FR_CA).add(this.createReference("1", "Impôt fédéral (%)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("2", "Impôt fédéral et impôt du Québec (%)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("3", "Montant fixe"));

		// English title
		refMap.get(UILocale.EN_CA).add(this.createReference("1", "Federal tax (%)"));
		refMap.get(UILocale.EN_CA).add(this.createReference("2", "Federal and Quebec tax (%)"));
		refMap.get(UILocale.EN_CA).add(this.createReference("3", "Flat amount"));
		
		// add both locale to cache
		logger.info("Adding reference to cache for reference type: WithHoldingTax");
		this.addReferenceToCache(refMap, ReferenceType.RIF_WITH_HOLDING_TAX);
		return refMap.get(locale);
	}
	

	private List<Reference> createEftPaymentFrequencyTypes(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		// French Titles
		refMap.get(UILocale.FR_CA).add(this.createReference("10", "Mensuel"));
		refMap.get(UILocale.FR_CA).add(this.createReference("11", "Trimestriel"));
		refMap.get(UILocale.FR_CA).add(this.createReference("12", "Semestriel"));
		refMap.get(UILocale.FR_CA).add(this.createReference("13", "Annuel"));

		// English title
		refMap.get(UILocale.EN_CA).add(this.createReference("10", "Monthly"));
		refMap.get(UILocale.EN_CA).add(this.createReference("11", "Quarterly"));
		refMap.get(UILocale.EN_CA).add(this.createReference("12", "Semi-Annual"));
		refMap.get(UILocale.EN_CA).add(this.createReference("13", "Annual"));

		// add both locale to cache
		logger.info("Adding reference to cache for reference type: EftPaymentFrequencyTypes");
		this.addReferenceToCache(refMap, ReferenceType.EFT_PAYMENT_FREQUENCY_TYPES);
		return refMap.get(locale);
	}

	@SuppressWarnings("unchecked")
	protected  Map<UILocale, List<Reference>> getCountriesMap() {
		EnumMap<UILocale, List<Reference>> response = new EnumMap<>(UILocale.class);

		String key = this.createLocaleCacheKey(UILocale.EN_CA);
		List<Reference> allEn = (List<Reference>) cacheService.get(key, ReferenceType.COUNTRIES.getLabel(),REFDATA_CACHE);
		allEn = (allEn == null) ? this.createCountries(UILocale.EN_CA):allEn;

		key = this.createLocaleCacheKey(UILocale.FR_CA);
		List<Reference> allFr = (List<Reference>) cacheService.get(key, ReferenceType.COUNTRIES.getLabel(),REFDATA_CACHE);
		allFr = (allFr == null) ? this.createCountries(UILocale.FR_CA):allFr;

		if (CollectionUtils.isNotEmpty(allEn)) {
			response.put(UILocale.EN_CA, allEn);
		}

		if (CollectionUtils.isNotEmpty(allFr)) {
			response.put(UILocale.FR_CA, allFr);
		}

		return response;
	}

	// any calls to create a list will update both locale in cache
	private List<Reference> createTitles(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		// French Titles
		refMap.get(UILocale.FR_CA).add(this.createReference("100000~100004", "Mr/M"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100002~100005", "Ms/Mme"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100001~", "Mrs"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100003~", "Miss"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100007~100007", "Dr"));
		refMap.get(UILocale.FR_CA).add(this.createReference(null, "NA"));
		refMap.get(UILocale.FR_CA).add(this.createExpiredReference("100004", "M."));
		refMap.get(UILocale.FR_CA).add(this.createExpiredReference("100005", "Mme."));
		refMap.get(UILocale.FR_CA).add(this.createExpiredReference("100006", "Mlle."));
		refMap.get(UILocale.FR_CA).add(this.createExpiredReference("100007", "Dr."));
		refMap.get(UILocale.FR_CA).add(this.createExpiredReference("100000", "Mr."));
		refMap.get(UILocale.FR_CA).add(this.createExpiredReference("100001", "Mrs."));
		refMap.get(UILocale.FR_CA).add(this.createExpiredReference("100002", "Ms."));
		refMap.get(UILocale.FR_CA).add(this.createExpiredReference("100003", "Miss."));

		// English title
		refMap.get(UILocale.EN_CA).add(this.createReference("100000~100004", "Mr/M"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100002~100005", "Ms/Mme"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100001~", "Mrs"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100003~", "Miss"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100007~100007", "Dr"));
		refMap.get(UILocale.EN_CA).add(this.createReference(null, "NA"));		
		refMap.get(UILocale.EN_CA).add(this.createExpiredReference("100004", "M."));
		refMap.get(UILocale.EN_CA).add(this.createExpiredReference("100005", "Mme."));
		refMap.get(UILocale.EN_CA).add(this.createExpiredReference("100006", "Mlle."));
		refMap.get(UILocale.EN_CA).add(this.createExpiredReference("100007", "Dr."));
		refMap.get(UILocale.EN_CA).add(this.createExpiredReference("100000", "Mr."));
		refMap.get(UILocale.EN_CA).add(this.createExpiredReference("100001", "Mrs."));
		refMap.get(UILocale.EN_CA).add(this.createExpiredReference("100002", "Ms."));
		refMap.get(UILocale.EN_CA).add(this.createExpiredReference("100003", "Miss."));

		
		// add both locale to cache
		logger.info("Adding reference to cache for reference type: Titles");
		this.addReferenceToCache(refMap, ReferenceType.TITLES);
		return refMap.get(locale);
	}

	private List<Reference> createLanguages(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference("100", "English"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100001", "French"));

		refMap.get(UILocale.FR_CA).add(this.createReference("100", "Anglais"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100001", "Français"));

		// add both locale to cache
		logger.info("Adding reference to cache for reference type: Languages");
		this.addReferenceToCache(refMap, ReferenceType.LANGUAGES);
		return refMap.get(locale);
	}

	private List<Reference> createOptionTypeExperiences(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference("long_calls_puts", "Long Calls or Puts"));
		refMap.get(UILocale.EN_CA).add(this.createReference("spreads", "Spreads"));
		refMap.get(UILocale.EN_CA).add(this.createReference("covered", "Covered"));
		refMap.get(UILocale.EN_CA).add(this.createReference("none", "None"));
		refMap.get(UILocale.EN_CA).add(this.createReference("naked", "Naked"));

		refMap.get(UILocale.FR_CA).add(this.createReference("long_calls_puts", "Long Calls or Puts fr"));
		refMap.get(UILocale.FR_CA).add(this.createReference("spreads", "Spreads fr"));
		refMap.get(UILocale.FR_CA).add(this.createReference("covered", "Covered fr"));
		refMap.get(UILocale.FR_CA).add(this.createReference("none", "None fr"));
		refMap.get(UILocale.FR_CA).add(this.createReference("naked", "Naked fr"));

		// add both locale to cache
		logger.info("Adding reference to cache for reference type: OptionTypeExperiences");
		this.addReferenceToCache(refMap, ReferenceType.OPTION_TYPE_EXPERIENCES);
		return refMap.get(locale);
	}

	private List<Reference> createOptionTypes(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference("1", "Long Calls or Puts"));
		refMap.get(UILocale.EN_CA).add(this.createReference("2", "Spreads"));
		refMap.get(UILocale.EN_CA).add(this.createReference("3", "Covered"));
		refMap.get(UILocale.EN_CA).add(this.createReference("4", "None"));
		refMap.get(UILocale.EN_CA).add(this.createReference("5", "Naked"));


		refMap.get(UILocale.FR_CA).add(this.createReference("1", "Long Calls or Puts FR"));
		refMap.get(UILocale.FR_CA).add(this.createReference("2", "Spreads FR"));
		refMap.get(UILocale.FR_CA).add(this.createReference("3", "Covered FR"));
		refMap.get(UILocale.FR_CA).add(this.createReference("4", "None FR"));
		refMap.get(UILocale.FR_CA).add(this.createReference("5", "Naked FR"));

		// add both locale to cache
		logger.info("Adding reference to cache for reference type: OptionTypes");
		this.addReferenceToCache(refMap, ReferenceType.OPTION_TYPES);
		return refMap.get(locale);
	}

	private List<Reference> createOptionsKnowledge(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference("expert", "Expert"));
		refMap.get(UILocale.EN_CA).add(this.createReference("knowledgeable", "Knowledgeable"));
		refMap.get(UILocale.EN_CA).add(this.createReference("limited", "Limited"));
		refMap.get(UILocale.EN_CA).add(this.createReference("none", "None"));

		refMap.get(UILocale.FR_CA).add(this.createReference("expert", "Expert FR"));
		refMap.get(UILocale.FR_CA).add(this.createReference("knowledgeable", "Knowledgeable FR"));
		refMap.get(UILocale.FR_CA).add(this.createReference("limited", "Limited FR"));
		refMap.get(UILocale.FR_CA).add(this.createReference("none", "None FR"));

		// add both locale to cache
		logger.info("Adding reference to cache for reference type: OptionsKnowledge");
		this.addReferenceToCache(refMap, ReferenceType.OPTIONS_KNOWLEDGE);
		return refMap.get(locale);
	}

	private List<Reference> createCountries(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		List<Reference> countries = new ArrayList<>();
		List<Reference> frCountries = new ArrayList<>();

		try (Scanner scanner = new Scanner(this.getClass().getResourceAsStream("/countries.txt"), "UTF-8")) {
			while (scanner.hasNextLine()) {
				String[] columns = scanner.nextLine().split("\\t");

				countries.add(createCountryReference(columns[0], columns[1], columns[3]));
				frCountries.add(createCountryReference(columns[0], columns[2], columns[3]));
			}
		}
		try (Scanner scanner = new Scanner(this.getClass().getResourceAsStream("/provinces.txt"), "UTF-8")) {
			while (scanner.hasNextLine()) {
				String[] columns = scanner.nextLine().split("\\t");

				addStatProvReference(ECIF_COUNTRY_CODE_CANADA, countries, createStatProvReference(columns[0], columns[1], columns[3]));
				addStatProvReference(ECIF_COUNTRY_CODE_CANADA, frCountries, createStatProvReference(columns[0], columns[2], columns[3]));
			}
		}

		try (Scanner scanner = new Scanner(this.getClass().getResourceAsStream("/states.txt"), "UTF-8")) {
			while (scanner.hasNextLine()) {
				String[] columns = scanner.nextLine().split("\\t");				
				addStatProvReference(ECIF_COUNTRY_CODE_USA, countries, createStatProvReference(columns[0], columns[1], columns[3]));
				addStatProvReference(ECIF_COUNTRY_CODE_USA, frCountries, createStatProvReference(columns[0], columns[2], columns[3]));
			}
		}

		refMap.put(UILocale.EN_CA, countries);
		refMap.put(UILocale.FR_CA, frCountries);
		
		logger.info("Adding reference to cache for reference type: Countries");
		this.addReferenceToCache(refMap, ReferenceType.COUNTRIES);

		return refMap.get(locale);
	}

	 private List<Reference> createMaritalStatuses(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference("100001", "Single"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100002", "Married"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100003", "Common Law"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100004", "Divorced"));
		refMap.get(UILocale.EN_CA).add(this.createReference("100005", "Separated"));		
		refMap.get(UILocale.EN_CA).add(this.createReference("100006", "Widowed"));

		refMap.get(UILocale.FR_CA).add(this.createReference("100001", "Célibataire"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100002", "Marié(e)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100003", "Conjoint(e)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100004", "Divorcé(e)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100005", "Séparé(e)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("100006", "Veuf(ve)"));

		// add both locale to cache
		logger.info("Adding reference to cache for reference type: MaritalStatuses");
		this.addReferenceToCache(refMap, ReferenceType.MARITAL_STATUSES);
		return refMap.get(locale);
	}
	 
	 private List<Reference> createProvinceCodes(UILocale locale) {
			Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

			refMap.get(UILocale.EN_CA).add(this.createReference("101", "AB"));
			refMap.get(UILocale.EN_CA).add(this.createReference("102", "BC"));
			refMap.get(UILocale.EN_CA).add(this.createReference("103", "MB"));
			refMap.get(UILocale.EN_CA).add(this.createReference("104", "NB"));
			refMap.get(UILocale.EN_CA).add(this.createReference("105", "NL"));
			refMap.get(UILocale.EN_CA).add(this.createReference("106", "NT"));
			refMap.get(UILocale.EN_CA).add(this.createReference("107", "NS"));
			refMap.get(UILocale.EN_CA).add(this.createReference("108", "ON"));
			refMap.get(UILocale.EN_CA).add(this.createReference("109", "PE"));
			refMap.get(UILocale.EN_CA).add(this.createReference("110", "QC"));
			refMap.get(UILocale.EN_CA).add(this.createReference("111", "SK"));
			refMap.get(UILocale.EN_CA).add(this.createReference("112", "YT"));
			refMap.get(UILocale.EN_CA).add(this.createReference("113", "NU"));
			
			refMap.get(UILocale.FR_CA).add(this.createReference("101", "AB"));
			refMap.get(UILocale.FR_CA).add(this.createReference("102", "BC"));
			refMap.get(UILocale.FR_CA).add(this.createReference("103", "MB"));
			refMap.get(UILocale.FR_CA).add(this.createReference("104", "NB"));
			refMap.get(UILocale.FR_CA).add(this.createReference("105", "NL"));
			refMap.get(UILocale.FR_CA).add(this.createReference("106", "NT"));
			refMap.get(UILocale.FR_CA).add(this.createReference("107", "NS"));
			refMap.get(UILocale.FR_CA).add(this.createReference("108", "ON"));
			refMap.get(UILocale.FR_CA).add(this.createReference("109", "PE"));
			refMap.get(UILocale.FR_CA).add(this.createReference("110", "QC"));
			refMap.get(UILocale.FR_CA).add(this.createReference("111", "SK"));
			refMap.get(UILocale.FR_CA).add(this.createReference("112", "YT"));
			refMap.get(UILocale.FR_CA).add(this.createReference("113", "NU"));

			// add both locale to cache
			logger.info("Adding reference to cache for reference type: ProvinceCodes");
			this.addReferenceToCache(refMap, ReferenceType.PROVINCE_CODES);
			return refMap.get(locale);
	}

	private List<Reference> createAccountTypes(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference(Account.INDIVIDUAL_TYPE, "Individual Account"));
		refMap.get(UILocale.EN_CA).add(this.createReference(Account.JOINT_TYPE, "Joint Account"));
		refMap.get(UILocale.EN_CA).add(this.createReference(Account.TFSA_TYPE, "TFSA Account"));
		refMap.get(UILocale.EN_CA).add(this.createReference(Account.RSP_TYPE, "RSP Account"));		
		refMap.get(UILocale.EN_CA).add(this.createReference(Account.RIF_TYPE, "RIF Account"));
		refMap.get(UILocale.EN_CA).add(this.createReference(Account.LIRA_TYPE, "LIRA Account"));
		refMap.get(UILocale.EN_CA).add(this.createReference(Account.LIF_TYPE, "LIF Account"));
		
		refMap.get(UILocale.FR_CA).add(this.createReference(Account.INDIVIDUAL_TYPE, "Individual Account"));
		refMap.get(UILocale.FR_CA).add(this.createReference(Account.JOINT_TYPE, "Joint Account"));
		refMap.get(UILocale.FR_CA).add(this.createReference(Account.TFSA_TYPE, "TFSA Account"));
		refMap.get(UILocale.FR_CA).add(this.createReference(Account.RSP_TYPE, "RSP Account"));		
		refMap.get(UILocale.FR_CA).add(this.createReference(Account.RIF_TYPE, "RIF Account"));
		refMap.get(UILocale.FR_CA).add(this.createReference(Account.LIRA_TYPE, "LIRA Account"));
		refMap.get(UILocale.FR_CA).add(this.createReference(Account.LIF_TYPE, "LIF Account"));
		
		// add both locale to cache
		logger.info("Adding reference to cache for reference type: AccountTypes");
		this.addReferenceToCache(refMap, ReferenceType.ACCOUNT_TYPES);
		return refMap.get(locale);
	}
	
	private List<Reference> createJurisdictionTypes(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference("1","Federal"));
		refMap.get(UILocale.EN_CA).add(this.createReference("2","Provincial"));

		refMap.get(UILocale.FR_CA).add(this.createReference("1","Federal"));
		refMap.get(UILocale.FR_CA).add(this.createReference("2","Provincial"));

		logger.info("Adding reference to cache for reference type: JurisdictionTypes");
		this.addReferenceToCache(refMap, ReferenceType.JURISDICTION_TYPES);

		return refMap.get(locale);
	}	

	private List<Reference> createIirocOrganizations(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = readReferenceMapFromFile("/iiroc_organizations.txt");
		logger.info("Adding reference to cache for reference type: IirocOrganizations");
		this.addReferenceToCache(refMap, ReferenceType.IIROC_ORGANIZATIONS);
		return refMap.get(locale);
	}

	private List<Reference> createReceiveSecurityHolderOptionsList(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference("1", "I WANT to receive ALL securityholder materials"));
		refMap.get(UILocale.EN_CA).add(this.createReference("2", "I DECLINE to receive ALL securityholder materials"));
		refMap.get(UILocale.EN_CA).add(this.createReference("3", "I WANT to receive ONLY proxy-related materials"));

		refMap.get(UILocale.FR_CA).add(this.createReference("1", "I WANT to receive ALL securityholder materials Fr"));
		refMap.get(UILocale.FR_CA).add(this.createReference("2", "I DECLINE to receive ALL securityholder materials Fr"));
		refMap.get(UILocale.FR_CA).add(this.createReference("3", "I WANT to receive ONLY proxy-related materials Fr"));

		logger.info("Adding reference to cache for reference type: ReceiveSecurityHolderOptions");
		this.addReferenceToCache(refMap, ReferenceType.RECEIVE_SECURITY_HOLDER_OPTIONS);
		return refMap.get(locale);
	}

	public void addReferenceToCache(Map<UILocale, List<Reference>> refMap, ReferenceType type) {
		if (MapUtils.isEmpty(refMap))
			return;

		List<Reference> list = refMap.get(UILocale.EN_CA);
		// we can loop by refMap.keyset also.
		if (CollectionUtils.isNotEmpty(list)) {
			logger.debug("add label [{}] sources to cache [{}]", type.getLabel(), UILocale.EN_CA.getLang());
			cacheService.add(list, WFCacheKey.REFDATA.getCode(), type.getLabel(), REFDATA_CACHE);
		}

		List<Reference> frList = refMap.get(UILocale.FR_CA);
		if (CollectionUtils.isNotEmpty(list)) {
			logger.debug("add label [{}] sources to cache [{}]", type.getLabel(), UILocale.FR_CA.getLang());
			cacheService.add(frList, WFCacheKey.REFDATA_FR.getCode(), type.getLabel(), REFDATA_CACHE);
		}
	}
	
	private CountryReference createCountryReference(String code, String label, String isoCode) {
		CountryReference ref = new CountryReference();
		ref.setCode(code);
		ref.setLabel(label);
		ref.setIsoCode(isoCode);
		return ref;
	}

	private void addStatProvReference(String countryCode, List<Reference> countries, StatProvReference reference) {
		Reference country = countries.stream().filter(ref -> countryCode.equalsIgnoreCase(ref.getCode())).findFirst()
				.get();

		((CountryReference) country).getStateProvinces().add(reference);
	}

	private Map<UILocale, List<Reference>> readReferenceMapFromFile(String filename) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		List<Reference> enReferences = new ArrayList<>();
		List<Reference> frReferences = new ArrayList<>();
		try (Scanner scanner = new Scanner(this.getClass().getResourceAsStream(filename), "UTF-8")) {
			while (scanner.hasNextLine()) {
				String nextLine = scanner.nextLine();
				String[] columns = nextLine.split("\\t");
				
				enReferences.add(createReference(columns[0], columns[1]));
				frReferences.add(createReference(columns[0], columns[2]));
			}
		}
		refMap.put(UILocale.EN_CA, enReferences);
		refMap.put(UILocale.FR_CA, frReferences);
		return refMap;
	}

	 
	private List<Reference> createPaymentTypes(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference("1","Fee Based"));
		refMap.get(UILocale.EN_CA).add(this.createReference("2","Commission"));

		refMap.get(UILocale.FR_CA).add(this.createReference("1","Honoraires"));
		refMap.get(UILocale.FR_CA).add(this.createReference("2","Commission"));

		logger.info("Adding reference to cache for reference type: PaymentTypes");
		this.addReferenceToCache(refMap, ReferenceType.PAYMENT_TYPES);

		return refMap.get(locale);
	}
	
	private List<Reference> createFeeType(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();
		
		refMap.get(UILocale.EN_CA).add(this.createReference("A","BMO Senior Plan account holder"));
		refMap.get(UILocale.EN_CA).add(this.createReference("B","BMO/NB Employee"));
		refMap.get(UILocale.EN_CA).add(this.createReference("C","Standard Fee (default)"));
		refMap.get(UILocale.EN_CA).add(this.createReference("D","Standard Fee (default)"));
		refMap.get(UILocale.EN_CA).add(this.createReference("G","RESP - BMO NB Employee"));
		refMap.get(UILocale.EN_CA).add(this.createReference("H","Fee based"));
		refMap.get(UILocale.EN_CA).add(this.createReference("L","Locked In"));
		refMap.get(UILocale.EN_CA).add(this.createReference("N","InvestorLine use only"));
		refMap.get(UILocale.EN_CA).add(this.createReference("X","For InvestorLine use only"));
		refMap.get(UILocale.EN_CA).add(this.createReference("W","Address Unknown"));
		refMap.get(UILocale.EN_CA).add(this.createReference("V","Group Account"));
		refMap.get(UILocale.EN_CA).add(this.createReference("S","IA to Absorb"));
		refMap.get(UILocale.EN_CA).add(this.createReference("T","Household"));
		refMap.get(UILocale.EN_CA).add(this.createReference("U","BMO/NB Employee"));
		refMap.get(UILocale.EN_CA).add(this.createReference("Y","First Year \"Transfer In\" Accounts (reset annually)"));
		refMap.get(UILocale.EN_CA).add(this.createReference("Z","Branch Manager Discretion (reset annually)"));
				
		refMap.get(UILocale.FR_CA).add(this.createReference("A","Plan du titulaire de compte principal BMO"));
		refMap.get(UILocale.FR_CA).add(this.createReference("B","Employé de BMO / Nesbitt Burns"));
		refMap.get(UILocale.FR_CA).add(this.createReference("C","Frais standards (défaut)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("D","Frais standards (défaut)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("G","REEE - Employé BMO NB"));
		refMap.get(UILocale.FR_CA).add(this.createReference("H","Avec honoraires"));
		refMap.get(UILocale.FR_CA).add(this.createReference("L","Immobilisé"));
		refMap.get(UILocale.FR_CA).add(this.createReference("N","Réservé à l’usage de BMO Ligne d’action"));
		refMap.get(UILocale.FR_CA).add(this.createReference("X","Réservé à l’usage de BMO Ligne d’action"));
		refMap.get(UILocale.FR_CA).add(this.createReference("W","Adresse inconnue"));
		refMap.get(UILocale.FR_CA).add(this.createReference("V","Compte collectif"));
		refMap.get(UILocale.FR_CA).add(this.createReference("S","À absorber par le CP"));
		refMap.get(UILocale.FR_CA).add(this.createReference("T","Revenu du ménage supérieur à 250 000 $"));
		refMap.get(UILocale.FR_CA).add(this.createReference("U","Employé de BMO / Nesbitt Burns"));
		refMap.get(UILocale.FR_CA).add(this.createReference("Y","Comptes « transfert entrant » - première année (rétablis chaque année)"));
		refMap.get(UILocale.FR_CA).add(this.createReference("Z","Pouvoirs discrétionnaires des directeurs de succursale (rétablis chaque année)"));
		
		logger.info("Adding reference to cache for reference type: FeeType");
		this.addReferenceToCache(refMap, ReferenceType.FEE_TYPES);

		return refMap.get(locale);
	}

	private List<Reference> createReferralSources(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();
		
		refMap.get(UILocale.EN_CA).add(this.createReference("X","Employee Referrals"));
		refMap.get(UILocale.EN_CA).add(this.createReference("C","Client Referrals"));
		refMap.get(UILocale.EN_CA).add(this.createReference("N","Non-Client Referrals"));
		refMap.get(UILocale.EN_CA).add(this.createReference("B","BMO Referrals"));
		refMap.get(UILocale.EN_CA).add(this.createReference("I","Centres of Influence Referrals"));
		refMap.get(UILocale.EN_CA).add(this.createReference("S","Self-initiated Marketing"));
		refMap.get(UILocale.EN_CA).add(this.createReference("A","Firm-initiated Marketing"));
		refMap.get(UILocale.EN_CA).add(this.createReference("T","IA Transfer"));
		refMap.get(UILocale.EN_CA).add(this.createReference("U","Walk in / Call in"));
		refMap.get(UILocale.EN_CA).add(this.createReference("E","Existing Client - New Account"));

		refMap.get(UILocale.FR_CA).add(this.createReference("X","Références employés"));
		refMap.get(UILocale.FR_CA).add(this.createReference("C","Références clients"));
		refMap.get(UILocale.FR_CA).add(this.createReference("N","Références non-clients"));
		refMap.get(UILocale.FR_CA).add(this.createReference("B","Références BMO"));
		refMap.get(UILocale.FR_CA).add(this.createReference("I","Références centres d'influence"));
		refMap.get(UILocale.FR_CA).add(this.createReference("S","Marketing personnel"));
		refMap.get(UILocale.FR_CA).add(this.createReference("A","Marketing société"));
		refMap.get(UILocale.FR_CA).add(this.createReference("T","Transfert CP"));
		refMap.get(UILocale.FR_CA).add(this.createReference("U","Imprévu"));
		refMap.get(UILocale.FR_CA).add(this.createReference("E","Client existant - Nouveau compte"));
		
		logger.info("Adding reference to cache for reference type: ReferralSources");
		this.addReferenceToCache(refMap, ReferenceType.REFERRAL_SOURCES);

		return refMap.get(locale);
	}

	private List<Reference> createTimeUnits(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();
		
		refMap.get(UILocale.EN_CA).add(this.createReference("days","Days"));
		refMap.get(UILocale.EN_CA).add(this.createReference("months","Months"));
		refMap.get(UILocale.EN_CA).add(this.createReference("years","Years"));

		refMap.get(UILocale.FR_CA).add(this.createReference("days","Jours"));
		refMap.get(UILocale.FR_CA).add(this.createReference("months","Mois"));
		refMap.get(UILocale.FR_CA).add(this.createReference("years","Années"));
		
		logger.info("Adding reference to cache for reference type: TimeUnits");
		this.addReferenceToCache(refMap, ReferenceType.TIME_UNITS);

		return refMap.get(locale);
	}
	
	private List<Reference> createDocumentPreferenceOptions(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();
		
		refMap.get(UILocale.EN_CA).add(this.createReference("online","Online"));		
		refMap.get(UILocale.EN_CA).add(this.createReference("myMail","My mail"));		
		
		refMap.get(UILocale.FR_CA).add(this.createReference("online","Online FR"));		
		refMap.get(UILocale.FR_CA).add(this.createReference("myMail","My mail FR"));		

		logger.info("Adding reference to cache for reference type: DocumentPreferenceOptions");
		this.addReferenceToCache(refMap, ReferenceType.DOCUMENT_PREFERENCE_OPTIONS);

		return refMap.get(locale);
	}	

	private List<Reference> createApplicationStatuses(UILocale locale) {
		Map<UILocale, List<Reference>> refMap = this.initReferenceCacheMap();

		refMap.get(UILocale.EN_CA).add(this.createReference(AppStatus.DATA_COLLECTION.toString(), "Data Collection"));				 	
		refMap.get(UILocale.EN_CA).add(this.createReference(AppStatus.DOCUMENT_COLLECTION.toString(), "Signatures and Document Collection"));		
		refMap.get(UILocale.EN_CA).add(this.createReference(AppStatus.ACCOUNT_SETUP.toString(), "Account Setup"));		
		refMap.get(UILocale.EN_CA).add(this.createReference(AppStatus.IA_APPROVAL.toString(), "IA Approval"));		
		refMap.get(UILocale.EN_CA).add(this.createReference(AppStatus.IA_REMEDIATION.toString(), "IA Remediation"));		
		refMap.get(UILocale.EN_CA).add(this.createReference(AppStatus.BM_APPROVAL.toString(), "BM Approval"));		
		refMap.get(UILocale.EN_CA).add(this.createReference(AppStatus.COMPLETE.toString(), "Approved"));		

		refMap.get(UILocale.FR_CA).add(this.createReference(AppStatus.DATA_COLLECTION.toString(),"Collection de données"));		 		
		refMap.get(UILocale.FR_CA).add(this.createReference(AppStatus.DOCUMENT_COLLECTION.toString(),"Signatures et collection des documents"));		
		refMap.get(UILocale.FR_CA).add(this.createReference(AppStatus.ACCOUNT_SETUP.toString(),"Account Setup FR"));		
		refMap.get(UILocale.FR_CA).add(this.createReference(AppStatus.IA_APPROVAL.toString(),"Approbation du AI"));		
		refMap.get(UILocale.FR_CA).add(this.createReference(AppStatus.IA_REMEDIATION.toString(),"AI Remediation FR"));		
		refMap.get(UILocale.FR_CA).add(this.createReference(AppStatus.BM_APPROVAL.toString(),"Approbation du BM"));
		refMap.get(UILocale.FR_CA).add(this.createReference(AppStatus.COMPLETE.toString(),"Approved FR"));

		logger.info("Adding reference to cache for reference type: ApplicationStatuses");
		this.addReferenceToCache(refMap, ReferenceType.APPLICATION_STATUS);

		return refMap.get(locale);
	}

	private Map<UILocale, List<Reference>> initReferenceCacheMap() {
		Map<UILocale, List<Reference>> refMap = new HashMap<>();

		refMap.put(UILocale.EN_CA, new ArrayList<>());
		refMap.put(UILocale.FR_CA, new ArrayList<>());

		return refMap;
	}

	private Reference createReference(String code, String value) {
		return new Reference(code, value);
	}
	
	private Reference createExpiredReference(String code, String value) {
		Reference ref = new Reference(code, value);
		ref.setExpired(true);
		return ref;
	}

	private StatProvReference createStatProvReference(String code, String value, String isoCode){
		StatProvReference reference = new StatProvReference();
		reference.setCode(code);
		reference.setLabel(value);
		reference.setIsoCode(isoCode);
		return reference;
	}	
	
	@SuppressWarnings("unchecked")
	private void collectRefData(Map<ReferenceType, List<Reference>> references, UILocale locale, List<ReferenceType> referenceTypes) {
		String key = this.createLocaleCacheKey(locale);
		
		Iterator<ReferenceType> it = referenceTypes.iterator();
		while (it.hasNext()) {
			ReferenceType type = it.next();
			List<Reference> response = (List<Reference>) cacheService.get(key, type.getLabel(), REFDATA_CACHE);
			if (CollectionUtils.isNotEmpty(response)) {
				references.put(type, response);
				it.remove();
			}
		}
		
		if (CollectionUtils.isNotEmpty(referenceTypes)){
			references.putAll(loadReferenceData(referenceTypes, locale));
		}
	}
	
	private Map<ReferenceType, List<Reference>> loadReferenceData(List<ReferenceType> referenceTypes, UILocale locale) {
		GetDataListForParameterRequestBody request = new GetDataListForParameterRequestBody();
		
		for (ReferenceType referenceType: referenceTypes) {
			request.getParamsInquiry().add(createParamsInquiry(referenceType.getDataRefCode()));
			
			if (referenceType.getMappingRefCode() != null) {
				request.getParamsInquiry().add(createParamsInquiry(referenceType.getMappingRefCode()));
			}
		}

		GetDataListForParameterRequest requestWrapper = new GetDataListForParameterRequest();
		requestWrapper.setGetDataListForParameterRequest(request);
		try {
			GetDataListForParameterResponse dataListForParameter = referenceData.getDataListForParameter(requestWrapper, generateHeaderString(createHeader()));
			return extractData(referenceTypes, dataListForParameter, locale);
		} catch (JsonProcessingException ex) {
			logger.error("Failed to load reference data for given reference types :",ex);
			throw new WebServiceException(ex);
		}
	}

	private Map<ReferenceType, List<Reference>> extractData(List<ReferenceType> referenceTypes, GetDataListForParameterResponse dataListForParameter, UILocale locale) {
		Map<ReferenceType, List<Reference>> referenceMap = new HashMap<>();

		if (dataListForParameter != null && dataListForParameter.getOperationResponse() != null && dataListForParameter.getOperationResponse().getGetDataListForParameterResponse() != null) {
			for (ReferenceType referenceType: referenceTypes) { 
				 Map<UILocale, List<Reference>> refMap = dataListParser.extractReferenceList(referenceType, dataListForParameter.getOperationResponse().getGetDataListForParameterResponse(), locale);
				 logger.debug("Adding reference to cache for reference type: "+referenceType.getLabel());
				 this.addReferenceToCache(refMap, referenceType);
				 //return required locale data
				referenceMap.put(referenceType, refMap.get(locale));
			}
		}		
		return referenceMap;
	}

	@Override
	public boolean isValidCodeForType(String code, ReferenceType refType) {
		return ofType(refType, UILocale.EN_CA).stream().anyMatch(r -> r.getCode().equals(code));
	}

	@Override
	public OccupationReference getOccupationReferences(String code){
		
		List<Reference> occupations = this.ofType(ReferenceType.OCCUPATIONS_TYPES, UILocale.EN_CA);
		for(Reference ref: occupations){
			if(ref.getCode().equals(code)) {				
				OccupationReference occupationRef =(OccupationReference)ref;
				return occupationRef;
			}
		}
		return null;
	}

	/**
	 * 
	 * @param locale
	 * @return cacheKey code
	 */
	private String createLocaleCacheKey(UILocale locale) {
		WFCacheKey cacheKey = null;
		switch (locale) {
		case FR_CA:
			cacheKey = WFCacheKey.REFDATA_FR;
			break;

		default:
			cacheKey = WFCacheKey.REFDATA;
			break;
		}

		return cacheKey.getCode();
	}
	
	private HUBHeaderRequest createHeader() {
		return hubRequestComponent
				.getHubBuilder()
				.originatorResource("ReferenceDataV2")
				.originatorResourceFunction("getDataListForParameter")
				.build();
	}

	String generateHeaderString(final HUBHeaderRequest requestHeader) throws JsonProcessingException {
		return ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
	}

	private ParamsInquiry createParamsInquiry(String code) {
		ParamsInquiry paramsInquiry = new ParamsInquiry();
		paramsInquiry.setCode(code);
		paramsInquiry.setSource("RDM");
		return paramsInquiry;
	}
}
