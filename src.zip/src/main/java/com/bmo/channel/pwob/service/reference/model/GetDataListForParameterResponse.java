package com.bmo.channel.pwob.service.reference.model;

public class GetDataListForParameterResponse {
	private String status;
	private String messageCode;
	private GetDataListForParameterResponseBodyWrapper operationResponse;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessageCode() {
		return messageCode;
	}
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}
	public GetDataListForParameterResponseBodyWrapper getOperationResponse() {
		return operationResponse;
	}
	public void setOperationResponse(GetDataListForParameterResponseBodyWrapper operationResponse) {
		this.operationResponse = operationResponse;
	}
}
