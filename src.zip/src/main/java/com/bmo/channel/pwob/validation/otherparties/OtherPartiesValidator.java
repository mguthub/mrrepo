/**
 * 
 */
package com.bmo.channel.pwob.validation.otherparties;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Application;

/**
 * @author vvallia
 *
 */
public class OtherPartiesValidator implements ConstraintValidator<ValidOtherParties, Application> {
	@Autowired
	private GuaranteeValidator guaranteeValidator;

	@Autowired
	private GuarantorValidator guarantorValidator;

	@Override
	public void initialize(ValidOtherParties constraintAnnotation) {
	}

	@Override
	public boolean isValid(Application application, ConstraintValidatorContext context) {
		boolean valid = true;

		valid = guaranteeValidator.isValid(application, context) &&valid;
		valid = guarantorValidator.isValid(application, context) &&valid;

		return valid;
	}
}
