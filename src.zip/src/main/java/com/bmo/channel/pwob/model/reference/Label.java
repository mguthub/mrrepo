package com.bmo.channel.pwob.model.reference;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class Label {
	private String locale;
	private String value;

	public Label(String locale, String value) {
		this.locale = locale;
		this.value = value;
	}

	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}

	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}