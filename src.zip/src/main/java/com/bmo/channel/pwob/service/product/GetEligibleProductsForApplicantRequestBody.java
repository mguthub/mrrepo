package com.bmo.channel.pwob.service.product;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "LOB", "dateOfBirth", "provinceCode" })
public class GetEligibleProductsForApplicantRequestBody {
	@JsonProperty("LOB")
	private String lob;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String dateOfBirth;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String provinceCode;

	public String getLob() {
		return lob;
	}
	public void setLob(String lOB) {
		lob = lOB;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getProvinceCode() {
		return provinceCode;
	}
	public void setProvinceCode(String provinceCode) {
		this.provinceCode = provinceCode;
	}
}
