package com.bmo.channel.pwob.validation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.lang3.StringUtils;

/**
 * Validates date format. Does not validate whether field is required or not.
 * @author akhales
 */
public class DatePatternValidator extends AbstractBaseValidator implements ConstraintValidator<DateValidation, String> {
	private String code;
	private String pattern;

	@Override
	public void initialize(DateValidation constraintAnnotation) {
		code = constraintAnnotation.code();		
		pattern = constraintAnnotation.pattern();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if(StringUtils.isEmpty(value)) {
			 return true;
		}
		if(!isDatePatternValid(value,pattern)){
			this.createConstraintViolation(context, code, null);
			return false;
		}
		return true;
	}
}
