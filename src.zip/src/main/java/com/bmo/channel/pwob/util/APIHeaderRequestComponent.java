package com.bmo.channel.pwob.util;

public interface APIHeaderRequestComponent {

    APIRequestHeaderBuilder.HeaderBuilder getHubBuilder();

    <T> T requestBodyWithRequestorInfo(T t, String... strings);

    String getMetaInfo(String documentPackageId);
}
