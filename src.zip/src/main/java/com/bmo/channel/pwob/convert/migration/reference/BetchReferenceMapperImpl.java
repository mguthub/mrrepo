package com.bmo.channel.pwob.convert.migration.reference;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.Employment;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.validation.RefDataValues;

@Component
public class BetchReferenceMapperImpl implements BetchReferenceMapper {
	@Autowired
	private EventManager eventManager;

	// TODO figure out why spring context doesn't work when this is injected
//	@Autowired
//	private ReferencesService referencesService;

	static private final List<String> OLD_EMPLOYMENT_STATUSES = Arrays.asList(RefDataValues.EMPLOYMENT_STATUS_HOMEMAKER, RefDataValues.EMPLOYMENT_STATUS_STUDENT);
	static private final List<String> OLD_BUSINESS_NATURES = Arrays.asList(RefDataValues.NATURE_OF_BUSINESS_RETIRED, RefDataValues.NATURE_OF_BUSINESS_UNEMPLOYED);
	static private final List<String> OLD_OCCUPATIONS = Arrays.asList(RefDataValues.OCCUPATION_RETIRED);

	@Override
	public void updateApplication(Application application) {
		application.getParties().stream().forEach(p -> migrateEmploymentStatuses(application.getApplicationId(), p.getPartyRefId(), p.getPersonal()));
	}

	private void migrateEmploymentStatuses(String applicationId, String partyRefId, PersonalInformation personalInformation) {
		if (hasEmployomentInfo(personalInformation)) {
			Employment employment = personalInformation.getEmployment();
			if(Optional.ofNullable(employment.getEmploymentStatus()).isPresent()
				&& OLD_EMPLOYMENT_STATUSES.contains(employment.getEmploymentStatus())) {
				// null out
				eventManager.publishWarn(String.format("Nulling out employment status in application %s for party ref id %s",
						applicationId, 
						partyRefId));
				employment.setEmploymentStatus(null);
			}

			if(employment.getOccupation() != null) {
				if(OLD_OCCUPATIONS.contains(employment.getOccupation())) {
//				if(!referencesService.isValidCodeForType(employment.getOccupation(), ReferenceType.OCCUPATIONS_TYPES)) {
					eventManager.publishWarn(String.format("Nulling out occupation in application %s for party ref id %s",
							applicationId, 
							partyRefId));
					employment.setOccupation(null);
				}
			}

			if(employment.getNatureOfBusiness() != null) {
				if(OLD_BUSINESS_NATURES.contains(employment.getNatureOfBusiness())) {
//				if(!referencesService.isValidCodeForType(employment.getNatureOfBusiness(), ReferenceType.BUSINESS_NATURES)) {
					eventManager.publishWarn(String.format("Nulling out nature of business in application %s for party ref id %s",
							applicationId, 
							partyRefId));
					employment.setNatureOfBusiness(null);
				}
			}
		}
	}

	private boolean hasEmployomentInfo(PersonalInformation personalInformation) {
		return Optional.ofNullable(personalInformation.getEmployment()).isPresent();
	}
}
