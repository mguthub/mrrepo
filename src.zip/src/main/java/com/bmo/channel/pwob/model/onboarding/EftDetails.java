/**
 * 
 */
package com.bmo.channel.pwob.model.onboarding;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.DateValidation;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author vvallia
 *
 */
public class EftDetails {

	private Boolean isBankAccountOwnedByApplicant;
	
	private String institutionCode;
	
	private String transitCode;
	
	private String accountNumber;
	
	private String currencyCode;
	
	private String amount;
	
	@ApiModelProperty(example="10", value="Valid values can be found in the reference service", allowableValues="10,11,12,13")
	@ReferenceData(code=ErrorCodes.INVALID_EFT_FREQUENCY, type=ReferenceType.EFT_PAYMENT_FREQUENCY_TYPES)
	private String frequency;
	
	private String contributionType;
	
	@ApiModelProperty(example="1955-12-25", value="Format: YYYY-MM-DD")
	@DateValidation(code=ErrorCodes.INVALID_DATE)
	private String startDate;
	
	private Boolean hasType3AccountSetup;
	
	private Boolean isJointAccount;
	
	private String accountOwner;
	
	@ApiModelProperty(example="BMO", dataType="String")
	private String institutionName;

	private Boolean ownershipOfBankAccountVerified;
	
	public Boolean getIsBankAccountOwnedByApplicant() {
		return isBankAccountOwnedByApplicant;
	}

	public void setIsBankAccountOwnedByApplicant(Boolean isBankAccountOwnedByApplicant) {
		this.isBankAccountOwnedByApplicant = isBankAccountOwnedByApplicant;
	}

	public String getInstitutionCode() {
		return institutionCode;
	}

	public void setInstitutionCode(String institutionCode) {
		this.institutionCode = institutionCode;
	}

	public String getTransitCode() {
		return transitCode;
	}

	public void setTransitCode(String transitCode) {
		this.transitCode = transitCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getCurrencyCode() {
		return currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getFrequency() {
		return frequency;
	}

	public void setFrequency(String frequency) {
		this.frequency = frequency;
	}

	public String getContributionType() {
		return contributionType;
	}

	public void setContributionType(String contributionType) {
		this.contributionType = contributionType;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public Boolean getHasType3AccountSetup() {
		return hasType3AccountSetup;
	}

	public void setHasType3AccountSetup(Boolean hasType3AccountSetup) {
		this.hasType3AccountSetup = hasType3AccountSetup;
	}

	public Boolean getIsJointAccount() {
		return isJointAccount;
	}

	public void setIsJointAccount(Boolean isJointAccount) {
		this.isJointAccount = isJointAccount;
	}

	public String getAccountOwner() {
		return accountOwner;
	}

	public void setAccountOwner(String accountOwner) {
		this.accountOwner = accountOwner;
	}

	public String getInstitutionName() {
		return institutionName;
	}

	public void setInstitutionName(String institutionName) {
		this.institutionName = institutionName;
	}

	public Boolean isOwnershipOfBankAccountVerified() {
		return ownershipOfBankAccountVerified;
	}

	public void setOwnershipOfBankAccountVerified(Boolean ownershipOfBankAccountVerified) {
		this.ownershipOfBankAccountVerified = ownershipOfBankAccountVerified;
	}
	
}
