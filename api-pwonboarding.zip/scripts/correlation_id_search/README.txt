******************************************************************************************************************************
***********************************      Correlation ID Search Scripts    ****************************************************
******************************************************************************************************************************

The three scripts in this folder are used to remotely fetch the requests and 
responses that share a specified correlationId (corrId) when troubleshooting errors.

corrSearch.sh - the client-side script that is used to initiate a search.
serverSearch.sh - the server-side script that accesses and parses logs to find the desired entries
deploySearch.sh - the client-side script that deploys serverSearch.sh to new environments to allow searches

******************************************************************************************************************************
************************************************ Starting ********************************************************************
******************************************************************************************************************************

The first thing you need to do upon retrieving the scripts is to change the USER variables in 

-deploySearch.sh 	(line 3)
-corrSearch.sh 		(line 3)

to your BMO user id, so ssh connections are made with the correct credentials.

export USER=[YOUR USER ID HERE]


Similarly, if you have a generated rsa key, you need to specify the correct field path in line 7 of deploySearch.sh
Otherwise, the line should be commented out with a '#'.

ssh-copy-id -i PATH/TO/YOUR/id_rsa $1

Doing this part is optional, but it saves time in entering passwords every time a deployment or search is conducted

It is also recommended that you run the command "dos2unix serverSearch.sh" after copying the files. This converts the script
that will be moved to the environments to the correct line endings for unix environments. 

******************************************************************************************************************************
*********************************************** Deployment *******************************************************************
******************************************************************************************************************************

corrSearch searches will log fetch from both application servers on every run, but deploySearch must be run
for each application server.

./deploySearch.sh [hostname]

After this script  is completed, if you ssh into the hostname you specified, 
you should see a "search.sh" file in your home directory. This means the
deployment was successful.

If you specified an rsa-key, you should see your key in the "authorized_keys" file inside ~/.ssh

******************************************************************************************************************************
********************************************** Searching *********************************************************************
******************************************************************************************************************************

Using corrSearch.sh uses the following command:

./corrSearch.sh [env] [corrId] [server]

[env] - specifies the environment you want to search. and follows this convention: [env]app01.paas.bmogc.net
You only need to specify the part of the hostname that would appear in [env] rather than the whole thing 
(bwa-bccld2 for example).

The script also has some shortcuts for specifying already known hosts. So you can use 'dit2' instead of 'bwa-bccld2'
feel free to add or alter the if statements in corrSearch.sh to set the shortcuts to your liking.

[corrId] - This is just the correlation Id you want to search from.

[server] - specifies which server on the environment you want to do the log fetch from. This defaults to "api-workflows" which
suffices in most cases. But some environments have multiple deployments like "api-workflows-march" in DEV, which would need to
be specified if a log fetch was conducted there. The same is also true for api-party-v2 searches.

The results of the script run will be an ordered list of all requests and responses that share the specified correlation id
with logs from app01 appearing before app02 with a "**************************************" separating them.