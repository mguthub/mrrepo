package com.bmo.channel.pwob.model.user;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.user.AuthenticatedUser;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

public class User {
	private String firstName;
	private String lastName;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String jobFunction;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String branchCode;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<String> bmApproverFor;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<String> iaCodes;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<String> iaJurisdictionProvinces;	

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<String> iaApproverFor;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<SupportingIa> supportingSaFor;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<String> bmJurisdictionProvinces;
	
	@JsonIgnore
	private Map<String,String> iaAndBranchCodes = new HashMap<String,String>();	

	@JsonIgnore
	private AuthenticatedUser authenticatedUser;

	public User(AuthenticatedUser authenticatedUser) {
		this.authenticatedUser = authenticatedUser;
	}

	public Boolean getIsBranchManager() {
		return CollectionUtils.isNotEmpty(bmApproverFor);
	}
	public String getJobFunction() {
		return jobFunction;
	}
	public void setJobFunction(String jobFunction) {
		this.jobFunction = jobFunction;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public ApplicationLob getLob() {
		return authenticatedUser.getLob();
	}

	public List<String> getBmApproverFor() {
		return bmApproverFor;
	}

	public void setBmApproverFor(List<String> bmApproverFor) {
		this.bmApproverFor = Collections.unmodifiableList(bmApproverFor);
	}

	public List<String> getIaCodes() {
		return iaCodes;
	}

	public void setIaCodes(List<String> iaCodes) {
		this.iaCodes = Collections.unmodifiableList(iaCodes);
	}

	public List<String> getIaApproverFor() {
		return iaApproverFor;
	}

	public void setIaApproverFor(List<String> iaApproverFor) {
		this.iaApproverFor = Collections.unmodifiableList(iaApproverFor);
	}

	public List<SupportingIa> getSupportingSaFor() {
		return supportingSaFor;
	}

	public void setSupportingSaFor(List<SupportingIa> supportingSaFor) {
		this.supportingSaFor = supportingSaFor;
	}

	public String getNetworkId() {
		return authenticatedUser.getNetworkId();
	}

	@JsonIgnore
	public String getDomain() {
		return authenticatedUser.getDomain();
	}

	@JsonIgnore
	public String getUserId() {
		return authenticatedUser.getUserId();
	}

	@JsonIgnore
	public boolean isSA() {
		return "SA".equalsIgnoreCase(jobFunction);
	}
	
	public Map<String, String> getIaAndBranchCodes() {
		return iaAndBranchCodes;
	}

	public void setIaAndBranchCodes(Map<String, String> iaAndBranchCodes) {
		this.iaAndBranchCodes = iaAndBranchCodes;
	}
	
	public List<String> getIaJurisdictionProvinces() {
		return iaJurisdictionProvinces;
	}

	public void setIaJurisdictionProvinces(List<String> iaJurisdictionProvinces) {
		this.iaJurisdictionProvinces = iaJurisdictionProvinces;
	}
	
	public List<String> getBmJurisdictionProvinces() {
		return bmJurisdictionProvinces;
	}

	public void setBmJurisdictionProvinces(List<String> bmJurisdictionProvinces) {
		this.bmJurisdictionProvinces = bmJurisdictionProvinces;
	}	
	
	
}
