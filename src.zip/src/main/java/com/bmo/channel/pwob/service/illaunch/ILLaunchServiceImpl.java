package com.bmo.channel.pwob.service.illaunch;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.pwob.config.EnvironmentConfig;
import com.bmo.channel.pwob.service.digitaltoken.DigitalTokenService;

@Service
public class ILLaunchServiceImpl implements ILLaunchService{

	public static final String OLAP_FIRST_NAME_TAG = "FirstName";
	public static final String OLAP_LAST_NAME_TAG = "LastName";
	public static final String OLAP_CUSTOMER_ID_TAG = "EcifId";
	
	
	@Autowired
	EnvironmentConfig environmentConfig;
	
	@Autowired
	DigitalTokenService digitalTokenService;
	
	@Override
	public String redirectToOlap(String formData) {
		String redirect = 	"<html><body onload=\"document.input.submit()\">" +
								"<h3>Redirecting you to OLAP...</h3>" +
								"<form name=\"input\" action=\"https://bmilqa05.bmofg.com/ILOLAPWeb/olap/applyOnlinePrefill.do?method=prefill\" method=\"post\" style=\"display:none\">" +
									"<input type=\"text\" name=\"OLAP_ExternalInterface\" size=\"1000\" length=\"1000\"  value='"+ formData +"'/>" +
									"<input type=\"text\" name=\"method\"size=\"120\" length=\"120\" value=\"prefill\"/>" +
								"</form></body></html>";
		
		return redirect;
	}

	@Override
	public String parseAndRedirectToApp(String formData) {
		String redirect;		
		String paramString = "first_name=" + getXmlTagValue(formData, OLAP_FIRST_NAME_TAG) + "&last_name=" + getXmlTagValue(formData, OLAP_LAST_NAME_TAG) +
							 "&cache_token=" + digitalTokenService.generateToken(formData) +
							 "&customer_id=" + getXmlTagValue(formData, OLAP_CUSTOMER_ID_TAG);
		
		if(environmentConfig.getInjectionEnabled().equals("true")){
			String ivUser = "PWOBOFFQA1@pcdqa.OfficeQA";
			String ivGroups = "PWOB_BIL_USERS";
			redirect = environmentConfig.getApplnHostUrl() + "?iv_user=" + ivUser + "&iv_groups=" + ivGroups + "&" + paramString;
		}
		else{
			redirect = environmentConfig.getApplnHostUrl() + "?" + paramString;
		}
		
		String redirectResponse=
				"<!DOCTYPE HTML><html><head>"+
					"<script type=\"text/javascript\">window.location.href =\"" + redirect + "\"</script>" + 
				"</head></html>";
		
		
		return redirectResponse; 
	}

	private String getXmlTagValue(String formData, String tag) {
		String tagString = "<" + tag + ">";
		int start = formData.indexOf(tagString);
		if(start == -1) {
			return "";
		}
		
		int end = formData.indexOf("</" + tag + ">", start);
		return formData.substring(start + tagString.length(), end);
	}

	@Override
	public boolean isOlapOnly(String formData) {
		//TODO: Actual method still TBD 
		int start = formData.indexOf("<" + OLAP_CUSTOMER_ID_TAG + ">");
		return formData.indexOf("<" + OLAP_CUSTOMER_ID_TAG + ">", start+1) != -1;
	}

	
}
