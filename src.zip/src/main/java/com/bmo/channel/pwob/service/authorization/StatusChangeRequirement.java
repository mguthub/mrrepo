package com.bmo.channel.pwob.service.authorization;

import java.util.ArrayList;
import java.util.List;

public class StatusChangeRequirement {
	List<String> acceptableAppStatuses = new ArrayList<>();	

	public List<String> getAcceptableAppStatuses() {
		return acceptableAppStatuses;
	}
	public void setAcceptableAppStatuses(List<String> acceptableAppStatuses) {
		this.acceptableAppStatuses = acceptableAppStatuses;
	}	
}
