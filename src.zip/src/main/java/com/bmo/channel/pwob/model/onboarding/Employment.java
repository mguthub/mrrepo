package com.bmo.channel.pwob.model.onboarding;

import javax.validation.Valid;

import com.fasterxml.jackson.annotation.JsonInclude;

import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.bmo.channel.pwob.validation.reference.ReferenceData;

import io.swagger.annotations.ApiModelProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Employment{
	private Boolean retiredBmoEmployee;

	@ApiModelProperty(example="100001", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.BMO_COMPANY_CODES, code=ErrorCodes.INVALID_RETIRED_BMO_GROUP)
	private String  retiredBmoGroup;

	private Boolean isBmoEmployee;

	@ApiModelProperty(example="100000", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.EMPLOYMENT_STATUSES, code=ErrorCodes.INVALID_EMPLOYMENT_STATUS)
	private String employmentStatus;

	@DataValidationPattern(code=ErrorCodes.INVALID_EMPLOYER_BUSINESS_NAME)
	private String employerBusinessName;

	@ApiModelProperty(example="100001", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.BMO_COMPANY_CODES, code=ErrorCodes.INVALID_BMO_GROUP)
	private String bmoGroup;

	@ApiModelProperty(example="8", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.OCCUPATIONS_TYPES, code=ErrorCodes.INVALID_OCCUPATION_TYPES)
	private String occupation;

	@ApiModelProperty(example="online", value="Valid values can be found in the reference service")
	@ReferenceData(type=ReferenceType.BUSINESS_NATURES, code=ErrorCodes.INVALID_BUSINESS_NATURES)
	private String natureOfBusiness;

	@Valid
	private Phone primaryBusinessPhone;

	@DataValidationPattern(code=ErrorCodes.INVALID_JOB_TITLE)
	private String jobTitle;
	
	@Valid
	private Address employmentAddress;

	public Boolean getRetiredBmoEmployee() {
		return retiredBmoEmployee;
	}
	public void setRetiredBmoEmployee(Boolean retiredBmoEmployee) {
		this.retiredBmoEmployee = retiredBmoEmployee;
	}

	public String getRetiredBmoGroup() {
		return retiredBmoGroup;
	}
	public void setRetiredBmoGroup(String retiredBmoGroup) {
		this.retiredBmoGroup = retiredBmoGroup;
	}
	
	public String getEmploymentStatus() {
		return employmentStatus;
	}
	public void setEmploymentStatus(String employmentStatus) {
		this.employmentStatus = employmentStatus;
	}

	public String getEmployerBusinessName() {
		return employerBusinessName;
	}
	
	public void setEmployerBusinessName(String employerBusinessName) {
		this.employerBusinessName = employerBusinessName;
	}
	
	public String getOccupation() {
		return occupation;
	}
	
	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}
	
	public String getNatureOfBusiness() {
		return natureOfBusiness;
	}
	
	public void setNatureOfBusiness(String natureOfBusiness) {
		this.natureOfBusiness = natureOfBusiness;
	}
	
	public Phone getPrimaryBusinessPhone() {
		return primaryBusinessPhone;
	}
	
	public void setPrimaryBusinessPhone(Phone primaryBusinessPhone) {
		this.primaryBusinessPhone = primaryBusinessPhone;
	}
	
	public Address getEmploymentAddress() {
		return employmentAddress;
	}
	
	public void setEmploymentAddress(Address employmentAddress) {
		this.employmentAddress = employmentAddress;
	}
	
	public String getBmoGroup() {
		return bmoGroup;
	}
	
	public void setBmoGroup(String bmoGroup) {
		this.bmoGroup = bmoGroup;
	}
	public Boolean getIsBmoEmployee() {
		return isBmoEmployee;
	}
	public void setIsBmoEmployee(Boolean isBmoEmployee) {
		this.isBmoEmployee = isBmoEmployee;
	}
	public String getJobTitle() {
		return jobTitle;
	}
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}
		
}
