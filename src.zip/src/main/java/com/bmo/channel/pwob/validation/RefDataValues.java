package com.bmo.channel.pwob.validation;

public interface RefDataValues {
	//Employment
	public static final String EMPLOYMENT_STATUS_FULL_TIME = "100000";
	public static final String EMPLOYMENT_STATUS_PART_TIME = "100001";
	public static final String EMPLOYMENT_STATUS_CONTRACT = "100005";
	public static final String EMPLOYMENT_STATUS_SEASONAL = "100006";
	public static final String EMPLOYMENT_STATUS_SELF_EMPLOYED = "100002";
	public static final String EMPLOYMENT_STATUS_RETIRED = "100004";
	public static final String EMPLOYMENT_STATUS_UNEMPLOYED = "100003";
	public static final String EMPLOYMENT_STATUS_HOMEMAKER = "100007";
	public static final String EMPLOYMENT_STATUS_STUDENT = "100008";
	public static final int    EMPLOYER_NAME_MAX_LENGTH = 30;

	public static final String BMO_GROUP_NESBITT_BURNS = "100001";
	public static final String BMO_GROUP_INVESTOR_LINE = "100015";
	public static final String NATURE_OF_BUSINESS_ACCOUNTING = "100082";
	public static final String NATURE_OF_BUSINESS_RETIRED = "100146";
	public static final String NATURE_OF_BUSINESS_UNEMPLOYED = "100158";
	public static final String OCCUPATION_AGRICULTURE="08";
	public static final String OCCUPATION_DEPUTY_MINISTER = "b4";
	public static final String OCCUPATION_UNEMPLOYED = "61";
	public static final String OCCUPATION_HOMEMAKER = "35";
	public static final String OCCUPATION_STUDENT = "50";
	public static final String OCCUPATION_RETIRED = "46";
	
	public static final String PEP_TYPE_FOREIGN = "F";
	public static final String PEP_TYPE_DOMESTIC = "D";
	
	//Marital Statuses
	public static final String MARITAL_STATUS_SINGLE= "100001";
	public static final String MARITAL_STATUS_MARRIED = "100002";
	public static final String MARITAL_STATUS_COMMON_LAW = "100003";
	public static final String MARITAL_STATUS_SEPARATED = "100005";
	public static final String MARITAL_STATUS_WIDOWED = "100006";
	public static final String MARITAL_STATUS_DIVORCED = "100004";
		

	//Countries
	public static final String CANADA_COUNTRY_CODE = "100000";
	public static final String USA_COUNTRY_CODE = "100001";
	public static final String FRANCE_COUNTRY_CODE = "100074";
	public static final String INDIA_COUNTRY_CODE = "100100";
	public static final String GERMANY_COUNTRY_CODE = "100081";
	public static final String BELIZE_COUNTRY_CODE = "100024";
	public static final String SPAIN_COUNTRY_CODE = "100200";
	public static final String ALGERIA_COUNTRY_CODE = "100005";
	public static final String AFGHANISTAN_COUNTRY_CODE = "100002";
	
	//States and Provinces
	public static final String PROVINCE_AB = "101";
	public static final String PROVINCE_ONT = "108";
	public static final String PROVINCE_QBC = "110";
	public static final String PROVINCE_BC = "102";
	public static final String PROVINCE_SK = "111";
	public static final String PROVINCE_PE = "109";
	public static final String STATE_MN = "28";
	
	
	public static final String PROVINCE_MB = "103";
	public static final String PROVINCE_NB = "104";
	public static final String PROVINCE_NL = "105";
	public static final String PROVINCE_NS = "107";
	
	
	//Verification Values
	public static final String DOCUMENT_TYPE_PASSPORT_CARD = "009";	
	public static final String DOCUMENT_TYPE_NEXUS_CARD = "050";	
	public static final String DOCUMENT_TYPE_DRIVERS_LICENSE = "010";	
	public static final String DOCUMENT_TYPE_PROVINCIAL_HEALTH_INSURANCE_CARD = "014";	
	public static final String DOCUMENT_TYPE_CANADIAN_CITIZENSHIP_CARD = "015";
	public static final String DOCUMENT_TYPE_SASKATCHEWAN_MANDATORY_PHOTO_ID = "110";
	public static final String DOCUMENT_TYPE_PRINCE_EDWARD_ISLAND_VOLUNTARY_ID = "109";
	public static final String DOCUMENT_TYPE_PERMANENT_RESIDENCE_CARD = "013";
	public static final String DOCUMENT_TYPE_MANITOBA_IDENTIFICATION_CARD = "020";
	public static final String DOCUMENT_TYPE_GOVERNMENT_ISSUED_CERTIFICATE_INDIAN_STATUS = "022";
	
	public static final String ID_VERIFICATION_METHDOD_EMPLOYEE_CODE = "3";
	public static final String ID_VERIFICATION_METHOD_AGENT = "2";
	public static final String ID_VERIFICATION_METHOD_AFFILIATE = "1";
	
	//Source Of Wealth
	public static final String WEALTH_SOURCE_SAVINGS = "1";
	public static final String WEALTH_SOURCE_OTHER = "6";
	
	//Source of Income
	public static final String INCOME_SOURCE_INHERITANCE = "100010";
	public static final String INCOME_SOURCE_OTHER = "100020";
	
	//Account Subtypes
	public static final String ACCOUNT_SUBTYPE_CASH = "1";
	public static final String ACCOUNT_SUBTYPE_MARGIN = "2";
	public static final String ACCOUNT_SUBTYPE_MARGIN_SHORT = "5";
	public static final String ACCOUNT_SUBTYPE_DAP = "9";
	
	//Past Experience
	public static final String PAST_EXPERIENCE_BONDS  = "1";
	public static final String PAST_EXPERIENCE_ALTERNATIVE_INVESTMENTS = "7";
	
	//Intended Use
	public static final String INTENDED_USE_SAVINGS = "04";
	public static final String INTENDED_USE_OTHER = "08";
	
	//Investment Knowledge
	public static final String INVESTMENT_KNOWLEDGE_GOOD  = "B";
	
	//Account Link Type
	public static final String ACCOUNT_LINK_TYPE_CHEQUING = "1";
	
	//Investment Objective
	public static final String INVESTMENT_OBJECTIVE_INCOME = "INC";
	
	//Referral Source
	public static final String REFERRAL_SOURCE_BMO_REFERRER="B";

	/**
	 * Tax id missing reason
	 * @see <a href="https://confluence.bmogc.net/display/PWO/RIS+-+Identification+Missing+Reason">Confluence</a>
	 */
	public static final String TAX_ID_MISSING_REASON_OTHER = "3";
}
