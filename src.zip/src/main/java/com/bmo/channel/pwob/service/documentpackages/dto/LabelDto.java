package com.bmo.channel.pwob.service.documentpackages.dto;

public class LabelDto {
	private String locale;
	private String value;

	public LabelDto(String locale, String value) {
		this.locale = locale;
		this.value = value;
	}

	public String getLocale() {
		return locale;
	}
	public void setLocale(final String locale) {
		this.locale = locale;
	}
	public String getValue() {
		return value;
	}
	public void setValue(final String value) {
		this.value = value;
	}
}
