package com.bmo.channel.pwob.validation;

public interface Patterns {
	String ALPHANUMERIC = "\\.\\'\\-\\d\\sA-Za-z";
	String FRALPHANUMERIC = "\\.\\'\\-\\d\\’\\`\\sA-Za-zÀ-Ÿà-ÿ";
}
