package com.bmo.channel.pwob.convert.migration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.bmo.channel.core.event.EventManager;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.FeatureFlags;

@Component
@Order(value=4)
public class R7DataMigrator implements ApplicationMigrator {
	@Autowired
	private EventManager eventManager;

	@Override
	public void migrateApplication(Application application, FeatureFlags featureFlags) {
		application.setRelease(Application.RELEASE_VERSION_7);
	}

	@Override
	public boolean isMigrationRequired(Application application, FeatureFlags featureFlags) {
		String release = application.getRelease();
		if(isReleaseDifferent(release)) {
			eventManager.publishWarn(String.format("Migrating application %s because release version is %s", application.getApplicationId(), release));
			return true;
		} else {
			return false;
		}
	}

	private boolean isReleaseDifferent(String release) {
		//return !Application.RELEASE_VERSION_7.equals(release);
		
		try {
			Integer iRel = Integer.valueOf(release);
			return iRel <= 6;
		} catch(NumberFormatException ex) {
			return true;
		}
	}
}
