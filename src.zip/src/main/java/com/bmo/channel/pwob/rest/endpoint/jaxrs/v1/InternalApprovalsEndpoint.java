package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.ia.Approval;
import com.bmo.channel.pwob.model.ia.BMApproval;
import com.bmo.channel.pwob.model.ia.IAApproval;
import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.service.ia.InternalApprovalsService;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.ValidationManager.IdType;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(InternalApprovalsEndpoint.V1_SUBPATH)
@Path(WorkflowsEndpoint.V1_PATH)
public class InternalApprovalsEndpoint {

	public static final String V1_SUBPATH = "/internal_approvals";
	public static final String ACCOUNT_SETUP = "/account_setup";
	public static final String IA_APPROVAL = "/ia_approval";
	public static final String BM_APPROVAL = "/bm_approval";
	public static final String APPROVED = "/approve";

	@Autowired
	private InternalApprovalsService iaService;
	
	@Autowired
	private ValidationManager validationManager;

	@PUT
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}" + V1_SUBPATH + IA_APPROVAL)
	@ApiOperation(value="Update Acount Setup", notes="Accounts field should not be manually populated. It is there for reference", response=RelationshipSummary.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response replaceInternalApprovalsAccountSetup(@NotNull RelationshipSummary relationshipSummary, 
			@ApiParam(value = "Application ID") @PathParam("id") String workflowId){
		
		this.validationManager.validateId(workflowId, IdType.Application);
		iaService.updateRelationshipSummary(relationshipSummary, workflowId);
		return Response.ok(relationshipSummary).build();
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}" + V1_SUBPATH + BM_APPROVAL)
	@ApiOperation(value="Add new IA Approval to an application", notes="Response is just the original payload", response=IAApproval.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response newIAApproval(@NotNull IAApproval newIA, @PathParam("id") String workflowId){		
		this.validationManager.validateId(workflowId, IdType.Application);
		this.validationManager.validateModel(newIA,Action.SUBMIT);
		IAApproval response = iaService.addNewIAApproval(newIA, workflowId);
		return Response.ok(response).build();
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}" + V1_SUBPATH + APPROVED)
	@ApiOperation(value="Add new BM Approval to an application", notes="Response is just the original payload", response=BMApproval.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response approveBMApproval(@NotNull BMApproval newBM, @ApiParam(value = "Application ID") @PathParam("id") String workflowId){
		
		this.validationManager.validateId(workflowId, IdType.Application);	
		this.validationManager.validateModel(newBM,Action.SUBMIT);
		BMApproval response = iaService.addNewBMApproval(newBM, workflowId);
		return Response.ok(response).build();
	}
	
	@GET
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}" + V1_SUBPATH + ACCOUNT_SETUP)
	@ApiOperation(value="Get Account Setup info", 
	notes="The response will be a skeleton AccountSetup with references to the applications accounts for necessary data", response=RelationshipSummary.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response getIApprovalsRelationshipSummary(@ApiParam(value = "Application ID") @PathParam("id") String workflowId){	
		
		this.validationManager.validateId(workflowId, IdType.Application);
		RelationshipSummary setup = iaService.getInitialRelationshipSummary(workflowId);
		return Response.ok(setup).build();
	}
	
	@GET
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}" + V1_SUBPATH + IA_APPROVAL)
	@ApiOperation(value="Get the current IA Approvals", notes="List of previous comments, and of relevant IAs whose approval is required", response=Approval.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response iaApprovals(@ApiParam(value = "Application ID") @PathParam("id") String workflowId){
		
		this.validationManager.validateId(workflowId, IdType.Application);
		Approval response =iaService.getIAApprovals(workflowId);
		return Response.ok(response).build();
	}
	
	@GET
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}" + V1_SUBPATH + BM_APPROVAL)
	@ApiOperation(value="Get the current BM Approvals", notes="List of previous comments, and of relevant BMs whose approval is required", response=Approval.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response bmApprovals(@ApiParam(value = "Application ID") @PathParam("id") String workflowId){
		
		this.validationManager.validateId(workflowId, IdType.Application);
		Approval response = iaService.getBMApprovals(workflowId);
		return Response.ok(response).build();
	}
}
