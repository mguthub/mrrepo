package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.service.risprefill.RisPrefillService;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.ValidationManager.IdType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(RisPrefillEndpoint.V1_PATH)
@Path(RisPrefillEndpoint.V1_PATH)
public class RisPrefillEndpoint {
	public static final String V1_PATH = "v1/ris_search";
	
	@Autowired
	RisPrefillService risPrefillService;
	
	@Autowired
	protected ValidationManager validationManager;
	
	
	@GET
	@Path("/{accountNumber}")
	@ApiOperation(value="Search RIS for applicant using accountNumber", response=NewWorkflowRequest.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name="iv-user", value="ISAM injected header to identify users", dataType="string", paramType="header"),
		@ApiImplicitParam(name="iv-groups", value="ISAM injected header for user's AD group", dataType="string", paramType="header")})
	@ApiResponses(value={
			@ApiResponse(code=200, message="Success"),
			@ApiResponse(code=404, message="Not found")})
	public Response searchApplicantInRis(@ApiParam(value = "Client account number") @PathParam("accountNumber") @NotEmpty String accountNumber)
	{
		validationManager.validateId(accountNumber, IdType.AccountNumber);
		NewWorkflowRequest response = risPrefillService.searchForParty(accountNumber);	
		return Response.ok(response).build();
	}
}
