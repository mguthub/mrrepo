/**
 * @author Sasi Nagamony (snagamo)
 */
package com.bmo.channel.pwob.model.onboarding;

import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;

import io.swagger.annotations.ApiModelProperty;

public class Guarantee {
	
	@ApiModelProperty(value="Reference Id from guarantees")
	@DataValidationPattern(code = ErrorCodes.INVALID_GUARANTEE_REF_MAPPING)
	private String guaranteeRefId;
	
	@ApiModelProperty(example="11211220")
	@DataValidationPattern(code = ErrorCodes.INVALID_GUARANTEE_ACCOUNT_NUMBER)
	private String guaranteeAccountNumber;
	
	@DataValidationPattern(code=ErrorCodes.INVALID_GUARANTEE_RELATIONSHIP)
	private String relationship;

	public String getGuaranteeRefId() {
		return guaranteeRefId;
	}

	public void setGuaranteeRefId(String guaranteeRefId) {
		this.guaranteeRefId = guaranteeRefId;
	}

	public String getGuaranteeAccountNumber() {
		return guaranteeAccountNumber;
	}

	public void setGuaranteeAccountNumber(String guaranteeAccountNumber) {
		this.guaranteeAccountNumber = guaranteeAccountNumber;
	}

	public String getRelationship() {
		return relationship;
	}

	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}
			
}