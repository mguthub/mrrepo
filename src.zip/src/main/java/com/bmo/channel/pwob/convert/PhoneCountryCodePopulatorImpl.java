package com.bmo.channel.pwob.convert;

import org.springframework.stereotype.Component;

import com.bmo.channel.pwob.model.onboarding.Application;

@Component
public class PhoneCountryCodePopulatorImpl implements PhoneCountryCodePopulator {
	/**
	 * Prior to BETCH rules, this value was hard-coded for all country codes
	 */
	static final String COUNTRY_CODE = "001";

	@Override
	public void populate(Application application) {
		application.getParties().stream().forEach(new PartyPhoneCountryCodeConsumer());
	}
}
