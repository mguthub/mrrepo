package com.bmo.channel.pwob.model.reference;

public class OccupationReference extends Reference {
	private boolean isPoliticallyExposedOccupation;

	public OccupationReference(Reference reference) {
		this.setLabel(reference.getLabel());
		this.setCode(reference.getCode());
	}

	public boolean isPoliticallyExposedOccupation() {
		return isPoliticallyExposedOccupation;
	}

	public void setPoliticallyExposedOccupation(boolean isPoliticallyExposedOccupation) {
		this.isPoliticallyExposedOccupation = isPoliticallyExposedOccupation;
	}
}
