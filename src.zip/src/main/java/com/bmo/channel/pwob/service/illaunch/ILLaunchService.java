package com.bmo.channel.pwob.service.illaunch;

public interface ILLaunchService {

	String redirectToOlap(String formData);

	String parseAndRedirectToApp(String formData);

	boolean isOlapOnly(String formData);

}
