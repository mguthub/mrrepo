/**
 * @author akhales
 */
package com.bmo.channel.pwob.convert;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.mapping.DataMapper;
import com.bmo.channel.pwob.convert.features.DataMigrator;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.AppStatus;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.MultiApplicantsInvestmentExperience;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.RegulatoryDisclosures;
import com.bmo.channel.pwob.model.onboarding.Relationship;
import com.google.common.base.Strings;

import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.AccountInformation;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.ApplicationData;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.EftDetails;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.Metadata;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RelationshipSummary;
import net.bmogc.xmlns.hub.cg.pwob.pwobservice.types.v1.RifPaymentDetails;

@Service
public class ConvertorServiceImpl implements ConvertorService {
	
	@SuppressWarnings("unused")
	private static Logger logger = LoggerFactory.getLogger(ConvertorService.class);

	private final static String COLON = ":";	

	private static final String CANADA_CURRENCY_CODE = "CAD";


	@Autowired
	private DataMapper mapper;

	@Autowired
	private DataMigrator dataMigrator;

	@Autowired
	private PhoneCountryCodePopulator phoneCountryCodePopulator;

	@Override
	public ApplicationData getApplicationData(Application application) {
		if(Optional.ofNullable(application).isPresent()) {
			dataMigrator.migrateApplication(application);
			//phoneCountryCodePopulator.populate(application);

			if(application.getParties() != null){
				for(Party party: application.getParties()) {
					this.populateTradingSymbolWithCountry(party.getRegulatoryDisclosures());
				}
			}			
			ApplicationData applicationInformation = mapper.map(application, ApplicationData.class);
			this.mapJointAccountWithMultiApplicantInvestmentExperince(this.getJointAccounts(applicationInformation.getAccounts()),application.getMultiApplicantsInvestmentExperiences());
			
			this.populateAccountInformation(applicationInformation.getAccounts());
			this.setOnboardAppClientMetadata(applicationInformation.getClientMetadata(), application);

			if(application.getParties() != null){
				for(Party party: application.getParties()) {
					this.splitCountryFromTradingSymbol(party.getRegulatoryDisclosures());
				}
			}

			denormalizeRifEft(applicationInformation.getAccounts());
			return applicationInformation;
		} else {
			return null;
		}
	}
	

	
	List<AccountInformation> getJointAccounts(List<AccountInformation> accounts) {
		if(CollectionUtils.isEmpty(accounts)) {
			return Collections.emptyList();
		}
		List<AccountInformation> jointAccounts = accounts.stream()
				  				.filter(p -> p.getAccountType().contains(Account.JOINT_TYPE))
				  				.collect(Collectors.toList());
				  				
		if(CollectionUtils.isNotEmpty(jointAccounts)) {
			return jointAccounts;
		} else {
			return Collections.emptyList();
		}
	}

	void mapJointAccountWithMultiApplicantInvestmentExperince(List<AccountInformation> jointAccounts,List<MultiApplicantsInvestmentExperience> multiApplicantInvExps) {
		if(jointAccounts != null && CollectionUtils.isNotEmpty(jointAccounts) && multiApplicantInvExps != null && CollectionUtils.isNotEmpty(multiApplicantInvExps)){
			for(AccountInformation jointAccount: jointAccounts){
				if(jointAccount.getJointApplicantPartyRefIds() != null && CollectionUtils.isNotEmpty(jointAccount.getJointApplicantPartyRefIds())){
					List<String> jointApplicantsRefIds = new ArrayList<String>(jointAccount.getJointApplicantPartyRefIds());
					if(jointApplicantsRefIds != null && jointApplicantsRefIds.size() > 0){
						jointApplicantsRefIds.add(jointAccount.getPrimaryApplicantPartyRefId());
						
						for(MultiApplicantsInvestmentExperience exp: multiApplicantInvExps){							
							List<String> expPartyRefIds = new ArrayList<String>(exp.getPartyRefIds());
							if (CollectionUtils.isEqualCollection(expPartyRefIds, jointApplicantsRefIds)) {
								if(!Strings.isNullOrEmpty(exp.getInvExpRefId())){
									jointAccount.setInvExpRefId(exp.getInvExpRefId());
								}
								break;
							}
						}
						
					}
				}					
			}
			
		}
	}
	
	void denormalizeRifEft(List<AccountInformation> list) {
		list.stream().filter(a -> isRifPaymentSpecified(a)).forEach(a -> {
			RifPaymentDetails rifPayment = a.getRifPayment();
			if(areEftDetailsSpecified(a, rifPayment)) {
				EftDetails outboundEftDetails = a.getOutboundEftDetails();
				outboundEftDetails.setAmount(rifPayment.getAmount() != null ? rifPayment.getAmount().toString() : null);
				outboundEftDetails.setFrequency(rifPayment.getFrequency());
			}
		});
	}

	private boolean areEftDetailsSpecified(AccountInformation accountInformation, RifPaymentDetails rifPayment) {
		return com.bmo.channel.pwob.model.onboarding.RifPaymentDetails.METHOD_EFT.equals(rifPayment.getMethod()) && 
				accountInformation.getOutboundEftDetails() != null;
	}

	private boolean isRifPaymentSpecified(AccountInformation accountInformation) {
		return Account.RIF_TYPE.equals(accountInformation.getAccountType()) && accountInformation.getRifPayment() != null;
	}

	private void populateAccountInformation(List<AccountInformation> appInfoAccounts) {
		List<AccountInformation> spousalAccts = this.getSpousalRspAccounts(appInfoAccounts);
		List<AccountInformation> rifAccts = this.getRifAccounts(appInfoAccounts);
		
		this.populateHasContributorFlag(spousalAccts);
		this.populateRifEftCurrencyCode(rifAccts);
	}

	void populateRifEftCurrencyCode(List<AccountInformation> rifAccts) {
		for(AccountInformation appInfo: rifAccts){
			if(appInfo.getRifPayment() != null && appInfo.getOutboundEftDetails() != null && appInfo.getRifPayment().getMethod() != null &&
					appInfo.getRifPayment().getMethod().equalsIgnoreCase(com.bmo.channel.pwob.model.onboarding.RifPaymentDetails.METHOD_EFT)){
				appInfo.getOutboundEftDetails().setCurrencyCode(CANADA_CURRENCY_CODE);
			}
		}
	}

	private void populateHasContributorFlag(List<AccountInformation> appInfoAccounts) {
		for(AccountInformation appInfo: appInfoAccounts){
			appInfo.setHasContributer(appInfo.getContributor() != null);
		}
	}

	@Override
	public Application getOnboardApplicationData(String workflowId, ApplicationData applicationInfo, String appStatus) {

		Application application = mapper.map(applicationInfo, Application.class);
		application.setApplicationId(workflowId);
		this.setOnboardApplicationMetadata(applicationInfo.getClientMetadata(), application);
		if(application.getParties() != null) {
			for(Party party: application.getParties()) {
				this.splitCountryFromTradingSymbol(party.getRegulatoryDisclosures());
			}
		}
		if(AppStatus.DATA_COLLECTION.toString().equals(appStatus)) {
			dataMigrator.migrateApplication(application);
		}
		return application;
	}

	List<AccountInformation> getSpousalRspAccounts(List<AccountInformation> accounts) {

		return accounts.stream()
				.filter(t -> Optional.ofNullable(t.getAccountType()).isPresent()
						&& t.getAccountType().equalsIgnoreCase(Account.RSP_TYPE)
						&& Optional.ofNullable(t.isIsSpousal()).isPresent() && t.isIsSpousal())
				.collect(Collectors.toList());		
	}
	
	List<AccountInformation> getRspAccounts(List<AccountInformation> accounts) {
		
		return accounts.stream()				
					   .filter(t -> t.getAccountType() != null)
					   .filter(t -> t.getAccountType().equalsIgnoreCase(Account.RSP_TYPE))
					   .collect(Collectors.toList());
	}
	
	List<AccountInformation> getRifAccounts(List<AccountInformation> accounts) {
		
		return accounts.stream()				
					   .filter(t -> t.getAccountType() != null)
					   .filter(t -> t.getAccountType().equalsIgnoreCase(Account.RIF_TYPE))
					   .collect(Collectors.toList());
	}	

	void splitCountryFromTradingSymbol(RegulatoryDisclosures disclosure) {
		if(Optional.ofNullable(disclosure).isPresent()) {
			if(CollectionUtils.isNotEmpty(disclosure.getControlRelationships())) {
				for(Relationship rel : disclosure.getControlRelationships()) {
					this.removeCountryFromTradingSymbol(rel);																
				}						
			}

			if(CollectionUtils.isNotEmpty(disclosure.getInsiderRelationships())) {
				for(Relationship rel : disclosure.getInsiderRelationships()) {
					this.removeCountryFromTradingSymbol(rel);								
				}						
			}
			if(CollectionUtils.isNotEmpty(disclosure.getReportingInsiderRelationships())) {
				for(Relationship rel : disclosure.getReportingInsiderRelationships()) {
					this.removeCountryFromTradingSymbol(rel);								
				}						
			}

			if(CollectionUtils.isNotEmpty(disclosure.getSignificantShareholdings())) {
				for(Relationship rel : disclosure.getSignificantShareholdings()) {
					this.removeCountryFromTradingSymbol(rel);
				}							
			}
		}
	}

	private void removeCountryFromTradingSymbol(Relationship rel) {
		if(Optional.ofNullable(rel.getCompanyTradingSymbol()).isPresent() && rel.getCompanyTradingSymbol().contains(COLON)) {	
			String[] strList = rel.getCompanyTradingSymbol().split(COLON);
			rel.setCompanyTradingSymbol(strList[0]);	
			rel.setCountry(strList[1]);	
		}
	}

	void setOnboardAppClientMetadata(List<Metadata> metadata, Application application) {
		if(application.getClientMetadata() != null) {
			Map<String,String> map = application.getClientMetadata();
			if(!map.isEmpty()){
				for(Map.Entry<String, String> entry: map.entrySet()){
					Metadata meta = new Metadata();
					meta.setKey(entry.getKey());
					meta.setValue(entry.getValue());
					metadata.add(meta);
				}
			}
		}
	}

	void setOnboardApplicationMetadata(List<Metadata> metadata, Application application) {
		final Map<String,String> wfMetadata = new HashMap<>();
		for(Metadata entry: metadata){
			wfMetadata.put(entry.getKey(), entry.getValue());
		}
		application.setClientMetadata(wfMetadata);
	}

	@Override
	public RelationshipSummary convertRelationshipSummary(com.bmo.channel.pwob.model.ia.RelationshipSummary summary) {
		if(Optional.ofNullable(summary).isPresent()) {
			RelationshipSummary hubSummary = mapper.map(summary, RelationshipSummary.class);
			return hubSummary;	
		}

		return null;
	}
	
	@Override
	public com.bmo.channel.pwob.model.ia.RelationshipSummary convertHubRelationshipSummary(RelationshipSummary hubSummary, Application application) {
		if(Optional.ofNullable(hubSummary).isPresent()) {
			com.bmo.channel.pwob.model.ia.RelationshipSummary summary = mapper.map(hubSummary, com.bmo.channel.pwob.model.ia.RelationshipSummary.class);
			dataMigrator.migrationRelationshipSummary(summary, application);
			return summary;
		}	
		return null;
	}

	void populateTradingSymbolWithCountry(RegulatoryDisclosures workflowRegDisclosure) {
		if(Optional.ofNullable(workflowRegDisclosure).isPresent()) {
			if(CollectionUtils.isNotEmpty(workflowRegDisclosure.getControlRelationships())) {
				for(Relationship rel : workflowRegDisclosure.getControlRelationships()) {
					this.concatTradingSymbolCountry(rel);											
				}						
			}
	
			if(CollectionUtils.isNotEmpty(workflowRegDisclosure.getInsiderRelationships())) {
				for(Relationship rel : workflowRegDisclosure.getInsiderRelationships()) {
					this.concatTradingSymbolCountry(rel);	
				}						
			}
	
			if(CollectionUtils.isNotEmpty(workflowRegDisclosure.getReportingInsiderRelationships())) {
				for(Relationship rel : workflowRegDisclosure.getReportingInsiderRelationships()) {
					this.concatTradingSymbolCountry(rel);	
				}						
			}
			
			if(CollectionUtils.isNotEmpty(workflowRegDisclosure.getSignificantShareholdings())) {
				for(Relationship rel : workflowRegDisclosure.getSignificantShareholdings()) {
					this.concatTradingSymbolCountry(rel);	
				}						
			}		
		}
	}
	
	private void concatTradingSymbolCountry(Relationship rel) {
		if(Optional.ofNullable(rel.getCompanyTradingSymbol()).isPresent() && Optional.ofNullable(rel.getCountry()).isPresent()
				&& !rel.getCompanyTradingSymbol().contains(COLON)) {
			rel.setCompanyTradingSymbol(rel.getCompanyTradingSymbol().concat(COLON).concat(rel.getCountry()));	
		}
	}

}
