package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Branch;
import com.bmo.channel.pwob.model.onboarding.BranchResponse;
import com.bmo.channel.pwob.model.onboarding.BranchesResponse;
import com.bmo.channel.pwob.model.onboarding.FinancialInstitution;
import com.bmo.channel.pwob.model.onboarding.FinancialInstitutionsResponse;
import com.bmo.channel.pwob.service.fis.FinancialInstitutionsService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(FinancialInstitutionsEndpoint.V1_PATH)
@Path(FinancialInstitutionsEndpoint.V1_PATH)
public class FinancialInstitutionsEndpoint {
	public static final String V1_PATH = "v1/financial_institutions";
	public static final String V1_BRANCHES_SUBPATH = "/branches";

	@Autowired
	FinancialInstitutionsService financialInstitutionsService;

	@GET
	@Path("/")
	@ApiOperation(value="Get corresponding financial institutions", response=FinancialInstitutionsResponse.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name="iv-user", value="ISAM injected header to identify users", dataType="string", paramType="header"),
		@ApiImplicitParam(name="iv-groups", value="ISAM injected header for user's AD group", dataType="string", paramType="header")})
	@ApiResponses(value={@ApiResponse(code=200, message="Success")})
	public Response getFIsByPartialID(@ApiParam(value="Partial financial institution ID (e.g. '1')") @QueryParam("partialId") @NotEmpty String partialId,
                                      @ApiParam(value="Language code", allowableValues="en-ca, fr-ca", required=true) @QueryParam("lang") String lang)
	{
		List<FinancialInstitution> financialInstitutions = financialInstitutionsService.retrieveFinancialInstitutionsByPartialId(partialId, lang);
		FinancialInstitutionsResponse response = new FinancialInstitutionsResponse(financialInstitutions);
		
		return Response.ok(response).build();
	}
	
	@GET
	@Path("/{fiId}/branches/{transitId}")
	@ApiOperation(value="Get bank branch information", response=BranchResponse.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name="iv-user", value="ISAM injected header to identify users", dataType = "string", paramType="header"),
		@ApiImplicitParam(name="iv-groups", value="ISAM injected header for user's AD group", dataType = "string", paramType="header")})
	@ApiResponses(value={
		@ApiResponse(code=200, message="Success"),
		@ApiResponse(code=404, message="Not found")})
	public Response getBranchByExplicitID(@ApiParam(value = "Financial institution ID (e.g. '001')") @PathParam("fiId") @NotEmpty String fiId,
			                              @ApiParam(value = "Transit ID (e.g. '017110')") @PathParam("transitId") @NotEmpty String transitId,
			                              @ApiParam(value="Language code", allowableValues="en-ca, fr-ca", required=true) @QueryParam("lang") String lang)
	{
		Branch branch = financialInstitutionsService.retrieveBankBranchInformationByFiIdAndTransitId(fiId, transitId, lang);
		BranchResponse response = new BranchResponse(branch);
		
		return Response.ok(response).build();
	}
	
	@GET
	@Path("/{fiId}/branches")
	@ApiOperation(value="Get information on corresponding bank branches", response=BranchesResponse.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name="iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header"),
		@ApiImplicitParam(name="iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
		@ApiResponse(code=200, message="Success")})
	public Response getFIByExplicitID(@ApiParam(value="Financial institution ID (e.g. '001')") @PathParam("fiId") @NotEmpty String fiId,
                                      @ApiParam(value="Partial transit ID (e.g. '017')", required=true) @QueryParam("partialId") @NotEmpty String partialId,
                                      @ApiParam(value="Language code", allowableValues="en-ca, fr-ca", required=true) @QueryParam("lang") String lang)
	{
		List<Branch> branches = financialInstitutionsService.retrieveBankBranchesInformationByFiIdAndPartialTransitId(fiId, partialId, lang);
		BranchesResponse response = new BranchesResponse(branches);
		
		return Response.ok(response).build();
	}
}
