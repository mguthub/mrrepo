/**
 * @author akhales
 */
package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import javax.validation.constraints.NotNull;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.xml.ws.WebServiceException;

import org.hibernate.validator.constraints.NotEmpty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.core.exception.UnauthorizedSecurityException;
import com.bmo.channel.pwob.exception.ConstraintViolationExceptionHandler;
import com.bmo.channel.pwob.exception.ValidationErrorResponse;
import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.NextStepsData;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.product.BilProducts;
import com.bmo.channel.pwob.model.product.Products;
import com.bmo.channel.pwob.service.product.ProductService;
import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.service.reference.ReferencesService;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.service.workflow.WorkflowService;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.user.UserContextImpl;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.ValidationManager.IdType;
import com.bmo.channel.workflows.parties.service.PartiesService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@Produces({MediaType.APPLICATION_JSON + ";charset=utf-8"})
@Api(WorkflowsEndpoint.V1_PATH)
@Path(WorkflowsEndpoint.V1_PATH)
public class WorkflowsEndpoint {

	private Logger logger = LoggerFactory.getLogger(WorkflowsEndpoint.class);

	public static final String V1_PATH = "v1/workflows";
	public static final String INVALID_FIELDS_SUBPATH = "/invalid_fields"; 
	public static final String NOT_FOUND = "NOT_FOUND";
		
	@Autowired
	private WorkflowService workflowService;

	@Autowired
	private ConstraintViolationExceptionHandler constraintViolationExceptionHandler;

	@Autowired
	private ProductService productService;
	
	@Autowired
	private PartiesService partiesService;
	
	@Autowired
	protected ValidationManager validationManager;
	
	@Autowired
	protected UsersService usersService;

	@Autowired

	private ReferencesService referencesService;
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Path("/{id}/product_eligibilities")
    @ApiOperation(value="Get product eligibilities for a provided workflow", response=Products.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
    @ApiResponses(value={
            @ApiResponse(code=500, message="Internal server error"), 
            @ApiResponse(code=401, message="User cannot be identified"),
            @ApiResponse(code=400, message="Bad request"),
            @ApiResponse(code=404, message="Application Not found")})
    public Response productEligibilities(@NotNull Application application, @ApiParam(value = "Application ID") @PathParam("id") String id) {        

		
		 //Test
        this.validationManager.validateId(id, IdType.Application);
        application.setApplicationId(id);
        Products response = productService.determineProductEligibilities(application);
        return Response.ok(response).build();
    }
	
	
	@POST
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Path("/{id}/product_eligibilities/{partyId}")
    @ApiOperation(value="Get product eligibilities for a provided party", response=Products.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
    @ApiResponses(value={
            @ApiResponse(code=500, message="Internal server error"), 
            @ApiResponse(code=401, message="User cannot be identified"),
            @ApiResponse(code=400, message="Bad request"),
            @ApiResponse(code=404, message="Application Not found")})
    public Response productEligibilities(@NotNull Party party, @ApiParam(value = "Application ID") @PathParam("id") String id, @ApiParam(value = "Party ID") @PathParam("partyId") String partyId) {        

        this.validationManager.validateId(id, IdType.Application);
        Products response = productService.determineProductEligibilities(id, party);
        return Response.ok(response).build();
    }

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{id}")
	@ApiOperation(value="Get workflow data", response=Application.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Application getWorkflowData(@ApiParam(value = "Application ID") @PathParam("id") @NotEmpty String workflowId) {
		
		this.validationManager.validateId(workflowId, IdType.Application);	
		return workflowService.retrieveApplication(workflowId);
	}
	

	//bil retrieve application for next steps
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/retrieveApplication")
	@ApiOperation(value="Get next steps data for BIL", response=Application.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "workflow_id", value = "ISAM injected header to identify associated workflow id", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "am-eai-ext-user-id", value = "ISAM injected header for user id", dataType = "string",paramType = "header"),
		@ApiImplicitParam(name = "x_bmo_business_category", value = "ISAM injected header to identify LOB", dataType = "string",paramType = "header"),
		@ApiImplicitParam(name = "x_bmo_sso_id", value = "ISAM injected header for sso id", dataType = "string",paramType = "header")})
		
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public NextStepsData retrieveApplicationData(@Context HttpServletRequest httpRequest) {

		// validate headers
		if (Optional.ofNullable(httpRequest.getHeader(UserContext.WORKFLOW_ID)).isPresent()) {
			String workflowId = httpRequest.getHeader(UserContext.WORKFLOW_ID);
			this.validationManager.validateId(workflowId, IdType.Application);		
			return workflowService.retrieveNextStepsData(workflowId);
		} else
			throw new UnauthorizedSecurityException("invalid workflow_id " + httpRequest.getHeader(UserContext.WORKFLOW_ID));
	}
	

	@POST
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@ApiOperation(value="Create a new application", notes="", response=Application.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request")})
	public Response create(NewWorkflowRequest request) {
		
		Application workflow = workflowService.saveApplication(request);
		URI location = createURI(V1_PATH + "/" + workflow.getApplicationId());
		return Response.created(location).entity(workflow).build();
	}	
		
	//BIL changes	
	@POST
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/save")
	@ApiOperation(value="Create a new bil application", notes="", response=Application.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request")})
	public Response createBilApp(@NotNull Application application, @Context HttpServletRequest httpRequest) throws InterruptedException{		
		Application workflow;
		//Call reference service to get required data for local testing

		String lang = "en-ca";

		UILocale locale = UILocale.parse(lang);
		List<String> types = new ArrayList<>();
		types.add("accountUses");
		types.add("linkAccountTypes");
		types.add("bmoClientRelationshipType");

		Set<ReferenceType> referenceTypes = types.stream().map(this::parseReferenceType).collect(Collectors.toSet());
		referencesService.ofTypes(referenceTypes, locale);

		//validate headers
		if(Optional.ofNullable(httpRequest.getHeader(UserContext.WORKFLOW_ID)).isPresent() && !NOT_FOUND.equalsIgnoreCase(httpRequest.getHeader(UserContext.WORKFLOW_ID))) {
			String wcid = httpRequest.getHeader(UserContextImpl.WORKFLOW_ID);
			String user = httpRequest.getHeader(UserContextImpl.IV_USER_HEADER);
			workflow = workflowService.updateBilApplication(application, user, wcid);			
		}else {
			//initialize, create new application
			 workflow = workflowService.createBilApplication(application);
		}					

		return Response.ok(workflow).build();
	}
	
	ReferenceType parseReferenceType(String type) {
		return Arrays.asList(ReferenceType.values()).stream().filter(refType -> refType.toString().equals(type)).findFirst().get();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/parties/{ecifId}")
	@ApiOperation(value="Retrieve personal information", notes="Gets information about an existing client in the parties database", response=PersonalInformation.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=404, message="Application Not found")})
	
	public Response getParty(@ApiParam(value = "Ecif ID") @PathParam("ecifId") String ecifId){	
		
		this.validationManager.validateId(ecifId, IdType.Party);
		Party response = partiesService.getParty(ecifId);
		return Response.ok(response).build();
		 
	}

	@PUT
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}")
	@ApiOperation(value="Update Application", notes="After updating, data validation errors will appear in the reponse body, and must be resolved before proceeding to the next step", response=Application.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response replace(@NotNull Application application, @ApiParam(value = "Application ID") @PathParam("id") String applicationId) { 
		this.validationManager.validateId(applicationId, IdType.Application);
		application.setApplicationId(applicationId);
		Application updatedApplication = workflowService.updateApplication(application);
		return Response.ok(updatedApplication).build();
	}

	@DELETE
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}")
	@ApiOperation(value="Delete existing application")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response delete(@ApiParam(value = "Application ID") @PathParam("id") String workflowId) { 
		
		this.validationManager.validateId(workflowId, IdType.Application);
		workflowService.delete(workflowId);
		return Response.ok().build();
	}
	
	/**
	 * Validates a given workflow.
	 * Returns a format that is convenient for the PWOB Angular app to process, which is 
	 * why the standard validation deserialization is not used.
	 */
	@POST
	@Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
	@Path("/{id}" + INVALID_FIELDS_SUBPATH)
	@ApiOperation(value="Determine current data validation errors", 
		notes="Determines the validation errors that would arise if the application tried to advance to the next step in the workflow process",
		response=ValidationErrorResponse.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "iv-groups", value = "ISAM injected header for user's AD group", dataType = "string",paramType = "header")})
	@ApiResponses(value={
			@ApiResponse(code=500, message="Internal server error"), 
			@ApiResponse(code=409, message="Invalid application status for operation"),
			@ApiResponse(code=401, message="User cannot be identified"),
			@ApiResponse(code=403, message="User does not have permission to perform action"),
			@ApiResponse(code=400, message="Bad request"),
			@ApiResponse(code=404, message="Application Not found")})
	public Response invalidFields(@NotNull Application application, @ApiParam(value = "Application ID") @PathParam("id") String applicationId) {
		this.validationManager.validateId(applicationId, IdType.Application);

		try {
			application.setApplicationId(applicationId);
			workflowService.validate(application);
			return Response.ok().build();
		} catch(ConstraintViolationException cvx) {
			logger.warn("Application Validation Failure for application id: ",applicationId, cvx);
			ValidationErrorResponse createValidationErrorResponse = constraintViolationExceptionHandler.createValidationErrorResponse(cvx);
			return constraintViolationExceptionHandler.buildResponse(createValidationErrorResponse, Status.OK);
		}
	}

	private URI createURI(String path) {
		try {
			return new URI(path);
		} catch (URISyntaxException ex) {
			logger.error("Path could not be parsed as URI reference.",path,ex);
			throw new WebServiceException(ex);
		}
	}
	
	
	@GET
    @Consumes(MediaType.APPLICATION_JSON + ";charset=utf-8")
    @Path("/product_eligibilities")
    @ApiOperation(value="Get product eligibilities for BIL lob", response=Products.class)
	@ApiImplicitParams({
		@ApiImplicitParam(name = "iv-user", value = "ISAM injected header to identify users", dataType = "string",paramType = "header") ,
		@ApiImplicitParam(name = "x_bmo_business_category", value = "ISAM injected header for business category", dataType = "string",paramType = "header")})
    @ApiResponses(value={
            @ApiResponse(code=500, message="Internal server error"), 
            @ApiResponse(code=401, message="User cannot be identified"),
            @ApiResponse(code=400, message="Bad request"),
            @ApiResponse(code=404, message="Application Not found")})
    public Response productEligibilities() {
		
		BilProducts response = productService.getEligibleBilProducts();
        return Response.ok(response.getbilProduct()).build();
        
    }
	
	
	
}
