package com.bmo.channel.pwob.model.risprefill;

import java.io.Serializable;;

public class TestModel implements Serializable{
	private static final long serialVersionUID = 5804364163116980314L;
	private String firstName;
	private String lastName;
	private String mapDob;
	
	public TestModel() {
		this.firstName = "John";
		this.lastName = "Smith";
		this.mapDob = "1977-01-01";
	}
	public String getMapDob() {
		return mapDob;
	}
	public void setMapDob(String mapDob) {
		this.mapDob = mapDob;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
}
