package com.bmo.channel.pwob.service.accounts;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.channel.pwob.util.HubRequestHeaderBuilder.HeaderBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;

import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

@Service
public class AccountNumbersServiceImpl implements AccountNumbersService{

	private static Logger logger = LoggerFactory.getLogger(AccountNumbersServiceImpl.class);
	
	@Resource
	private WMTValidateAccountEndpointInterface wmtValidateAccountEndpointInterface;
	
	@Autowired
	private HubRequestComponent hubRequestComponent;
	
	@Autowired
	private UsersService usersService;

	@Override
	public ValidateAccountResponse validateAccount(String accountNumber,String iaCode, String rule) {
		ValidateAccountRequest request= new ValidateAccountRequest();
		ValidateAccountRequestBody validateAccountRequestBody= new ValidateAccountRequestBody();
		String hubHeader="";
		ValidateAccountResponse validateAccountResponse=new ValidateAccountResponse();
		ValidateAccountHUBResponse hubResponse=null;
		
		try {
			validateAccountRequestBody.setAccountId(accountNumber);
			validateAccountRequestBody.setInvestmentAdvisorCode(iaCode);
			validateAccountRequestBody.setNetworkId(usersService.currentUser().getNetworkId());	
			List<String> ruleList= new ArrayList<String>();
			ruleList.add(rule);
			Map<String,List<String>> ruleListMap = new HashMap<String,List<String>>();
			ruleListMap.put("rule", ruleList);
			validateAccountRequestBody.setRuleList(ruleListMap);
			request.setValidateAccountRequestBody(validateAccountRequestBody);
			final HUBHeaderRequest requestHeader = createRequestHeader("validateAccount", "WMTAccountEndpoint", accountNumber,null,null,null);
			hubHeader = generateHeaderString(requestHeader);
			hubResponse=wmtValidateAccountEndpointInterface.validateAccount(request, hubHeader);
			if(hubResponse!=null)
			{
				validateAccountResponse.setAccountId(hubResponse.getValidateAccountResponseBody().getAccountId());
				validateAccountResponse.setValidAccountNumber(hubResponse.getValidateAccountResponseBody().isIsValidAccountNumber());
				if(!hubResponse.getValidateAccountResponseBody().isIsValidAccountNumber()){
					logger.error("Account Number not found: "+accountNumber);
					throw new NotFoundException("Account Number is not found");
				}
			}
			else {
				logger.error("Hub error - Account number service response is null for account number: "+accountNumber);
				throw new WebServiceException("Account Number service response is null");
			}
			
		} catch (JsonProcessingException ex) {
			logger.error("Failure in JSON processing JSON during Account Validation. ", ex);
			throw new WebServiceException(ex);
		}
		return validateAccountResponse;
	}
	
	
	private HUBHeaderRequest createRequestHeader(final String service, final String resourceFunction, final String workflowId, String packageId, String documentId, String ecifId) {
		HeaderBuilder headerBuilder = hubRequestComponent.getHubBuilder()
			.originatorResource(service)
			.originatorResourceFunction(resourceFunction)
			.workflowId(workflowId)
			.packageId(packageId)
			.documentId(documentId)
			.partyId(ecifId);
		final HUBHeaderRequest requestHeader = headerBuilder.build();
		
		return requestHeader;
	}
	
	public String generateHeaderString(final HUBHeaderRequest requestHeader) throws JsonProcessingException {
		return ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
	}
}
