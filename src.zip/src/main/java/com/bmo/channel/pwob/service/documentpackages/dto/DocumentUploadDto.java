package com.bmo.channel.pwob.service.documentpackages.dto;

import java.util.List;

public class DocumentUploadDto {
	private List<String> content;
	
	public List<String> getContent() {
		return content;
	}

	public void setContent(List<String> content) {
		this.content = content;
	}
}
