package com.bmo.channel.pwob.validation.reference;

import java.util.HashSet;
import java.util.List;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintValidatorContext.ConstraintViolationBuilder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.service.reference.ReferencesService;
import com.bmo.channel.pwob.service.user.UsersService;

/**
 * Validate that field value belongs to list of reference data.
 * 
 * @author Ryan Chambers rcham02
 */
public class ReferenceListDataValidator implements ConstraintValidator<ReferenceListData, List<String>> {
	
	@Autowired
	ReferencesService referencesService;
	
	@Autowired 
	UsersService userService;
	
	private ReferenceType referenceDataType;
	private String code;

	@Override
	public void initialize(ReferenceListData constraint) {
		referenceDataType = constraint.type();
		code = constraint.code();
	}

	@Override
	public boolean isValid(List<String> value, ConstraintValidatorContext context) {
		List<Reference> referenceTypeList = referencesService.ofType(referenceDataType,UILocale.EN_CA);
		boolean validEntry = true;
		if (value != null) {
			for (String item : value) {
				if(StringUtils.isNotBlank(item)) {
					validEntry = isValidEntry(item, referenceTypeList);
					if (!validEntry) {
						context.disableDefaultConstraintViolation();
						ConstraintViolationBuilder builder = context.buildConstraintViolationWithTemplate(code);
						builder.addConstraintViolation();
						return validEntry;
					}
				}
			}

			if(hasDuplicates(value)) {
				context.disableDefaultConstraintViolation();
				ConstraintViolationBuilder builder = context.buildConstraintViolationWithTemplate(code);
				builder.addConstraintViolation();
				return false;
			}
		}
		return validEntry;
	}

	boolean hasDuplicates(List<String> value) {
		return new HashSet<>(value).size() != value.size();
	}

	boolean isValidEntry(String value, List<Reference> referenceTypeList) {
		return referenceTypeList.stream().anyMatch(r -> value.equals(r.getCode()));
	}
}
