
package com.bmo.channel.pwob.util;

public class Constants {
	public static final int ZERO = 0;
	public static final int ONE = 1;
	public static final int TWO = 2;
	public static final int THREE = 3;
	public static final int ELEVEN = 11;
	public static final int SIXTY = 60;
	
	/** Application. */
	public static final String WIS_SERVICE_NAME = "WIS";
	public static final String WIS_GET_WORKFLOW_FUNCTION = "GW";
	public static final String HOUR = "HOUR";
	public static final String DAY = "DAY";
	public static final String WORK_FLOW_ID_TYPE = "workflow";
	public static final String SPACE_STRING = " ";
	public static final String EMPTY_STRING = "";
	public static final String APPLICATION_PDF = "application/pdf";
	public static final String HEADER_DOCUMENT_EXTENSION = "Document-Extension";
	public static final String PDF_EXTENSION = "pdf";
	public static final String DOT = ".";
	
	public static final String LANGUAGE_CODE_100001 = "100001";
	public static final String FRENCH = "French";
	public static final String LANGUAGE_CODE_100 = "100";
	public static final String ENGLISH = "English";
	
	/** Lob. */
	public static final String NESBITT = "Nesbitt";
	public static final String INVESTOR_LINE = "InvestorLine";
	
	
	public static final String REQUEST_ID = "X-BMO-REQUEST-ID";
    
	public static final String VALID_ACCOUNT_TYPE_A = "A";
	public static final String VALID_ACCOUNT_TYPE_W = "W";
	
	/** BIL **/
	public static final String BIL_IA_CODE_PREFIX = "BIL\\";
	
	public static final String SAME_PRIMARY_APPLICANT_PRIMARY_ADDR="1";
	public static final String SAME_PRIMARY_APPLICANT_ALTERNATE_ADDR="2";
	public static final String OTHER_ADDR="3";
	
	public static final String BMO_SEARCH_STR="bmo";
	public static final String BANK_OF_MONTREAL_SEARCH_STR="bank of montreal";
	public static final String NESBITT_BURNS_SEARCH_STR="nesbitt burns";
	

	public static final String MIN_DOB="1850-01-01";

	/** Tax Residency **/
	public static final int MAX_TAX_RESIDENCY=4;

}
