package com.bmo.channel.pwob.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.core.TreeNode;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;

public abstract class ArrayOrObjectDeserializer<T> extends JsonDeserializer<List<T>> {
	private final Class<T> objectClass;
	
	protected ArrayOrObjectDeserializer(Class<T> objectClass) {
		this.objectClass = objectClass;
	}

	@Override
	public List<T> deserialize(JsonParser jp, DeserializationContext ctxt) throws IOException {
		List<T> ret = new ArrayList<>();

		ObjectCodec oc = jp.getCodec();
		JsonNode node = oc.readTree(jp);

		if (node.isArray()) {
			for (JsonNode n : (ArrayNode)((TreeNode)node)) {
				ret.add(deserializeObject(n));
			}
		} else {
			ret.add(deserializeObject(node));
		}

		return ret;
	}
	
	private T deserializeObject(JsonNode node) throws JsonMappingException, JsonParseException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return mapper.readValue(node.toString(), this.objectClass);
	}
}
