package com.bmo.channel.pwob.service.digitaltoken;

public class DigitalTokenPayload {
	private String payload;

	public String getPayload() {
		return payload;
	}

	public void setPayload(String payload) {
		this.payload = payload;
	}
	
}
