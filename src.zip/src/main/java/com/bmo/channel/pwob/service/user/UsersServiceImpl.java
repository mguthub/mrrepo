package com.bmo.channel.pwob.service.user;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.common.ehcache.CacheService;
import com.bmo.channel.core.exception.UnauthorizedSecurityException;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.user.InvestmentAdvisor;
import com.bmo.channel.pwob.model.user.SupportingIa;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.service.iacode.IaCodesService;
import com.bmo.channel.pwob.user.AuthenticatedUser;
import com.bmo.channel.pwob.user.UserContext;
import com.bmo.channel.pwob.validation.ErrorCodes;

import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetDetailedUserInformationResponseType;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.GetUsersForInvestmentAdvisorCodeResponseType.PcdUsers.PcdUser;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.InvestmentAdvisorCodes;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.InvestmentAdvisorCodes.InvestmentAdvisorCode;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.JurisdictionProvinces;
import net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.JurisdictionProvinces.JurisdictionProvince;

@Service
public class UsersServiceImpl implements UsersService {
	public static final String IA_CODE_CACHE_NAME = "iaCodesCache";
	
	public static final String SUPERVISOR_OF_ACCOUNTS = "31";	
	public static final String SUPERVISOR_OF_OPTIONS_ACCOUNTS = "36";	
	public static final String SUPERVISOR_OF_MANAGED_ACCOUNTS = "35";

	private static Logger logger = LoggerFactory.getLogger(UsersServiceImpl.class);

	@Autowired
	private UserContext userContext;

	@Autowired
	private IaCodesService iaCodesService;

	@Autowired
	private CacheService cacheService;

	@Override
	public User currentUser() {
		return getUser(userContext.getAuthenticatedUser());
	}

	@Override
	public User getUserByNetworkId(String networkId) {
		AuthenticatedUser authenticatedUser = userContext.getAuthenticatedUser();
		return getUser(new AuthenticatedUser(networkId, authenticatedUser.getDomain(), authenticatedUser.getLob()));
	}
	
	@Override
	public Set<InvestmentAdvisor> getIAUsersByIACode(String iaCodesList) {
		Set<InvestmentAdvisor>  investmentAdvisors= new HashSet<InvestmentAdvisor>();
		
		String[] iaCodes = iaCodesList.split(",");
		for(String iaCode : iaCodes){
			List<PcdUser> pcdUsers=  iaCodesService.usersForIaCode(iaCode, null);
			List<net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser> iaUsers=  iaCodesService.iaUsersForIaCode(iaCode, null);
			
			if(pcdUsers != null && pcdUsers.size()>0 && iaUsers != null && iaUsers.size() >0){
				for(net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser iaUser : iaUsers){ 
					for(PcdUser pcdUser: pcdUsers){
						if(pcdUser.getNetworkId().equals(iaUser.getNetworkId())){
							InvestmentAdvisor investmentAdvisor = new InvestmentAdvisor();	  
							investmentAdvisor.setFirstName(iaUser.getFirstName());
							investmentAdvisor.setLastName(iaUser.getLastName());
							investmentAdvisor.setNetworkId(iaUser.getNetworkId());
							
							if(pcdUser.getJurisdictionProvinces() != null){
								List<JurisdictionProvince> jurisdictionProvinces= pcdUser.getJurisdictionProvinces().getJurisdictionProvince();
								if(CollectionUtils.isNotEmpty(jurisdictionProvinces)){
									for(JurisdictionProvince jurisdictionProvince : jurisdictionProvinces){
										investmentAdvisor.getJurisdictionProvinces().add(jurisdictionProvince.getProvince());
									}
								}else{
									investmentAdvisor.setJurisdictionProvinces(null);
								}
							}else{
								investmentAdvisor.setJurisdictionProvinces(null);
							}
							investmentAdvisors.add(investmentAdvisor);	
						}
					}				
				}
			}
		}
		
		return investmentAdvisors;
	}

	User getUser(AuthenticatedUser authenticatedUser) {
		User user = (User)cacheService.get(authenticatedUser.getNetworkId(), authenticatedUser.getLob().name(), IA_CODE_CACHE_NAME);

		logger.debug("ia code cache found/ networkid: {}, lob: {}", authenticatedUser.getNetworkId(), authenticatedUser.getLob());

		if(user != null) {
			return user;
		}

		user = new User(authenticatedUser);

		if(ApplicationLob.nb == user.getLob()) {
			populateIaCodes(user, authenticatedUser);
		}
		
		cacheService.add(user, user.getNetworkId(), authenticatedUser.getLob().name(), IA_CODE_CACHE_NAME);
		logger.debug("ia code cache added/ networkid: {}, lob: {}", user.getNetworkId(), authenticatedUser.getLob());

		return user;
	}

	private void populateIaCodes(User user, AuthenticatedUser authenticatedUser) {
		GetDetailedUserInformationResponseType resp = iaCodesService.getUserInformation(authenticatedUser);
		net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser userInfo = resp.getPcdUser();
		if(userInfo == null){
			throw new UnauthorizedSecurityException(ErrorCodes.USER_NOT_FOUND + " : " + authenticatedUser.getNetworkId());
		}
		populateIsBmApproverFor(user, resp);
		populateUserIdInfo(user, resp);
	}

	private void populateIsBmApproverFor(User user, GetDetailedUserInformationResponseType resp) {
		if(Optional.ofNullable(resp).map(GetDetailedUserInformationResponseType::getBranchManagerApprovalCodes).map(GetDetailedUserInformationResponseType.BranchManagerApprovalCodes::getBranchManagerAdvisorCodes).map(InvestmentAdvisorCodes::getInvestmentAdvisorCode).isPresent()){
			List<InvestmentAdvisorCode> iaBmApproverCodes = resp.getBranchManagerApprovalCodes().getBranchManagerAdvisorCodes().getInvestmentAdvisorCode();
			if(CollectionUtils.isNotEmpty(iaBmApproverCodes)){
				user.setBmApproverFor(populateIaCodeList(iaBmApproverCodes));
			}
		}	
		populateBMJurisdictionProvinces(user,resp);
	}

	private void populateIsIaApproverFor(User user, GetDetailedUserInformationResponseType resp) {
		if(Optional.ofNullable(resp).map(GetDetailedUserInformationResponseType::getInvestmentAdvisorApprovalCodes).map(GetDetailedUserInformationResponseType.InvestmentAdvisorApprovalCodes::getInvestmentAdvisorCodes).map(InvestmentAdvisorCodes::getInvestmentAdvisorCode).isPresent()){
			
			List<InvestmentAdvisorCode> iaIaApproverCodes = resp.getInvestmentAdvisorApprovalCodes().getInvestmentAdvisorCodes().getInvestmentAdvisorCode();
			user.setIaApproverFor(populateIaCodeList(iaIaApproverCodes));
		}
	}
	
	private void populateIaJurisdictionProvinces(User user, GetDetailedUserInformationResponseType resp) {
		if(Optional.ofNullable(resp).map(GetDetailedUserInformationResponseType::getInvestmentAdvisorApprovalCodes).map(GetDetailedUserInformationResponseType.InvestmentAdvisorApprovalCodes::getJurisdictionProvinces).map(JurisdictionProvinces::getJurisdictionProvince).isPresent()){
			
			List<JurisdictionProvince> iaJurisdictionProvinces = resp.getInvestmentAdvisorApprovalCodes().getJurisdictionProvinces().getJurisdictionProvince();
			user.setIaJurisdictionProvinces(populateIaJurisdictionProvinces(iaJurisdictionProvinces));
		}
	}
	
	
	
	private void populateIaAandBranchCodes(User user, List<InvestmentAdvisorCode> investmentAdvisorCodes) {
		Map<String,String> iaAndBranchCodes = user.getIaAndBranchCodes();
		for(InvestmentAdvisorCode investmentAdvisorCode : investmentAdvisorCodes){
			iaAndBranchCodes.put(investmentAdvisorCode.getIaCode(), investmentAdvisorCode.getBranchCode());
		}		
	}

	private void populateUserIdInfo(User user, GetDetailedUserInformationResponseType resp) {
		
		
		net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser userInfo = resp.getPcdUser();
		

		user.setFirstName(userInfo.getFirstName());
		user.setLastName(userInfo.getLastName());
		user.setJobFunction(userInfo.getJobDescription());
		List<InvestmentAdvisorCode> investmentAdvisorCodes = userInfo.getInvestmentAdvisorCodes().getInvestmentAdvisorCode();
		user.setIaCodes(populateIaCodeList(investmentAdvisorCodes));
		if(CollectionUtils.isNotEmpty(investmentAdvisorCodes)) {
			user.setBranchCode(investmentAdvisorCodes.get(0).getBranchCode());
			populateIaAandBranchCodes(user,investmentAdvisorCodes);
		}

		if(user.isSA() && Optional.ofNullable(resp).map(GetDetailedUserInformationResponseType::getSupportingPcdUsers).map(GetDetailedUserInformationResponseType.SupportingPcdUsers::getPcdUsers).map(GetDetailedUserInformationResponseType.SupportingPcdUsers.PcdUsers::getPcdUser).isPresent()){
			populateIsSupportingSaFor(user, resp);
		} else {
			populateIsIaApproverFor(user, resp);
			populateIaJurisdictionProvinces(user,resp);
		}
		
	}

	private void populateIsSupportingSaFor(User user, GetDetailedUserInformationResponseType resp) {
		List<net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser> pcdList = resp.getSupportingPcdUsers().getPcdUsers().getPcdUser();
		List<SupportingIa> iaList = new ArrayList<>();

		for(net.bmogc.xmlns.hub.cg.investmentadvisorunit.intf.types.v2.PcdUser pcdUser: pcdList){
			SupportingIa ia = new SupportingIa();
			ia.setFirstName(pcdUser.getFirstName());
			ia.setLastName(pcdUser.getLastName());
			ia.setNetworkId(pcdUser.getNetworkId());
			ia.setIaCodes(populateIaCodeList(pcdUser.getInvestmentAdvisorCodes().getInvestmentAdvisorCode()));
			iaList.add(ia);
		}
		user.setSupportingSaFor(iaList);
	}

	private List<String> populateIaCodeList(List<InvestmentAdvisorCode> investmentAdvisorCodes) {
		List<String> iaCodes = new ArrayList<>();

		if(investmentAdvisorCodes != null) {
			for(InvestmentAdvisorCode iaCode: investmentAdvisorCodes){
				iaCodes.add(iaCode.getIaCode());
			}
		}		

		return iaCodes;
	}
	
	private List<String> populateIaJurisdictionProvinces(List<JurisdictionProvince> jurisdictionProvinces) {
		List<String> jurisdictionProvincesList = new ArrayList<>();

		if(jurisdictionProvinces != null) {
			for(JurisdictionProvince jurisdictionProvince: jurisdictionProvinces){
				if(SUPERVISOR_OF_ACCOUNTS.equals(jurisdictionProvince.getCategory()) || SUPERVISOR_OF_MANAGED_ACCOUNTS.equals(jurisdictionProvince.getCategory()) || SUPERVISOR_OF_OPTIONS_ACCOUNTS.equals(jurisdictionProvince.getCategory())){
					jurisdictionProvincesList.add(jurisdictionProvince.getProvince());
				}
			}
		}	
		return jurisdictionProvincesList;
	}
	
	private void populateBMJurisdictionProvinces(User user, GetDetailedUserInformationResponseType resp) {
		if(Optional.ofNullable(resp).map(GetDetailedUserInformationResponseType::getBranchManagerApprovalCodes).map(GetDetailedUserInformationResponseType.BranchManagerApprovalCodes::getJurisdictionProvinces).map(JurisdictionProvinces::getJurisdictionProvince).isPresent()){
			List<JurisdictionProvince> bmJurisdictionProvinces = resp.getBranchManagerApprovalCodes().getJurisdictionProvinces().getJurisdictionProvince();
			user.setBmJurisdictionProvinces(populateIaJurisdictionProvinces(bmJurisdictionProvinces));
		}
	}
}
