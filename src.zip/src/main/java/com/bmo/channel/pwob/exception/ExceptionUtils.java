package com.bmo.channel.pwob.exception;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;

import io.swagger.client.model.APIError;
import io.swagger.client.model.MessageList;
import io.swagger.client.model.ServiceResponseMessage;
import net.bmogc.xmlns.serviceexception._2_1.ApplicationIntegrityException;
import net.bmogc.xmlns.serviceexception._2_1.InputViolationException;
import net.bmogc.xmlns.serviceexception._2_1.SystemException;

public class ExceptionUtils {

	public static final String STATUS_SUCCESS = "Success";
	public static final String STATUS_FAILED = "FAILED";
	public static final String MSG_KEY = "MESSAGE";
	public static final String NOT_FOUND = "404";
    public static final String MISSING_IN_DTS_DB = "HUB.CG.DTS.GDP.InputValidation.Missing.Package";
    public static final String MISSING_IN_DTS = "HUB.CG.DTS.APTPP.InputValidation.Missing.Package";
    public static final String MISSING_DOCUMENT_IN_DTS = "HUB.CG.DTS.ADTP.InputValidation.Missing.Document";
	public static final String HUBERROR = "HUB Server is down";
	private static final String GENERATE_FROM_APPLICATION_APP_DATA_TIME_NOT_MATCH_ERROR = "OAD.GenerateFromApplication.AppDataTimeNotMatch.Error";
	private static final String GENERATE_FROM_APPLICATION_APP_DATA_NOT_FOUND_ERROR = "OAD.GenerateFromApplication.AppDataNotFound.Error";
	public static final String XSS_DETECTED = "XSS contents detected";

	static final String WMT_ACCOUNT_ROOT_COMPONENT = "WMTAccount_root";
	static final String RESERVE_ACCOUNT_NUMBER_FAILED_MESSAGE = "RESERVE.ACCOUNT.NUMBER.FAILED";
	private static final String FORM_GENERATE_APP_DATA_TIME_NOT_MATCH_ERROR = "AppDataTimeNotMatch.Error";
	private static final String FORM_GENERATE_APP_DATA_NOT_FOUND_ERROR = "AppDataNotFound.Error";
	
	private ExceptionUtils() {
		 throw new IllegalAccessError("Utility class");
	}

	public static void throwGenerateDocumentPackagesErrors(final Exception e) {
		if (e instanceof net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.http.v1_0.ApplicationIntegrityException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.http.v1_0.ApplicationIntegrityException) e).getFaultInfo());

		} else if (e instanceof net.bmogc.xmlns.hub.cg.documentservices.onboardapplicationdocumentation._interface.v1.ApplicationIntegrityException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.documentservices.onboardapplicationdocumentation._interface.v1.ApplicationIntegrityException) e).getFaultInfo());

		} else if (e instanceof net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.ApplicationIntegrityException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.ApplicationIntegrityException) e).getFaultInfo());

		} else if (e instanceof net.bmogc.xmlns.hub.cg.document.documentation._interface.v1.ApplicationIntegrityException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.document.documentation._interface.v1.ApplicationIntegrityException) e).getFaultInfo());

		} else if (e instanceof net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.http.v1_0.SystemException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.http.v1_0.SystemException) e).getFaultInfo());
			
		} else if (e instanceof net.bmogc.xmlns.hub.cg.documentservices.onboardapplicationdocumentation._interface.v1.SystemException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.documentservices.onboardapplicationdocumentation._interface.v1.SystemException) e).getFaultInfo());
			
		} else if (e instanceof net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.SystemException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.SystemException) e).getFaultInfo());		
					
		} else if (e instanceof net.bmogc.xmlns.hub.cg.document.documentation._interface.v1.SystemException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.document.documentation._interface.v1.SystemException) e).getFaultInfo());
			
		} else if (e instanceof net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.http.v1_0.InputViolationException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.customerservice.onboardapplicationpreparation.intf.http.v1_0.InputViolationException) e).getFaultInfo());
			
		} else if (e instanceof net.bmogc.xmlns.hub.cg.documentservices.onboardapplicationdocumentation._interface.v1.InputViolationException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.documentservices.onboardapplicationdocumentation._interface.v1.InputViolationException) e).getFaultInfo());
			
		} else if (e instanceof net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.InputViolationException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.document.documenttrackingservice._interface.v3.InputViolationException) e).getFaultInfo());					
			
		} else if (e instanceof net.bmogc.xmlns.hub.cg.document.documentation._interface.v1.InputViolationException) {
			
			throwDocumentServiceException(((net.bmogc.xmlns.hub.cg.document.documentation._interface.v1.InputViolationException) e).getFaultInfo());
			
		} else {
			throwWebServiceExceptionWithMsg(e.getMessage());
		}
	}

	public static void throwWebServiceExceptionWithMsg(final String msg) {		
		if (StringUtils.isNoneBlank(msg)) {
			WebServiceException webEx = new WebServiceException();
			webEx.addContextInfo(MSG_KEY, msg);
			throw webEx;
		} else {
			throw new WebServiceException();
		}		
	}

	public static void throwDocumentServiceException(final ApplicationIntegrityException aie) {
		if (aie!=null) {
			if(GENERATE_FROM_APPLICATION_APP_DATA_NOT_FOUND_ERROR.equalsIgnoreCase(aie.getServiceExceptionId())) {
				throw new NotFoundException(aie.getDetailedMessageText());
			} else if(GENERATE_FROM_APPLICATION_APP_DATA_TIME_NOT_MATCH_ERROR.equalsIgnoreCase(aie.getServiceExceptionId())) {
				throw buildStatusExceptionForActionNotAllowedContext("generate documents", "document generation in progress");
			} else {
				throwWebServiceExceptionWithMsg(aie.getDetailedMessageText());
			}		
		} else {
			throwWebServiceExceptionWithMsg(null);
		}
	}

	public static void throwDocumentServiceException(final javax.ws.rs.InternalServerErrorException ise) {
		if (Optional.ofNullable(ise).isPresent()) {
			APIError aPIError=ise.getResponse().readEntity(APIError.class);
			List<ServiceResponseMessage> serviceResponseMessageList = Optional.ofNullable(aPIError).map(APIError::getMessageList).map(MessageList::getServiceResponseMessage).get();
			String messageCode = null;
			if (CollectionUtils.isNotEmpty(serviceResponseMessageList)) {
				messageCode = Optional.ofNullable(serviceResponseMessageList.get(0)).map(ServiceResponseMessage::getMessageCode).get();
			}
			if(FORM_GENERATE_APP_DATA_NOT_FOUND_ERROR.equalsIgnoreCase(messageCode)) {
				throw new NotFoundException(Optional.ofNullable(serviceResponseMessageList.get(0)).map(ServiceResponseMessage::getMessageText).get());
			} else if(FORM_GENERATE_APP_DATA_TIME_NOT_MATCH_ERROR.equalsIgnoreCase(messageCode)) {
				throw buildStatusExceptionForActionNotAllowedContext("generate documents", "document generation in progress");
			} else {
				throwWebServiceExceptionWithMsg(Optional.ofNullable(serviceResponseMessageList.get(0)).map(ServiceResponseMessage::getMessageText).get());
			}		
		} else {
			throwWebServiceExceptionWithMsg(null);
		}
	}
	
	public static void throwDocumentServiceException(final SystemException se) {
		if (se != null) {
			throwWebServiceExceptionWithMsg(se.getDetailedMessageText());
		} else {
			throwWebServiceExceptionWithMsg(null);
		}
	}

	public static void throwDocumentServiceException(final InputViolationException ive) {
		if (ive != null) {
			if(isAccountReserveError(ive)) {
				throw new WebServiceException("Error reserving accounts calling doc prep");
			} else {
				throwWebServiceExceptionWithMsg(ive.getDetailedMessageText());
			}
		} else {
			throwWebServiceExceptionWithMsg(null);
		}
	}

	public static PwobStatusException buildStatusExceptionForActionNotAllowedContext(String action, String currentStatus) {
		return new PwobStatusException("Action not allowed: Action=" + action + ", CurrentStatus=" + currentStatus, PwobStatusException.ErrorType.actionNotAllowed);
	}	
	
	public static BackEndException buildBackEndException(String message, String serviceExceptionId) {
		return new BackEndException(message, serviceExceptionId);
	}	
	

	static boolean isAccountReserveError(InputViolationException ive) {
		return WMT_ACCOUNT_ROOT_COMPONENT.equals(ive.getOriginatingComponentName()) && 
			ive.getValidationExceptionDetailList() != null &&
			ive.getValidationExceptionDetailList().getValidationExceptionDetail() != null &&
			ive.getValidationExceptionDetailList().getValidationExceptionDetail().stream().anyMatch(v -> RESERVE_ACCOUNT_NUMBER_FAILED_MESSAGE.equals(v.getErrorText()));
	}

	public static PwobStatusException buildStatusExceptionForStaleApplicationDataContext(String date, String savedDate, String lastUpdatedBy) {
		return new PwobStatusException("stale data: Date=" + date +", SavedDate=" + savedDate + ", LastUpdatedBy=" + lastUpdatedBy, PwobStatusException.ErrorType.staleData);
	}
}
