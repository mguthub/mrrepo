package com.bmo.channel.workflows.parties.service;

import com.bmo.channel.common.domain.party.Person;
import com.bmo.channel.pwob.model.onboarding.Party;

public interface PartyMapper {

	Party mapPerson(Person person);

	Person mapPartyCreate(String firstName, String lastName);

}
