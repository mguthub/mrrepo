package com.bmo.channel.pwob.model.user;

import java.util.ArrayList;
import java.util.List;

public class SupportingIa {
	private String firstName;
	private String lastName;
	private String networkId;
	private List<String> iaCodes = new ArrayList<>();
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public List<String> getIaCodes() {
		return iaCodes;
	}
	public void setIaCodes(List<String> iaCodes) {
		this.iaCodes = iaCodes;
	}
	public String getNetworkId() {
		return networkId;
	}
	public void setNetworkId(String networkId) {
		this.networkId = networkId;
	}
}
