package com.bmo.channel.pwob.model.onboarding;

import java.util.List;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class BranchesResponse {
	private List<Branch> branches;
	
	public BranchesResponse(List<Branch> branches) {
		this.branches = branches;
	}
	
	public List<Branch> getBranches() {
		return branches;
	}
	
	public void setBranches(List<Branch> branches) {
		this.branches = branches;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
