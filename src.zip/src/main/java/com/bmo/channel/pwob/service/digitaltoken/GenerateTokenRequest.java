/**
 * 
 */
package com.bmo.channel.pwob.service.digitaltoken;

/**
 * @author vvallia
 *
 */
public class GenerateTokenRequest {
	
	private String payload;
	
	private String tokenTTL;

	/**
	 * @return the payload
	 */
	public String getPayload() {
		return payload;
	}

	/**
	 * @param payload the payload to set
	 */
	public void setPayload(String payload) {
		this.payload = payload;
	}

	/**
	 * @return the tokenTTL
	 */
	public String getTokenTTL() {
		return tokenTTL;
	}

	/**
	 * @param tokenTTL the tokenTTL to set
	 */
	public void setTokenTTL(String tokenTTL) {
		this.tokenTTL = tokenTTL;
	}
	
	
}
