package com.bmo.channel.pwob.service.risprefill;

import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.springframework.web.bind.annotation.RequestBody;

import net.bmogc.xmlns.hub.cg.wealthmanagement.risaccountreporting.intf.types.v1.GetAccountDetailsRequestType;
import net.bmogc.xmlns.hub.cg.wealthmanagement.risaccountreporting.intf.types.v1.GetAccountDetailsResponseType;

@Produces(MediaType.APPLICATION_JSON)
public interface RisAccountSearchEndpointInterface {
	
	@POST
	public GetAccountDetailsResponseType getAccountDetails(@RequestBody GetAccountDetailsRequestType requestWrapper, 
			@HeaderParam("APIHeaderRequest") String requestHeader);
}
