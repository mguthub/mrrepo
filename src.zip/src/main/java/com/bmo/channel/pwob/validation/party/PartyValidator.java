package com.bmo.channel.pwob.validation.party;

import java.util.List;
import java.util.Optional;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.bmorelationship.BmoRelationshipValidator;
import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Identity;
import com.bmo.channel.pwob.model.onboarding.InvestmentExperience;
import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PartyRole;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.Phone;
import com.bmo.channel.pwob.model.onboarding.TaxResidency;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.InvestmentObjectivesValidator;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.employment.EmploymentValidator;
import com.bmo.channel.pwob.validation.financialstatus.FinancialWealthValidator;
import com.bmo.channel.pwob.validation.financialstatus.IncomeValidator;
import com.bmo.channel.pwob.validation.financialstatus.InvestmentExperienceKnowledgeValidator;
import com.bmo.channel.pwob.validation.financialstatus.NetWorthValidator;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.preferences.PreferencesValidator;
import com.bmo.channel.pwob.validation.regulatory.RegulatoryDisclosureValidator;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;
import com.bmo.channel.pwob.validation.residence.ResidenceAddressValidator;
import com.bmo.channel.pwob.validation.taxation.TaxationValidator;

public class PartyValidator extends AbstractBaseValidator implements ConstraintValidator<ValidParty, Party> {
	private static final String PREFERENCES_NODE = "preferences";
	private static final String PREFERENCES_FIELD_PATH = "preferences";
	private static final String REGULATORY_NODE = "regulatoryDisclosures";
	private static final String REGULATORY_FIELD_PATH = "regulatoryDisclosures";
	public static final String FINANCIAL_OTHER = "financial.other";
	public static final String FINANCIAL_STATUS_INCOME = "financial.status.income";
	public static final String FINANCIAL_STATUS_NETWORTH = "financial.status.netWorth";
	public static final String REGULATORYDISCLOSURES_VERIFICATION="regulatoryDisclosures.verification";
	public static final String REGEX_ID_VERIFICATION_METHOD=".*";
	public static final String COUNTRY_CODE_PATTERN =  "^\\d\\d?\\d?$";
	public static final String PASSWORD_PATTERN = "^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]{1,6}$";
	@Autowired UsersService userService;
	
	@Autowired private PreferencesValidator preferencesValidator;
	
	@Autowired EmploymentValidator employmentValidator;
	
	@Autowired ResidenceAddressValidator residenceAddressValidator;
	
	@Autowired InvestmentObjectivesValidator investmentObjectivesValidator;
	
	@Autowired ValidationRequestFactory validationRequestFactory;
	
	@Autowired RegulatoryDisclosureValidator regulatoryDisclosureValidator;
	
	@Autowired private JointApplicantValidator jointApplicantValidator;
	
	@Autowired private TaxationValidator taxationValidator; 
	
	@Autowired private InvestmentExperienceKnowledgeValidator investmentExperienceKnowledgeValidator;
	
	@Autowired private NetWorthValidator netWorthValidator;
	
	@Autowired private FinancialWealthValidator financialWealthValidator;
	
	@Autowired private IncomeValidator incomeValidator;
	
	@Autowired private BmoRelationshipValidator bmoRelationshipValidator;

	@Override
	public void initialize(ValidParty constraintAnnotation) {
		// none required
	}

	@Override
	public boolean isValid(final Party party, final ConstraintValidatorContext context) {
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		boolean valid = true;
		if (validationContext.getAction() == Action.SAVE) {
			if(ApplicationLob.il == this.userService.currentUser().getLob() ) {
				valid = validatePasswordforBIL(party,context);
				if(!valid) {
					this.createConstraintViolation(context, ErrorCodes.INVALID_PASSWORD, "password");
					return false;		
				}
			}
			// only validate if submitting
			else{
				return true;
			}
		}

		ValidationRequest request = validationRequestFactory.createBuilder(
										context, userService.currentUser().getLob()
									).build();

		
		
		if (this.isPrimaryApplicantRole(party.getRoles())) {
			valid = this.validatePrimaryApplicant(party, validationContext.getApplication().getAccounts(), request) && valid;
			
		}

		if (this.isJointApplicantRole(party.getRoles())) {
			valid = this.validateJointApplicant(party, request, validationContext.getApplication()) && valid;
			
		}

		if (this.isTradingAuthRole(party.getRoles())) {
			valid = this.validateTradingAuth(party, request) && valid;
		}
		
		if(CollectionUtils.isNotEmpty(party.getRoles())){
			if(party.getFinancial() != null){
				ValidationRequest financialWealthContext = request.createChildValidationRequest(FINANCIAL_OTHER, FINANCIAL_OTHER);
				valid = financialWealthValidator.isValid(party.getFinancial().getOther(), financialWealthContext) && valid;
				
				ValidationRequest financialNetWorthContext = request.createChildValidationRequest(FINANCIAL_STATUS_NETWORTH, FINANCIAL_STATUS_NETWORTH);
				valid = netWorthValidator.isValid(party.getFinancial().getStatus().getNetWorth(), financialNetWorthContext) && valid;
				
				ValidationRequest financialIncomeContext = request.createChildValidationRequest(FINANCIAL_STATUS_INCOME, FINANCIAL_STATUS_INCOME);
				valid = incomeValidator.isValid(party.getFinancial().getStatus().getIncome(), financialIncomeContext) && valid;
			}
			
			if(party.getRegulatoryDisclosures() != null){
				if(party.getRegulatoryDisclosures().getVerification() != null && request.getLob() == ApplicationLob.nb) { 
					if(StringUtils.isBlank(party.getRegulatoryDisclosures().getVerification().getIdVerificationMethod()) || 
							!party.getRegulatoryDisclosures().getVerification().getIdVerificationMethod().matches(REGEX_ID_VERIFICATION_METHOD)) {
						ValidationRequest financialNetWorthContext = request.createChildValidationRequest(REGULATORYDISCLOSURES_VERIFICATION, REGULATORYDISCLOSURES_VERIFICATION);					
						financialNetWorthContext.addConstraintViolation(ID_VERIFICATION_METHOD_FIELD_NAME,ErrorCodes.INVALID_ID_VERIFICATION_METHOD);
					}	
				}
			}
		}
		return valid;
	}
	
	private boolean validatePasswordforBIL(Party party, ConstraintValidatorContext context) {
		if ( party.getRoles().contains(PartyRole.PRIMARY_APPLICANT) && (StringUtils.isEmpty(party.getPassword()) || !passwordValidation(party.getPassword())) ) {
				return false;
		}
		return true;
	}
	
	boolean passwordValidation(String password) {
		return password.matches(PASSWORD_PATTERN) ;
	}
	
	/**
	 * Validate all elements for Trading Authority Role
	 * @param valid
	 * @param party
	 * @param validTA
	 * @param request
	 * @return
	 */
	private boolean validateTradingAuth(Party party, ValidationRequest request) {
		boolean valid = true;
		request.setPartyRole(PartyRole.TRADING_AUTHORITY);
		ValidationRequest residenceRequestContext = request.createChildValidationRequest(PERSONAL_RESIDENCE, PERSONAL_RESIDENCE);
		valid = this.residenceAddressValidator.validateResidenceAddress(party.getPersonal().getResidence(), residenceRequestContext) && valid;

		ValidationRequest identityRequestContext = request.createChildValidationRequest(PERSONAL_IDENTITY_NODE, PERSONAL_IDENTITY_PATH);
		identityRequestContext.setFieldName(DOB_FIELD_NAME);
		identityRequestContext.setErrorCode(ErrorCodes.INVALID_DATE_OF_BIRTH);
		valid = this.validateDateOfBirth(party.getPersonal().getIdentity(), identityRequestContext) && valid;

		if(Optional.ofNullable(party.getRegulatoryDisclosures()).isPresent()){
			valid = this.regulatoryDisclosureValidator.validateRegulatory(party.getRegulatoryDisclosures(), request.createChildValidationRequest(REGULATORY_NODE, REGULATORY_FIELD_PATH)) && valid;
		}
		
		if(Optional.ofNullable(party.getRegulatoryDisclosures()).isPresent()){
			valid = this.regulatoryDisclosureValidator.validateRegulatory(party.getRegulatoryDisclosures(), request.createChildValidationRequest(REGULATORY_NODE, REGULATORY_FIELD_PATH)) && valid;
		}
		
		return valid;
	}

	public boolean validateDateOfBirth(Identity identity, ValidationRequest request) {
		if(identity == null || StringUtils.isBlank(identity.getDateOfBirth())) {
			request.addConstraintViolation();					
			return false;
		}
		return true;
	}

	/**
	 * Validate all elements for Primary Applicant Role
	 * @param valid
	 * @param party
	 * @param accounts
	 * @param request
	 * @return
	 */
	private boolean validatePrimaryApplicant(Party party, List<Account> accounts, ValidationRequest request) {
		boolean valid = true;
		boolean onlyJointAccounts = true;
		boolean noAccounts = false;

		request.setPartyRole(PartyRole.PRIMARY_APPLICANT);
		
		valid = this.preferencesValidator.arePreferencesValid(party.getPreferences(), request.createChildValidationRequest(PREFERENCES_NODE, PREFERENCES_FIELD_PATH)) && valid;

		//if(accounts != null && accounts.size() > 0){
		if(accounts != null && accounts.size() > 1){
			request.setFieldName("applyInvestmentObjectivesToAccounts");
			request.setErrorCode(ErrorCodes.INVALID_APPLY_INVESTMENT_OBJECTIVES_TO_ACCOUNTS);
			valid = this.isValidApplyInvestmentObjectivesToAccounts(party.getApplyInvestmentObjectivesToAccounts(), request) && valid;
		}

		request.setFieldName("creditBureauConsent");
		request.setErrorCode(ErrorCodes.INVALID_CREDIT_BUREAU_CONSENT);
		valid = this.isValidCreditBureauConsent(party.getCreditBureauConsent(), request) && valid;

		/*if(party.getInvestmentObjectives()!= null){
			valid = validateInvestmentObjectives(party, request, accounts) && valid;
		}
*/
		if(this.isTaxResidencyRequired(request.getLob())) {
			ValidationRequest taxResRequest = request.createChildValidationRequest("personal.residencyForTax", "personal.residencyForTax");

			valid = this.validateTaxResidency(party.getPersonal(), taxResRequest) && valid;
		}

		valid = this.employmentValidator.validateEmployment(party.getPersonal().getEmployment(),party.getPersonal().getResidence().getPrimaryPhone(),false, request.createChildValidationRequest(PERSONAL_EMPLOYMENT_NODE, PERSONAL_EMPLOYMENT_PATH)) && valid;

		valid = this.residenceAddressValidator.validateResidenceAddress(party.getPersonal().getResidence(), request) && valid; 

		if (party.getPersonal().getResidence().getSecondaryPhone() != null) {
			valid = this.validateSecondaryPhone(request, party.getPersonal().getResidence().getPrimaryPhone(),party.getPersonal().getResidence().getSecondaryPhone()) && valid;
		}		
		
		if(CollectionUtils.isNotEmpty(accounts) && accounts.size() > 0){
			for(Account account: accounts){
				if(!Account.JOINT_TYPE.equals(account.getType())){
					onlyJointAccounts = false;
				}
			}			
		}else{			
			noAccounts = true;
		}
		ValidationRequest investmentExpRequest = request.createChildValidationRequest("financial.investment", "financial.investment");
		
		if(noAccounts || onlyJointAccounts){
			if(party.getFinancial() != null){
				InvestmentExperience exp = party.getFinancial().getInvestment();
				if(CollectionUtils.isNotEmpty(exp.getPastExperience()) ||  StringUtils.isNotEmpty(exp.getInvestmentKnowledge()) || StringUtils.isNotEmpty(exp.getAltInvestmentExperience())){
					investmentExpRequest.addConstraintViolation("primaryApplicantInvestmentExperience", ErrorCodes.INVALID_PRIMARY_APPLICANT_INVESTMENT_EXP);
				}
			}
		}else{
				InvestmentExperience exp= null;
				if(party.getFinancial() == null){
					exp = new InvestmentExperience();
				}else{
					exp = party.getFinancial().getInvestment();
				}
				valid = this.investmentExperienceKnowledgeValidator.isInvestmentExperienceValid(exp, investmentExpRequest) && valid;
		}
		
		
		if(Optional.ofNullable(party.getRegulatoryDisclosures()).isPresent()){
			valid = this.regulatoryDisclosureValidator.validateRegulatory(party.getRegulatoryDisclosures(), request.createChildValidationRequest(REGULATORY_NODE, REGULATORY_FIELD_PATH)) && valid;
			valid = this.regulatoryDisclosureValidator.validatePoliticallyExposedPerson(party.getRegulatoryDisclosures(), request.createChildValidationRequest(REGULATORY_NODE, REGULATORY_FIELD_PATH)) && valid;
		}
		
		//W8-W9 form validation for primary applicant
		ValidationRequest formRequest = request.createChildValidationRequest(TAXATION_PATH, TAXATION_NODE);
		valid = this.taxationValidator.validateW8W9Form(party, accounts, formRequest) && valid;
			
		//BMO client relationship type validation
		if(ApplicationLob.il == request.getLob()) {
			valid = this.bmoRelationshipValidator.validateBmoRelationship(party.getBmoRelationship(), request.createChildValidationRequest(BMO_RELATIONSHIP_PATH, BMO_RELATIONSHIP_NODE)) && valid;

		}

		return valid;
	}
	
	/**
	 * Validate all elements for Joint Applicant Role
	 * @param valid
	 * @param party
	 * @param accounts
	 * @param request
	 * @param applicationId 
	 * @return
	 */
	private boolean validateJointApplicant(Party party, ValidationRequest request, Application app) {
		boolean valid = true;
		boolean isPrimaryApplicantSpouse = false;
		
		String applicationId = app.getApplicationId();
		request.setPartyRole(PartyRole.JOINT_APPLICANT);

		if(this.isTaxResidencyRequired(request.getLob())) {
			ValidationRequest taxResRequest = request.createChildValidationRequest("personal.residencyForTax", "personal.residencyForTax");

			valid = this.validateTaxResidency(party.getPersonal(), taxResRequest) && valid;
		}	
		if(Optional.ofNullable(party.getIsPrimaryApplicantSpouse()).isPresent() && party.getIsPrimaryApplicantSpouse()){
		  isPrimaryApplicantSpouse = party.getIsPrimaryApplicantSpouse();
		}
		
		valid = this.employmentValidator.validateEmployment(party.getPersonal().getEmployment(),party.getPersonal().getResidence().getPrimaryPhone(), isPrimaryApplicantSpouse, request.createChildValidationRequest(PERSONAL_EMPLOYMENT_NODE, PERSONAL_EMPLOYMENT_PATH)) && valid;

		valid = this.residenceAddressValidator.validateResidenceAddress(party.getPersonal().getResidence(), request) && valid;

		valid = jointApplicantValidator.validateJointProductEligibility(applicationId, party, request) && valid;

		if (party.getPersonal().getResidence().getSecondaryPhone() != null) {
			valid = this.validateSecondaryPhone(request,party.getPersonal().getResidence().getPrimaryPhone(), party.getPersonal().getResidence().getSecondaryPhone()) && valid;
		}
		
		if(Optional.ofNullable(party.getRegulatoryDisclosures()).isPresent()){
			valid = this.regulatoryDisclosureValidator.validatePoliticallyExposedPerson(party.getRegulatoryDisclosures(), request.createChildValidationRequest(REGULATORY_NODE, REGULATORY_FIELD_PATH)) && valid;
			
			if (party.getIsPrimaryApplicantSpouse() == null || !party.getIsPrimaryApplicantSpouse()) {
				valid = this.regulatoryDisclosureValidator.validateRegulatory(party.getRegulatoryDisclosures(), request.createChildValidationRequest(REGULATORY_NODE, REGULATORY_FIELD_PATH)) && valid;
			}
		}
		
		//W8-W9 form validation for primary applicant
				ValidationRequest formRequest = request.createChildValidationRequest(TAXATION_PATH, TAXATION_NODE);
				valid = this.taxationValidator.validateW8W9Form(party, app.getAccounts(), formRequest) && valid;
		
		return valid;
	}

	@Override
	protected boolean validateField(ValidationRequest validationRequest) {		
		String fullFieldPath = validationRequest.calculateFullFieldPath().replaceAll("\\d+", "");
		String regex = this.retrievePatternForFieldAndLob(validationRequest.getLob(), fullFieldPath);		
		if(StringUtils.isBlank(validationRequest.getFieldValue()) || 
				(StringUtils.isNoneBlank(regex) && !validationRequest.getFieldValue().matches(regex))) {						
			return false;
		}
		return true;
	}

	private boolean validateTaxResidency(PersonalInformation personalInfo, ValidationRequest request) {
		boolean flag = true;

		if(personalInfo == null) {
			this.createConstraintViolation(request.getContext(), ErrorCodes.INVALID_TAX_RESIDENCIES, PERSONAL_NODE.concat(".").concat(RESIDENCY_TAX_NODE));
			flag = false;
		} else {
			flag = this.validateAndAddConstraintViolation(request, personalInfo);

			if(personalInfo.getResidencyForTax() == null || (personalInfo.getResidencyForTax().size() < 1 || personalInfo.getResidencyForTax().size() > 4)) {
				this.createConstraintViolation(request.getContext(), ErrorCodes.INVALID_TAX_RESIDENCIES, PERSONAL_NODE.concat(".").concat(RESIDENCY_TAX_NODE));
			}
		}
		return flag;
	}
	
	public boolean isValidPhoneNumber(Phone phoneNumber) {		
		if (Optional.ofNullable(phoneNumber.getIsInternationalNumber()).isPresent() && phoneNumber.getIsInternationalNumber()
				&& StringUtils.isBlank(phoneNumber.getPhoneNumber())) {
			return false;
		}	
		return true;
	}	

	public boolean isValidCountryCode(Phone phoneNumber) {
		if (Optional.ofNullable(phoneNumber.getIsInternationalNumber()).isPresent() && phoneNumber.getIsInternationalNumber()
				&& (StringUtils.isBlank(phoneNumber.getCountryCode())
						|| !this.doesPatternMatch(phoneNumber.getCountryCode(), COUNTRY_CODE_PATTERN))){
			return false;
		}	
		return true;
	}

	private boolean validateAndAddConstraintViolation(ValidationRequest request, PersonalInformation personalInfo) {
		boolean valid = true;
		if(CollectionUtils.isNotEmpty(personalInfo.getResidencyForTax())) {
			for(int index = 0; index < personalInfo.getResidencyForTax().size(); index++) {
				TaxResidency taxResidency = personalInfo.getResidencyForTax().get(index);
				request.setFieldValue(taxResidency.getCountry());
				if(StringUtils.isBlank(taxResidency.getCountry()) || !this.validateField(request)) {
					ValidationRequest residencyRequestContext = request.createChildValidationRequest("personal.residencyForTax[" + index + "]", null);
					residencyRequestContext.setErrorCode(ErrorCodes.INVALID_COUNTRY);
					residencyRequestContext.setFieldName("country");
					residencyRequestContext.addConstraintViolation();
					valid = false;
				}
			}
		} else {
			ValidationRequest personalValidationRequest = request.createChildValidationRequest("personal", null);
			personalValidationRequest.setFieldName("residencyForTax");
			personalValidationRequest.setErrorCode(ErrorCodes.INVALID_TAX_RESIDENCIES);
			personalValidationRequest.addConstraintViolation();
			valid = false;
		}

		return valid;
	}

	private boolean isValidApplyInvestmentObjectivesToAccounts(Boolean flag, ValidationRequest request) {
		if (ApplicationLob.nb == request.getLob())
			return checkNull(request, flag);
		else 
			return true;
	}		

	private boolean isValidCreditBureauConsent(Boolean flag, ValidationRequest request) {
		/*if (ApplicationLob.il == request.getLob())
			return checkNull(request, flag);
		else*/
		// for BIL (add check for credit bureau consent )
		
			return true; 
	}

	private boolean validateSecondaryPhone(ValidationRequest request,Phone primaryPhone, Phone secondaryPhone) {
		boolean valid = true;		
		if (StringUtils.isNotBlank(secondaryPhone.getPhoneExtension()) && StringUtils.isBlank(secondaryPhone.getPhoneNumber())
				&& primaryPhone.getIsInternationalNumber() == null){
			request.setErrorCode(ErrorCodes.INVALID_PHONE_FOR_EXTENSION);
			request.setChildPropertyNode(PERSONAL_RESIDENCE + ".secondaryPhone");
			request.setChildFieldPath(PERSONAL_RESIDENCE);
			request.setFieldName(PHONE_NUMBER_FIELD_NAME);
			request.addConstraintViolation();
			valid = false;
		}		
		if (primaryPhone.getIsInternationalNumber() != null && primaryPhone.getIsInternationalNumber() && StringUtils.isBlank(secondaryPhone.getPhoneNumber())
				&& StringUtils.isNotBlank(secondaryPhone.getCountryCode())) {
			request.setErrorCode(ErrorCodes.INVALID_PHONE_FOR_EXTENSION);
			request.setChildPropertyNode(PERSONAL_RESIDENCE + ".secondaryPhone");
			request.setChildFieldPath(PERSONAL_RESIDENCE);
			request.setFieldName(PHONE_NUMBER_FIELD_NAME);
			request.addConstraintViolation();			
			valid = false;
			
		}
		
		if (primaryPhone.getIsInternationalNumber() != null && primaryPhone.getIsInternationalNumber() && StringUtils.isNotBlank(secondaryPhone.getPhoneNumber())
				&& (StringUtils.isBlank(secondaryPhone.getCountryCode()) || !this.doesPatternMatch(secondaryPhone.getCountryCode(), COUNTRY_CODE_PATTERN))) {
			request.setErrorCode(ErrorCodes.INVALID_PHONE_COUNTRY_CODE);
			request.setChildPropertyNode(PERSONAL_RESIDENCE + ".secondaryPhone");
			request.setChildFieldPath(PERSONAL_RESIDENCE);
			request.setFieldName(COUNTRY_CODE_FIELD_NAME);
			request.addConstraintViolation();
			valid = false;
		}
		
		return valid;
	}
	
}
