package com.bmo.channel.pwob.service.reference.mapping;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.collections.PredicateUtils;

import com.bmo.channel.pwob.model.reference.Reference;

/**
 * There can be duplicate codes in a list of {@link com.bmo.channel.pwob.model.reference.Reference} objects, some expired
 * and some not. This class will filter out these duplicates, preferring non-expired references.
 * @author Ryan Chambers (rcham02)
 */
class DuplicatesFilter {

	/**
	 * @param references  list of references, with possibly the same code in the list, with one reference expired and the other not.
	 * @return  
	 */
	List<Reference> filterOutDuplicates(List<Reference> references) {
		Map<String, Boolean> duplicateCodes = new HashMap<>();
		CollectionUtils.filter(references, PredicateUtils.notNullPredicate());
		for (Reference reference : references) {
			Boolean entry = duplicateCodes.get(reference.getCode());
			if(entry == null) {
				duplicateCodes.put(reference.getCode(), Boolean.FALSE);
			} else {
				duplicateCodes.put(reference.getCode(), Boolean.TRUE);
			}
		}

		return references.stream().filter(new Predicate<Reference>() {
			@Override
			public boolean test(Reference ref) {
				if(duplicateCodes.get(ref.getCode()).booleanValue()) {
					return ref.getExpired() == null || !ref.getExpired();
				} else {
					return true;
				}
			}
			
		}).collect(Collectors.toList());
	}
}
