package com.bmo.channel.pwob.service.documentpackages;

import java.util.List;

import com.bmo.channel.pwob.rest.endpoint.jaxrs.v1.DocumentUpdateUploadResponse;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentDto;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentPackageDto;
import com.bmo.channel.pwob.service.documentpackages.dto.DocumentUploadDto;

/**
 * Services related document packages.
 */
public interface DocumentPackagesService {
	List<DocumentPackageDto> retrieveDocumentPackages(final String workflowId, boolean isAuthorised);

	DocumentDto viewDocument(final String workflowId, final String repositoryId, final String documentPackageId, final List<String> documentIds);

	byte[] retrieveDocumentContent(final String workflowId, final String repositoryId, final String documentPackageId, final List<String> documentIds, boolean isAuthorised, final String partyId);

	void activateESigning(final String workflowId);
	
	void assignUsersToeSignDocs(final String workflowId);

	void paperSigning(final String workflowId, final String documentPackageId);

	DocumentUpdateUploadResponse updateDocument(final String workflowId, final String documentPackageId, final String contentType, final DocumentUploadDto request);

	byte[] print(final String workflowId, final String repositoryId, final String documentPackageId);
}
