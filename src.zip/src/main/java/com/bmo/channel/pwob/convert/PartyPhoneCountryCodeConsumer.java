package com.bmo.channel.pwob.convert;

import java.util.function.Consumer;

import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.model.onboarding.PersonalInformation;
import com.bmo.channel.pwob.model.onboarding.Phone;
import com.bmo.channel.pwob.model.onboarding.Residence;

/**
 * Only hard-code country code if:
 * <dl>
 * 	<dt>Residence</dt>
 *	<dd>primary phone is international = null or false</dd> 
 * 	<dt>EmploymentInformation</dt>
 *	<dd>phone is international = null or false</dd> 
 * </dl>
 * @author Ryan Chambers (rcham02)
 */
class PartyPhoneCountryCodeConsumer implements Consumer<Party> {
	@Override
	public void accept(Party party) {
		if(party != null && party.getPersonal() != null) {
			PersonalInformation personal = party.getPersonal();
			acceptResidence(personal);
			acceptEmployment(personal);
		}
	}

	private void acceptEmployment(PersonalInformation personal) {
		if(personal.getEmployment() != null && personal.getEmployment().getPrimaryBusinessPhone() != null) {
			Phone primaryBusinessPhone = personal.getEmployment().getPrimaryBusinessPhone();
			if(shouldHardCodeCountryCode(primaryBusinessPhone)) {
				primaryBusinessPhone.setCountryCode(PhoneCountryCodePopulatorImpl.COUNTRY_CODE);
			}
		}
	}

	private boolean shouldHardCodeCountryCode(Phone primaryBusinessPhone) {
		return primaryBusinessPhone.getIsInternationalNumber() == null || !primaryBusinessPhone.getIsInternationalNumber();
	}

	private void acceptResidence(PersonalInformation personal) {
		if(personal.getResidence() != null && personal.getResidence().getPrimaryPhone() != null) {
			Residence residence = personal.getResidence();
			Phone primaryPhone = residence.getPrimaryPhone();
			if(primaryPhone != null && shouldHardCodeCountryCode(primaryPhone)) {
				primaryPhone.setCountryCode(PhoneCountryCodePopulatorImpl.COUNTRY_CODE);
				if(residence.getSecondaryPhone() != null) {
					residence.getSecondaryPhone().setCountryCode(PhoneCountryCodePopulatorImpl.COUNTRY_CODE);
				}
			}
		}
	}
}