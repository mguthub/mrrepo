package com.bmo.channel.pwob.rest.endpoint.jaxrs.v1;

import com.bmo.channel.pwob.model.onboarding.Credential;

public class CredentialResponse {

	private Credential credential;

	public CredentialResponse(Credential credential) {
		this.credential = credential;
	}
	public Credential getCredential() {
		return credential;
	}

	public void setCredential(Credential credential) {
		this.credential = credential;
	}
}
