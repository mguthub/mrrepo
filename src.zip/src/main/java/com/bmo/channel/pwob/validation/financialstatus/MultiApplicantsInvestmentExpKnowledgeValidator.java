package com.bmo.channel.pwob.validation.financialstatus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.onboarding.Account;
import com.bmo.channel.pwob.model.onboarding.Application;
import com.bmo.channel.pwob.model.onboarding.MultiApplicantsInvestmentExperience;
import com.bmo.channel.pwob.model.user.User;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.MultiApplicantsInvestmentExperienceKnowledge;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

public class MultiApplicantsInvestmentExpKnowledgeValidator extends AbstractBaseValidator implements ConstraintValidator<MultiApplicantsInvestmentExperienceKnowledge, MultiApplicantsInvestmentExperience> {

	
	public static final String JOINT_APPLICANTS_INV_EXPERIENCE 	= "multiApplicantsInvestmentExperience";
	
	public static final String MULTI_APPLICANTS_INVESTMENT_EXP_FIELD_NAME 	= "multiApplicantsInvestmentExperience";	

	@Autowired ValidationRequestFactory validationRequestFactory;

	@Autowired private UsersService userService;
	
	@Autowired private InvestmentExperienceKnowledgeValidatorImpl investmentExperienceKnowledgeValidator;

	@Override
	public void initialize(MultiApplicantsInvestmentExperienceKnowledge constraintAnnotation) {		
	}

	@Override
	public boolean isValid(MultiApplicantsInvestmentExperience value, ConstraintValidatorContext context) {
		
		ValidationContextHolder validationContextHolder = ValidationManager.validationContext.get();		
		ValidationRequest request = validationRequestFactory.createBuilder(context, userService.currentUser().getLob()).build();

		if(validationContextHolder.getAction() == Action.SAVE) {
			return true;
		}

		Application application = validationContextHolder.getApplication();
		List<Account> jointAccounts = application.getJointAccounts();
		
		boolean valid = false;
		
	
		if(jointAccounts != null){
			List<String> partyRefIds = new ArrayList<String>(value.getPartyRefIds());
			for(Account jointAccount : jointAccounts){					
					if(jointAccount.getJointApplicantPartyRefIds() != null 
								&& CollectionUtils.isNotEmpty(jointAccount.getJointApplicantPartyRefIds())
								&& jointAccount.getJointApplicantPartyRefIds().size() > 0){
						List<String> jointAccountApplicants = new ArrayList<String>(jointAccount.getJointApplicantPartyRefIds());						
						
						jointAccountApplicants.add(jointAccount.getPrimaryApplicantPartyRefId());

						if (CollectionUtils.isEqualCollection(partyRefIds, jointAccountApplicants)) {
							valid = true;
							break;
						}
					}
								
			}
			if(!valid){
				request.addConstraintViolation(MULTI_APPLICANTS_INVESTMENT_EXP_FIELD_NAME, ErrorCodes.INVALID_MULTI_APPLICANTS_INVESTMENT_EXP);
				return valid;
			}
		}else{
				request.addConstraintViolation(MULTI_APPLICANTS_INVESTMENT_EXP_FIELD_NAME, ErrorCodes.INVALID_MULTI_APPLICANTS_INVESTMENT_EXP);
				return valid;
		}
		
		ValidationRequest investmentExpRequestContext = request.createChildValidationRequest(JOINT_APPLICANTS_INV_EXPERIENCE, JOINT_APPLICANTS_INV_EXPERIENCE);
		
		valid = this.investmentExperienceKnowledgeValidator.isInvestmentExperienceValid(value.getMultiApplicantInvestmentExperience(), investmentExpRequestContext) && valid;
		
		return valid;
	}

}
