package com.bmo.channel.pwob.convert.taxresidency;

import com.bmo.channel.pwob.model.onboarding.Application;

/**
 * Tax residency data migration
 *
 */
public interface BetchTaxResidencyMapper {
	void updateApplication(Application application);	

}
