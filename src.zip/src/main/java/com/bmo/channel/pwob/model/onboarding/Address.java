package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;
import com.fasterxml.jackson.annotation.JsonInclude;

import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.data.DataValidationPattern;
import com.bmo.channel.pwob.validation.region.CountryAndProvince;

import io.swagger.annotations.ApiModelProperty;

@CountryAndProvince(countryFieldName="country", provinceFieldName="province")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Address {

	@DataValidationPattern(code=ErrorCodes.INVALID_UNIT_NUMBER)
	private String unitNumber;

	@DataValidationPattern(code=ErrorCodes.INVALID_STREET_ADDR)
	private String streetAddress;

	@DataValidationPattern(code=ErrorCodes.INVALID_POSTAL_CODE)
	private String postalCode;

	@DataValidationPattern(code=ErrorCodes.INVALID_CITY)
	private String city;

	@ApiModelProperty(example="101", value="Valid values can be found in the reference service")
	private String province;

	@ApiModelProperty(example="100000", value="Valid values can be found in the reference service")
	@DataValidationPattern(code=ErrorCodes.INVALID_COUNTRY)
	private String country;
	
	private Boolean livedInLessThanTwoYears;

	public String getUnitNumber() {
		return unitNumber;
	}
	public void setUnitNumber(String unitNumber) {
		this.unitNumber = unitNumber;
	}
	public String getStreetAddress() {
		return streetAddress;
	}
	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	public Boolean getLivedInLessThanTwoYears() {
		return livedInLessThanTwoYears;
	}
	public void setLivedInLessThanTwoYears(Boolean livedInLessThanTwoYears) {
		this.livedInLessThanTwoYears = livedInLessThanTwoYears;
	}
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);	
	}
}
