package com.bmo.channel.pwob.validation.verification;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.Properties;

import javax.annotation.Resource;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.enums.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.onboarding.AppStatus;
import com.bmo.channel.pwob.model.onboarding.ApplicationLob;
import com.bmo.channel.pwob.model.onboarding.Verification;
import com.bmo.channel.pwob.model.reference.CountryReference;
import com.bmo.channel.pwob.model.reference.Reference;
import com.bmo.channel.pwob.model.reference.StatProvReference;
import com.bmo.channel.pwob.service.reference.ReferenceType;
import com.bmo.channel.pwob.service.reference.ReferencesService;
import com.bmo.channel.pwob.service.user.UsersService;
import com.bmo.channel.pwob.util.DateUtils;
import com.bmo.channel.pwob.validation.AbstractBaseValidator;
import com.bmo.channel.pwob.validation.AddressValidator;
import com.bmo.channel.pwob.validation.ErrorCodes;
import com.bmo.channel.pwob.validation.RefDataValues;
import com.bmo.channel.pwob.validation.ValidationManager;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder;
import com.bmo.channel.pwob.validation.holder.ValidationContextHolder.Action;
import com.bmo.channel.pwob.validation.request.ValidationRequest;
import com.bmo.channel.pwob.validation.request.ValidationRequestFactory;

/**
 * Validate Client Verification details on submit
 * @author Sasi Nagamony (snagamo)
 */
public class VerificationValidator extends AbstractBaseValidator implements ConstraintValidator<ValidVerification, Verification> {		
	
	private static Logger logger = LoggerFactory.getLogger(VerificationValidator.class);

	@Resource(name = "validationRules")
	private Properties validationRules;
	
	@Autowired UsersService userService;
	@Autowired ValidationRequestFactory requestFactory;
	@Autowired private AddressValidator addressValidator;
	@Autowired protected ReferencesService referencesService;

	@Override
	public void initialize(ValidVerification constraintAnnotation) {	}

	@Override
	public boolean isValid(Verification verification, ConstraintValidatorContext context) {
		
		ValidationContextHolder validationContext = ValidationManager.validationContext.get();
		
		if(validationContext.getAction() == Action.SAVE) {
			// only validate if submitting
			return true;
		}
		
		ApplicationLob lob = this.userService.currentUser().getLob();
		
		ValidationRequest request = requestFactory.createBuilder(context, lob).build();
		
		boolean valid = true;
		
		if(verification != null && request.getLob() == ApplicationLob.nb) { 			
			if (StringUtils.isNoneBlank(verification.getIdVerificationMethod())
					&& (AppStatus.DATA_COLLECTION.toString()
							.equalsIgnoreCase(validationContext.getApplication().getStatus())
							&& RefDataValues.ID_VERIFICATION_METHDOD_EMPLOYEE_CODE
									.equals(verification.getIdVerificationMethod()))
					|| (AppStatus.ACCOUNT_SETUP.toString()
									.equalsIgnoreCase(validationContext.getApplication().getStatus())
							&& RefDataValues.ID_VERIFICATION_METHOD_AFFILIATE
									.equals(verification.getIdVerificationMethod()))) {
				//validate Document type
				request.setFieldValue(verification.getDocumentType());
				valid = this.validateDocumentType(request) && valid;
				
				if(StringUtils.isNoneBlank(verification.getDocumentType())) {
					
					//validate Provided id Match with Applicant Information 
					valid = this.isProvidedIdMatchApplicantInformation(verification,request) && valid;
					
					//validate ID Number
					request.setFieldValue(verification.getIdNumber());
					valid = this.validateIdNumber(request) && valid;
					
					//validate Expiry Date
					if (!(this.isDocumentTypeCanadianCitizenshipCard(verification.getDocumentType())
							|| (this.isDocumentTypeProvincialHealthInsurance(verification.getDocumentType())
									&& this.isProvinceAlberta(verification.getProvince())))) {
						request.setFieldValue(verification.getExpiryDate());
						valid = this.validateExpiryDate(request) && valid;
					}
					
			
					//validate Country - required for PP & Nexus
					if(this.isDocumentTypePassport(verification.getDocumentType()) || this.isDocumentTypeNexus(verification.getDocumentType())) {									
						request.setFieldValue(verification.getCountry());						
						valid = this.addressValidator.validateCountry(request) && valid;	
					}				
					//Validate Province for Driver's licence
					if(this.isDocumentTypeDL(verification.getDocumentType())) {									
						request.setFieldValue(verification.getProvince());						
						valid = this.validateProvince(request) && valid;					
					}
					
					//validate Province - required for Health card with excluding ON
					if(this.isDocumentTypeProvincialHealthInsurance(verification.getDocumentType())) {							
						request.setFieldValue(verification.getProvince());				
						valid = this.validateHealthCardProvince(request) && valid;
					}
					
					//Country of birth & Is Place of birth: US flag are required when Passport is document type					
					if(this.isDocumentTypePassport(verification.getDocumentType())) {							
						if(!Optional.ofNullable(verification.getIsPlaceOfBirthUS()).isPresent()) {									
							request.setFieldName(IS_PLACE_OF_BIRTH_US);
							request.setErrorCode(ErrorCodes.INVALID_IS_PLACE_OF_BIRTH_US);	
							request.addConstraintViolation();
							valid = false;
						}
						else if (verification.getIsPlaceOfBirthUS() != null && verification.getCountryOfBirth() == null){
							request.setFieldName(COUNTRY_OF_BIRTH_FIELD_NAME);
							request.setErrorCode(ErrorCodes.INVALID_COUNTRY_OF_BIRTH);	
							request.addConstraintViolation();
							valid = false;
						}
						else if (verification.getIsPlaceOfBirthUS() && !RefDataValues.USA_COUNTRY_CODE.equals(verification.getCountryOfBirth())) {
							request.setFieldName(COUNTRY_OF_BIRTH_FIELD_NAME);
							request.setErrorCode(ErrorCodes.INVALID_COUNTRY_OF_BIRTH);	
							request.addConstraintViolation();
							valid = false;
						} 
						else if (!verification.getIsPlaceOfBirthUS() && !RefDataValues.CANADA_COUNTRY_CODE.equals(verification.getCountryOfBirth())) {
							request.setFieldName(COUNTRY_OF_BIRTH_FIELD_NAME);
							request.setErrorCode(ErrorCodes.INVALID_COUNTRY_OF_BIRTH);	
							request.addConstraintViolation();
							valid = false;
						}
					}				
				}
				request.setFieldValue(verification.getEmployeeFirstName());
				valid = this.validateEmployeeFirstName(request) && valid;
				
				request.setFieldValue(verification.getEmployeeLastName());
				valid = this.validateEmployeeLastName(request) && valid;
				
				request.setFieldValue(verification.getClientIdCaptureTime());
				valid = this.validateClientIdCaptureTime(request) && valid;
			}			
		}
		return valid;
	}

	@Override
	protected boolean validateAndAddConstraintViolation(ValidationRequest request) {		
		boolean valid = StringUtils.isNotBlank(request.getFieldValue()) && validateField(request);				
		if(!valid) {
			request.addConstraintViolation();
		}
		return valid;
	}
	
	@Override
	protected boolean validateField(ValidationRequest request) {		
		String fullFieldPath = request.calculateFullFieldPath().replaceAll("\\d+", "");
		String regex = this.retrievePatternForFieldAndLob(request.getLob(), fullFieldPath);
		if(StringUtils.isBlank(request.getFieldValue()) || (StringUtils.isNoneBlank(regex) && !request.getFieldValue().matches(regex))) {	
			return false;
		}
		return true;
	}
	
	private boolean validateIdVerificationMethod(ValidationRequest request) {
		request.setFieldName(ID_VERIFICATION_METHOD_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_ID_VERIFICATION_METHOD);
		return this.validateAndAddConstraintViolation(request);
	}
	
	private boolean validateDocumentType(ValidationRequest request) {
		request.setFieldName(DOCUMENT_TYPE_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_DOCUMENT_TYPE);		
		return this.validateAndAddConstraintViolation(request);
	}
	
	private boolean validateIdNumber(ValidationRequest request) {
		request.setFieldName(ID_NUMBER_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_ID_NUMBER);		
		return this.validateAndAddConstraintViolation(request);
	}
	
	private boolean validateExpiryDate(ValidationRequest request) {
		request.setFieldName(EXPIRY_DATE_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_EXPIRY_DATE);
		boolean valid = true;
		try 
		{	
			valid = StringUtils.isNoneBlank(request.getFieldValue()) && 
					!DateUtils.isBefore(new SimpleDateFormat(AbstractBaseValidator.DEFAULT_DATE_PATTERN).format(new Date()), request.getFieldValue(),AbstractBaseValidator.DEFAULT_DATE_PATTERN);
			if(!valid)
				request.addConstraintViolation(); 
		} catch (DateTimeParseException |ParseException ex) {
			logger.warn("Failed to validate expiry date : " ,request.getFieldValue(), ex);
			request.addConstraintViolation();
		}
		return valid;
	}
	
	private boolean isDocumentTypePassport(String docType) {		
		return StringUtils.isNoneBlank(docType) && docType.equalsIgnoreCase(RefDataValues.DOCUMENT_TYPE_PASSPORT_CARD);
	}
	private boolean isDocumentTypeNexus(String docType) {		
		return StringUtils.isNoneBlank(docType) && docType.equalsIgnoreCase(RefDataValues.DOCUMENT_TYPE_NEXUS_CARD);
	}
	private boolean isDocumentTypeDL(String docType) {		
		return StringUtils.isNoneBlank(docType) && docType.equalsIgnoreCase(RefDataValues.DOCUMENT_TYPE_DRIVERS_LICENSE);
	}
	private boolean isDocumentTypeProvincialHealthInsurance(String docType) {		
		return StringUtils.isNoneBlank(docType) && docType.equalsIgnoreCase(RefDataValues.DOCUMENT_TYPE_PROVINCIAL_HEALTH_INSURANCE_CARD);
	}
	
	private boolean isDocumentTypeCanadianCitizenshipCard(String docType) {		
		return StringUtils.isNoneBlank(docType) && docType.equalsIgnoreCase(RefDataValues.DOCUMENT_TYPE_CANADIAN_CITIZENSHIP_CARD);
	}	
	
	private boolean isProvinceAlberta(String province) {		
		return StringUtils.isNoneBlank(province) && province.equalsIgnoreCase(RefDataValues.PROVINCE_AB);
	}
		
	private boolean validateProvince(ValidationRequest request) {
		request.setFieldName(PROVINCE_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_PROVINCE);		
		boolean valid = StringUtils.isNoneBlank(request.getFieldValue()) && this.isValidProvince(request.getFieldValue(), request.getLocale());		
		if(!valid) {
			request.addConstraintViolation();
		}
		return valid;		
	}
	
	//Validate excluding ON	
	public boolean validateHealthCardProvince(ValidationRequest request) {
		request.setFieldName(PROVINCE_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_PROVINCE);		
		return this.addConstraintViolation(request) && this.validateAndAddConstraintViolation(request);
	}
		
	protected boolean addConstraintViolation(ValidationRequest request) {	
				
		boolean valid = this.isValidEntry(request.getFieldValue(), this.excludeProvinceOntario(RefDataValues.CANADA_COUNTRY_CODE, request.getLocale()));		
		if(!valid) {
			request.addConstraintViolation();
		}
		return valid;
	}	
	
	private boolean isValidEntry(String value, List<StatProvReference> referenceTypeList) {
		if(CollectionUtils.isNotEmpty(referenceTypeList) && StringUtils.isNoneBlank(value))
			 return referenceTypeList.stream().anyMatch(r -> value.equals(r.getCode()));
		else return false;
	}
	
	private List<StatProvReference> excludeProvinceOntario(String value, String locale) {
		List<StatProvReference> provinces = null;	
		Optional<Reference> countryReferenceOption = this.getCountryReference(value, locale);
		if(countryReferenceOption.isPresent()) {
			CountryReference countryReference = (CountryReference)countryReferenceOption.get();			
			if(!countryReference.getStateProvinces().isEmpty()) {				
				provinces  = new ArrayList<>(countryReference.getStateProvinces());				
				provinces.removeIf(c -> c.getCode().equals(RefDataValues.PROVINCE_ONT));				
			} 
		}							
		return provinces;
	}
	
	private Optional<Reference> getCountryReference(String value, String locale) {
		Optional<Reference> countryReferenceOption = referencesService.ofType(ReferenceType.COUNTRIES, UILocale.parse(locale))
				   .stream()
				   .filter(c -> c.getCode().equalsIgnoreCase(value))
				   .findFirst();			
		return countryReferenceOption;
	}
	
	private boolean isValidProvince(String value, String locale) {		
		Optional<Reference> countryReferenceOption = this.getCountryReference(RefDataValues.CANADA_COUNTRY_CODE, locale);		
		if(countryReferenceOption.isPresent()) {
			CountryReference countryReference = (CountryReference)countryReferenceOption.get();
			if(!countryReference.getStateProvinces().isEmpty()) {
				List<StatProvReference> provinces =  countryReference.getStateProvinces();					
				return provinces.stream().anyMatch(c -> c.getCode().equals(value));
			}
		}
		
		return false;
	}
	
	private boolean isProvidedIdMatchApplicantInformation(Verification value, ValidationRequest request) {		
		boolean valid= true;		
		if(value.getIdProvidedMatchApplicantInformation()== null) {
			request.setFieldName(ID_PROVIDED_MATCH_APPLICANT_INFO_FIELD_NAME);
			request.setErrorCode(ErrorCodes.INVALID_ID_PROVIDED_MATCH_APPLICANT_INFORMATION);
			request.addConstraintViolation();
			valid = false;
		}
		else {			
			if(!value.getIdProvidedMatchApplicantInformation() && 
					(value.getReasonForDiscrepancy()== null || (value.getReasonForDiscrepancy()!=null && !checkDiscrepancy(value.getReasonForDiscrepancy(), request)))){
				request.setFieldName(REASON_FOR_DISCREPANCY_FIELD_NAME);
				request.setErrorCode(ErrorCodes.INVALID_REASON_FOR_DISCREPANCY);
				request.addConstraintViolation();
				valid = false;
			}
		}
		
		return valid;
	}
	private boolean checkDiscrepancy(String value, ValidationRequest request){				
		request.setFieldName(REASON_FOR_DISCREPANCY_FIELD_NAME);		
		String fullFieldPath = request.calculateFullFieldPath().replaceAll("\\d+", "");
		String regex = this.retrievePatternForFieldAndLob(request.getLob(), fullFieldPath);
		return (StringUtils.isNoneBlank(regex) && value.matches(regex));
	}
	
	private boolean validateEmployeeFirstName(ValidationRequest request) {
		request.setFieldName(EMP_FIRST_NAME_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_VERIFIED_EMPLOYEE_FIRST_NAME);		
		return this.validateAndAddConstraintViolation(request);
	}
	
	private boolean validateEmployeeLastName(ValidationRequest request) {
		request.setFieldName(EMP_LAST_NAME_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_VERIFIED_EMPLOYEE_LAST_NAME);		
		return this.validateAndAddConstraintViolation(request);
	}
	
	private boolean validateClientIdCaptureTime(ValidationRequest request) {
		request.setFieldName(CLIENT_ID_CAPTURE_TIME_FIELD_NAME);
		request.setErrorCode(ErrorCodes.INVALID_VERIFIED_DATE);		
		return this.validateAndAddConstraintViolation(request);
	}
	
}