/**
 * @author akhales
 */
package com.bmo.channel.pwob.convert;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.bmo.channel.pwob.util.DateUtils;

import net.bmogc.xmlns.bmo._2002.header.BMOHdrRq;
import net.bmogc.xmlns.bmo._2002.header.ServiceInfo;
import net.bmogc.xmlns.bmo._2002.header.SrcInfo;

public class WSBuilder {
	private static Logger logger = LoggerFactory.getLogger(WSBuilder.class);

	/**
	 * Create old-style request header
	 * @param serviceName 
	 * @param serviceFunction 
	 * @return
	 */
	public static BMOHdrRq build(String serviceName, String serviceFunction) {
		BMOHdrRq request = new BMOHdrRq();

		request.setVersion("1");
		request.setRqUID(UUID.randomUUID().toString());

		SrcInfo src = new SrcInfo();
		src.setChType("BRN");
		src.setChInst("0124");
		src.setAppName("PWOB");
		src.setHostName(getHostName());
		request.setSrcInfo(src);

		request.setClientDt(DateUtils.getTimestamp());

		ServiceInfo svcInfo = new ServiceInfo();
		svcInfo.setServiceName(serviceName);
		svcInfo.setServiceFunc(serviceFunction);

		request.setServiceInfo(svcInfo);

		return request;
	}

	private static String getHostName() {
		String hostName = null;
		try{
			hostName= InetAddress.getLocalHost().getHostName();
			if(hostName != null && hostName.length()>16){
				hostName = hostName.substring(0,16);
			}else if(hostName == null){
				hostName="host_name";
			}
		} catch (UnknownHostException ex) {
			logger.warn("System is configured with bad host name", ex);
			hostName="host_name";
		}

		return hostName;
	}
}
