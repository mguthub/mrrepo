package com.bmo.channel.pwob.service.fis;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.ws.rs.BadRequestException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmo.channel.common.ehcache.CacheService;
import com.bmo.channel.core.exception.NotFoundException;
import com.bmo.channel.core.exception.WebServiceException;
import com.bmo.channel.pwob.model.UILocale;
import com.bmo.channel.pwob.model.onboarding.Branch;
import com.bmo.channel.pwob.model.onboarding.FinancialInstitution;
import com.bmo.channel.pwob.util.ChannelObjectMapper;
import com.bmo.channel.pwob.util.HubRequestComponent;
import com.bmo.channel.pwob.util.HubRequestHeaderBuilder.HeaderBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;

import net.bmogc.xmlns.hub.header.v1.HUBHeaderRequest;

@Service
public class FinancialInstitutionsServiceImpl implements FinancialInstitutionsService {
	private static Logger logger = LoggerFactory.getLogger(FinancialInstitutionsServiceImpl.class);
	
	private static final String FI_PATH = "FIBranch";
	private static final String FI_FUNCTION = "GetFIList";
	private static final String TRANSIT_DETAIL_FUNCTION = "GetFITransitDetail";
	private static final String FI_CACHE_NAME = "financialInstitutionsCache";

	@SuppressWarnings("unused")
	private static final String BRANCH_FUNCTION = "GetFIBranch";
	
	@Resource
	private FinancialInstitutionsEndpointInterface financialInstitutionsEndpointInterface;
	
	@Autowired
	private HubRequestComponent hubRequestComponent;
	
	@Autowired
	private CacheService cacheService;
	
	@Override
	public List<FinancialInstitution> retrieveFinancialInstitutionsByPartialId(final String partialId, final String lang) {
		UILocale locale = validateLang(lang);
		
		if (!Optional.ofNullable(partialId).isPresent()){
			logger.error("Query parameter 'partialId' not present:",partialId);
			throw new BadRequestException("Query parameter 'partialId' not present");
		}
		final List<FinancialInstitution> fiList = retrieveFinancialInstitutions(locale).stream().filter(fi -> fi.getFiId().contains(partialId)).collect(Collectors.toList());
		
		return fiList;
	}

    private List<FinancialInstitution> retrieveFinancialInstitutions(UILocale locale) {
    	final HUBHeaderRequest requestHeader = createRequestHeader(FI_PATH, FI_FUNCTION);
    	try {
    		FinancialInstitutionsHubResponse financialInstitutions = (FinancialInstitutionsHubResponse) cacheService.get(FI_CACHE_NAME, FI_CACHE_NAME, FI_CACHE_NAME);

    		logger.debug("Financial institutions cache found/ name: " + FI_CACHE_NAME);
    		
    		if(financialInstitutions == null) {
    			financialInstitutions = financialInstitutionsEndpointInterface.getFIList(generateHeaderString(requestHeader));
    			cacheService.add(financialInstitutions, FI_CACHE_NAME, FI_CACHE_NAME, FI_CACHE_NAME);
    			logger.debug("Financial institutions cache added/ name: " + FI_CACHE_NAME);
    		}
        	
        	return financialInstitutions.toFIList(locale);
    	} catch (Exception ex) {
    		logger.error("Failed to retrieve financial institutions with locale: ",locale, ex);
			throw new WebServiceException(ex);
    	}
	}
	
	@Override
	public Branch retrieveBankBranchInformationByFiIdAndTransitId(final String fiId, final String transitId, String lang) {
		UILocale locale = validateLang(lang);
		
		// Remove leading zeros
		String mFiId = removeLeadingZeros(fiId);
		
		List<Branch> branches = retrieveBankBranchInformation(mFiId, transitId, locale).stream()
									.filter(b -> mFiId.equals(removeLeadingZeros(b.getFiId())))
									.collect(Collectors.toList());
		
		if (branches.isEmpty()) {
			logger.error("Failed to found bank branch information with fiID: "+fiId,"and transitID :"+transitId);
			throw new NotFoundException("No branch found with fiID '" + fiId +
										"' and transit number '" + transitId + "'");
		}
		
		return branches.get(0);
	}
	
	@Override
	public List<Branch> retrieveBankBranchesInformationByFiIdAndPartialTransitId(final String fiId, final String partialId, String lang) {
		UILocale locale = validateLang(lang);
		
		if (!Optional.ofNullable(partialId).isPresent()){
			logger.error("Failed to retrieve bank branch information with partialID: ",partialId);
			throw new BadRequestException("Query parameter 'partialId' not present");
		}		
		return retrieveBankBranchInformation(removeLeadingZeros(fiId), partialId, locale);
	}

	private List<Branch> retrieveBankBranchInformation(String fiId, String transitId, UILocale locale) {
		TransitDetailsHubRequest request = new TransitDetailsHubRequest(fiId, transitId);

		HUBHeaderRequest requestHeader = createRequestHeader(FI_PATH, TRANSIT_DETAIL_FUNCTION);

		try {
			TransitDetailsHubResponse fiTransitDetailResponse = financialInstitutionsEndpointInterface.getFITransitDetail(createRequestJson(request), generateHeaderString(requestHeader));
			return fiTransitDetailResponse.toBranchList(locale);
		} catch (Exception ex) {
			logger.error("Failed to retrieve bank branch information with financial institution id: ",fiId, ex);
			throw new WebServiceException(ex);
		}
	}

	/**
	 * TODO use @JsonPropertyOrder annotation instead of string request body
	 * hub service will fail (!?) if the order of parameters in the request are not as follows
	 * @param request
	 * @return
	 */
	private String createRequestJson(TransitDetailsHubRequest request) {
		return String.format("{\"InstitutionNumber\": \"%s\", \"transitnumber\": \"%s\"}", request.getInstitutionNumber(), request.getTransitNumber());
	}

	private String removeLeadingZeros(String s) {
		s = StringUtils.stripStart(s, "0");
		return s.isEmpty() ? "0" : s;
	}

	private UILocale validateLang(String lang) {
		if (!Optional.ofNullable(lang).isPresent()) {
			logger.error("Query parameter language not present"+lang);
			throw new BadRequestException("'lang' query parameter not present");
		}
		
		if (lang.equals(UILocale.EN_CA.getLang())) {
			return UILocale.EN_CA;
		} else if (lang.equals(UILocale.FR_CA.getLang())) {
			return UILocale.FR_CA;
		} else {
			logger.error("Query parameter language is not valid.");
			throw new WebServiceException("Invalid 'lang' parameter: " + lang);
		}
	}
	
	private HUBHeaderRequest createRequestHeader(final String service, final String resourceFunction) {
		HeaderBuilder headerBuilder = hubRequestComponent.getHubBuilder()
			.originatorResource(service)
			.originatorResourceFunction(resourceFunction);
		
		return headerBuilder.build();
	}
	
	String generateHeaderString(final HUBHeaderRequest requestHeader) throws JsonProcessingException {
		return ChannelObjectMapper.INSTANCE.getObjectMapper().writeValueAsString(requestHeader);
	}
}
