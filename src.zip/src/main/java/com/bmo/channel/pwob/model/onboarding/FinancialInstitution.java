package com.bmo.channel.pwob.model.onboarding;

import org.apache.commons.lang3.builder.ToStringBuilder;
import io.swagger.annotations.ApiModelProperty;

public class FinancialInstitution {
	@ApiModelProperty(example="0001", value="Financial institution ID")
	private String fiId;
	
	@ApiModelProperty(example="BANK OF MONTREAL", value="Financial institution name")
	private String name;
	
	public String getFiId() {
		return fiId;
	}

	public void setFiId(String fiId) {
		this.fiId = fiId;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}
