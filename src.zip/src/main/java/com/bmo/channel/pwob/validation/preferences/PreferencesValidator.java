package com.bmo.channel.pwob.validation.preferences;

import com.bmo.channel.pwob.model.onboarding.Preferences;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface PreferencesValidator {
	boolean arePreferencesValid(Preferences preferences, ValidationRequest request);
	
	boolean arePreferencesValidForJointAccount(Preferences preferences, ValidationRequest request);
}
