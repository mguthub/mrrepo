package com.bmo.channel.pwob.convert.features;

import com.bmo.channel.pwob.model.ia.RelationshipSummary;
import com.bmo.channel.pwob.model.onboarding.Application;

/**
 * Executes all data migrations specified for the application.
 * @author Ryan Chambers (rcham02)
 */
public interface DataMigrator {
	void migrateApplication(Application application);

	void migrationRelationshipSummary(RelationshipSummary relationshipSummary, Application application);
}
