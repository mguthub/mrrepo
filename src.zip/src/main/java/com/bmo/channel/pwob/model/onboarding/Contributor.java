/**
 * 
 */
package com.bmo.channel.pwob.model.onboarding;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author vvallia
 *
 */
public class Contributor {
	
	
	private Name name =  new Name();
	
	@ApiModelProperty(example="046454286", value="Must pass a LuhnCheck")
	private String socialInsuranceNumber;
	
	@ApiModelProperty(example="1955-12-25", value="Format: YYYY-MM-DD")
	private String dateOfBirth;
	

	public Name getName() {
		return name;
	}
	public void setName(Name name) {
		this.name = name;
	}
	public String getSocialInsuranceNumber() {
		return socialInsuranceNumber;
	}
	public void setSocialInsuranceNumber(String socialInsuranceNumber) {
		this.socialInsuranceNumber = socialInsuranceNumber;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	
}
