package com.bmo.channel.pwob.service.risprefill;

import java.util.List;

import com.bmo.channel.pwob.model.NewWorkflowRequest;
import com.bmo.channel.pwob.model.onboarding.Party;

public interface RisPrefillService {
	public List<Party> getParties(String token, NewWorkflowRequest request);
	public NewWorkflowRequest searchForParty(String accountNumber);
}
