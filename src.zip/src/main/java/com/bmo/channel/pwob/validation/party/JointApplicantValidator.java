package com.bmo.channel.pwob.validation.party;

import com.bmo.channel.pwob.model.onboarding.Party;
import com.bmo.channel.pwob.validation.request.ValidationRequest;

public interface JointApplicantValidator {
	boolean validateJointProductEligibility(String applicationId, Party party, ValidationRequest partyValidationRequest);
}
