/**
 * 
 */
package com.bmo.channel.pwob.service.digitaltoken;

/**
 * @author vvallia
 *
 */
public class ValidateTokenRequest {

	private String cachedToken;

	/**
	 * @return the cachedToken
	 */
	public String getCachedToken() {
		return cachedToken;
	}

	/**
	 * @param cachedToken the cachedToken to set
	 */
	public void setCachedToken(String cachedToken) {
		this.cachedToken = cachedToken;
	}
	
	
}
